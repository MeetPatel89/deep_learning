"""Branch execution tools and restart-safe monitoring of recorded runs only."""

import asyncio
import copy
import time
import uuid
from typing import Any

from data_mcp_core.guards import require
from data_mcp_core.results import bounded_result, paginate, redact
from mcp.server.fastmcp import Context

from synapse_mcp_server.base import field
from synapse_mcp_server.branch_package import TERMINAL, build_package, digest
from synapse_mcp_server.config import RepositoryBackend
from synapse_mcp_server.debugging import classify_failure
from synapse_mcp_server.execution_store import now
from synapse_mcp_server.sdk_staging import SDKStagingAdapter
from synapse_mcp_server.studio_http import StudioHTTPAdapter


def repository_identity(settings):
    repository = settings.repository
    if repository is None:
        return None
    return digest(
        {
            "local_path": repository.local_path,
            "github_repository": repository.github_repository,
            "artifact_root": repository.artifact_root,
        }
    )


def public_record(record):
    result = {
        key: copy.deepcopy(value)
        for key, value in record.items()
        if key not in {"staged", "names", "owner", "runs"}
    } | {
        "staged_artifacts": [
            {"type": v["kind"], "name": v["name"], "state": v["state"]}
            for v in record.get("staged", [])
        ]
    }
    for name in result["provenance"].get("secure_parameters", []):
        result["provenance"]["parameters"][name] = "[REDACTED]"
    return result


class BranchExecutionTools:
    def _branch_guard(self, workspace, backend):
        settings = self.workspace(workspace, "execution")
        require(settings, "allow_run")
        if backend == "sdk_staging":
            require(settings, "allow_live_env")
            require(settings, "allow_manage")
        elif backend != "studio_http":
            raise ValueError("Unsupported branch execution backend")
        return settings

    def _branch_adapter(self, workspace, backend):
        self._branch_guard(workspace, backend)
        if backend == "studio_http":
            return StudioHTTPAdapter(self.config, workspace)
        return SDKStagingAdapter(self, workspace)

    def _branch_record(self, workspace, execution_id):
        self.workspace(workspace, "execution")
        record = self.execution_store.get(workspace, execution_id)
        settings = self._branch_guard(workspace, record["backend"])
        if record["endpoint"] != settings.endpoint:
            raise PermissionError(
                "Workspace endpoint changed; recorded execution cannot be redirected"
            )
        return record

    def run_branch_pipeline(
        self,
        workspace: str,
        pipeline: str,
        branch: str,
        repository_backend: RepositoryBackend | None = None,
        parameters: dict[str, Any] | None = None,
        test_profile: str | None = None,
        dry_run: bool = True,
    ) -> dict[str, Any]:
        """Test an exact Git snapshot in the configured dev workspace. A named test profile and
        allow_run are required. SDK staging also requires allow_live_env and allow_manage.
        Defaults to validation only. No publish, live-definition fallback or backend fallback.
        """
        settings = self.workspace(workspace, "execution")
        backend = settings.branch_execution_backend
        self._branch_guard(workspace, backend)
        profile_name = test_profile or settings.default_test_profile
        if not profile_name or profile_name not in settings.test_profiles:
            raise ValueError("Execution requires a configured named test_profile")
        repository = self.repository(workspace, repository_backend)
        snapshot = repository.snapshot(branch)
        package = build_package(
            snapshot, pipeline, profile_name, settings.test_profiles[profile_name], parameters
        )
        execution_id = uuid.uuid4().hex
        adapter = self._branch_adapter(workspace, backend)
        record = {
            "execution_id": execution_id,
            "workspace": workspace,
            "endpoint": settings.endpoint,
            "repository_identity": repository_identity(settings),
            "backend": backend,
            "created_at": now(),
            "state": "preparing",
            "status": "NotStarted",
            "native_run_id": None,
            "provenance": package.provenance(),
            "cleanup": "not_needed" if backend == "studio_http" else "pending",
            "staged": [],
            "runs": {},
            "tree_complete": False,
        }
        try:
            if backend == "studio_http":
                record["contract_digest"] = adapter.validate(package)
            else:
                record["staged"], record["names"], record["owner"] = adapter.plan(
                    package, execution_id
                )
            if dry_run:
                return bounded_result({"dry_run": True, **public_record(record)})
            with self.execution_store.lock(execution_id):
                self.execution_store.create(record)
                try:
                    if backend == "sdk_staging":
                        record["state"] = "deploying"
                        self.execution_store.save(record)
                        adapter.deploy(record)
                    record["state"] = "submitting"
                    self.execution_store.save(record)
                    record["native_run_id"] = (
                        adapter.submit(package, record["contract_digest"])
                        if backend == "studio_http"
                        else adapter.submit(record)
                    )
                    record["state"], record["status"] = "running", "Queued"
                    self.execution_store.save(record)
                except Exception as error:
                    record["error"] = redact(str(error))
                    # A submission may have succeeded despite a timeout or contract error.
                    # Do not replay it or delete artifacts while an unknown run may be active.
                    if record["state"] == "submitting":
                        record["state"] = "submission_unknown"
                    else:
                        record["state"] = "deployment_failed"
                    self.execution_store.save(record)
                    if record["state"] == "deployment_failed":
                        adapter.cleanup(record)
            return bounded_result(public_record(record))
        finally:
            adapter.close()

    def _branch_tree(self, record, adapter):
        pending = [record["native_run_id"]]
        runs = {}
        complete = True
        while pending:
            run_id = pending.pop()
            if run_id in runs:
                continue
            if len(runs) >= 500:
                raise ValueError("Branch run tree exceeds 500 runs; cleanup is blocked")
            run = adapter.status(record, run_id)
            status = field(run, "status")
            if status not in TERMINAL | {"Queued", "InProgress", "Canceling", "Cancelling"}:
                raise ValueError("Unknown branch run status; cleanup is blocked")
            activities = adapter.activities(record, run_id)
            runs[run_id] = {"run": run, "activities": activities}
            for activity in activities:
                if field(activity, "activityType") == "ExecutePipeline":
                    child_id = field(field(activity, "output", {}) or {}, "pipelineRunId")
                    if child_id:
                        if not isinstance(child_id, str):
                            raise ValueError("Invalid child pipeline run identifier")
                        pending.append(child_id)
                    elif field(activity, "status") not in {"Skipped", "Inactive"}:
                        # A failed launch may still have created a child. Do not assume quiescence.
                        complete = False
        record["runs"] = runs
        record["tree_complete"] = complete
        states = [field(v["run"], "status") for v in runs.values()]
        finished = complete and all(s in TERMINAL for s in states)
        record["status"] = (
            (
                "Failed"
                if "Failed" in states
                else "Cancelled"
                if any(s in {"Cancelled", "Canceled"} for s in states)
                else "Succeeded"
            )
            if finished
            else field(runs[record["native_run_id"]]["run"], "status")
        )
        record["state"] = "finished" if finished else "running"
        record["child_run_ids"] = [
            identifier for identifier in runs if identifier != record["native_run_id"]
        ]
        self.execution_store.save(record)

    def _refresh_branch(self, workspace, execution_id, cleanup=True):
        with self.execution_store.lock(execution_id):
            record = self._branch_record(workspace, execution_id)
            if record["state"] == "submitting" and not record["native_run_id"]:
                record["state"] = "submission_unknown"
                record["error"] = "Restart interrupted submission; no native run ID was journaled"
                self.execution_store.save(record)
            elif record["state"] in {"preparing", "deploying"} and not record["native_run_id"]:
                record["state"] = "deployment_failed"
                record["error"] = "Restart interrupted deployment before pipeline submission"
                self.execution_store.save(record)
            adapter = self._branch_adapter(workspace, record["backend"])
            try:
                if record["native_run_id"] and record["state"] != "finished":
                    self._branch_tree(record, adapter)
                if (
                    cleanup
                    and record["backend"] == "sdk_staging"
                    and record["cleanup"] != "complete"
                ):
                    if record["state"] in {
                        "finished",
                        "deployment_failed",
                        "preparing",
                        "deploying",
                    }:
                        adapter.cleanup(record)
                return record
            finally:
                adapter.close()

    def get_branch_pipeline_run(self, workspace: str, execution_id: str) -> dict[str, Any]:
        """Refresh a recorded branch test and its child runs using its original backend.
        Finished SDK tests automatically clean up owned artifacts when permissions allow it.
        """
        return bounded_result(public_record(self._refresh_branch(workspace, execution_id)))

    def list_branch_pipeline_runs(
        self,
        workspace: str,
        limit: int = 100,
        continuation: str | None = None,
    ) -> dict[str, Any]:
        """Read locally recorded execution provenance without Azure requests."""
        self.workspace(workspace, "execution")
        records = sorted(
            self.execution_store.list(workspace), key=lambda v: v["created_at"], reverse=True
        )
        return paginate(
            [public_record(v) for v in records],
            limit,
            continuation,
            "branch-executions:" + workspace,
        )

    def get_branch_activity_results(
        self,
        workspace: str,
        execution_id: str,
        run_id: str | None = None,
        limit: int = 100,
        continuation: str | None = None,
    ) -> dict[str, Any]:
        """Inspect branch activity input/output/errors; child IDs must belong to this execution."""
        record = self._refresh_branch(workspace, execution_id)
        runs = record["runs"]
        if run_id and run_id not in runs:
            raise ValueError("Run ID does not belong to this recorded branch execution")
        items = [
            {"run_id": identifier, **activity}
            for identifier, details in runs.items()
            if run_id is None or identifier == run_id
            for activity in details["activities"]
        ]
        return paginate(items, limit, continuation, f"branch-activities:{execution_id}:{run_id}")

    def diagnose_branch_pipeline_run(self, workspace: str, execution_id: str) -> dict[str, Any]:
        """Diagnose branch activity and child failures using recorded execution results."""
        record = self._refresh_branch(workspace, execution_id)
        failures = []
        for run_id, details in record["runs"].items():
            for activity in details["activities"]:
                if field(activity, "status") != "Failed":
                    continue
                child = field(field(activity, "output", {}) or {}, "pipelineRunId")
                if (
                    child in record["runs"]
                    and field(record["runs"][child]["run"], "status") == "Failed"
                ):
                    continue
                failures.append(
                    {
                        "run_id": run_id,
                        "activity": activity,
                        "causes": classify_failure(field(activity, "error", {})),
                    }
                )
        return bounded_result(
            {
                "execution_id": execution_id,
                "status": record["status"],
                "failed_leaf_activities": failures,
                "error": record.get("error"),
                "tree_complete": record["tree_complete"],
                "cleanup_errors": record.get("cleanup_errors", []),
            }
        )

    async def wait_for_branch_pipeline_run(
        self,
        workspace: str,
        execution_id: str,
        timeout_seconds: int = 60,
        poll_seconds: float = 5,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Wait with MCP progress for a branch test and its children; preserve pending cleanup."""
        self._branch_record(workspace, execution_id)
        if not 1 <= timeout_seconds <= 3600 or not 0.1 <= poll_seconds <= 60:
            raise ValueError("timeout must be 1–3600 seconds; polling must be 0.1–60 seconds")
        started = time.monotonic()
        deadline = started + timeout_seconds
        while time.monotonic() < deadline:
            try:
                record = await asyncio.wait_for(
                    asyncio.to_thread(self._refresh_branch, workspace, execution_id),
                    max(0.001, deadline - time.monotonic()),
                )
            except TimeoutError:
                break
            if ctx:
                await ctx.report_progress(
                    min(time.monotonic() - started, timeout_seconds),
                    timeout_seconds,
                    "Branch pipeline " + record["status"],
                )
            if record["state"] in {"finished", "deployment_failed", "submission_unknown"}:
                result = {"execution": public_record(record), "timed_out": False}
                if record["status"] == "Failed":
                    result["diagnosis"] = self.diagnose_branch_pipeline_run(workspace, execution_id)
                return bounded_result(result)
            await asyncio.sleep(min(poll_seconds, max(0, deadline - time.monotonic())))
        return {"execution_id": execution_id, "timed_out": True}

    def cancel_branch_pipeline_run(
        self,
        workspace: str,
        execution_id: str,
        dry_run: bool = True,
    ) -> dict[str, Any]:
        """Cancel a recorded branch run and its children through the original execution backend."""
        with self.execution_store.lock(execution_id):
            record = self._branch_record(workspace, execution_id)
            if not record["native_run_id"]:
                raise ValueError("No known native run ID; submission outcomes are never guessed")
            if dry_run:
                return {"dry_run": True, "execution_id": execution_id, "backend": record["backend"]}
            adapter = self._branch_adapter(workspace, record["backend"])
            try:
                for run_id in [record["native_run_id"], *record.get("child_run_ids", [])]:
                    adapter.cancel(record, run_id)
                record["cancel_requested"] = True
                self.execution_store.save(record)
            finally:
                adapter.close()
        return {"execution_id": execution_id, "cancel_requested": True}

    def cleanup_branch_pipeline_run(
        self,
        workspace: str,
        execution_id: str,
        dry_run: bool = True,
    ) -> dict[str, Any]:
        """Clean up owned SDK artifacts after all known runs finish. No force deletion."""
        record = self._refresh_branch(workspace, execution_id, cleanup=False)
        if dry_run:
            return bounded_result({"dry_run": True, **public_record(record)})
        if record["state"] not in {"finished", "deployment_failed", "deploying", "preparing"}:
            raise ValueError("Cleanup blocked while runs may be active or submission is uncertain")
        return bounded_result(public_record(self._refresh_branch(workspace, execution_id)))

    async def _resume_branch_executions(self):
        """Lifespan recovery rechecks current permissions; it never resubmits a test."""
        while True:
            records = await asyncio.to_thread(self.execution_store.list)
            for record in records:
                if record["state"] in {"finished", "deployment_failed"} and record["cleanup"] in {
                    "complete",
                    "not_needed",
                }:
                    continue
                if record["state"] == "submission_unknown":
                    continue
                try:
                    task = asyncio.create_task(
                        asyncio.to_thread(
                            self._refresh_branch, record["workspace"], record["execution_id"]
                        )
                    )
                    try:
                        await asyncio.shield(task)
                    except asyncio.CancelledError:
                        # Finish the journal transition before lifespan closes SQLite/clients.
                        await task
                        raise
                except Exception:
                    # Preserve the journal for inspection/retry under current permissions.
                    continue
            await asyncio.sleep(15)
