"""Independent Synapse stdio MCP server with configurable tool groups."""

import asyncio
import inspect
from contextlib import asynccontextmanager, suppress
from functools import wraps

from data_mcp_core.results import bounded_result, redact
from data_mcp_core.sql import close_connections
from mcp.server.fastmcp import FastMCP

from synapse_mcp_server.artifacts import ArtifactTools
from synapse_mcp_server.base import SynapseBase
from synapse_mcp_server.branch_execution import BranchExecutionTools
from synapse_mcp_server.clients import ClientRegistry
from synapse_mcp_server.config import SynapseConfig, get_config
from synapse_mcp_server.debugging import DebugTools
from synapse_mcp_server.execution import ExecutionTools
from synapse_mcp_server.git_tools import GitTools
from synapse_mcp_server.monitoring import MonitoringTools
from synapse_mcp_server.sql_tools import SQLTools

TOOLSETS = {
    "workspace": [
        "list_workspaces",
        "get_workspace_info",
        "list_sql_pools",
        "list_spark_pools",
        "list_integration_runtimes",
        "list_role_assignments",
    ],
    "artifacts": [
        "list_artifacts",
        "get_artifact",
        "search_artifacts",
        "analyze_pipeline",
        "upsert_artifact",
        "delete_artifact",
    ],
    "monitoring": [
        "query_pipeline_runs",
        "get_pipeline_run",
        "query_activity_runs",
        "get_activity_run",
        "query_trigger_runs",
        "get_run_tree",
        "pipeline_run_stats",
        "compare_pipeline_runs",
    ],
    "debugging": [
        "diagnose_pipeline_run",
        "get_spark_application_logs",
        "list_spark_applications",
        "create_data_flow_debug_session",
        "add_data_flow_to_debug_session",
        "run_data_flow_debug_command",
        "delete_data_flow_debug_session",
    ],
    "execution": [
        "run_branch_pipeline",
        "get_branch_pipeline_run",
        "list_branch_pipeline_runs",
        "get_branch_activity_results",
        "wait_for_branch_pipeline_run",
        "cancel_branch_pipeline_run",
        "diagnose_branch_pipeline_run",
        "cleanup_branch_pipeline_run",
        "run_pipeline",
        "cancel_pipeline_run",
        "wait_for_pipeline_run",
        "start_trigger",
        "stop_trigger",
        "rerun_trigger_run",
        "create_spark_session",
        "run_spark_statement",
        "close_spark_session",
        "submit_spark_batch",
        "pause_sql_pool",
        "resume_sql_pool",
    ],
    "git": [
        "list_git_branches",
        "create_git_branch",
        "diff_git_branch",
        "commit_git_branch",
        "push_git_branch",
        "prepare_git_pr",
        "create_draft_pr",
    ],
    "sql": [
        "test_sql_connection",
        "run_sql_query",
        "list_sql_objects",
        "describe_table",
        "get_object_definition",
        "explain_query",
        "list_active_requests",
        "get_request_steps",
        "check_table_skew",
        "query_history",
    ],
}


class SynapseService(
    GitTools,
    BranchExecutionTools,
    SQLTools,
    ExecutionTools,
    DebugTools,
    MonitoringTools,
    ArtifactTools,
    SynapseBase,
):
    pass


def _safe_tool(method):
    if inspect.iscoroutinefunction(method):

        @wraps(method)
        async def call(*args, **kwargs):
            try:
                return bounded_result(await method(*args, **kwargs))
            except Exception as error:
                raise RuntimeError(redact(str(error))) from None
    else:

        @wraps(method)
        def call(*args, **kwargs):
            try:
                return bounded_result(method(*args, **kwargs))
            except Exception as error:
                raise RuntimeError(redact(str(error))) from None

    return call


def create_server(
    config: SynapseConfig | None = None, clients: ClientRegistry | None = None
) -> FastMCP:
    service = SynapseService(config or get_config(), clients)

    @asynccontextmanager
    async def lifespan(app):
        recovery = asyncio.create_task(service._resume_branch_executions())
        try:
            yield {}
        finally:
            recovery.cancel()
            with suppress(asyncio.CancelledError):
                await recovery
            service.close()
            close_connections()

    server = FastMCP("Azure Synapse", lifespan=lifespan)
    for toolset in service.config.enabled_toolsets:
        for name in TOOLSETS[toolset]:
            method = getattr(service, name)
            description = inspect.getdoc(method)
            if (
                toolset not in {"git", "artifacts"}
                and "branch" not in name
                and name != "list_workspaces"
            ):
                description = "Requires allow_live_env. " + (description or "")
            server.add_tool(_safe_tool(method), name=name, description=description)
    return server


mcp = create_server()


def main():
    mcp.run(transport="stdio")
