"""Trace propagated tools, explicit generations, streaming, and online scoring.

This deterministic example requires local Langfuse credentials and the
``langfuse`` and ``model-runtime`` extras, with no model-provider API keys.
"""

from argparse import ArgumentParser, BooleanOptionalAction
from asyncio import TaskGroup, run, sleep
from collections.abc import AsyncIterator
from contextlib import aclosing
from pathlib import Path

from dotenv import load_dotenv
from model_runtime import (
    FinishReason,
    Message,
    ModelCapabilities,
    ModelRequest,
    ModelResponse,
    ModelRouter,
    ModelRuntime,
    StreamEvent,
    Usage,
)

from observability_ai import (
    ContentCapturePolicy,
    LangfuseSettings,
    Telemetry,
    TraceAttributes,
    __version__,
    current_trace_id,
)
from observability_ai.evaluation import Contains, LengthWithin, LiveEvaluation
from observability_ai.langfuse import Scorer, build_langfuse_client


class _DemoModel:
    """Return a fixed answer and illustrative token counts without a provider."""

    capabilities = ModelCapabilities(streaming=False)

    async def complete(self, model_id: str, request: ModelRequest) -> ModelResponse:
        """Yield to the other tool before returning a deterministic response."""
        await sleep(0)
        answer = (
            "Two-dimensional vectors form a vector space."
            if request.messages[-1].text.startswith("example:")
            else "A vector space supports addition and scaling."
        )
        return ModelResponse(
            message=Message.assistant(answer),
            usage=Usage(input_tokens=7, output_tokens=3, cached_tokens=2),
            finish_reason=FinishReason.STOP,
            model=model_id,
        )

    async def stream(
        self, model_id: str, request: ModelRequest
    ) -> AsyncIterator[StreamEvent]:
        """Reject streaming, which this example does not use."""
        raise NotImplementedError
        yield


async def run_agent(
    telemetry: Telemetry,
    runtime: ModelRuntime,
    scorer: Scorer,
    *,
    trace: TraceAttributes,
) -> tuple[str, str]:
    """Run concurrent tools, stream the answer, then score its recording trace."""
    question = "What is a vector space?"
    live = LiveEvaluation(
        [Contains(name="mentions_topic"), LengthWithin(min_length=1)],
        sink=scorer.as_live_sink(),
    )

    async def answer_part(part: str) -> str:
        with telemetry.tool(part, call_id=f"call-{part}", input=question) as tool:
            request = ModelRequest.from_text(f"{part}: {question}")
            with telemetry.generation(
                "chat demo-model",
                model="demo-model",
                provider_name="demo",
                input=request.messages[-1].text,
            ) as generation:
                response = await runtime.complete("demo", request)
                generation.set_model("demo-model", response_model=response.model)
                generation.set_usage(
                    input_tokens=response.usage.input_tokens,
                    output_tokens=response.usage.output_tokens,
                    cached_tokens=response.usage.cached_tokens,
                )
                generation.set_output(response.text)
            tool.set_output(response.text)
            return response.text

    with telemetry.propagate(trace):
        with telemetry.agent("example agent", input=question) as agent:
            trace_id = agent.trace_id
            assert trace_id is not None
            with telemetry.chain("research"):
                async with TaskGroup() as tasks:
                    answers = [
                        tasks.create_task(answer_part(part))
                        for part in ("definition", "example")
                    ]
            answer = " ".join(task.result() for task in answers)
            # This is response delivery, not another model generation. The
            # wrapper records timing/counts, never the individual chunks.
            async with aclosing(
                telemetry.stream("answer stream", _answer_chunks(answer), type="chain")
            ) as chunks:
                answer = "".join([chunk async for chunk in chunks])
            agent.set_output(answer)
            recording_trace_id = current_trace_id()
        # Explicit IDs let evaluation target an ended trace. Unsampled requests
        # still return their answer, but do not create orphan scores.
        if recording_trace_id is not None:
            await live.evaluate(
                input=question,
                output=answer,
                expected_output="vector space",
                trace_id=recording_trace_id,
            )
    return trace_id, answer


async def _answer_chunks(answer: str) -> AsyncIterator[str]:
    """Simulate incremental delivery of the already-computed response."""
    for offset in range(0, len(answer), 16):
        await sleep(0)
        yield answer[offset : offset + 16]


async def main() -> None:
    """Configure application-owned telemetry and send one local example trace."""
    parser = ArgumentParser(description=__doc__)
    parser.add_argument(
        "--capture-content",
        action=BooleanOptionalAction,
        default=None,
        help="override the GenAI capture environment flag for facade payloads",
    )
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    load_dotenv(root / ".env")
    load_dotenv(root / "observability" / ".env")
    settings = LangfuseSettings.from_env()
    policy = (
        ContentCapturePolicy()
        if args.capture_content is None
        else ContentCapturePolicy(enabled=args.capture_content)
    )
    trace = TraceAttributes(
        session_id="observability-ai-phase-4",
        user_id="example-user",
        tags=("observability-ai", "agent"),
        metadata={"phase": "4"},
    )
    # This SDK client only sends scores. Telemetry exports every observation.
    client = build_langfuse_client(settings)
    try:
        with Telemetry(
            settings,
            service_name="agent-example",
            service_version=__version__,
            content_capture=policy,
        ) as telemetry:
            # The facade owns each generation; adding a runtime observer here
            # would instrument the same model call twice.
            runtime = ModelRuntime(ModelRouter({"demo": (_DemoModel(), "demo-model")}))
            trace_id, _ = await run_agent(
                telemetry, runtime, Scorer(client), trace=trace
            )
            telemetry.force_flush()
        client.flush()
        print(
            f"trace {trace_id}; inspect 'example agent', its stream, and trace scores"
        )
    finally:
        client.shutdown()


if __name__ == "__main__":
    run(main())
