---
doc_id: TICKET-8830
title: Branch Users Login Failure After Certificate Rotation
doc_type: historical_ticket
service_id: svc_identity_gateway
owner_group: Service Desk L1
visibility: internal
status: closed
created_at: "2026-06-13T08:20:00"
updated_at: "2026-06-13T10:45:00"
related_records:
  - INC-1104
  - KI-104
  - RUNBOOK-SSO-003
source_facts:
  - KI-104
  - svc_identity_gateway
difficulty_tags:
  - historical-resolution
  - similar-symptoms
servicenow:
  table: incident
  number: INC008830
  parent_incident: INC001104
  state: Closed
  impact: 2
  urgency: 2
  priority: 3
  priority_label: "3 - Moderate"
  category: Software
  subcategory: Authentication
  business_service: Employee Portal
  cmdb_ci: Identity Gateway
  assignment_group: IAM Platform
  opened_by_group: Service Desk L1
  contact_type: Phone
  related_known_issue: KI00104
  visibility: internal
  contains_customer_safe_wording: false
---

# Branch Users Login Failure After Certificate Rotation

## Record details

| Field | Value |
| --- | --- |
| Table | incident |
| Number | INC008830 |
| Parent incident | INC001104 |
| State | Closed |
| Impact | 2 |
| Urgency | 2 |
| Priority | 3 - Moderate |
| Category | Software |
| Subcategory | Authentication |
| Business service | Employee Portal |
| Configuration item | Identity Gateway |
| Assignment group | IAM Platform |
| Opened by group | Service Desk L1 |
| Contact type | Phone |
| Related known issue | KI00104 |
| Visibility | internal |
| Contains customer-safe wording | false |

## Ticket summary

TICKET-8830 was opened by Service Desk L1 for branch users who could not complete Employee Portal SSO after the identity certificate rotation. The symptoms matched the earlier incident pattern in INC-1104 and the known issue KI-104.

Ticket was linked to INC-1104 after Service Desk L1 confirmed the timing and error pattern.

## User report

Branch users reported invalid SAML response errors. The report stated that some users could access Employee Portal normally while other users in the same branch could not complete login.

The ticket was opened at 2026-06-13T08:20:00, after the CHG-2407 maintenance window and after INC-1104 had already documented the broader post-rotation issue.

## Triage notes

Service Desk L1 completed the following checks:

- Confirmed the affected application was Employee Portal.
- Captured the visible invalid SAML response error.
- Confirmed more than one branch user was affected.
- Checked recent identity maintenance and found CHG-2407.
- Matched the symptoms to KI-104.
- Routed the ticket through RUNBOOK-SSO-003 handling.

Because the issue was not isolated to one user, the ticket was not handled as a single-user browser issue.

## Related incident or known issue

Related records:

- INC-1104: Employee Portal Login Failures After Okta Certificate Rotation.
- KI-104: SSO Metadata Cache Delay After Certificate Rotation.
- RUNBOOK-SSO-003: Identity Gateway SSO Login Failure Runbook.

The ticket supported the same conclusion as INC-1104: partial login failures can continue after certificate rotation if Identity Gateway metadata has not refreshed consistently across the platform.

## Resolution

Resolution was metadata cache refresh followed by certificate thumbprint validation. IAM Platform confirmed the active IdP certificate thumbprint and Service Desk L1 asked affected branch users to retry Employee Portal sign-in.

After retest, the branch users were able to complete SSO. No new service defect was created from this ticket because it matched KI-104 and PRB-202.

## Customer-facing update

Customer-facing update used the approved customer-safe summary from KI-104.

The approved wording was:

"We are validating the enterprise sign-in configuration after scheduled identity maintenance."

The ticket notes did not expose internal metadata-cache implementation details in the customer-facing update.

## Closure notes

Closed at 2026-06-13T10:45:00. Closure reason: known issue matched, workaround completed, branch users confirmed sign-in restored.

The ticket remains useful for future retrieval because it describes the same issue with different phrasing: branch login failure after certificate rotation, invalid SSO response, partial Employee Portal access, and post-maintenance sign-in issue.

## Related records

- INC-1104: Employee Portal Login Failures After Okta Certificate Rotation.
- KI-104: SSO Metadata Cache Delay After Certificate Rotation.
- RUNBOOK-SSO-003: Identity Gateway SSO Login Failure Runbook.
