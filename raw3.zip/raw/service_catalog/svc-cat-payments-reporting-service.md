---
doc_id: SVC-CAT-PAYMENTS-001
title: Payments Reporting Service Catalog Entry
doc_type: service_catalog
service_id: svc_payments_reporting
owner_group: Data Applications
visibility: internal
status: active
created_at: "2026-05-01T09:00:00"
updated_at: "2026-06-16T10:00:00"
related_records:
  - KI-221
  - RUNBOOK-PAY-007
source_facts:
  - svc_payments_reporting
difficulty_tags:
  - ownership-routing
  - azure-data-stack
servicenow:
  table: cmdb_ci_service
  number: SVC0001002
  sys_class_name: cmdb_ci_service
  name: Payments Reporting Service
  service_tier: 1
  operational_status: Operational
  business_criticality: "1 - most critical"
  owned_by_group: Data Applications
  support_group: Data Applications
  visibility: internal
  contains_customer_safe_wording: false
---

# Payments Reporting Service Catalog Entry

## Record details

| Field | Value |
| --- | --- |
| Table | cmdb_ci_service |
| Number | SVC0001002 |
| Class name | cmdb_ci_service |
| Name | Payments Reporting Service |
| Service tier | 1 |
| Operational status | Operational |
| Business criticality | 1 - most critical |
| Owned by group | Data Applications |
| Support group | Data Applications |
| Visibility | internal |
| Contains customer-safe wording | false |

## Service summary

Payments Reporting Service provides dashboards and exports for payment operations. It is used by business operations teams to review payment activity, compare reporting totals, and produce payment-related exports from the reporting layer.

The service is a Tier 1 internal reporting service. A stale dashboard does not automatically mean source payment transactions are missing, but it can interrupt operational reconciliation and business reporting.

## Business purpose

Nautilus Financial Systems uses the Payments Reporting Service to give payment operations users a reporting view over payment transaction activity. The service supports dashboards and exports, so support tickets may describe the same issue in different ways: stale payment dashboard, delayed reporting view, payment export mismatch, latest partition not reflected, or totals that do not match an operational transaction view.

The service catalog entry should be used for ownership and routing decisions when the question is about data freshness, reporting refresh behavior, or mismatched payment export totals.

## Owning team

Data Applications owns Payments Reporting Service. Service Desk L1 performs initial triage by confirming the affected dashboard or export, the expected reporting period, and whether source transaction availability can be confirmed. Data freshness incidents should be escalated to Data Applications after L1 confirms dashboard staleness and source transaction availability.

Data Applications owns final remediation for refresh failures, watermark issues, partition backfills, and Synapse/Fabric reporting layer recovery.

## Key dependencies

Dependencies include Azure Synapse Analytics, Microsoft Fabric, Azure SQL Database, Azure Databricks, and Internal API Gateway.

| Dependency | Support relevance |
| --- | --- |
| Azure Synapse Analytics | Reporting refresh dependency and query layer for some reporting outputs. |
| Microsoft Fabric | Reporting layer where refresh watermark symptoms may be visible. |
| Azure SQL Database | Staging and control data used to compare source freshness against reporting state. |
| Azure Databricks | Transformation job dependency that produces payment reporting output partitions. |
| Internal API Gateway | Internal API routing dependency used by reporting and operational access paths. |

## Supported users and systems

The supported users are payment operations and business users who rely on payment dashboards and exports. Support should distinguish between three reports that sound similar:

- Dashboard stale by more than four hours.
- Export totals do not match the operational transaction view.
- Source transactions are present but the reporting layer has not advanced.

The third pattern is especially important because it points toward KI-221 rather than data loss.

## Common incident patterns

Common Payments Reporting Service incidents include:

- Payments dashboard data is stale by more than four hours.
- Databricks transformation job shows successful completion.
- Azure SQL Database staging tables contain current payment transaction records.
- Synapse or Fabric reporting layer still shows the previous data refresh watermark.
- Business users report exported payment totals that do not match the operational transaction view.

Known issue KI-221 covers a reporting refresh condition where the downstream reporting layer skips the latest partition after a successful transformation.

## Initial triage guidance

Service Desk L1 should capture:

- Dashboard or export name.
- Current dashboard timestamp or visible reporting period.
- Expected payment reporting period.
- Whether the issue affects one user or multiple business users.
- Whether source payment transaction availability has been confirmed.

If the report is stale and source transactions are available, use RUNBOOK-PAY-007 and escalate to Data Applications with the observed dashboard age and any export mismatch details.

## Escalation guidance

Escalate to Data Applications when:

- Dashboard staleness is confirmed.
- Source transaction records are available while reporting is behind.
- Export totals do not match dashboard totals after refresh timing is considered.
- Watermark or latest partition state needs investigation.
- The issue follows CHG-2411 or another recent reporting pipeline change.

For communication outside the support team, use the customer-safe language from KI-221: reporting data is delayed, but source payment transactions are not lost.

## Related records

- KI-221: Payments dashboard data freshness delay after Synapse/Fabric refresh failure.
- RUNBOOK-PAY-007: Payments Reporting Data Freshness Runbook.

