"""Build local OpenTelemetry providers and authenticated Langfuse export."""

from base64 import b64encode

from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import SpanProcessor, TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.sdk.trace.sampling import ParentBased, TraceIdRatioBased
from opentelemetry.util.types import AttributeValue

from ._processors import _FailOpenSpanProcessor
from .config import LangfuseSettings


def langfuse_span_exporter(settings: LangfuseSettings) -> OTLPSpanExporter:
    """Build an OTLP/HTTP exporter using project Basic auth and v4 ingestion."""
    credentials = b64encode(
        f"{settings.public_key}:{settings.secret_key}".encode()
    ).decode("ascii")
    return OTLPSpanExporter(
        endpoint=f"{settings.base_url}/api/public/otel/v1/traces",
        headers={
            "Authorization": f"Basic {credentials}",
            "x-langfuse-ingestion-version": "4",
        },
    )


def build_tracer_provider(
    settings: LangfuseSettings,
    *,
    service_name: str,
    service_version: str,
    span_processor: SpanProcessor | None = None,
) -> TracerProvider:
    """Create an owned provider with parent-based sampling and service identity.

    By default, completed spans are batched and sent to Langfuse. An injected
    processor replaces that export path, for example for in-memory tests. The
    caller owns shutdown; the process-wide tracer provider is never changed.
    The attached processor is guarded against callback and lifecycle failures,
    logged through OTel. Repeated shutdown closes that processor at most once.
    """
    for name, value in (
        ("service_name", service_name),
        ("service_version", service_version),
    ):
        if not isinstance(value, str):
            raise TypeError(f"{name} must be a string")
        if not value.strip():
            raise ValueError(f"{name} must not be empty")

    resource_attributes: dict[str, AttributeValue] = {
        "service.name": service_name,
        "service.version": service_version,
    }
    if settings.environment is not None:
        resource_attributes["langfuse.environment"] = settings.environment
    if settings.release is not None:
        resource_attributes["langfuse.release"] = settings.release

    processor = span_processor
    if processor is None:
        processor = BatchSpanProcessor(langfuse_span_exporter(settings))
    provider = TracerProvider(
        resource=Resource.create(resource_attributes),
        sampler=ParentBased(TraceIdRatioBased(settings.sample_ratio)),
    )
    provider.add_span_processor(_FailOpenSpanProcessor(processor))
    return provider
