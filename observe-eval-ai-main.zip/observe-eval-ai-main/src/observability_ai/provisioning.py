"""Prepare Langfuse headless initialization and persist local app configuration.

This module uses only the standard library. Docker and HTTP orchestration belong
to the CLI; none of these helpers starts a container or contacts Langfuse.
"""

from collections.abc import Mapping, Sequence
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from json import JSONDecodeError, dumps, loads
from os import fsync
from pathlib import Path
from re import fullmatch, match, sub
from secrets import token_urlsafe
from stat import S_IMODE
from tempfile import NamedTemporaryFile
from uuid import uuid4


class ProvisioningError(ValueError):
    """Report an invalid provisioning request or local configuration."""


def _timestamp() -> str:
    """Return an ISO 8601 timestamp with an explicit UTC offset."""
    return datetime.now(UTC).isoformat()


def _validate_text(name: str, value: str) -> None:
    """Require nonblank, single-line text without exposing its value."""
    if not isinstance(value, str) or not value.strip():
        raise ProvisioningError(f"{name} must be a nonblank string")
    if any(character in value for character in "\r\n\x00"):
        raise ProvisioningError(f"{name} must not contain newlines or NUL characters")


def _validate_identifier(name: str, value: str) -> None:
    """Validate identifiers passed through to Langfuse."""
    _validate_text(name, value)
    if any(character.isspace() for character in value):
        raise ProvisioningError(f"{name} must not contain whitespace")


def _validate_app(app: str) -> None:
    """Require the app slug format shared by the CLI and registry."""
    if not isinstance(app, str) or fullmatch(r"[a-z0-9-]{1,40}", app) is None:
        raise ProvisioningError(
            "app must contain 1 to 40 lowercase letters, digits, or hyphens"
        )


def _validate_key(name: str, value: str, prefix: str) -> None:
    """Require a Langfuse key prefix and an unambiguous credential value."""
    _validate_identifier(name, value)
    if not value.startswith(prefix) or len(value) == len(prefix) or ":" in value:
        raise ProvisioningError(f"{name} must start with {prefix} and contain a key")


def _validate_email(email: str) -> None:
    """Reject email forms that fail Langfuse's startup schema validation."""
    _validate_text("user_email", email)
    if (
        fullmatch(
            r"(?!\.)(?!.*\.\.)[A-Za-z0-9_'+.\-]*[A-Za-z0-9_+\-]@"
            r"(?:[A-Za-z0-9](?:[A-Za-z0-9\-]*[A-Za-z0-9])?\.)+[A-Za-z]{2,}",
            email,
        )
        is None
    ):
        raise ProvisioningError("user_email must be an email address")


@dataclass(frozen=True, slots=True)
class AppProvision:
    """Describe one app's organization, project, credentials, and optional owner.

    Project ID and name default to the app slug. New key pairs are generated for
    each instance unless supplied explicitly. Supplying an email also generates
    a password when absent. Secrets are excluded from the representation.
    """

    app: str
    project_id: str | None = None
    project_name: str | None = None
    org_id: str = "observability-ai"
    org_name: str = "Observability AI"
    user_email: str | None = None
    user_name: str | None = None
    user_password: str | None = field(default=None, repr=False)
    retention_days: int | None = None
    public_key: str = field(default_factory=lambda: f"pk-lf-{uuid4()}")
    secret_key: str = field(default_factory=lambda: f"sk-lf-{uuid4()}", repr=False)

    def __post_init__(self) -> None:
        """Resolve defaults and reject invalid inputs before any side effects."""
        _validate_app(self.app)
        if self.project_id is None:
            object.__setattr__(self, "project_id", self.app)
        if self.project_name is None:
            object.__setattr__(self, "project_name", self.app)
        # Local variables preserve narrowed types after frozen-field defaults.
        project_id = self.project_id
        project_name = self.project_name
        assert project_id is not None
        assert project_name is not None
        _validate_identifier("project_id", project_id)
        _validate_identifier("org_id", self.org_id)
        _validate_text("project_name", project_name)
        _validate_text("org_name", self.org_name)
        _validate_key("public_key", self.public_key, "pk-lf-")
        _validate_key("secret_key", self.secret_key, "sk-lf-")
        if self.retention_days is not None and (
            isinstance(self.retention_days, bool)
            or not isinstance(self.retention_days, int)
            or self.retention_days < 3
        ):
            raise ProvisioningError("retention_days must be an integer of at least 3")
        if self.user_email is None:
            if self.user_name is not None or self.user_password is not None:
                raise ProvisioningError(
                    "user_name and user_password require user_email"
                )
        else:
            _validate_email(self.user_email)
            if self.user_password is None:
                object.__setattr__(self, "user_password", token_urlsafe(32))
        for name, value in (
            ("user_name", self.user_name),
            ("user_password", self.user_password),
        ):
            if value is not None:
                _validate_text(name, value)


def init_environment(spec: AppProvision) -> dict[str, str]:
    """Map all ten initialization variables, including explicit empty values.

    Empty values prevent a stack's dotenv defaults from supplying an unrelated
    user or retention setting during Compose interpolation.
    """
    return {
        "LANGFUSE_INIT_ORG_ID": spec.org_id,
        "LANGFUSE_INIT_ORG_NAME": spec.org_name,
        "LANGFUSE_INIT_PROJECT_ID": spec.project_id or spec.app,
        "LANGFUSE_INIT_PROJECT_NAME": spec.project_name or spec.app,
        "LANGFUSE_INIT_PROJECT_RETENTION": (
            str(spec.retention_days) if spec.retention_days is not None else ""
        ),
        "LANGFUSE_INIT_PROJECT_PUBLIC_KEY": spec.public_key,
        "LANGFUSE_INIT_PROJECT_SECRET_KEY": spec.secret_key,
        "LANGFUSE_INIT_USER_EMAIL": spec.user_email or "",
        "LANGFUSE_INIT_USER_NAME": spec.user_name or "",
        "LANGFUSE_INIT_USER_PASSWORD": spec.user_password or "",
    }


def _assignment(line: str) -> tuple[str, str] | None:
    """Extract a dotenv assignment without interpreting its value."""
    assignment = match(r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=(.*)$", line)
    if assignment is None:
        return None
    return assignment.group(1), assignment.group(2).strip()


def _parse_env_value(value: str, key: str) -> str:
    """Read a single-line dotenv value without expanding shell expressions."""
    if value.startswith("#"):
        return ""
    if not value or value[0] not in {"'", '"'}:
        return sub(r"\s+#.*$", "", value).rstrip()
    quote = value[0]
    result: list[str] = []
    index = 1
    escapes = {"n": "\n", "r": "\r", "t": "\t", "b": "\b", "f": "\f", "v": "\v"}
    while index < len(value):
        character = value[index]
        if character == quote:
            remainder = value[index + 1 :].strip()
            if remainder and not remainder.startswith("#"):
                raise ProvisioningError(f"Invalid trailing content for {key} in .env")
            return "".join(result)
        if character == "\\" and index + 1 < len(value):
            following = value[index + 1]
            if following in {quote, "\\"}:
                result.append(following)
                index += 2
                continue
            if quote == '"' and following in escapes:
                result.append(escapes[following])
                index += 2
                continue
        result.append(character)
        index += 1
    raise ProvisioningError(f"Unterminated quoted value for {key} in .env")


def read_env_file(path: str | Path) -> dict[str, str]:
    """Read single-line dotenv assignments, returning an empty map if missing.

    Export prefixes, quotes, and inline comments are supported. Duplicate keys
    use their last value. Shell commands and variable references remain literal.
    Blank lines, comments, and lines without assignments are ignored.
    """
    path = Path(path)
    try:
        content = path.read_text(encoding="utf-8", newline="")
    except FileNotFoundError:
        return {}
    except (OSError, UnicodeError) as error:
        raise ProvisioningError(f"Cannot read environment file: {path}") from error
    result: dict[str, str] = {}
    for line in content.splitlines():
        assignment = _assignment(line)
        if assignment is not None:
            key, value = assignment
            result[key] = _parse_env_value(value, key)
    return result


def _atomic_write(path: Path, content: str) -> None:
    """Replace a file atomically, preserving its mode or creating it as 0600."""
    temporary: Path | None = None
    try:
        mode = S_IMODE(path.stat().st_mode) if path.exists() else 0o600
        with NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            newline="",
            dir=path.parent,
            prefix=f".{path.name}.",
            delete=False,
        ) as handle:
            temporary = Path(handle.name)
            temporary.chmod(mode)
            handle.write(content)
            handle.flush()
            fsync(handle.fileno())
        temporary.replace(path)
    except OSError as error:
        raise ProvisioningError(f"Cannot write configuration file: {path}") from error
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _quote_env_value(value: str) -> str:
    """Encode dotenv text literally, including dollars, quotes, and backslashes."""
    if fullmatch(r"[A-Za-z0-9_./:@%+,-]*", value) is not None:
        return value
    escaped = value.replace("\\", "\\\\").replace("'", "\\'")
    return f"'{escaped}'"


def upsert_env_file(path: str | Path, values: Mapping[str, str]) -> None:
    """Replace requested dotenv keys, preserving unrelated lines and comments.

    Repeated target assignments collapse to one entry; new keys append in mapping
    order. Updated assignments retain their inline comments. Writes are atomic,
    new files have mode 0600, and existing file permissions are preserved.
    """
    for key, value in values.items():
        if (
            not isinstance(key, str)
            or fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key) is None
        ):
            raise ProvisioningError("Environment variable names must be identifiers")
        if not isinstance(value, str) or any(char in value for char in "\r\n\x00"):
            raise ProvisioningError(f"{key} must be a string without newlines or NUL")
    path = Path(path)
    try:
        content = path.read_text(encoding="utf-8", newline="")
    except FileNotFoundError:
        content = ""
    except (OSError, UnicodeError) as error:
        raise ProvisioningError(f"Cannot read environment file: {path}") from error
    lines: list[str] = []
    seen: set[str] = set()
    for line in content.splitlines(keepends=True):
        assignment = _assignment(line.rstrip("\r\n"))
        if assignment is None or assignment[0] not in values:
            lines.append(line)
            continue
        key, old_value = assignment
        comment = _env_comment(old_value)
        if key not in seen:
            newline = "\r\n" if line.endswith("\r\n") else "\n"
            lines.append(f"{key}={_quote_env_value(values[key])}{comment}{newline}")
            seen.add(key)
        elif comment:
            lines.append(f"{comment.lstrip()}\n")
    for key, value in values.items():
        if key not in seen:
            if lines and not lines[-1].endswith(("\n", "\r")):
                lines[-1] += "\n"
            lines.append(f"{key}={_quote_env_value(value)}\n")
    _atomic_write(path, "".join(lines))


def _env_comment(value: str) -> str:
    """Find an assignment's inline comment outside quoted text."""
    quote: str | None = None
    escaped = False
    for index, character in enumerate(value):
        if escaped:
            escaped = False
            continue
        if character == "\\" and quote is not None:
            escaped = True
        elif character == quote:
            quote = None
        elif quote is None and character in {"'", '"'}:
            quote = character
        elif (
            quote is None
            and character == "#"
            and (index == 0 or value[index - 1].isspace())
        ):
            return f" {value[index:]}"
    return ""


@dataclass(frozen=True, slots=True)
class ProvisionedApp:
    """Record an app's public provisioning metadata without secret credentials."""

    app: str
    org_id: str
    project_id: str
    public_key: str
    user_email: str | None = None
    created_at: str = field(default_factory=_timestamp)
    rotated_at: str | None = None

    def __post_init__(self) -> None:
        """Validate registry identity and timestamps at construction."""
        _validate_app(self.app)
        _validate_identifier("org_id", self.org_id)
        _validate_identifier("project_id", self.project_id)
        _validate_key("public_key", self.public_key, "pk-lf-")
        if self.user_email is not None:
            _validate_email(self.user_email)
        for name, value in (
            ("created_at", self.created_at),
            ("rotated_at", self.rotated_at),
        ):
            if value is None and name == "rotated_at":
                continue
            if not isinstance(value, str):
                raise ProvisioningError(f"{name} must be an ISO 8601 timestamp")
            try:
                timestamp = datetime.fromisoformat(value)
            except ValueError as error:
                raise ProvisioningError(
                    f"{name} must be an ISO 8601 timestamp"
                ) from error
            if timestamp.tzinfo is None:
                raise ProvisioningError(f"{name} must include a timezone")


def _validate_registry(entries: Sequence[ProvisionedApp]) -> None:
    """Reject ambiguous app, project, or public key assignments."""
    for attribute in ("app", "project_id", "public_key"):
        values = [getattr(entry, attribute) for entry in entries]
        if len(values) != len(set(values)):
            raise ProvisioningError(f"Registry contains a duplicate {attribute}")


def read_registry(path: str | Path) -> list[ProvisionedApp]:
    """Read and validate a JSON registry, returning an empty list if missing."""
    path = Path(path)
    try:
        content = path.read_text(encoding="utf-8", newline="")
    except FileNotFoundError:
        return []
    except (OSError, UnicodeError) as error:
        raise ProvisioningError(f"Cannot read provisioning registry: {path}") from error
    try:
        records = loads(content)
        if not isinstance(records, list) or any(
            not isinstance(record, dict) for record in records
        ):
            raise ProvisioningError("Registry must contain a JSON array of app records")
        entries = [ProvisionedApp(**record) for record in records]
        _validate_registry(entries)
        return entries
    except (JSONDecodeError, TypeError, ProvisioningError) as error:
        raise ProvisioningError(f"Invalid provisioning registry: {path}") from error


def write_registry(path: str | Path, entries: Sequence[ProvisionedApp]) -> None:
    """Atomically store validated app records using only the public schema."""
    if any(not isinstance(entry, ProvisionedApp) for entry in entries):
        raise ProvisioningError("Registry entries must be ProvisionedApp instances")
    _validate_registry(entries)
    # Explicit fields prevent dataclass subclasses from adding secrets to JSON.
    names = ProvisionedApp.__dataclass_fields__
    records = [
        {key: value for key, value in asdict(entry).items() if key in names}
        for entry in entries
    ]
    _atomic_write(Path(path), f"{dumps(records, indent=2)}\n")


def resolve_stack_dir(flag: str | Path | None, environ: Mapping[str, str]) -> Path:
    """Resolve a stack flag or environment setting and require its config files."""
    configured = flag if flag is not None else environ.get("OBSERVABILITY_AI_STACK_DIR")
    if configured is None or not str(configured).strip():
        raise ProvisioningError(
            "Set --stack-dir PATH or OBSERVABILITY_AI_STACK_DIR to the checkout's "
            "observability directory containing compose.yaml and .env"
        )
    path = Path(configured).expanduser().resolve()
    missing = [name for name in ("compose.yaml", ".env") if not (path / name).is_file()]
    if missing:
        raise ProvisioningError(
            f"Stack directory {path} is missing {', '.join(missing)}; "
            "check --stack-dir or OBSERVABILITY_AI_STACK_DIR"
        )
    return path
