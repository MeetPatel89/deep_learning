# Three data MCP servers

Three independently installable Python stdio MCP servers share a Polars-based core:

| Distribution / command | Purpose | Configuration |
| --- | --- | --- |
| `qa-mcp-server` | Compare every row of SQL/file datasets; produce colored Excel reports and a complete Parquet difference dump | `QA_MCP_CONFIG` |
| `fs-mcp-server` | Browse local, ADLS Gen2, S3 and GCS stores; inspect, query, validate, convert and maintain datasets | `FS_MCP_CONFIG` |
| `synapse-mcp-server` | Discover artifacts, monitor and diagnose runs, execute pipelines/Spark jobs and inspect SQL pools | `SYNAPSE_MCP_CONFIG` |
| `data-mcp-core` | Configuration, Azure credentials, permission/path guards, stores, file formats, SQL and bounded/redacted results | Library; no MCP tools |

The existing QA comparison engine and report accounting are preserved. See the
[QA guide](packages/qa_mcp_server/README.md) for normalization, primary keys,
multiset comparisons, memory planning and complete report semantics.

## Install and run

Use Python 3.12+ and [uv](https://docs.astral.sh/uv/). This repository is a virtual
uv workspace; install any server with its own dependency graph:

```sh
uv sync --package qa-mcp-server
uv run --package qa-mcp-server qa-mcp-server
uv run --package fs-mcp-server fs-mcp-server
uv run --package synapse-mcp-server synapse-mcp-server
```

Each command waits for an MCP client on stdin. Stdout is reserved for MCP messages.
`python -m qa_mcp_server`, `python -m fs_mcp_server` and
`python -m synapse_mcp_server` work in an environment containing that package.
The root `main.py` remains a compatibility entry point for QA.

Optional server extras are `s3`, `gcs`, `iceberg` and `legacy` (SAS/Stata/SPSS).
For example, `uv sync --package fs-mcp-server --extra s3`. The shared core also
provides separate `sql` and `formats` extras. Synapse does not depend on QA or the
filesystem server. Local file tools do not need an ODBC installation. SQL tools
require the [Microsoft ODBC Driver 18 runtime](https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server).

## Configuration and credentials

Set the server's configuration variable to an absolute TOML filename. Start from
[fs.toml](examples/fs.toml), [synapse.toml](examples/synapse.toml) or
[qa.toml](examples/qa.toml). An absent configuration means no named stores/workspaces;
QA's existing direct local paths and interactive SQL connections still work.

```toml
[auth_profiles.app]
mode = "service_principal"
tenant_id = "${AZURE_TENANT_ID}"
client_id = "${AZURE_CLIENT_ID}"
client_secret = "${AZURE_CLIENT_SECRET}"

[stores.raw]
protocol = "abfss"
account_name = "lake"
container = "raw"
root = "sales/"
auth = "app"
allow_write = false
```

Auth profiles support `default`, `cli`, `interactive_browser`, `device_code`,
`service_principal`, `managed_identity`, `account_key` and `sas`. The last two are
storage-only and require `account_key` or `sas_token`. Azure credentials are cached
per profile; Polars receives a refreshable token provider. ODBC token authentication
uses the database scope and UTF-16-LE access-token attribute 1256.

`${ENV_VAR}` references are expanded before validation; missing variables fail
without exposing values. Credentials and secure artifact fields are redacted from
results and errors. `generate_sas` intentionally returns its newly signed secret
and is registered only for ADLS configurations, with explicit `allow_sas` required.
SAS lifetimes are capped at one hour; write/delete SAS permissions also require the
corresponding store flags.

All mutation flags default to false. Permission checks also apply to dry runs:

| Operations | Required flag |
| --- | --- |
| File/dataset writes, conversions, copies, transfers, Delta writes/optimize/restore, ADLS metadata/undelete | Destination `allow_write` |
| Deletes, Delta vacuum | `allow_delete` |
| Moves | `allow_write` and `allow_delete` |
| ADLS ACL changes and deleted-path listing | `allow_manage` |
| Published pipeline/trigger/Spark execution and standalone data-flow debugging | Workspace `allow_live_env` and `allow_run` |
| Live artifact edits/deletes and SQL pool pause/resume | Workspace `allow_live_env` and `allow_manage` |
| SQL statements other than classified read-only queries | Workspace `allow_live_env` and `allow_sql_write` |
| Git feature-branch edits, commits, pushes and draft PR creation | Workspace `allow_git_write` |
| Studio branch tests | Workspace `allow_run` and a configured profile/contract |
| SDK branch staging/tests/cleanup | Workspace `allow_live_env`, `allow_run` and `allow_manage` |

Every filesystem tool takes a named `store` and a path relative to its configured
`root`. Absolute paths, `..` traversal and symlinks escaping local roots are rejected.
`allowed_local_roots` optionally adds a local allowlist. Store roots cannot be
deleted. Deletes, artifact authoring and Delta vacuum default to `dry_run=true`;
other mutation tools accept an explicit `dry_run`.

Tool groups can be restricted with `enabled_toolsets`. FS groups are `discovery`,
`content`, `datasets`, `delta`, `files` and `adls`. Synapse groups include `git`, `workspace`,
`artifacts`, `monitoring`, `debugging`, `execution` and `sql`, and individual
workspaces may restrict them further.

Object stores use the normal AWS/GCP credential chain. Advanced backend settings
are available in `[stores.NAME.options.fsspec]` and
`[stores.NAME.options.polars]`. Common S3 key/secret/token/region/endpoint options
and GCS service-account credentials are forwarded to Polars. For a local Azure
Blob emulator, `options.fsspec.connection_string` selects its Blob endpoint;
ADLS ACLs, HNS rename and path restore require real ADLS Gen2. Azurite cannot test
those HNS operations.

## MCP clients

Copy [mcp.json](examples/mcp.json) into your client's MCP settings and replace the
checkout/config paths. Enable any subset of the three entries. The invocation is:

```json
{
  "mcpServers": {
    "data-files": {
      "command": "uv",
      "args": ["--directory", "/path/to/data_mcp_server", "run", "--package", "fs-mcp-server", "fs-mcp-server"],
      "env": {"FS_MCP_CONFIG": "/path/to/fs.toml"}
    }
  }
}
```

On Windows use `uv.exe` and Windows paths. QA `auth="interactive"` opens the Entra
MFA dialog on the server machine; headless environments should use token auth.

## Filesystem tools

- Discovery: `list_stores`, `list_paths`, `get_path_info`, `find_files`,
  `summarize_directory` (extension counts, sizes and hive partition fields).
- Content: `read_text` (zero-based byte/line ranges, head/tail), `search_text`,
  `detect_format` (extension, magic bytes, compression, delimiter and encoding).
- Datasets: `inspect_dataset`, `preview_dataset`, `profile_dataset`,
  `query_datasets`, `validate_dataset`, `convert_dataset`.
- Delta: `delta_describe`, `delta_history`, `delta_list_files`, `delta_write`,
  `delta_optimize`, `delta_vacuum`, `delta_restore`.
- Files: `write_text`, `write_dataset`, `make_directory`, `copy_path`, `move_path`,
  `delete_path`, `transfer` between stores.
- ADLS (registered only when an `abfss` store exists): `get_acl`, `set_acl`,
  `get_properties`, `set_metadata`, `list_deleted_paths`, `undelete_path`,
  `generate_sas`. HNS moves use the atomic ADLS rename operation.

Readers cover CSV/TSV/PSV, JSON, NDJSON/JSONL, hive Parquet, versioned/timestamped
Delta, Arrow IPC/Feather, Avro, Excel xlsx/xls/xlsb, ODS, text/log, fixed-width, XML,
ORC (Arrow), optional Iceberg and optional SAS/Stata/SPSS (pandas fallback only).
Compression supports gzip, bzip2, xz, zstd and zip. A ZIP with multiple members
requires `options.archive_member`. Formats needing local access are staged to a
scratch directory removed on success or error. Iceberg directories with multiple
metadata files require an explicit metadata JSON path.

Writers support CSV, Parquet, NDJSON, IPC, Delta append/overwrite/merge and Excel.
CSV/Parquet/NDJSON/IPC scans are lazy/streamed where possible. Excel, legacy/custom
readers, random previews and current export/conversion writers can materialize
whole datasets; bounded inline output does not make those operations memory bounded.

```json
{"store":"raw","path":"orders/","sample_size":5}
```

```json
{
  "datasets": {"orders":{"store":"raw","path":"orders/","format":"parquet"}},
  "query": "SELECT customer_id, SUM(amount) AS total FROM orders GROUP BY customer_id",
  "limit": 100
}
```

`preview_dataset.filter_expression` is a Polars SQL expression, such as
`amount > 100 AND status = 'paid'`. SQL tables in `query_datasets` must be supplied
aliases; file-reading table functions are blocked. Validation rules use `type`
and `column`, with `pattern` for regex, `min`/`max` for range, or `values` for
allowed values. Fixed-width options use `column_specs = {id = [0, 8]}`. XML options
require a simple `record_xpath` (for example `//row`), optional `namespaces`, and
optional `fields` mapping column names to child XPath expressions.

## Synapse tools

The server uses SDK clients for artifacts, Livy, ARM and access control. Clients
are initialized lazily. Workspaces are addressed by configured alias, such as
`prod` in [synapse.toml](examples/synapse.toml).

Artifact tools default to Git. Live artifact access requires `source="live"`,
and **all live operations now require `allow_live_env=true`**, including reads,
monitoring, ARM, SQL and Spark. Existing installations must explicitly enable it
to retain previous live behavior. Feature-branch writes use `allow_git_write`.
See the [Git workflow, permission matrix and backend rollout requirements](packages/synapse_mcp_server/README.md)
for local/GitHub development, test profiles, branch execution, recovery and PR tools.
The Studio HTTP adapter requires a pinned authenticated protocol capture;
its synthetic transport tests do not establish live compatibility.

- Workspace: `list_workspaces`, `get_workspace_info`, `list_sql_pools`,
  `list_spark_pools`, `list_integration_runtimes`, `list_role_assignments`.
- Artifacts: `list_artifacts`, `get_artifact`, `search_artifacts`,
  `analyze_pipeline` (activity DAG and nested pipeline/dataset/service references),
  `upsert_artifact` (redacted diff), `delete_artifact`.
- Monitoring: `query_pipeline_runs`, `get_pipeline_run`, `query_activity_runs`,
  `get_activity_run`, `query_trigger_runs`, `get_run_tree`, `pipeline_run_stats`,
  `compare_pipeline_runs` (including Copy rows and repeated activity attempts).
- Debugging: `diagnose_pipeline_run`, `list_spark_applications`,
  `get_spark_application_logs`, `create_data_flow_debug_session`,
  `add_data_flow_to_debug_session`, `run_data_flow_debug_command`,
  `delete_data_flow_debug_session`.
- Execution: `run_branch_pipeline` and branch status/activity/wait/cancel/diagnosis/cleanup
  tools; `run_pipeline` for already-published pipelines, `cancel_pipeline_run`, `wait_for_pipeline_run`,
  `start_trigger`, `stop_trigger`, `rerun_trigger_run`, `create_spark_session`,
  `run_spark_statement`, `close_spark_session`, `submit_spark_batch`,
  `pause_sql_pool`, `resume_sql_pool`.
- SQL: `test_sql_connection`, `run_sql_query`, `list_sql_objects`, `describe_table`,
  `get_object_definition`, `explain_query`, `list_active_requests`,
  `get_request_steps`, `check_table_skew`, `query_history`.

Run queries default to the preceding seven days by last update time; supply
`after`/`before` ISO timestamps for older runs. Continue a query by passing the
returned opaque `continuation` with the same filters. Parameter filters are
applied after the Azure page query. `wait_for_pipeline_run` accepts bounded timeout
and polling intervals, reports MCP progress and automatically diagnoses failure.
`run_pipeline` supports `reference_pipeline_run_id`, `is_recovery` and
`start_activity_name`. Debug commands are `executePreview`, `executeStatistics`
and `executeExpressionQuery`; preview/statistics aliases map to the SDK's
`executePreviewQuery` and `executeStatisticsQuery` commands. Library upserts accept `content_base64`.

Diagnosis descends to failed leaf activities, preserves resolved input/output
and collects Copy metrics, SQL errors, data-flow metrics and available Spark stderr.
Hints classify authentication, firewall, missing path, schema, timeout and memory
errors. Spark monitoring/history HTTP endpoints are **best-effort** and can depend
on application retention and workspace permissions. The current ADLS SDK exposes
path restore as `_undelete_path`; the wrapper is covered by mocked tests.
Explicit `source="live"` artifact edits bypass a git-enabled workspace's repository
and return that warning with the diff/result. Git edits and tests never publish,
merge PRs or change the collaboration/publish branch heads.

SQL endpoints resolve to `<workspace>.sql.azuresynapse.net` for dedicated pools and
`<workspace>-ondemand.sql.azuresynapse.net` for serverless. `sqlglot` classifies
T-SQL and rejects unknown syntax, multiple statements, nested writes and
`SELECT INTO` while writes are disabled. SELECT/WITH/set queries and EXPLAIN of
read-only queries are allowed. Use a read-only Entra identity as the database
permission boundary. EXPLAIN and `sys.dm_pdw_*` diagnostics require a dedicated
pool; history uses serverless `sys.dm_exec_requests_history`.

Inline filesystem/Synapse results are capped at 1,000 rows and 50,000 characters;
large individual definitions/logs include a truncation indicator. Filesystem list
pagination and Azure run continuation preserve page positions. Large query results
can be exported to a configured writable store as Parquet/CSV.

## QA cloud and generic sources

Existing `csv`, `parquet`, `excel`, `sql` and `inline` sources remain compatible.
Paths are strings accepting local files or `abfss://`, `s3://`, `gs://` URIs.
An optional `store` selects a configured root and auth profile. Generic `file`
sources use the same registry as the filesystem server:

```json
{"type":"file","store":"raw","path":"orders/","format":"delta","version":12}
{"type":"file","path":"s3://bucket/events.jsonl.gz","format":"ndjson"}
{"type":"file","path":"/data/records.xml","format":"xml","options":{"record_xpath":"//row"}}
{"type":"sql","workspace":"prod","pool":"serverless","database":"lake","auth":"token","query":"SELECT * FROM dbo.orders"}
```

`timestamp` provides Delta timestamp time travel instead of `version`. Named QA
workspaces resolve the endpoint and configured auth profile. Without `workspace`,
SQL still accepts `server` and `database`; interactive authentication is the default.

## Development and validation

```sh
uv sync --all-packages --all-extras --group dev
uv run --all-packages --all-extras pytest -q
uv run --all-packages --all-extras ruff check .
uv run --all-packages --all-extras ruff format --check .
uv build --all-packages
```

Each package owns its tests. Normal tests generate local datasets, mock SDK/ODBC
clients, validate all mutation guards, and exercise each server through a real MCP
stdio session. Cloud credentials are not needed. Optional format tests use installed
extras; normal test selection excludes `live` and `azurite` markers.

To opt into cloud smoke tests, configure `FS_MCP_CONFIG`/`FS_MCP_LIVE_STORE` and/or
`SYNAPSE_MCP_CONFIG`/`SYNAPSE_MCP_LIVE_WORKSPACE`, then run `pytest -m live`.
For Blob-compatible emulator listing, set `FS_MCP_AZURITE_CONFIG` and
`FS_MCP_AZURITE_STORE` and run `pytest -m azurite`. These tests are read-only and
skip when their required configuration is absent. HNS-specific ACL/rename/restore
behavior requires a real ADLS account and is not covered by Azurite.
