"""Sample and evaluate live outputs with an explicit synchronous score sink."""

from collections.abc import Callable, Mapping, Sequence
from inspect import isawaitable
from random import random

from .._context import current_observation_id, current_trace_id
from ..config import _validate_text
from .results import EvaluationResult, Evaluator, _metadata_snapshot, _validated_value


class LiveEvaluation:
    """Run sync/async evaluators inline, sampling once for the complete evaluation.

    No background tasks are created. Evaluator, sink, and cancellation errors
    propagate; callers decide whether to catch them. All evaluators complete and
    their outputs are checked before any score is sent. Sink delivery is not
    transactional: a sink failure may follow previously delivered scores.
    """

    def __init__(
        self,
        evaluators: Sequence[Evaluator],
        *,
        sink: Callable[[EvaluationResult, str, str | None], None],
        sample_ratio: float = 1.0,
        random_source: Callable[[], float] = random,
    ) -> None:
        """Snapshot evaluators and inject delivery and optional sampling randomness."""
        checked = _validated_value("sample_ratio", sample_ratio, "NUMERIC", None)
        if not isinstance(checked, float) or not 0 <= checked <= 1:
            raise ValueError("sample_ratio must be between 0 and 1")
        self._evaluators = tuple(evaluators)
        if any(not callable(evaluator) for evaluator in self._evaluators):
            raise TypeError("evaluators must contain callable evaluators")
        if not callable(sink):
            raise TypeError("sink must be callable")
        if not callable(random_source):
            raise TypeError("random_source must be callable")
        self._sink = sink
        self._sample_ratio = checked
        self._random_source = random_source

    async def evaluate(
        self,
        *,
        input: object = None,
        output: object,
        expected_output: object = None,
        metadata: Mapping[str, object] | None = None,
        trace_id: str | None = None,
        observation_id: str | None = None,
    ) -> tuple[EvaluationResult, ...]:
        """Evaluate and deliver scores to explicit IDs or the active recording span.

        An explicit trace ID with no observation ID targets the trace. Otherwise
        current IDs are captured before running evaluators, including judges that
        open nested spans. Sampled calls need a trace; skipped calls return ``()``
        without resolving IDs or executing evaluators/sinks. Results preserve
        evaluator order. This async method also accepts synchronous evaluators.
        """
        if self._sample_ratio == 0:
            return ()
        if self._sample_ratio < 1 and self._random_source() >= self._sample_ratio:
            return ()
        if trace_id is None:
            trace_id = current_trace_id()
            if observation_id is None:
                observation_id = current_observation_id()
        if trace_id is None:
            raise ValueError(
                "live evaluation requires a trace_id or active recording span"
            )
        _validate_text("trace_id", trace_id)
        if observation_id is not None:
            _validate_text("observation_id", observation_id)
        dimensions = _metadata_snapshot(metadata) if metadata is not None else None
        results: list[EvaluationResult] = []
        for evaluator in self._evaluators:
            output_value = evaluator(
                input=input,
                output=output,
                expected_output=expected_output,
                metadata=dimensions,
            )
            evaluated = (
                await output_value if isawaitable(output_value) else output_value
            )
            if isinstance(evaluated, EvaluationResult):
                results.append(evaluated)
            elif (
                isinstance(evaluated, Sequence)
                and not isinstance(evaluated, (str, bytes))
                and all(isinstance(result, EvaluationResult) for result in evaluated)
            ):
                results.extend(evaluated)
            else:
                raise TypeError("evaluators must return EvaluationResult values")
        for result in results:
            self._sink(result, trace_id, observation_id)
        return tuple(results)
