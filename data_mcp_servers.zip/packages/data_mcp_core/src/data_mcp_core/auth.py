"""Cached Azure credentials and storage/ODBC token helpers."""

import atexit
import hashlib
import json
import struct
from threading import RLock
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, SecretStr, model_validator

from data_mcp_core.results import register_secret

STORAGE_SCOPE = "https://storage.azure.com/.default"
SQL_SCOPE = "https://database.windows.net/.default"
SYNAPSE_SCOPE = "https://dev.azuresynapse.net/.default"
SQL_COPT_SS_ACCESS_TOKEN = 1256


class AuthProfile(BaseModel):
    model_config = ConfigDict(extra="forbid", hide_input_in_errors=True)
    mode: Literal[
        "default",
        "cli",
        "interactive_browser",
        "device_code",
        "service_principal",
        "managed_identity",
        "account_key",
        "sas",
    ] = "default"
    tenant_id: str | None = None
    client_id: str | None = None
    client_secret: SecretStr | None = None
    account_key: SecretStr | None = None
    sas_token: SecretStr | None = None

    @model_validator(mode="after")
    def required_fields(self):
        if self.mode == "service_principal" and not (
            self.tenant_id and self.client_id and self.client_secret
        ):
            raise ValueError("service_principal requires tenant_id, client_id and client_secret")
        if self.mode == "account_key" and not self.account_key:
            raise ValueError("account_key authentication requires account_key")
        if self.mode == "sas" and not self.sas_token:
            raise ValueError("sas authentication requires sas_token")
        for secret in (self.client_secret, self.account_key, self.sas_token):
            if secret:
                register_secret(secret.get_secret_value())
        return self


_credentials: dict[tuple[str, bool], Any] = {}
_lock = RLock()


def profile_key(profile: AuthProfile) -> str:
    data = profile.model_dump()
    for key, value in data.items():
        if isinstance(value, SecretStr):
            data[key] = value.get_secret_value()
    return hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()


def resolve_auth(auth: str | AuthProfile, profiles: dict[str, AuthProfile]) -> AuthProfile:
    if isinstance(auth, AuthProfile):
        return auth
    if auth in profiles:
        return profiles[auth]
    if auth in {"default", "cli", "interactive_browser", "device_code", "managed_identity"}:
        return AuthProfile(mode=auth)
    raise ValueError(f"Unknown auth profile: {auth}")


def get_credential(profile: AuthProfile | None = None, *, asynchronous: bool = False) -> Any:
    profile = profile or AuthProfile()
    if profile.mode in {"account_key", "sas"}:
        raise ValueError("Storage account keys and SAS cannot authenticate Azure service APIs")
    key = (profile_key(profile), asynchronous)
    with _lock:
        if key not in _credentials:
            if asynchronous:
                from azure.identity import aio as identity
            else:
                from azure import identity
            options = {}
            if profile.tenant_id:
                options["tenant_id"] = profile.tenant_id
            if profile.mode == "default":
                credential = identity.DefaultAzureCredential(
                    managed_identity_client_id=profile.client_id
                )
            elif profile.mode == "cli":
                credential = identity.AzureCliCredential(**options)
            elif profile.mode in {"interactive_browser", "device_code"}:
                if profile.client_id:
                    options["client_id"] = profile.client_id
                cls = (
                    identity.InteractiveBrowserCredential
                    if profile.mode == "interactive_browser"
                    else identity.DeviceCodeCredential
                )
                credential = cls(**options)
            elif profile.mode == "service_principal":
                credential = identity.ClientSecretCredential(
                    profile.tenant_id, profile.client_id, profile.client_secret.get_secret_value()
                )
            else:
                credential = identity.ManagedIdentityCredential(
                    **({"client_id": profile.client_id} if profile.client_id else {})
                )
            _credentials[key] = credential
        return _credentials[key]


def get_token(profile: AuthProfile, scope: str) -> Any:
    token = get_credential(profile).get_token(scope)
    register_secret(token.token)
    return token


def pack_odbc_token(token: str) -> bytes:
    encoded = token.encode("utf-16-le")
    return struct.pack("<I", len(encoded)) + encoded


def odbc_token_attributes(profile: AuthProfile) -> dict[int, bytes]:
    return {SQL_COPT_SS_ACCESS_TOKEN: pack_odbc_token(get_token(profile, SQL_SCOPE).token)}


def azure_credential_provider(profile: AuthProfile):
    def provide():
        token = get_token(profile, STORAGE_SCOPE)
        return {"bearer_token": token.token}, token.expires_on

    return provide


def close_credentials() -> None:
    # Async credentials belong to fsspec's loop; they are closed by their filesystem clients.
    with _lock:
        for (_, asynchronous), credential in list(_credentials.items()):
            if not asynchronous:
                credential.close()
        _credentials.clear()


atexit.register(close_credentials)
