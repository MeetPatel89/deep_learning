# Local Langfuse backend

This directory owns the local Langfuse Docker Compose stack and its standalone
OTLP ingestion smoke test, moved from `model-runtime` in Phase 0 of
`observability-ai`. The stack uses Langfuse v4 images and sends the v4 ingestion
header; direct OTLP/HTTP traces go to `/api/public/otel/v1/traces`.

Python 3.14, `uv`, Docker, and Docker Compose v2 or newer are required. Backend
startup, shutdown, and smoke-test commands run from the `observe-eval-ai`
repository root. Provisioning commands run from the consuming app's directory.

## What runs

| Container | Responsibility |
| --- | --- |
| `langfuse-web` | Serves the UI, public API, authentication, and OTLP ingestion endpoint on `http://localhost:3000`. |
| `langfuse-worker` | Processes ingestion and other background jobs outside the web request path. |
| `postgres` | Stores transactional application state such as users, organizations, projects, and API-key metadata. |
| `clickhouse` | Stores and queries high-volume trace and observation data. |
| `redis` | Backs queues and short-lived coordination/cache state shared by web and worker. |
| `minio` | Provides local S3-compatible object storage; its startup command creates the `langfuse` bucket. |

Named Docker volumes retain each datastore across normal container restarts.
All published ports are bound to `127.0.0.1`; this is a local learning setup,
not production infrastructure.

## Start the backend

From the repository root, copy the template:

```bash
cp observability/.env.example observability/.env
```

Replace every `replace-with-...` value in `observability/.env`. Generate
independent values with these commands; `ENCRYPTION_KEY` must be the 64-character
hex output:

```bash
openssl rand -base64 32
openssl rand -hex 32
```

The populated `.env` is ignored by the repository and must not be committed.
Start the stack and inspect its status:

```bash
docker compose --env-file observability/.env \
  -f observability/compose.yaml up -d
docker compose --env-file observability/.env \
  -f observability/compose.yaml ps
```

Create application projects and an optional first login with the provisioning
command below. The standalone smoke test still reads credentials from
`observability/.env`: set its `LANGFUSE_PUBLIC_KEY` and `LANGFUSE_SECRET_KEY` to a
pair from the project you want to test. You can create an additional pair in that
project's API Keys settings at `http://localhost:3000`. The provisioning command
does not edit the stack's `.env`.

## Provisioning apps

Install `observe-eval-ai` in the consuming app's environment and start the central
stack as shown above. From the app directory, point at the checkout's
`observability/` directory in the app's `.env`:

```dotenv
OBSERVABILITY_AI_STACK_DIR=../observe-eval-ai/observability
```

Then provision a dedicated project and write its verified credentials to that
same app file:

```bash
uv run observability-ai provision --app fieldguide --app-env .env \
  --user-email meet@example.com
uv run observability-ai verify --app fieldguide --app-env .env
uv run observability-ai apps list
uv run observability-ai where
```

The app slug accepts 1–40 lowercase letters, digits, or hyphens and becomes the
project ID and default project name. The default organization is
`observability-ai` (display name `Observability AI`). Use `--org my-team` and
`--org-name "My Team"` for a different organization, and `--project-name` for a
display name when creating a project. An app already in the registry cannot
move to another organization or project through this command.

`--user-email` is optional. It creates a missing user and grants OWNER membership
in the organization. The CLI prints a generated password once for that invocation;
it applies only if the user is new. An existing user keeps their password and
gains membership. `--user-name` supplies the display name for a new user. Save
the printed password if you need the new login; it is not written to an app file
or the registry.

An explicit `--stack-dir` takes precedence over `OBSERVABILITY_AI_STACK_DIR`:

```bash
uv run observability-ai provision --app fieldguide --app-env .env \
  --stack-dir ../observe-eval-ai/observability --dry-run
```

The variable is read from the app's `.env` and the process environment, with the
process value taking precedence. Relative paths resolve from the directory where
the command runs, including paths read from `.env`. Stack discovery requires both
`compose.yaml` and `.env`. `where` prints the resolved directory, the Compose
project name derived from that directory (normally `observability`), and the base
URL. This command manages stacks using that default directory-based project name.
Custom Compose project names are not supported by provisioning.

### Startup and credential handling

Provisioning uses Langfuse's
[headless initialization](https://langfuse.com/self-hosting/administration/headless-initialization).
It recreates only `langfuse-web` with `up -d --no-deps --force-recreate`; the worker,
databases, queues, and their volumes continue running. Other apps may see an
ingestion interruption, typically 10–30 seconds, while the web service restarts.
The CLI asks for confirmation; use `--yes` for unattended runs. `--dry-run` prints
the Compose command and all ten INIT variable names with values redacted, without
starting Docker, calling HTTP endpoints, or writing files.

All ten `LANGFUSE_INIT_*` values go into the Compose subprocess environment.
Optional values are explicitly empty, overriding any bootstrap INIT values still
in the stack `.env`. The stack file is never modified. Those credentials also
remain in the web container's Docker environment until that container is recreated;
the local app file is not the only place Docker administrators can inspect them.
An ordinary Compose `up -d` later restores the stack file's INIT configuration. If
those values are empty, startup initialization is a no-op; if bootstrap values
remain configured, they are applied again. Previously created projects persist.

After restart, the CLI waits for the database-aware health endpoint and checks
`/api/public/projects` with the app's keys against the expected project and
organization. Only after verification succeeds does it upsert
`LANGFUSE_PUBLIC_KEY`, `LANGFUSE_SECRET_KEY`, and `LANGFUSE_BASE_URL` into the app's
`.env`. Failed health or key checks leave that file untouched and print a startup
logs command. Increase `--timeout` from the default 120 seconds if startup needs
more time. The base URL defaults to `http://localhost:3000`; an app or process
`LANGFUSE_BASE_URL` overrides the stack file's value.

App dotenv updates preserve unrelated lines and comments and remove duplicate
assignments for the three updated keys. New files have mode 0600; existing
permissions are preserved. The parser supports single-line quoted or unquoted
values, optional `export` prefixes, and comments. It does not expand variables,
execute shell expressions, or parse multiline values. Keep the app `.env` out of
source control. For `verify`, exported credentials take precedence over the app
file; clear stale exports if they still point to another project.

`provisioned.json` beside the Compose file records app, organization and project
IDs, public key, optional user email, and creation/rotation timestamps. This
gitignored registry contains no secret API keys or passwords. `apps list` displays
these local records; it does not discover every project on the server.

### Re-provisioning, rotation, and limits

Re-running the same command reuses the registered key pair from the app's `.env`
and verifies it after another web restart. If the registry exists but credentials
are missing or differ, restore the original app file or request rotation. After a
deliberate stack reset with `down --volumes`, re-running provisioning recreates the
project with the saved pair when both registry and app file remain. Data deleted
by that reset cannot be recovered by provisioning.

```bash
uv run observability-ai provision --app fieldguide --app-env .env \
  --rotate-keys --yes
uv run observability-ai verify --app fieldguide --app-env .env
```

Rotation creates a fresh pair and saves it only after verification. Old API keys
remain valid: delete retired pairs in the Langfuse UI when no application uses
them. The CLI does not revoke them. Existing traces, datasets, and experiments
stay in the project where they were originally written.

Headless initialization creates missing entities; it does not rename existing
organizations/projects, change their retention, reset existing user passwords,
or move a project to another organization. `--retention-days` accepts an integer
of at least 3, applies only on project creation, and requires the data-retention
entitlement; OSS ignores it. This CLI does not use the licensed organization,
project, key, or user-role administration APIs. Use the UI for those management
operations beyond creation and adding an owner.

Concurrent provisioning commands are blocked by the `.provision.lock` directory
in the stack. Normal exits remove it. After a crash, confirm that no provisioning
command is running before removing the empty lock directory and retrying.

See the [v0.7.0 verification record](PROVISIONING_VERIFICATION.md) for the live
scratch-project provisioning and trace-isolation evidence.

## Verify OTLP ingestion

The smoke test has inline `uv` dependencies and remains isolated from the
project environment. It constructs one plain OTel span and exports it directly
to Langfuse using OTLP/HTTP with Basic auth:

```bash
uv run observability/smoke_test.py
```

The same OpenTelemetry dependencies are installed in the project environment,
so repository linting and type checks also cover the script. The smoke test
does not call a model provider or require provider API keys.

The command prints the 32-character trace ID after export. Open the Tracing
view in Langfuse and locate the trace named `manual OTLP smoke test`. The span
has two deliberately non-GenAI attributes (`smoke_test.phase` and
`smoke_test.purpose`). The resource service name is
`observability-ai-otel-smoke-test`. A failed export exits with an error instead
of reporting a successful trace.

To exercise the package facade after this direct connectivity check, run:

```bash
uv run examples/raw_otel_example.py
```

The example also reads `observability/.env` and creates a parent with concurrent
tool observations and raw OTel children. See the [package Quickstart](../README.md)
for its API and environment settings. Package sampling uses
`LANGFUSE_SAMPLE_RATE`; the `OTEL_TRACES_SAMPLER*` settings in the backend template
remain available for other OTel clients.

## Existing model-runtime stack

For an existing sibling checkout, move the ignored
`model-runtime/observability/.env` into `observability-ai/observability/.env`
alongside the relocated Compose file. Do not replace existing credentials with
new values when reusing the databases.

Both Compose files live in a directory named `observability`, so the default
Compose project name and named volumes stay the same. The commands above can
manage the existing containers from the new location without deleting data. If
you previously supplied a custom project name, keep supplying that name.

The `model-runtime` examples remain in their repository. Copy
`LANGFUSE_PUBLIC_KEY`, `LANGFUSE_SECRET_KEY`, `LANGFUSE_BASE_URL`, and any desired
`OTEL_*` client settings into `model-runtime/.env` beside the provider keys and
model IDs. The examples now load only that root file, with exported environment
variables taking precedence. See the
[runtime integration guide](../../model-runtime/observability/README.md).

## Troubleshooting and shutdown

| Provisioning failure | Action |
| --- | --- |
| Stack directory missing or incomplete | Set `--stack-dir` or `OBSERVABILITY_AI_STACK_DIR` to the checkout's `observability/` directory containing both `compose.yaml` and `.env`; relative paths start at the invoking directory. |
| Docker unavailable, Compose missing, or daemon unreachable | Install Compose v2 or newer, start Docker, and on WSL enable Docker Desktop integration for the distribution. Start the full central stack before provisioning. |
| Health timeout | Inspect `langfuse-web` startup logs and database status using the printed Compose command; retry with a larger `--timeout` after correcting startup failures. |
| Key verification failure | Confirm the base URL targets this stack and inspect startup logs. Restore the app's matching credentials or use `--rotate-keys`; an existing project cannot be moved to another organization through headless initialization. |
| Registered keys differ or are missing | Restore the original app `.env`, or rotate deliberately; the public registry cannot recover a lost secret. |
| `.provision.lock` exists | Wait for the active command; after a crash, confirm no provisioning process is running before removing the empty lock directory. |

If export returns `401`, confirm the public and secret keys belong to the same
project. If it cannot connect, check `docker compose ... ps` and inspect logs:

```bash
docker compose --env-file observability/.env \
  -f observability/compose.yaml logs --tail=100 langfuse-web langfuse-worker
```

Stop containers while retaining data:

```bash
docker compose --env-file observability/.env \
  -f observability/compose.yaml down
```

Adding `--volumes` to `down` permanently deletes the local Langfuse databases
and object storage.
