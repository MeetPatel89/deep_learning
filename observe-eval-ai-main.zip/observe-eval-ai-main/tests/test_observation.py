"""Exercise observation updates, generation attribution, and capture boundaries."""

from dataclasses import FrozenInstanceError, replace
from datetime import datetime
from json import loads
from typing import cast
from unittest.mock import Mock

from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.trace import INVALID_SPAN, get_current_span
from pytest import mark, raises

from observability_ai import (
    ContentCapturePolicy,
    Generation,
    LangfuseSettings,
    Observation,
    ObservationLevel,
    Telemetry,
    TraceAttributes,
)


def test_handle_updates_raw_span_and_is_frozen(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Explicit attributes, metadata, level, events, and exceptions reach the span."""
    telemetry, exporter = otel
    with telemetry.observe("work") as observation:
        assert isinstance(observation, Observation)
        assert get_current_span() is observation.span
        observation.set_attribute("app.count", 3)
        observation.set_attributes({"app.ready": True})
        observation.set_metadata({"route": "test", "attempts": 2})
        observation.set_level("WARNING", "retried")
        observation.add_event("checkpoint", {"step": 1}, timestamp=123)
        observation.record_exception(ValueError("recorded"), escaped=False)
        with raises(FrozenInstanceError):
            setattr(observation, "span", INVALID_SPAN)
        with raises(ValueError, match="level"):
            observation.set_level(cast(ObservationLevel, "bad"))
    (span,) = exporter.get_finished_spans()
    assert span.attributes == {
        "langfuse.observation.type": "span",
        "app.count": 3,
        "app.ready": True,
        "langfuse.observation.metadata.route": "test",
        "langfuse.observation.metadata.attempts": 2,
        "langfuse.observation.level": "WARNING",
        "langfuse.observation.status_message": "retried",
    }
    assert [event.name for event in span.events] == ["checkpoint", "exception"]
    assert span.events[0].timestamp == 123
    assert Observation(INVALID_SPAN).trace_id is None
    assert Observation(INVALID_SPAN).observation_id is None


@mark.parametrize("enabled, sampled", [(False, 1.0), (True, 0.0), (True, 1.0)])
def test_input_output_updates_share_redaction_and_recording_gate(
    settings: LangfuseSettings,
    enabled: bool,
    sampled: float,
) -> None:
    """Entry and later payloads use one policy, and skipped capture does no work."""
    redactor = Mock(return_value={"safe": True})
    exporter = InMemorySpanExporter()
    with Telemetry(
        replace(settings, sample_ratio=sampled),
        service_name="capture",
        service_version="1",
        span_processor=SimpleSpanProcessor(exporter),
        content_capture=ContentCapturePolicy(enabled=enabled, redactor=redactor),
    ) as telemetry:
        with telemetry.observe("work", input="secret") as observation:
            observation.set_output("result")
        observation.set_input("after end")
    if enabled and sampled:
        assert redactor.call_count == 2
        (span,) = exporter.get_finished_spans()
        assert span.attributes is not None
        assert span.attributes["langfuse.observation.input"] == '{"safe": true}'
        assert span.attributes["langfuse.observation.output"] == '{"safe": true}'
    else:
        redactor.assert_not_called()


def test_generation_attribution_and_updates(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Export model identity, parameters, usage, prompts, timing, and costs."""
    telemetry, exporter = otel
    with telemetry.generation(
        "answer", model="requested", provider_name="provider"
    ) as g:
        assert isinstance(g, Generation)
        g.set_model("requested", "returned")
        parameters = {"temperature": 0.3}
        g.set_model_parameters(parameters)
        parameters["temperature"] = 0.9
        g.set_usage(7, 3, 2)
        g.link_prompt("answer-prompt", 2)
        g.mark_completion_start()
        g.set_cost(input_cost=0, output_cost=0.02, total_cost=0.02)
    (span,) = exporter.get_finished_spans()
    attrs = span.attributes
    assert attrs is not None
    assert attrs["gen_ai.request.model"] == "requested"
    assert attrs["gen_ai.response.model"] == "returned"
    assert attrs["gen_ai.provider.name"] == "provider"
    assert attrs["gen_ai.operation.name"] == "chat"
    assert attrs["gen_ai.usage.input_tokens"] == 7
    assert attrs["gen_ai.usage.output_tokens"] == 3
    assert attrs["gen_ai.usage.cache_read.input_tokens"] == 2
    assert attrs["langfuse.observation.prompt.name"] == "answer-prompt"
    assert attrs["langfuse.observation.prompt.version"] == 2
    assert attrs["langfuse.observation.cost_details.input"] == 0
    assert attrs["langfuse.observation.cost_details.output"] == 0.02
    assert attrs["langfuse.observation.cost_details.total"] == 0.02
    params = attrs["langfuse.observation.model.parameters"]
    assert isinstance(params, str) and loads(params) == {"temperature": 0.3}
    first = attrs["langfuse.observation.completion_start_time"]
    assert isinstance(first, str)
    assert span.start_time is not None and span.end_time is not None
    assert span.start_time / 1e9 <= datetime.fromisoformat(first).timestamp()
    assert datetime.fromisoformat(first).timestamp() <= span.end_time / 1e9


def test_typed_helpers_propagate_and_event_has_zero_duration(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """New helpers carry dimensions, and an event leaves its parent's context intact."""
    telemetry, exporter = otel
    with telemetry.propagate(TraceAttributes(session_id="request")):
        with telemetry.agent("parent") as parent:
            for helper in (
                telemetry.retriever,
                telemetry.embedding,
                telemetry.guardrail,
                telemetry.evaluator,
            ):
                with helper(helper.__name__) as observation:
                    assert isinstance(observation, Observation)
            with telemetry.tool("search", call_id="call-1", description="Search docs"):
                pass
            event = telemetry.event("checkpoint")
            assert get_current_span() is parent.span
            assert not event.span.is_recording()
    spans = {span.name: span for span in exporter.get_finished_spans()}
    assert spans["checkpoint"].start_time == spans["checkpoint"].end_time
    for name, span in spans.items():
        assert span.attributes is not None
        assert span.attributes["langfuse.session.id"] == "request"
        if name not in {"parent", "search", "checkpoint"}:
            assert span.attributes["langfuse.observation.type"] == name
        if name != "parent":
            assert span.parent == spans["parent"].context
    assert spans["search"].attributes is not None
    assert spans["search"].attributes["gen_ai.tool.call.id"] == "call-1"
    assert spans["search"].attributes["gen_ai.tool.name"] == "search"
    assert spans["search"].attributes["gen_ai.tool.description"] == "Search docs"


def test_usage_updates_replace_previous_cached_count(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """New usage totals cannot retain a cache count larger than the new input total."""
    telemetry, exporter = otel
    with telemetry.generation("answer", model="model", provider_name="test") as g:
        g.set_usage(7, 3, 2)
        g.set_usage(0, 0)
    (span,) = exporter.get_finished_spans()
    assert span.attributes is not None
    assert span.attributes["gen_ai.usage.input_tokens"] == 0
    assert span.attributes["gen_ai.usage.cache_read.input_tokens"] == 0
