"""Small deterministic checks with no model or backend dependencies."""

from collections.abc import Mapping, Sized
from dataclasses import dataclass, field
from math import isclose
from re import Pattern, compile

from ..config import _validate_text
from ._json import _strict_json
from .results import EvaluationResult, _validated_value


def _text(value: object, name: str) -> str:
    if not isinstance(value, str):
        raise TypeError(f"{name} must be a string")
    return value


def _nonnegative_number(value: float, name: str) -> None:
    number = _validated_value(name, value, "NUMERIC", None)
    if not isinstance(number, float) or number < 0:
        raise ValueError(f"{name} must be nonnegative")


def _nonnegative_integer(value: int, name: str) -> None:
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{name} must be an integer")
    if value < 0:
        raise ValueError(f"{name} must be nonnegative")


@dataclass(frozen=True, slots=True)
class ExactMatch:
    """Compare output to expected_output using Python equality, without coercion."""

    name: str = "exact_match"

    def __post_init__(self) -> None:
        """Require a usable score name."""
        _validate_text("name", self.name)

    def __call__(
        self,
        *,
        input: object = None,
        output: object,
        expected_output: object = None,
        metadata: Mapping[str, object] | None = None,
    ) -> EvaluationResult:
        """Return a boolean score for exact equality."""
        return EvaluationResult(self.name, output == expected_output, "BOOLEAN")


@dataclass(frozen=True, slots=True)
class Contains:
    """Check whether a string output contains the expected string, case-sensitively."""

    name: str = "contains"

    def __post_init__(self) -> None:
        """Require a usable score name."""
        _validate_text("name", self.name)

    def __call__(
        self,
        *,
        input: object = None,
        output: object,
        expected_output: object = None,
        metadata: Mapping[str, object] | None = None,
    ) -> EvaluationResult:
        """Use substring membership; an empty expected string matches."""
        matched = _text(expected_output, "expected_output") in _text(output, "output")
        return EvaluationResult(self.name, matched, "BOOLEAN")


@dataclass(frozen=True, slots=True)
class RegexMatch:
    """Search string output with a precompiled regular expression."""

    pattern: str
    flags: int = 0
    name: str = "regex_match"
    _compiled: Pattern[str] = field(init=False, repr=False, compare=False)

    def __post_init__(self) -> None:
        """Compile once, rejecting invalid expressions at configuration time."""
        _validate_text("name", self.name)
        _text(self.pattern, "pattern")
        object.__setattr__(self, "_compiled", compile(self.pattern, self.flags))

    def __call__(
        self,
        *,
        input: object = None,
        output: object,
        expected_output: object = None,
        metadata: Mapping[str, object] | None = None,
    ) -> EvaluationResult:
        """Return true for any match; use anchors when a full match is needed."""
        matched = self._compiled.search(_text(output, "output")) is not None
        return EvaluationResult(self.name, matched, "BOOLEAN")


@dataclass(frozen=True, slots=True)
class NumericTolerance:
    """Compare finite numbers with absolute and relative math.isclose tolerances."""

    abs_tolerance: float = 0.0
    rel_tolerance: float = 0.0
    name: str = "numeric_tolerance"

    def __post_init__(self) -> None:
        """Reject negative, non-finite, or boolean tolerances."""
        _validate_text("name", self.name)
        _nonnegative_number(self.abs_tolerance, "abs_tolerance")
        _nonnegative_number(self.rel_tolerance, "rel_tolerance")

    def __call__(
        self,
        *,
        input: object = None,
        output: object,
        expected_output: object = None,
        metadata: Mapping[str, object] | None = None,
    ) -> EvaluationResult:
        """Reject numeric strings and booleans instead of coercing them."""
        values: list[float] = []
        for name, value in (("output", output), ("expected_output", expected_output)):
            if isinstance(value, bool) or not isinstance(value, (float, int)):
                raise TypeError(f"{name} must be a number, not a boolean")
            checked = _validated_value(name, value, "NUMERIC", None)
            assert isinstance(checked, float)
            values.append(checked)
        matched = isclose(
            values[0], values[1], rel_tol=self.rel_tolerance, abs_tol=self.abs_tolerance
        )
        return EvaluationResult(self.name, matched, "BOOLEAN")


@dataclass(frozen=True, slots=True)
class JsonParsable:
    """Accept one JSON value, rejecting non-finite constants and duplicate keys."""

    name: str = "json_parsable"

    def __post_init__(self) -> None:
        """Require a usable score name."""
        _validate_text("name", self.name)

    def __call__(
        self,
        *,
        input: object = None,
        output: object,
        expected_output: object = None,
        metadata: Mapping[str, object] | None = None,
    ) -> EvaluationResult:
        """Return false for malformed JSON text; non-string output is an error."""
        text = _text(output, "output")
        try:
            _strict_json(text)
        except ValueError:
            return EvaluationResult(self.name, False, "BOOLEAN")
        return EvaluationResult(self.name, True, "BOOLEAN")


@dataclass(frozen=True, slots=True)
class LengthWithin:
    """Check inclusive len() bounds on a string, collection, or other Sized output."""

    min_length: int = 0
    max_length: int | None = None
    name: str = "length_within"

    def __post_init__(self) -> None:
        """Require ordered, nonnegative integer bounds."""
        _validate_text("name", self.name)
        _nonnegative_integer(self.min_length, "min_length")
        if self.max_length is not None:
            _nonnegative_integer(self.max_length, "max_length")
            if self.max_length < self.min_length:
                raise ValueError("max_length must be at least min_length")

    def __call__(
        self,
        *,
        input: object = None,
        output: object,
        expected_output: object = None,
        metadata: Mapping[str, object] | None = None,
    ) -> EvaluationResult:
        """Measure characters/items, not bytes or tokens unless output does so."""
        if not isinstance(output, Sized):
            raise TypeError("output must support len()")
        size = len(output)
        matched = size >= self.min_length and (
            self.max_length is None or size <= self.max_length
        )
        return EvaluationResult(self.name, matched, "BOOLEAN")
