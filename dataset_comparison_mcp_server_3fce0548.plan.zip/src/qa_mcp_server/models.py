"""Validated tool inputs. Paths refer to the machine running the server."""

from pathlib import Path
from typing import Annotated, Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator


class Model(BaseModel):
    model_config = ConfigDict(extra="forbid")


class SQLConnection(Model):
    server: str = Field(min_length=1)
    database: str = Field(min_length=1)
    username: str | None = None
    driver: str = Field(default="ODBC Driver 18 for SQL Server", min_length=1)
    timeout: int = Field(default=30, gt=0)


class SQLSource(SQLConnection):
    type: Literal["sql"] = "sql"
    query: str | None = Field(default=None, min_length=1)
    query_file: Path | None = None

    @model_validator(mode="after")
    def exactly_one_query(self):
        if (self.query is None) == (self.query_file is None):
            raise ValueError("Specify exactly one of query or query_file")
        if self.query is not None and not self.query.strip():
            raise ValueError("query must not be blank")
        return self


class CSVSource(Model):
    type: Literal["csv"] = "csv"
    path: Path
    delimiter: str = Field(default=",", min_length=1, max_length=1)
    encoding: str = "utf-8"
    has_header: bool = True
    null_values: str | list[str] | dict[str, str] | None = None

    @model_validator(mode="after")
    def single_byte_delimiter(self):
        if len(self.delimiter.encode("utf-8")) != 1:
            raise ValueError("delimiter must be a single byte")
        return self


class ParquetSource(Model):
    type: Literal["parquet"] = "parquet"
    path: Path


class ExcelSource(Model):
    type: Literal["excel"] = "excel"
    path: Path
    sheet: str | int | None = None


class InlineSource(Model):
    type: Literal["inline"] = "inline"
    rows: list[dict[str, Any]]


DatasetSource = Annotated[
    SQLSource | CSVSource | ParquetSource | ExcelSource | InlineSource,
    Field(discriminator="type"),
]


class CompareOptions(Model):
    primary_keys: list[str] | None = None
    column_mapping: dict[str, str] = Field(default_factory=dict)
    ignore_columns: list[str] = Field(default_factory=list)
    numeric_tolerance: float = Field(default=0, ge=0, allow_inf_nan=False)
    trim_strings: bool = False
    case_insensitive: bool = False
    treat_null_as_equal: bool = True
    memory_budget_mb: float = Field(default=1024, gt=0, allow_inf_nan=False)
    num_partitions: int | None = Field(default=None, ge=1, le=65536)

    @model_validator(mode="after")
    def unambiguous_columns(self):
        if len(set(self.primary_keys or [])) != len(self.primary_keys or []):
            raise ValueError("primary_keys must be unique")
        if len(set(self.column_mapping.values())) != len(self.column_mapping):
            raise ValueError("column_mapping must be one-to-one")
        if set(self.primary_keys or []) & set(self.ignore_columns):
            raise ValueError("Cannot ignore a primary key")
        return self


class OutputOptions(Model):
    output_dir: Path = Path("reports")
    max_rows_per_file: int = Field(default=100_000, ge=1, le=1_048_575)
    include_matched_rows: bool = False
    max_total_report_rows: int | None = Field(default=None, ge=0)
