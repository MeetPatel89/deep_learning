"""Shared infrastructure for independent data MCP servers (no MCP dependency)."""
