---
doc_id: CHG-2411
title: Update Databricks Runtime and Synapse/Fabric Refresh Pipeline for Payments Reporting Service
doc_type: change_record
service_id: svc_payments_reporting
owner_group: Data Applications
visibility: internal
status: completed
created_at: "2026-06-13T13:00:00"
updated_at: "2026-06-15T22:35:00"
related_records:
  - KI-221
  - INC-1217
  - REL-PAYMENTS-2026-06
  - TASK-CHG-2411
  - POL-CAB-001
source_facts:
  - CHG-2411
  - KI-221
  - svc_payments_reporting
difficulty_tags:
  - azure-data-stack
  - change-to-incident-linkage
  - temporal-reasoning
servicenow:
  table: change_request
  number: CHG002411
  type: Normal
  state: Closed
  close_code: Successful
  risk: High
  impact: 2
  cab_required: true
  cab_date: "2026-06-14"
  approval: Approved
  approval_policy: POL-CAB-001
  business_service: Payments Reporting Service
  cmdb_ci: Payments Reporting Pipeline
  assignment_group: Data Applications
  requested_by_group: Data Applications
  related_incident: INC001217
  related_known_issue: KI00221
  visibility: internal
  contains_customer_safe_wording: false
---

# Update Databricks Runtime and Synapse/Fabric Refresh Pipeline for Payments Reporting Service

## Record details

| Field | Value |
| --- | --- |
| Table | change_request |
| Number | CHG002411 |
| Type | Normal |
| State | Closed |
| Close code | Successful |
| Risk | High |
| Impact | 2 |
| CAB required | true |
| CAB date | 2026-06-14 |
| Approval | Approved |
| Approval policy | POL-CAB-001 |
| Business service | Payments Reporting Service |
| Configuration item | Payments Reporting Pipeline |
| Assignment group | Data Applications |
| Requested by group | Data Applications |
| Related incident | INC001217 |
| Related known issue | KI00221 |
| Visibility | internal |
| Contains customer-safe wording | false |

## Change summary

CHG-2411 updated Databricks runtime and Synapse/Fabric refresh pipeline behavior for Payments Reporting Service. The service provides dashboards and exports for payment operations, and the change was owned by Data Applications.

Change updated Databricks runtime and Synapse/Fabric refresh pipeline.

Change risk was high.

Change risk was high because the release touched the payment reporting data path used by dashboards and exports. Related known issue is KI-221.

## Change window

Change window was 2026-06-15T21:00:00 to 2026-06-15T22:30:00.

| Field | Value |
| --- | --- |
| Planned start | 2026-06-15T21:00:00 |
| Planned end | 2026-06-15T22:30:00 |
| Owner group | Data Applications |
| Service | Payments Reporting Service |
| Risk | High |
| Status | Completed |

The change record was updated at 2026-06-15T22:35:00 after implementation completion.

## Services affected

Primary service:

- Payments Reporting Service, service ID svc_payments_reporting.

Dependencies in scope:

- Azure Synapse Analytics.
- Microsoft Fabric.
- Azure SQL Database.
- Azure Databricks.
- Internal API Gateway.

The expected user-facing behavior was improved reporting refresh reliability without changes to the payment operations dashboard workflow.

## Implementation notes

The implementation updated the Databricks runtime and the downstream Synapse/Fabric reporting refresh pipeline. Data Applications treated the deployment as high risk because the transformation job, control data, and reporting layer all needed to remain aligned.

Implementation notes indicated the change completed in the planned window. No immediate rollback was recorded in the change record.

## Validation performed

Post-change validation included:

- Confirming the Databricks transformation path completed.
- Confirming the reporting refresh pipeline ran after the runtime update.
- Checking expected availability of Payments Reporting Service dashboards and exports.

The later incident, INC-1217, showed that a successful transformation alone was not enough to prove reporting freshness. The incident began after CHG-2411 completed, and the reporting layer still showed the previous refresh watermark.

## Risk and rollback notes

The primary risk was reporting freshness divergence: the source transaction path and transformation job could appear current while the Synapse/Fabric reporting layer remained behind. KI-221 documents this known issue pattern.

Rollback would have required Data Applications to revert the pipeline behavior and confirm reporting refresh state. Rollback was not used for INC-1217 because recovery was achieved by rerunning the reporting refresh and backfilling from the last successful payment partition.

## Post-change monitoring

Monitor for the following within the first reporting cycles after CHG-2411:

- Payments dashboard data stale by more than four hours.
- Payment export totals that do not match the operational transaction view.
- Databricks transformation success with reporting layer still behind.
- Azure SQL Database staging tables containing current records while Synapse/Fabric shows an old watermark.

If these conditions appear, link KI-221, escalate to Data Applications, and use RUNBOOK-PAY-007.

## Related records

- KI-221: Payments Dashboard Data Freshness Delay After Synapse/Fabric Refresh Failure.
- INC-1217: Payments Dashboard Stale After Refresh Pipeline Update.
- REL-PAYMENTS-2026-06: June 2026 Payments Reporting Pipeline Release Notes.
- TASK-CHG-2411: Change tasks created and completed under CHG-2411.
- POL-CAB-001: CAB approval policy applied to CHG-2411.
