"""SQL pool queries, metadata and dedicated/serverless diagnostics."""

from typing import Any, Literal

import polars as pl
from data_mcp_core import formats, sql
from data_mcp_core.guards import planned_action, require
from data_mcp_core.results import bounded_result, cap_rows
from data_mcp_core.stores import resolve_path


def sql_literal(value: str) -> str:
    return "N'" + value.replace("'", "''") + "'"


class SQLTools:
    def _sql_connection(self, workspace, pool=None, database=None):
        settings = self.live_workspace(workspace, "sql")
        pool = pool or settings.default_dedicated_pool or "serverless"
        database = database or (
            settings.serverless_database if pool in {"serverless", "ondemand"} else pool
        )
        return sql.SQLConnection(
            workspace=settings.name,
            pool=pool,
            database=database,
            driver=settings.sql_driver,
            timeout=settings.sql_timeout,
            auth="token",
            auth_profile=self.config.auth_profile(settings.auth),
        )

    def _sql_read(self, workspace, query, pool=None, database=None, limit=1000):
        connection = self._sql_connection(workspace, pool, database)
        source = sql.SQLSource(
            **connection.model_dump(), auth_profile=connection.auth_profile, query=query
        )
        frames, count = [], 0
        batches = sql.iter_sql_batches(source, min(10_000, limit + 1))
        try:
            for frame in batches:
                frames.append(frame.head(limit + 1 - count))
                count += frames[-1].height
                if count > limit:
                    break
        finally:
            batches.close()
        frame = pl.concat(frames, how="vertical_relaxed") if frames else pl.DataFrame()
        return cap_rows(frame.to_dicts(), limit)

    def test_sql_connection(
        self, workspace: str, pool: str | None = None, database: str | None = None
    ) -> dict[str, Any]:
        """Run SELECT 1 on a dedicated or serverless SQL endpoint using an Entra token."""
        return sql.test_connection(self._sql_connection(workspace, pool, database))

    def run_sql_query(
        self,
        workspace: str,
        query: str,
        pool: str | None = None,
        database: str | None = None,
        limit: int = 100,
        output_store: str | None = None,
        output_path: str | None = None,
        output_format: Literal["parquet", "csv"] = "parquet",
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Run classified T-SQL; writes require allow_sql_write and exports require store
        allow_write.
        """
        settings = self.live_workspace(workspace, "sql")
        if not 1 <= limit <= 1000:
            raise ValueError("limit must be between 1 and 1000")
        read_only = True
        try:
            sql.ensure_read_only(query)
        except PermissionError:
            read_only = False
            require(settings, "allow_sql_write")
        output = None
        if output_store is not None or output_path is not None:
            if not output_store or not output_path:
                raise ValueError("Export requires output_store and output_path")
            output = resolve_path(
                output_path,
                store=output_store,
                stores=self.config.stores,
                auth_profiles=self.config.auth_profiles,
                allowed_local_roots=self.config.allowed_local_roots,
            )
            require(output.store, "allow_write")
            if not read_only:
                raise ValueError("SQL export requires a read-only query")
        plan = planned_action(
            "run_sql_query",
            dry_run,
            workspace=workspace,
            pool=pool,
            database=database,
            query=query,
            output_store=output_store,
            output_path=output_path,
            read_only=read_only,
        )
        if plan:
            return plan
        if not read_only:
            return bounded_result(
                sql.execute_sql(self._sql_connection(workspace, pool, database), query)
            )
        if output:
            connection = self._sql_connection(workspace, pool, database)
            source = sql.SQLSource(
                **connection.model_dump(), auth_profile=connection.auth_profile, query=query
            )
            frames = list(sql.iter_sql_batches(source, 10_000))
            frame = pl.concat(frames, how="vertical_relaxed") if frames else pl.DataFrame()
            return formats.write_dataset(frame, output, output_format)
        return self._sql_read(workspace, query, pool, database, limit)

    def list_sql_objects(
        self,
        workspace: str,
        pool: str | None = None,
        database: str | None = None,
        object_type: Literal[
            "table", "view", "procedure", "external_table", "data_source", "file_format"
        ] = "table",
        schema: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        """List SQL tables, views, procedures, external tables, data sources or file formats."""
        if object_type in {"data_source", "file_format"}:
            view = (
                "sys.external_data_sources"
                if object_type == "data_source"
                else "sys.external_file_formats"
            )
            query = f"SELECT * FROM {view}"
        else:
            views = {
                "table": "sys.tables",
                "view": "sys.views",
                "procedure": "sys.procedures",
                "external_table": "sys.external_tables",
            }
            query = (
                f"SELECT s.name AS schema_name, o.name, o.object_id FROM "
                f"{views[object_type]} o JOIN sys.schemas s ON o.schema_id=s.schema_id"
            )
            if schema:
                query += " WHERE s.name=" + sql_literal(schema)
        return self.run_sql_query(workspace, query, pool, database, limit)

    def describe_table(
        self,
        workspace: str,
        table: str,
        schema: str = "dbo",
        pool: str | None = None,
        database: str | None = None,
    ) -> dict[str, Any]:
        """Describe columns, index, distribution, partitions and dedicated-pool row counts."""
        object_id = f"OBJECT_ID({sql_literal(schema + '.' + table)})"
        columns = self._sql_read(
            workspace,
            (
                f"SELECT c.name, t.name AS data_type, c.max_length, c.precision, "
                f"c.scale, c.is_nullable, c.column_id FROM sys.columns c JOIN "
                f"sys.types t ON c.user_type_id=t.user_type_id WHERE "
                f"c.object_id={object_id} ORDER BY c.column_id"
            ),
            pool,
            database,
        )
        indexes = self._sql_read(
            workspace,
            f"SELECT name, type_desc, is_unique FROM sys.indexes WHERE object_id={object_id}",
            pool,
            database,
        )
        partition_columns = self._sql_read(
            workspace,
            (
                f"SELECT c.name, ic.partition_ordinal FROM sys.index_columns ic JOIN "
                f"sys.columns c ON ic.object_id=c.object_id AND "
                f"ic.column_id=c.column_id WHERE ic.object_id={object_id} AND "
                f"ic.partition_ordinal > 0"
            ),
            pool,
            database,
        )
        result = {
            "columns": columns["rows"],
            "indexes": indexes["rows"],
            "partition_columns": partition_columns["rows"],
        }
        connection = self._sql_connection(workspace, pool, database)
        if connection.pool not in {"serverless", "ondemand"}:
            result["distribution"] = self._sql_read(
                workspace,
                (
                    f"SELECT distribution_policy_desc FROM "
                    f"sys.pdw_table_distribution_properties WHERE "
                    f"object_id={object_id}"
                ),
                pool,
                database,
            )["rows"]
            # Node partition row counts must be joined through the physical table mapping.
            result["partitions"] = self._sql_read(
                workspace,
                (
                    f"SELECT p.partition_number, SUM(p.row_count) AS row_count FROM "
                    f"sys.dm_pdw_nodes_db_partition_stats p JOIN sys.pdw_nodes_tables "
                    f"nt ON p.object_id=nt.object_id AND p.pdw_node_id=nt.pdw_node_id "
                    f"AND p.distribution_id=nt.distribution_id JOIN "
                    f"sys.pdw_table_mappings tm ON nt.name=tm.physical_name WHERE "
                    f"tm.object_id={object_id} AND p.index_id IN (0,1) GROUP BY "
                    f"p.partition_number"
                ),
                pool,
                database,
            )["rows"]
        else:
            result["row_count_note"] = (
                "External/serverless table row counts require scanning the external data."
            )
        return bounded_result(result)

    def get_object_definition(
        self,
        workspace: str,
        name: str,
        schema: str = "dbo",
        pool: str | None = None,
        database: str | None = None,
    ) -> dict[str, Any]:
        """Read a view, procedure or function definition through OBJECT_DEFINITION."""
        query = (
            f"SELECT OBJECT_DEFINITION(OBJECT_ID({sql_literal(schema + '.' + name)})) AS definition"
        )
        return self.run_sql_query(workspace, query, pool, database)

    def explain_query(
        self, workspace: str, query: str, pool: str | None = None, database: str | None = None
    ) -> dict[str, Any]:
        """Get an EXPLAIN plan for a read-only dedicated-pool query."""
        sql.ensure_read_only(query)
        connection = self._sql_connection(workspace, pool, database)
        if connection.pool in {"serverless", "ondemand"}:
            raise ValueError(
                "EXPLAIN requires a dedicated SQL pool; use Synapse Studio for serverless plans"
            )
        return self._sql_read(workspace, "EXPLAIN " + query, pool, database, 100)

    def _dedicated(self, workspace, pool, database):
        connection = self._sql_connection(workspace, pool, database)
        if connection.pool in {"serverless", "ondemand"}:
            raise ValueError("This diagnostic requires a dedicated SQL pool")

    def list_active_requests(
        self, workspace: str, pool: str | None = None, database: str | None = None, limit: int = 100
    ) -> dict[str, Any]:
        """List active dedicated-pool requests from sys.dm_pdw_exec_requests."""
        self._dedicated(workspace, pool, database)
        return self.run_sql_query(
            workspace,
            (
                "SELECT * FROM sys.dm_pdw_exec_requests WHERE status NOT IN "
                "('Completed','Failed','Cancelled') ORDER BY submit_time DESC"
            ),
            pool,
            database,
            limit,
        )

    def get_request_steps(
        self,
        workspace: str,
        request_id: str,
        pool: str | None = None,
        database: str | None = None,
        limit: int = 100,
    ) -> dict[str, Any]:
        """Get distributed execution steps for a dedicated-pool request."""
        self._dedicated(workspace, pool, database)
        return self.run_sql_query(
            workspace,
            (
                f"SELECT * FROM sys.dm_pdw_request_steps WHERE "
                f"request_id={sql_literal(request_id)} ORDER BY step_index"
            ),
            pool,
            database,
            limit,
        )

    def check_table_skew(
        self,
        workspace: str,
        table: str,
        schema: str = "dbo",
        pool: str | None = None,
        database: str | None = None,
    ) -> dict[str, Any]:
        """Measure per-distribution row counts and maximum/mean skew for a dedicated table."""
        self._dedicated(workspace, pool, database)
        object_id = f"OBJECT_ID({sql_literal(schema + '.' + table)})"
        query = (
            f"SELECT p.distribution_id, SUM(p.row_count) AS row_count FROM "
            f"sys.dm_pdw_nodes_db_partition_stats p JOIN sys.pdw_nodes_tables nt ON "
            f"p.object_id=nt.object_id AND p.pdw_node_id=nt.pdw_node_id AND "
            f"p.distribution_id=nt.distribution_id JOIN sys.pdw_table_mappings tm ON "
            f"nt.name=tm.physical_name WHERE tm.object_id={object_id} AND p.index_id "
            f"IN (0,1) GROUP BY p.distribution_id"
        )
        rows = self._sql_read(workspace, query, pool, database)["rows"]
        counts = [row["row_count"] or 0 for row in rows]
        mean = sum(counts) / len(counts) if counts else 0
        return {
            "distributions": rows,
            "max_to_mean": max(counts) / mean if mean else None,
            "total_rows": sum(counts),
            "distribution_count": len(counts),
        }

    def query_history(
        self, workspace: str, database: str | None = None, limit: int = 100
    ) -> dict[str, Any]:
        """Read recent serverless SQL requests from sys.dm_exec_requests_history."""
        return self.run_sql_query(
            workspace,
            "SELECT * FROM sys.dm_exec_requests_history ORDER BY start_time DESC",
            "serverless",
            database,
            limit,
        )
