"""SDK-independent score values and the shared evaluator contract."""

from collections.abc import Awaitable, Mapping, Sequence
from dataclasses import dataclass, field
from math import isfinite
from types import MappingProxyType
from typing import Literal, Protocol

from ..config import _validate_text

type ScoreDataType = Literal["NUMERIC", "CATEGORICAL", "BOOLEAN", "TEXT"]


def _validated_value(
    name: str,
    value: float | str,
    data_type: ScoreDataType,
    comment: str | None,
) -> float | str:
    """Validate the score contract and normalize booleans to SDK numbers."""
    _validate_text("name", name)
    if comment is not None and not isinstance(comment, str):
        raise TypeError("comment must be a string")
    if data_type in ("CATEGORICAL", "TEXT"):
        if not isinstance(value, str):
            raise TypeError("value must be a string")
        _validate_text("value", value)
        if data_type == "TEXT" and len(value) > 500:
            raise ValueError("TEXT value must contain at most 500 characters")
        return value
    if data_type == "BOOLEAN":
        if not isinstance(value, (int, float)):
            raise TypeError("BOOLEAN value must be a boolean or numeric 0 or 1")
        if value not in (0, 1):
            raise ValueError("BOOLEAN value must be 0 or 1")
        return float(value)
    if data_type == "NUMERIC":
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise TypeError("NUMERIC value must be a number, not a boolean")
        try:
            number = float(value)
        except OverflowError as exc:
            raise ValueError("NUMERIC value must be finite") from exc
        if not isfinite(number):
            raise ValueError("NUMERIC value must be finite")
        return number
    raise ValueError("data_type must be NUMERIC, CATEGORICAL, BOOLEAN, or TEXT")


def _metadata_snapshot(metadata: Mapping[str, object]) -> Mapping[str, object]:
    if not isinstance(metadata, Mapping):
        raise TypeError("metadata must be a mapping")
    snapshot = dict(metadata)
    for key in snapshot:
        _validate_text("metadata key", key)
    return MappingProxyType(snapshot)


@dataclass(frozen=True, slots=True)
class EvaluationResult:
    """One validated score with a read-only, shallow snapshot of its metadata.

    Numeric and boolean values are normalized to floats. Nested metadata values
    remain application-owned; result construction does not serialize payloads.
    """

    name: str
    value: float | str
    data_type: ScoreDataType = "NUMERIC"
    comment: str | None = None
    metadata: Mapping[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate scores before they reach a sink or experiment runner."""
        object.__setattr__(
            self,
            "value",
            _validated_value(self.name, self.value, self.data_type, self.comment),
        )
        object.__setattr__(self, "metadata", _metadata_snapshot(self.metadata))


type EvaluationOutput = EvaluationResult | Sequence[EvaluationResult]


class Evaluator(Protocol):
    """Evaluate keyword-only application values, synchronously or asynchronously."""

    def __call__(
        self,
        *,
        input: object,
        output: object,
        expected_output: object,
        metadata: Mapping[str, object] | None,
    ) -> EvaluationOutput | Awaitable[EvaluationOutput]:
        """Return one score or a sequence; exceptions propagate to the caller."""
        ...
