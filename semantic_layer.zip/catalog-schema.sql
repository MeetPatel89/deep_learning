-- V1 SQLite semantic catalog. This file never runs against Azure SQL.
-- Enable foreign keys on EACH connection before beginning a transaction.
-- Requires SQLite JSON functions. Publisher validates all payload schemas,
-- specialized object kinds, lifecycle, field ownership and business rules.
PRAGMA foreign_keys = ON;

CREATE TABLE catalog_release (
    release_id TEXT PRIMARY KEY,
    schema_version INTEGER NOT NULL CHECK (schema_version > 0),
    status TEXT NOT NULL CHECK (status IN ('draft','reviewed','published','retired')),
    content_sha256 TEXT,
    created_at TEXT NOT NULL,
    published_at TEXT,
    CHECK (status <> 'published' OR
           (content_sha256 IS NOT NULL AND published_at IS NOT NULL))
);
CREATE TABLE active_catalog (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id)
);
CREATE TABLE catalog_object (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    object_id TEXT NOT NULL,
    object_kind TEXT NOT NULL CHECK (object_kind IN
      ('entity','field','value_domain','canonical_value','relationship',
       'predicate','metric')),
    label TEXT NOT NULL,
    description TEXT NOT NULL,
    owner TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('draft','reviewed','published','deprecated')),
    provenance_json TEXT NOT NULL CHECK (json_valid(provenance_json)),
    PRIMARY KEY (release_id, object_id)
);
CREATE TABLE entity (
    release_id TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    connection_ref TEXT NOT NULL,
    physical_schema TEXT NOT NULL,
    physical_object TEXT NOT NULL,
    grain_description TEXT NOT NULL,
    keys_json TEXT NOT NULL CHECK (json_valid(keys_json)),
    identity_namespace TEXT NOT NULL,
    temporal_json TEXT NOT NULL CHECK (json_valid(temporal_json)),
    access_policy_ref TEXT NOT NULL,
    PRIMARY KEY (release_id, entity_id),
    FOREIGN KEY (release_id, entity_id)
      REFERENCES catalog_object(release_id, object_id)
);
CREATE TABLE value_domain (
    release_id TEXT NOT NULL,
    domain_id TEXT NOT NULL,
    normalization_json TEXT NOT NULL CHECK (json_valid(normalization_json)),
    resolution_policy_json TEXT NOT NULL CHECK (json_valid(resolution_policy_json)),
    PRIMARY KEY (release_id, domain_id),
    FOREIGN KEY (release_id, domain_id)
      REFERENCES catalog_object(release_id, object_id)
);
CREATE TABLE field (
    release_id TEXT NOT NULL,
    field_id TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    physical_column TEXT NOT NULL,
    physical_type TEXT NOT NULL,
    semantic_type TEXT NOT NULL,
    nullable INTEGER NOT NULL CHECK (nullable IN (0,1)),
    null_meaning TEXT NOT NULL,
    roles_json TEXT NOT NULL CHECK (json_valid(roles_json)),
    operators_json TEXT NOT NULL CHECK (json_valid(operators_json)),
    aliases_json TEXT NOT NULL CHECK (json_valid(aliases_json)),
    sensitivity TEXT NOT NULL,
    domain_id TEXT,
    PRIMARY KEY (release_id, field_id),
    FOREIGN KEY (release_id, field_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, entity_id) REFERENCES entity(release_id, entity_id),
    FOREIGN KEY (release_id, domain_id) REFERENCES value_domain(release_id, domain_id),
    UNIQUE (release_id, entity_id, physical_column)
);
CREATE TABLE canonical_value (
    release_id TEXT NOT NULL,
    value_id TEXT NOT NULL,
    domain_id TEXT NOT NULL,
    PRIMARY KEY (release_id, value_id),
    FOREIGN KEY (release_id, value_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, domain_id) REFERENCES value_domain(release_id, domain_id)
);
CREATE TABLE value_alias (
    release_id TEXT NOT NULL,
    value_id TEXT NOT NULL,
    locale TEXT NOT NULL,
    normalized_alias TEXT NOT NULL,
    PRIMARY KEY (release_id, value_id, locale, normalized_alias),
    FOREIGN KEY (release_id, value_id)
      REFERENCES canonical_value(release_id, value_id)
    -- Intentionally permits the same alias for different values.
    -- Resolver reports ambiguity; publisher prevents silent last-write wins.
);
CREATE INDEX value_alias_lookup
  ON value_alias(release_id, locale, normalized_alias);
CREATE TABLE value_binding (
    release_id TEXT NOT NULL,
    binding_id TEXT NOT NULL,
    value_id TEXT NOT NULL,
    field_id TEXT NOT NULL,
    literal_type TEXT NOT NULL CHECK (literal_type IN
      ('string','integer','decimal','boolean','date','timestamp')),
    literal_json TEXT NOT NULL CHECK (json_valid(literal_json)),
    valid_from TEXT NOT NULL,
    valid_to TEXT,
    PRIMARY KEY (release_id, binding_id),
    FOREIGN KEY (release_id, value_id)
      REFERENCES canonical_value(release_id, value_id),
    FOREIGN KEY (release_id, field_id) REFERENCES field(release_id, field_id),
    CHECK (valid_to IS NULL OR valid_from < valid_to)
);
CREATE INDEX value_binding_lookup
  ON value_binding(release_id, value_id, field_id, valid_from);
CREATE TABLE relationship (
    release_id TEXT NOT NULL,
    relationship_id TEXT NOT NULL,
    source_entity_id TEXT NOT NULL,
    target_entity_id TEXT NOT NULL,
    source_role TEXT NOT NULL,
    target_role TEXT NOT NULL,
    key_pairs_json TEXT NOT NULL CHECK (json_valid(key_pairs_json)),
    cardinality_json TEXT NOT NULL CHECK (json_valid(cardinality_json)),
    required_predicates_json TEXT NOT NULL CHECK (json_valid(required_predicates_json)),
    identity_json TEXT NOT NULL CHECK (json_valid(identity_json)),
    temporal_json TEXT NOT NULL CHECK (json_valid(temporal_json)),
    PRIMARY KEY (release_id, relationship_id),
    FOREIGN KEY (release_id, relationship_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, source_entity_id) REFERENCES entity(release_id, entity_id),
    FOREIGN KEY (release_id, target_entity_id) REFERENCES entity(release_id, entity_id)
);
CREATE INDEX relationship_outgoing
  ON relationship(release_id, source_entity_id);
CREATE TABLE relationship_operation (
    release_id TEXT NOT NULL,
    operation_id TEXT NOT NULL,
    relationship_id TEXT NOT NULL,
    operator TEXT NOT NULL CHECK (operator IN
      ('exists','not_exists','enrich_left','expand_left')),
    contract_json TEXT NOT NULL CHECK (json_valid(contract_json)),
    PRIMARY KEY (release_id, operation_id),
    FOREIGN KEY (release_id, relationship_id)
      REFERENCES relationship(release_id, relationship_id)
);
CREATE TABLE predicate (
    release_id TEXT NOT NULL,
    predicate_id TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    expression_json TEXT NOT NULL CHECK (json_valid(expression_json)),
    purpose TEXT NOT NULL CHECK (purpose IN
      ('business','source_restriction','security_restriction')),
    PRIMARY KEY (release_id, predicate_id),
    FOREIGN KEY (release_id, predicate_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, entity_id) REFERENCES entity(release_id, entity_id)
);
CREATE TABLE metric (
    release_id TEXT NOT NULL,
    metric_id TEXT NOT NULL,
    base_entity_id TEXT NOT NULL,
    definition_json TEXT NOT NULL CHECK (json_valid(definition_json)),
    PRIMARY KEY (release_id, metric_id),
    FOREIGN KEY (release_id, metric_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, base_entity_id) REFERENCES entity(release_id, entity_id)
);
CREATE TABLE verified_example (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    example_id TEXT NOT NULL,
    question TEXT NOT NULL,
    semantic_query_json TEXT NOT NULL CHECK (json_valid(semantic_query_json)),
    reference_sql TEXT,
    fixture_id TEXT NOT NULL,
    expected_json TEXT NOT NULL CHECK (json_valid(expected_json)),
    review_status TEXT NOT NULL CHECK (review_status IN ('draft','approved','rejected')),
    reviewer TEXT,
    PRIMARY KEY (release_id, example_id)
);
CREATE TABLE assertion (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    assertion_id TEXT NOT NULL,
    subject_id TEXT NOT NULL,
    requirement_json TEXT NOT NULL CHECK (json_valid(requirement_json)),
    evidence_json TEXT NOT NULL CHECK (json_valid(evidence_json)),
    valid_until TEXT,
    failure_action_json TEXT NOT NULL CHECK (json_valid(failure_action_json)),
    PRIMARY KEY (release_id, assertion_id)
    -- subject may be an object, an operation, or a source identity namespace;
    -- publisher resolves the typed subject in requirement_json.
);
