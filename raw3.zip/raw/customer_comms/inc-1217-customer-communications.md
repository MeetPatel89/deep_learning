---
doc_id: COMM-INC-1217
title: INC-1217 Customer Communications
doc_type: customer_communication
service_id: svc_payments_reporting
owner_group: Service Desk L1
visibility: customer_safe
status: closed
created_at: "2026-06-15T23:40:00"
updated_at: "2026-06-16T04:15:00"
related_records:
  - INC-1217
  - KI-221
  - POL-COMMS-001
source_facts:
  - KI-221
  - svc_payments_reporting
difficulty_tags:
  - customer-safe
  - permission-boundary
servicenow:
  table: u_customer_communication
  number: COMM0002001
  parent: INC001217
  parent_table: incident
  channel: Email and status page
  visibility: customer_safe
  contains_customer_safe_wording: true
---

# INC-1217 Customer Communications

## Record details

| Field | Value |
| --- | --- |
| Table | u_customer_communication |
| Number | COMM0002001 |
| Parent | INC001217 |
| Parent table | incident |
| Channel | Email and status page |
| Visibility | customer_safe |
| Contains customer-safe wording | true |

## Communication log

These are the outbound customer communications sent for INC001217 by Service Desk L1 via email and the status page. All wording was approved per POL-COMMS-001 and uses the customer-safe summary from the related known issue. No internal reporting-platform details were included.

### 2026-06-15T23:40:00 — Initial notification

We are aware that some payments reporting dashboards and exports are showing older data than expected. Reporting data is delayed, but source payment transactions are not lost. Our teams are investigating, and we will provide an update as work progresses. No action is required from you at this time.

### 2026-06-16T01:15:00 — Investigation update

Our teams have identified the cause of the reporting delay and are working to restore normal reporting freshness. Reporting data is delayed, but source payment transactions are not lost. If you need current payment figures before the reporting view is restored, please contact the service desk and we will assist you.

### 2026-06-16T03:30:00 — Recovery in progress

Restoration of the reporting view is in progress and dashboards are beginning to reflect current data. Reporting data is delayed, but source payment transactions are not lost. We recommend regenerating any exports produced during the delay window once we confirm full recovery.

### 2026-06-16T04:15:00 — Resolution notice

The payments reporting delay has been resolved. Dashboards and exports now reflect the expected reporting period. Reporting data was delayed during this incident, but source payment transactions were not lost. If you generated an export while the delay was in effect, please regenerate it and contact the service desk if totals still look inconsistent.
