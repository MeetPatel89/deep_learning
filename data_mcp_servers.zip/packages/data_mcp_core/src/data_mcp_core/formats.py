"""Polars-first dataset readers and writers, with scoped staging for remote formats."""

import codecs
import csv
import json
import shutil
import tempfile
import zipfile
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import polars as pl

from data_mcp_core.stores import ResolvedPath, resolve_path

EXTENSIONS = {
    "csv": "csv",
    "tsv": "csv",
    "psv": "csv",
    "json": "json",
    "jsonl": "ndjson",
    "ndjson": "ndjson",
    "parquet": "parquet",
    "pq": "parquet",
    "delta": "delta",
    "arrow": "ipc",
    "ipc": "ipc",
    "feather": "ipc",
    "avro": "avro",
    "xlsx": "excel",
    "xls": "excel",
    "xlsb": "excel",
    "ods": "ods",
    "orc": "orc",
    "xml": "xml",
    "txt": "text",
    "log": "text",
    "fwf": "fixed_width",
    "sas7bdat": "sas",
    "xpt": "sas",
    "dta": "stata",
    "sav": "spss",
    "zsav": "spss",
}
ALIASES = {
    "tsv": "csv",
    "psv": "csv",
    "jsonl": "ndjson",
    "feather": "ipc",
    "arrow": "ipc",
    "xlsx": "excel",
    "xls": "excel",
    "xlsb": "excel",
    "log": "text",
    "txt": "text",
    "fwf": "fixed_width",
    "dta": "stata",
    "sav": "spss",
}
COMPRESSIONS = {"gz": "gzip", "bz2": "bz2", "xz": "xz", "zst": "zstd", "zip": "zip"}
WRITERS = frozenset({"csv", "parquet", "ndjson", "ipc", "delta", "excel"})
READERS = frozenset(EXTENSIONS.values()) | {"iceberg"}


def normalize_format(format: str) -> str:
    return ALIASES.get(format.lower(), format.lower())


def _suffix(path: str) -> tuple[str, str | None]:
    suffixes = Path(path).suffixes
    if not suffixes:
        return "", None
    suffix = suffixes[-1][1:].lower()
    compression = COMPRESSIONS.get(suffix)
    extension = suffixes[-2][1:].lower() if compression and len(suffixes) > 1 else suffix
    return extension, compression


@contextmanager
def _decoded_stream(resolved: ResolvedPath, compression: str | None, options: dict):
    with resolved.fs.open(resolved.fs_path, "rb") as raw:
        if compression == "zip":
            # Copy a remote archive to a seekable local file without loading it into RAM.
            with tempfile.TemporaryFile() as archive_file:
                shutil.copyfileobj(raw, archive_file)
                archive_file.seek(0)
                with zipfile.ZipFile(archive_file) as archive:
                    names = [name for name in archive.namelist() if not name.endswith("/")]
                    member = options.get("archive_member")
                    if member is None:
                        if len(names) != 1:
                            raise ValueError(
                                "ZIP datasets with multiple files require archive_member"
                            )
                        member = names[0]
                    with archive.open(member) as handle:
                        yield handle
        elif compression:
            from fsspec.compression import compr

            with compr[compression](raw, mode="rb") as handle:
                yield handle
        else:
            yield raw


@contextmanager
def staged_path(resolved: ResolvedPath, options: dict | None = None):
    options = options or {}
    extension, compression = _suffix(resolved.uri)
    if resolved.store.protocol == "file" and not compression:
        yield Path(resolved.fs_path)
        return
    with tempfile.TemporaryDirectory(prefix="data_mcp_") as directory:
        path = Path(directory) / ("dataset." + extension)
        with _decoded_stream(resolved, compression, options) as src, path.open("wb") as dst:
            shutil.copyfileobj(src, dst)
        yield path


def detect_format(path: str | ResolvedPath, options: dict | None = None) -> dict[str, Any]:
    resolved = resolve_path(path) if isinstance(path, str) else path
    options = options or {}
    if not resolved.exists():
        raise FileNotFoundError("Dataset path does not exist")
    if resolved.fs.isdir(resolved.fs_path):
        if resolved.child("_delta_log").exists():
            return {"format": "delta", "compression": None}
        if resolved.child("metadata").exists():
            if resolved.fs.glob(resolved.child("metadata/*.metadata.json").fs_path):
                return {"format": "iceberg", "compression": None}
        if resolved.fs.glob(resolved.child("**/*.parquet").fs_path):
            return {"format": "parquet", "compression": None, "hive_partitioning": True}
        raise ValueError("Directory is not a recognized dataset")
    extension, compression = _suffix(resolved.uri)
    format = EXTENSIONS.get(extension)
    with _decoded_stream(resolved, compression, options) as handle:
        sample = handle.read(64 * 1024)
    if sample.startswith(b"PAR1"):
        format = "parquet"
    elif sample.startswith(b"ARROW1"):
        format = "ipc"
    elif sample.startswith(b"Obj\x01"):
        format = "avro"
    elif sample.startswith(b"ORC"):
        format = "orc"
    elif sample.startswith(b"PK\x03\x04") and format not in {"excel", "ods"}:
        format = "excel"
    elif sample.lstrip().startswith(b"<") and format in {None, "text"}:
        format = "xml"
    if extension == "json" and resolved.uri.endswith(".metadata.json"):
        format = "iceberg"
    encoding, delimiter = None, None
    if format in {None, "csv", "text", "fixed_width", "json", "ndjson", "xml"}:
        try:
            sample.decode("utf-8-sig")
            encoding = "utf-8-sig" if sample.startswith(codecs.BOM_UTF8) else "utf-8"
        except UnicodeDecodeError:
            from charset_normalizer import from_bytes

            match = from_bytes(sample).best()
            encoding = match.encoding if match else "utf-8"
        text = sample.decode(options.get("encoding") or encoding, errors="replace")
        if format is None and text.lstrip().startswith(("{", "[")):
            try:
                json.loads(text)
                format = "json"
            except json.JSONDecodeError:
                format = "ndjson"
        if format in {None, "csv", "text"}:
            try:
                delimiter = csv.Sniffer().sniff(text[:8192], delimiters=",\t;|").delimiter
            except csv.Error:
                delimiter = {"tsv": "\t", "psv": "|"}.get(extension, ",")
            if format is None:
                format = "csv" if delimiter in text else "text"
    return {
        "format": format or "text",
        "compression": compression,
        "encoding": encoding,
        "delimiter": delimiter,
    }


@contextmanager
def _utf8_file(path: Path, encoding: str):
    if codecs.lookup(encoding).name == "utf-8":
        yield path
        return
    with tempfile.TemporaryDirectory(prefix="data_mcp_utf8_") as directory:
        output = Path(directory) / "decoded.csv"
        with (
            path.open("r", encoding=encoding, newline="") as src,
            output.open("w", encoding="utf-8", newline="") as dst,
        ):
            shutil.copyfileobj(src, dst)
        yield output


def _custom_frame(path: Path, format: str, options: dict) -> pl.DataFrame:
    if format in {"text", "fixed_width"}:
        lines = path.read_text(encoding=options.get("encoding", "utf-8")).splitlines()
        frame = pl.DataFrame({"line": lines}, schema={"line": pl.String})
        if format == "text":
            return frame
        specs = options.get("column_specs")
        if not specs:
            raise ValueError("fixed_width requires column_specs: {name: [start, end]}")
        expressions = []
        for name, (start, end) in specs.items():
            if start < 0 or end <= start:
                raise ValueError("Fixed-width column ranges must have 0 <= start < end")
            expressions.append(
                pl.col("line").str.slice(start, end - start).str.strip_chars().alias(name)
            )
        return frame.select(expressions)
    if format == "xml":
        from lxml import etree

        record_xpath = options.get("record_xpath")
        if not record_xpath:
            raise ValueError("XML requires record_xpath (for example //row)")
        # Iterparse uses the last XPath component to free each record as it is consumed.
        tag = record_xpath.rstrip("/").rsplit("/", 1)[-1]
        if any(character in tag for character in "[]@*"):
            raise ValueError(
                "record_xpath must be a simple element path; use fields for child XPath"
            )
        rows = []
        parts = [part for part in record_xpath.split("/") if part]
        namespaces = options.get("namespaces", {})

        def qualified(part):
            if ":" in part:
                prefix, local = part.split(":", 1)
                return "{" + namespaces[prefix] + "}" + local
            return part

        tag = qualified(tag)
        for _, element in etree.iterparse(
            str(path), events=("end",), tag=tag, resolve_entities=False, no_network=True
        ):
            ancestry = [node.tag for node in reversed(list(element.iterancestors()))] + [
                element.tag
            ]
            target = [qualified(part) for part in parts]
            matches = (
                ancestry[-len(target) :] == target
                if record_xpath.startswith("//")
                else ancestry == target
            )
            if matches:
                fields = options.get("fields")
                if fields:
                    row = {}
                    for name, xpath in fields.items():
                        value = element.xpath(xpath, namespaces=namespaces)
                        if isinstance(value, list):
                            value = value[0] if value else None
                        row[name] = value.text if isinstance(value, etree._Element) else value
                else:
                    row = {etree.QName(child).localname: child.text for child in element}
                    row.update(element.attrib)
                rows.append(row)
            element.clear()
            while element.getprevious() is not None:
                del element.getparent()[0]
        return (
            pl.DataFrame(rows, infer_schema_length=None)
            if rows
            else pl.DataFrame(schema=options.get("schema"))
        )
    raise ValueError(f"Unsupported custom format: {format}")


@contextmanager
def scan_dataset(
    path: str | ResolvedPath,
    format: str | None = None,
    options: dict[str, Any] | None = None,
):
    """Keep staged files alive for the full LazyFrame scan/collection lifetime."""
    resolved = resolve_path(path) if isinstance(path, str) else path
    options = dict(options or {})
    is_glob = any(character in resolved.relative for character in "*?[")
    detected = detect_format(resolved, options) if not is_glob else {}
    if is_glob and format is None:
        extension, _ = _suffix(resolved.uri)
        format = EXTENSIONS.get(extension)
        if not format:
            raise ValueError("Glob datasets require an explicit format")
    format = normalize_format(format or detected["format"])
    if format not in READERS:
        raise ValueError(f"Unsupported dataset format: {format}")
    if not resolved.exists() and not any(character in resolved.relative for character in "*?["):
        raise FileNotFoundError("Dataset path does not exist")
    cloud = (
        {
            "storage_options": resolved.storage_options(),
            "credential_provider": resolved.credential_provider,
        }
        if resolved.store.protocol != "file"
        else {}
    )
    _, compression = _suffix(resolved.uri)
    if format == "delta":
        if options.get("version") is not None and options.get("timestamp") is not None:
            raise ValueError("Specify version or timestamp, not both")
        yield pl.scan_delta(
            resolved.uri, version=options.get("version", options.get("timestamp")), **cloud
        )
        return
    if format == "iceberg":
        try:
            import pyiceberg  # noqa: F401
        except ImportError as error:
            raise RuntimeError("Install the [iceberg] extra to read Iceberg") from error
        metadata = resolved
        if resolved.fs.isdir(resolved.fs_path):
            entries = resolved.fs.glob(resolved.child("metadata/*.metadata.json").fs_path)
            if not entries:
                raise ValueError("Iceberg metadata was not found")
            # Require explicit metadata selection when several snapshots exist.
            if len(entries) != 1:
                raise ValueError("Specify the Iceberg metadata JSON path explicitly")
            metadata = resolve_store_child(resolved, entries[0])
        iceberg_options = {
            **resolved.storage_options(token=True),
            **options.get("storage_options", {}),
        }
        yield pl.scan_iceberg(
            metadata.uri, storage_options=iceberg_options, **options.get("scan_options", {})
        )
        return
    if format in {"parquet", "ipc", "ndjson", "csv"} and not compression:
        if format == "csv" and codecs.lookup(
            options.get("encoding") or detected.get("encoding") or "utf-8"
        ).name not in {"utf-8", "utf-8-sig"}:
            pass  # Transcode below, including remote CSV.
        else:
            target: str | list[str] = resolved.uri
            if is_glob:
                entries = sorted(resolved.fs.glob(resolved.fs_path))
                target = [resolve_store_child(resolved, entry).uri for entry in entries]
                if not target:
                    raise FileNotFoundError("Dataset glob matched no files")
            elif format == "parquet" and resolved.fs.isdir(resolved.fs_path):
                entries = sorted(resolved.fs.glob(resolved.child("**/*.parquet").fs_path))
                target = [resolve_store_child(resolved, entry).uri for entry in entries]
                if not target:
                    raise ValueError("Parquet directory contains no Parquet files")
            readers = {
                "parquet": pl.scan_parquet,
                "ipc": pl.scan_ipc,
                "ndjson": pl.scan_ndjson,
                "csv": pl.scan_csv,
            }
            kwargs = dict(options.get("scan_options", {}))
            if format == "csv":
                kwargs.update(
                    separator=options.get("delimiter") or detected.get("delimiter") or ",",
                    has_header=options.get("has_header", True),
                    null_values=options.get("null_values"),
                    infer_schema_length=None,
                    raise_if_empty=False,
                )
            elif format == "parquet":
                kwargs["hive_partitioning"] = options.get("hive_partitioning", True)
            yield readers[format](target, **kwargs, **cloud)
            return
    if is_glob:
        raise ValueError("Globs require a native uncompressed CSV/Parquet/IPC/NDJSON reader")
    with staged_path(resolved, options) as local:
        kwargs = dict(options.get("read_options", {}))
        if format == "csv":
            with _utf8_file(
                local, options.get("encoding") or detected.get("encoding") or "utf-8"
            ) as utf8:
                yield pl.scan_csv(
                    utf8,
                    separator=options.get("delimiter") or detected.get("delimiter") or ",",
                    has_header=options.get("has_header", True),
                    null_values=options.get("null_values"),
                    infer_schema_length=None,
                    raise_if_empty=False,
                    **kwargs,
                )
            return
        if format in {"parquet", "ipc", "ndjson"}:
            yield {"parquet": pl.scan_parquet, "ipc": pl.scan_ipc, "ndjson": pl.scan_ndjson}[
                format
            ](local, **kwargs)
            return
        if format == "json":
            frame = pl.read_json(local, infer_schema_length=None, **kwargs)
        elif format == "avro":
            frame = pl.read_avro(local, **kwargs)
        elif format in {"excel", "ods"}:
            sheet = options.get("sheet")
            if isinstance(sheet, int):
                if sheet < 1:
                    raise ValueError("Excel sheet index must be at least 1")
                kwargs["sheet_id"] = sheet
            elif sheet:
                kwargs["sheet_name"] = sheet
            kwargs["raise_if_empty"] = False
            frame = (
                pl.read_ods(local, **kwargs)
                if format == "ods"
                else pl.read_excel(local, engine="calamine", **kwargs)
            )
            if isinstance(frame, dict):
                raise ValueError("Select a single sheet")
        elif format == "orc":
            import pyarrow.orc as orc

            frame = pl.from_arrow(orc.read_table(local, **kwargs))
        elif format in {"sas", "stata", "spss"}:
            try:
                import pandas as pd
            except ImportError as error:
                raise RuntimeError("Install the [legacy] extra for SAS, Stata and SPSS") from error
            readers = {"sas": pd.read_sas, "stata": pd.read_stata, "spss": pd.read_spss}
            frame = pl.from_pandas(readers[format](local, **kwargs))
        else:
            frame = _custom_frame(local, format, options)
        yield frame.lazy()


def resolve_store_child(resolved: ResolvedPath, entry: str) -> ResolvedPath:
    from data_mcp_core.stores import resolve_store

    return resolve_store(
        resolved.store,
        resolved.relative_name(entry),
        profile=resolved.auth,
        allowed_local_roots=resolved.allowed_local_roots,
    )


def iter_file_batches(
    path: str | ResolvedPath,
    batch_size: int = 10_000,
    format: str | None = None,
    options: dict | None = None,
) -> Iterator[pl.DataFrame]:
    if batch_size < 1:
        raise ValueError("batch_size must be positive")
    with scan_dataset(path, format, options) as scan:
        emitted = False
        for frame in scan.collect_batches(chunk_size=batch_size, engine="streaming"):
            emitted = True
            yield frame
        if not emitted:
            yield pl.DataFrame(schema=scan.collect_schema())


def read_dataset(
    path: str | ResolvedPath, format: str | None = None, options: dict | None = None
) -> pl.DataFrame:
    with scan_dataset(path, format, options) as scan:
        return scan.collect(engine="streaming")


def write_dataset(
    frame: pl.DataFrame,
    path: str | ResolvedPath,
    format: str | None = None,
    options: dict | None = None,
) -> dict[str, Any]:
    """Low-level writer; callers must check their own configuration permissions first."""
    resolved = resolve_path(path) if isinstance(path, str) else path
    options = dict(options or {})
    extension, compression = _suffix(resolved.uri)
    format = normalize_format(format or EXTENSIONS.get(extension, ""))
    if format not in WRITERS:
        raise ValueError(f"No writer for format: {format}")
    if compression:
        raise ValueError(
            "Compressed output is not supported; select a native writer compression option"
        )
    if format == "delta":
        mode = options.pop("mode", "append")
        if mode not in {"append", "overwrite", "merge"}:
            raise ValueError("Delta mode must be append, overwrite or merge")
        kwargs = {"storage_options": resolved.storage_options(token=True)}
        if mode == "merge":
            predicate = options.pop("predicate", None)
            if not predicate:
                raise ValueError("Delta merge requires a predicate using source and target aliases")
            merger = frame.write_delta(
                resolved.uri,
                mode="merge",
                delta_merge_options={
                    "predicate": predicate,
                    "source_alias": "source",
                    "target_alias": "target",
                },
                **kwargs,
            )
            result = merger.when_matched_update_all().when_not_matched_insert_all().execute()
            return {"path": resolved.relative, "format": format, "metrics": result}
        frame.write_delta(resolved.uri, mode=mode, delta_write_options=options, **kwargs)
    else:
        # Materializing formats use one local scratch file, then stream it to fsspec.
        with tempfile.TemporaryDirectory(prefix="data_mcp_write_") as directory:
            local = Path(directory) / ("dataset." + ("xlsx" if format == "excel" else format))
            if format == "excel":
                import xlsxwriter

                with xlsxwriter.Workbook(
                    local, {"strings_to_formulas": False, "strings_to_urls": False}
                ) as workbook:
                    frame.write_excel(workbook=workbook, **options)
            else:
                writer = {
                    "csv": frame.write_csv,
                    "parquet": frame.write_parquet,
                    "ndjson": frame.write_ndjson,
                    "ipc": frame.write_ipc,
                }[format]
                writer(local, **options)
            parent = (
                str(Path(resolved.fs_path).parent)
                if resolved.store.protocol == "file"
                else resolved.fs_path.rpartition("/")[0]
            )
            if parent:
                resolved.fs.makedirs(parent, exist_ok=True)
            with local.open("rb") as src, resolved.fs.open(resolved.fs_path, "wb") as dst:
                shutil.copyfileobj(src, dst)
    return {"path": resolved.relative, "format": format, "row_count": frame.height}
