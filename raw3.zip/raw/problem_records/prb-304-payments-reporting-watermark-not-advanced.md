---
doc_id: PRB-304
title: Payments Reporting Watermark Not Advanced After Successful Databricks Transformation
doc_type: problem_record
service_id: svc_payments_reporting
owner_group: Data Applications
visibility: internal
status: known_error
created_at: "2026-06-16T09:00:00"
updated_at: "2026-06-17T12:00:00"
related_records:
  - KI-221
  - INC-1217
  - RUNBOOK-PAY-007
  - TASK-PRB-304
source_facts:
  - KI-221
  - svc_payments_reporting
difficulty_tags:
  - root-cause
  - azure-sql-control-table
  - internal-only-detail
servicenow:
  table: problem
  number: PRB000304
  state: Known Error
  known_error: true
  impact: 2
  urgency: 2
  priority: 3
  business_service: Payments Reporting Service
  cmdb_ci: Payments Reporting Pipeline
  assignment_group: Data Applications
  opened_by_group: Data Applications
  related_incident: INC001217
  related_change: CHG002411
  related_known_issue: KI00221
  visibility: internal
  contains_customer_safe_wording: false
---

# Payments Reporting Watermark Not Advanced After Successful Databricks Transformation

## Record details

| Field | Value |
| --- | --- |
| Table | problem |
| Number | PRB000304 |
| State | Known Error |
| Known error | true |
| Impact | 2 |
| Urgency | 2 |
| Priority | 3 |
| Business service | Payments Reporting Service |
| Configuration item | Payments Reporting Pipeline |
| Assignment group | Data Applications |
| Opened by group | Data Applications |
| Related incident | INC001217 |
| Related change | CHG002411 |
| Related known issue | KI00221 |
| Visibility | internal |
| Contains customer-safe wording | false |

## Problem summary

PRB-304 tracks the known error where Payments Reporting Service can show stale dashboards even after the Databricks transformation completes successfully. The issue is internal to the reporting refresh path and is owned by Data Applications.

Root cause is that the Azure SQL Database control-table watermark may not advance correctly after a successful Databricks transformation. The reporting layer can skip the latest partition.

## Related incidents

Primary related incident:

- INC-1217: Payments Dashboard Stale After Refresh Pipeline Update.

Related known issue:

- KI-221: Payments Dashboard Data Freshness Delay After Synapse/Fabric Refresh Failure.

INC-1217 began after CHG-2411 completed and was resolved by rerunning the Synapse/Fabric reporting refresh and backfilling from the last successful payment partition.

## Root cause analysis

The data path has separate evidence points for source availability, transformation completion, and reporting freshness. During the failure mode, Azure SQL Database staging tables can contain current payment transaction records and the Databricks transformation can report success, while the reporting refresh layer remains on the previous watermark.

The key internal failure is misalignment between the Azure SQL Database control-table watermark and the latest Databricks output partition. When the watermark is not advanced correctly, the downstream Synapse/Fabric reporting layer can skip the newest partition.

This creates a stale dashboard or export mismatch without source payment transaction loss.

## Known error

Known error indicators:

- Dashboard data stale by more than four hours.
- Databricks transformation shows successful completion.
- Azure SQL Database staging tables contain current records.
- Synapse/Fabric reporting layer shows previous data refresh watermark.
- Exported payment totals do not match the operational transaction view.

Source payment transactions are not lost. The defect is in reporting freshness and partition selection.

## Workaround

Use RUNBOOK-PAY-007. The approved workaround is:

1. Validate the Azure SQL Database control-table watermark.
2. Confirm the latest Databricks output partition.
3. Rerun the Synapse/Fabric reporting refresh.
4. Backfill from the last successful payment partition if the latest partition was skipped.
5. Verify dashboard and export totals with business users.

## Permanent fix status

Status is known error. Data Applications owns permanent remediation and will continue to track the watermark and partition reconciliation behavior through this problem record.

Until permanent remediation is recorded, support should treat matching stale dashboard reports as KI-221 candidates and follow RUNBOOK-PAY-007.

## Communication guidance

Customer-facing communication should not over-explain internal control-table behavior. Use the customer-safe summary from KI-221:

"Reporting data is delayed, but source payment transactions are not lost."

Internal work notes may include Azure SQL Database control-table watermark, Databricks output partition, and Synapse/Fabric refresh details. Customer-facing updates should not expose those mechanics.

## Related records

- KI-221: Payments Dashboard Data Freshness Delay After Synapse/Fabric Refresh Failure.
- INC-1217: Payments Dashboard Stale After Refresh Pipeline Update.
- RUNBOOK-PAY-007: Payments Reporting Data Freshness Runbook.
- TASK-PRB-304: Problem tasks tracking root-cause confirmation and permanent remediation.

