"""Contain failures at the OpenTelemetry span-processor boundary."""

from logging import getLogger
from threading import Lock
from typing import override

from opentelemetry.context import Context
from opentelemetry.sdk.trace import ReadableSpan, Span, SpanProcessor

# Use OTel's trace logger and the application's existing logging handlers.
_logger = getLogger("opentelemetry.sdk.trace")


class _FailOpenSpanProcessor(SpanProcessor):
    """Delegate callbacks, contain ordinary failures, and close at most once."""

    def __init__(self, processor: SpanProcessor) -> None:
        self._processor = processor
        self._closed = False
        self._shutdown_lock = Lock()

    @override
    def on_start(self, span: Span, parent_context: Context | None = None) -> None:
        """Preserve start hooks without exposing processor failures to callers."""
        if self._closed:
            return
        try:
            self._processor.on_start(span, parent_context=parent_context)
        except Exception:
            _logger.exception("Exception in span processor on_start.")

    @override
    def _on_ending(self, span: Span) -> None:
        if self._closed:
            return
        try:
            # OTel invokes this pre-end hook in the supported SDK versions.
            self._processor._on_ending(span)
        except Exception:
            _logger.exception("Exception in span processor _on_ending.")

    @override
    def on_end(self, span: ReadableSpan) -> None:
        """Preserve export hooks without replacing application exceptions."""
        if self._closed:
            return
        try:
            self._processor.on_end(span)
        except Exception:
            _logger.exception("Exception in span processor on_end.")

    @override
    def force_flush(self, timeout_millis: int = 30_000) -> bool:
        """Report failure on an exception or when shutdown has already begun."""
        if self._closed:
            return False
        try:
            return self._processor.force_flush(timeout_millis)
        except Exception:
            _logger.exception("Exception in span processor force_flush.")
            return False

    @override
    def shutdown(self) -> None:
        """Attempt shutdown once, including when the processor raises."""
        with self._shutdown_lock:
            if self._closed:
                return
            self._closed = True
        # Do not hold the lock while running application-supplied processor code.
        try:
            self._processor.shutdown()
        except Exception:
            _logger.exception("Exception in span processor shutdown.")
