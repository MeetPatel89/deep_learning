"""Provision application projects on a local Langfuse Compose stack."""

from argparse import ArgumentParser, Namespace
from base64 import b64encode
from collections.abc import Iterator, Sequence
from contextlib import contextmanager
from datetime import UTC, datetime
from json import JSONDecodeError, loads
from os import environ
from pathlib import Path
from re import sub
from shlex import join
from subprocess import PIPE, CalledProcessError, TimeoutExpired, run
from sys import stderr
from time import monotonic, sleep
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen

from .provisioning import (
    AppProvision,
    ProvisionedApp,
    ProvisioningError,
    init_environment,
    read_env_file,
    read_registry,
    resolve_stack_dir,
    upsert_env_file,
    write_registry,
)


def _parser() -> ArgumentParser:
    parser = ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    provision = commands.add_parser(
        "provision", help="Create an app's Langfuse project"
    )
    provision.add_argument("--app", required=True)
    provision.add_argument("--project-name")
    provision.add_argument("--org")
    provision.add_argument("--org-name")
    provision.add_argument("--user-email")
    provision.add_argument("--user-name")
    provision.add_argument("--retention-days", type=int)
    provision.add_argument("--rotate-keys", action="store_true")
    provision.add_argument("--yes", action="store_true")
    provision.add_argument("--dry-run", action="store_true")
    provision.add_argument("--timeout", type=float, default=120.0)
    verify = commands.add_parser("verify", help="Verify app credentials and project")
    verify.add_argument("--app", help="Expected project ID (otherwise use registry)")
    where = commands.add_parser("where", help="Show the stack location and endpoint")
    apps = commands.add_parser("apps", help="Inspect registered applications")
    listing = apps.add_subparsers(dest="apps_command", required=True).add_parser("list")
    for command in (provision, verify, where, listing):
        command.add_argument("--app-env", default=".env", type=Path)
        command.add_argument("--stack-dir", type=Path)
    return parser


def _base_url(settings: dict[str, str]) -> str:
    value = settings.get("LANGFUSE_BASE_URL", "http://localhost:3000").rstrip("/")
    try:
        parsed = urlsplit(value)
        _ = parsed.port
    except ValueError as exc:
        raise ProvisioningError("LANGFUSE_BASE_URL is not a valid URL") from exc
    if (
        parsed.scheme not in {"http", "https"}
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
    ):
        raise ProvisioningError(
            "LANGFUSE_BASE_URL must be an HTTP(S) URL without credentials, "
            "query, or fragment"
        )
    return value


def _project_name(stack: Path) -> str:
    name = sub(r"[^a-z0-9_-]", "", stack.name.lower()).lstrip("-_")
    if not name:
        raise ProvisioningError(
            "The stack directory must have a valid Compose project name"
        )
    return name


def _compose(stack: Path) -> list[str]:
    return [
        "docker",
        "compose",
        "--project-name",
        _project_name(stack),
        "--env-file",
        str(stack / ".env"),
        "-f",
        str(stack / "compose.yaml"),
    ]


def _docker(command: list[str], environment: dict[str, str]) -> str:
    try:
        result = run(
            command,
            env=environment,
            check=True,
            stdout=PIPE,
            stderr=PIPE,
            text=True,
            timeout=120,
        )
    except FileNotFoundError as exc:
        raise ProvisioningError(
            "Docker is missing. Install Docker with the Compose v2 plugin; "
            "on WSL enable Docker Desktop integration."
        ) from exc
    except (CalledProcessError, TimeoutExpired) as exc:
        raise ProvisioningError(
            "Docker command failed. Check Docker/Compose installation and daemon "
            "availability; on WSL enable Docker Desktop integration. "
            "Inspect stack logs for details."
        ) from exc
    return result.stdout


def wait_for_health(base_url: str, timeout: float) -> None:
    """Wait for Langfuse and its database without exposing response bodies."""
    deadline = monotonic() + timeout
    while True:
        try:
            with urlopen(
                base_url.rstrip("/")
                + "/api/public/health?failIfDatabaseUnavailable=true",
                timeout=min(5.0, max(0.1, deadline - monotonic())),
            ) as response:
                if response.status == 200:
                    return
        except URLError, OSError, TimeoutError:
            pass
        remaining = deadline - monotonic()
        if remaining <= 0:
            raise ProvisioningError("Langfuse health check timed out")
        sleep(min(1.0, remaining))


def verify_project(
    base_url: str,
    public_key: str,
    secret_key: str,
    expected_project: str | None = None,
    expected_org: str | None = None,
) -> str:
    """Check credentials and return the single authenticated project identifier."""
    if not public_key or not secret_key:
        raise ProvisioningError(
            "Set both LANGFUSE_PUBLIC_KEY and LANGFUSE_SECRET_KEY "
            "in the app environment"
        )
    authorization = b64encode(f"{public_key}:{secret_key}".encode()).decode("ascii")
    request = Request(base_url.rstrip("/") + "/api/public/projects")
    request.add_unredirected_header("Authorization", "Basic " + authorization)
    try:
        with urlopen(request, timeout=10) as response:
            payload = loads(response.read())
    except HTTPError as exc:
        raise ProvisioningError(
            f"Key verification failed (HTTP {exc.code}); "
            "check this instance's project credentials"
        ) from exc
    except (URLError, OSError, JSONDecodeError, UnicodeError) as exc:
        raise ProvisioningError(
            "Key verification failed; check LANGFUSE_BASE_URL and stack availability"
        ) from exc
    data = payload.get("data") if isinstance(payload, dict) else None
    if not isinstance(data, list) or len(data) != 1 or not isinstance(data[0], dict):
        raise ProvisioningError("Key verification failed: expected exactly one project")
    project_id = data[0].get("id")
    if not isinstance(project_id, str) or not project_id:
        raise ProvisioningError("Key verification failed: project ID missing")
    if expected_project is not None and project_id != expected_project:
        raise ProvisioningError(
            "Key verification failed: credentials belong to a different project"
        )
    organization = data[0].get("organization")
    if expected_org is not None and (
        not isinstance(organization, dict) or organization.get("id") != expected_org
    ):
        raise ProvisioningError(
            "Key verification failed: project belongs to a different organization; "
            "headless initialization cannot move an existing project"
        )
    return project_id


@contextmanager
def _provision_lock(stack: Path) -> Iterator[None]:
    path = stack / ".provision.lock"
    try:
        path.mkdir(mode=0o700)
    except FileExistsError as exc:
        raise ProvisioningError(
            "Provisioning is already in progress (.provision.lock exists). "
            "Remove the empty lock directory only after confirming no provision "
            "command is running."
        ) from exc
    try:
        yield
    finally:
        path.rmdir()


def _spec(
    args: Namespace, saved: dict[str, str], entries: list[ProvisionedApp]
) -> AppProvision:
    previous = next((entry for entry in entries if entry.app == args.app), None)
    org_id = args.org or (previous.org_id if previous else "observability-ai")
    if previous and (org_id != previous.org_id or previous.project_id != args.app):
        raise ProvisioningError(
            "A registered app cannot change organization or project; "
            "choose a new app slug"
        )
    keys: dict[str, str] = {}
    if previous and not args.rotate_keys:
        public = saved.get("LANGFUSE_PUBLIC_KEY", "")
        secret = saved.get("LANGFUSE_SECRET_KEY", "")
        if public != previous.public_key or not secret:
            raise ProvisioningError(
                "Registered app credentials are missing or differ from its registry. "
                "Restore the app .env or use --rotate-keys"
            )
        keys = {"public_key": public, "secret_key": secret}
    return AppProvision(
        app=args.app,
        project_name=args.project_name,
        org_id=org_id,
        org_name=args.org_name
        or ("Observability AI" if org_id == "observability-ai" else org_id),
        user_email=args.user_email,
        user_name=args.user_name,
        retention_days=args.retention_days,
        **keys,
    )


def _provision(args: Namespace, stack: Path, app_env: Path, base_url: str) -> None:
    if not 0 < args.timeout < float("inf"):
        raise ProvisioningError("--timeout must be a positive finite number")
    if app_env.resolve() == (stack / ".env").resolve():
        raise ProvisioningError("The app .env must be separate from the stack .env")
    registry = stack / "provisioned.json"
    command = _compose(stack) + [
        "up",
        "-d",
        "--no-deps",
        "--force-recreate",
        "langfuse-web",
    ]
    if args.dry_run:
        spec = _spec(args, read_env_file(app_env), read_registry(registry))
        for name in init_environment(spec):
            print(f"{name}=<redacted>")
        print(join(command))
        return
    print(
        "Provisioning restarts langfuse-web. Other apps may see a brief ingestion "
        "interruption (typically 10–30 seconds).",
        file=stderr,
    )
    if not args.yes:
        try:
            accepted = input("Continue? [y/N] ").strip().lower() in {"y", "yes"}
        except EOFError:
            accepted = False
        if not accepted:
            raise ProvisioningError(
                "Provisioning cancelled; use --yes for unattended execution"
            )
    with _provision_lock(stack):
        entries = read_registry(registry)
        spec = _spec(args, read_env_file(app_env), entries)
        previous = next((entry for entry in entries if entry.app == spec.app), None)
        stack_values = read_env_file(stack / ".env")
        environment = {
            key: value
            for key, value in environ.items()
            if key not in stack_values
            and not key.startswith("COMPOSE_")
            and not key.startswith("LANGFUSE_INIT_")
        }
        environment.update(init_environment(spec))
        version = (
            _docker(["docker", "compose", "version", "--short"], environment)
            .strip()
            .lstrip("v")
        )
        if (
            not version
            or not version.split(".")[0].isdigit()
            or int(version.split(".")[0]) < 2
        ):
            raise ProvisioningError("Docker Compose v2 or newer is required")
        _docker(["docker", "info"], environment)
        services = _docker(
            _compose(stack) + ["ps", "--status", "running", "--services"], environment
        )
        if not {"langfuse-worker", "postgres", "clickhouse", "redis", "minio"}.issubset(
            set(services.split())
        ):
            raise ProvisioningError(
                "Start the central Compose stack before provisioning; "
                "its worker and datastores must be running"
            )
        if previous and not args.rotate_keys:
            print("Reusing the app's registered API key pair.", file=stderr)
        try:
            _docker(command, environment)
            if spec.user_email:
                print(
                    "Generated password (used only if "
                    f"{spec.user_email} is a NEW user): "
                    f"{spec.user_password}"
                )
                print(
                    "Existing users keep their password and gain OWNER membership.",
                    file=stderr,
                )
            wait_for_health(base_url, args.timeout)
            project_id = verify_project(
                base_url, spec.public_key, spec.secret_key, spec.project_id, spec.org_id
            )
        except ProvisioningError:
            print(
                "Inspect startup logs: "
                + join(_compose(stack) + ["logs", "langfuse-web"]),
                file=stderr,
            )
            raise
        now = datetime.now(UTC).isoformat()
        entry = ProvisionedApp(
            app=spec.app,
            org_id=spec.org_id,
            project_id=project_id,
            public_key=spec.public_key,
            user_email=spec.user_email or (previous.user_email if previous else None),
            created_at=previous.created_at if previous else now,
            rotated_at=now
            if args.rotate_keys and previous
            else (previous.rotated_at if previous else None),
        )
        upsert_env_file(
            app_env,
            {
                "LANGFUSE_PUBLIC_KEY": spec.public_key,
                "LANGFUSE_SECRET_KEY": spec.secret_key,
                "LANGFUSE_BASE_URL": base_url,
            },
        )
        write_registry(
            registry, [item for item in entries if item.app != spec.app] + [entry]
        )
        print(f"Verified project {project_id}; credentials saved to {app_env}")
        if args.rotate_keys:
            print(
                "Old API keys remain valid. Delete them in the Langfuse UI "
                "when no longer needed.",
                file=stderr,
            )
        if args.retention_days is not None:
            print(
                "Retention applies only to a newly created project with the "
                "Langfuse data-retention entitlement; OSS ignores it.",
                file=stderr,
            )


def main(argv: Sequence[str] | None = None) -> int:
    """Run the provisioning console command and return its exit status."""
    args = _parser().parse_args(argv)
    try:
        app_env = args.app_env.absolute()
        saved = read_env_file(app_env)
        settings = {**saved, **environ}
        if args.command == "verify":
            expected = args.app
            if args.stack_dir or settings.get("OBSERVABILITY_AI_STACK_DIR"):
                stack = resolve_stack_dir(args.stack_dir, settings)
                matching = [
                    entry
                    for entry in read_registry(stack / "provisioned.json")
                    if entry.public_key == settings.get("LANGFUSE_PUBLIC_KEY")
                ]
                if expected is None and matching:
                    expected = matching[0].project_id
            project_id = verify_project(
                _base_url(settings),
                settings.get("LANGFUSE_PUBLIC_KEY", ""),
                settings.get("LANGFUSE_SECRET_KEY", ""),
                expected,
            )
            print(f"Verified project {project_id}")
            return 0
        stack = resolve_stack_dir(args.stack_dir, settings)
        base_url = _base_url({**read_env_file(stack / ".env"), **settings})
        if args.command == "where":
            print(
                f"Stack: {stack}\nCompose project: {_project_name(stack)}\n"
                f"Base URL: {base_url}"
            )
        elif args.command == "apps":
            entries = read_registry(stack / "provisioned.json")
            print("APP\tORG\tPROJECT\tPUBLIC KEY\tUSER\tCREATED\tROTATED")
            for entry in entries:
                print(
                    "\t".join(
                        (
                            entry.app,
                            entry.org_id,
                            entry.project_id,
                            entry.public_key,
                            entry.user_email or "-",
                            entry.created_at,
                            entry.rotated_at or "-",
                        )
                    )
                )
        else:
            _provision(args, stack, app_env, base_url)
        return 0
    except (ProvisioningError, OSError) as exc:
        print(f"observability-ai: {exc}", file=stderr)
        return 1
    except KeyboardInterrupt:
        print("observability-ai: interrupted", file=stderr)
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
