"""Freeze and validate every dependency before contacting a Synapse workspace."""

import copy
import hashlib
import json
import re
from dataclasses import dataclass

from data_mcp_core.results import register_secret

from synapse_mcp_server.config import BranchTestProfile
from synapse_mcp_server.repository import Snapshot

REFERENCES = {
    "PipelineReference": "pipeline",
    "DatasetReference": "dataset",
    "LinkedServiceReference": "linked_service",
    "NotebookReference": "notebook",
    "DataFlowReference": "data_flow",
}
RUNTIMES = {
    "BigDataPoolReference": "spark_pools",
    "IntegrationRuntimeReference": "integration_runtimes",
}
TERMINAL = {"Succeeded", "Failed", "Cancelled", "Canceled"}


def digest(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, allow_nan=False, separators=(",", ":")).encode()
    ).hexdigest()


def merge(target, override):
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(target.get(key), dict):
            merge(target[key], value)
        else:
            target[key] = copy.deepcopy(value)


def walk(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from walk(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk(child)


def literal_reference(value, kind):
    if not isinstance(value, str) or not value or "@" in value:
        if kind == "NotebookReference":
            raise ValueError(
                "Parameterized notebook names cannot select unpublished notebooks; "
                "use a literal NotebookReference or a profile override"
            )
        raise ValueError(f"Unresolved dynamic {kind}; use a literal development reference")
    return value


@dataclass
class ExecutionPackage:
    snapshot: Snapshot
    pipeline: str
    profile_name: str
    profile: BranchTestProfile
    parameters: dict
    artifacts: dict[str, dict]
    order: list[str]

    @property
    def fingerprint(self):
        return digest(
            {
                "pipeline": self.pipeline,
                "profile": self.profile.model_dump(),
                "parameters": self.parameters,
                "artifacts": self.artifacts,
            }
        )

    def provenance(self):
        declarations = self.artifacts["pipeline/" + self.pipeline]["properties"].get(
            "parameters", {}
        )
        return {
            **self.snapshot.metadata(),
            "pipeline": self.pipeline,
            "test_profile": self.profile_name,
            "profile_fingerprint": digest(self.profile.model_dump()),
            "execution_fingerprint": self.fingerprint,
            "parameters": self.parameters,
            "secure_parameters": [
                name
                for name, spec in declarations.items()
                if str(spec.get("type", "")).lower() in {"securestring", "secureobject"}
            ],
            "artifacts": self.order,
        }

    def stage(self, execution_id):
        names = {key: f"mcp_{execution_id}_{digest(key)[:12]}" for key in self.order}
        definitions = copy.deepcopy(self.artifacts)
        owner = "synapse-mcp:" + execution_id
        for key, definition in definitions.items():
            definition["name"] = names[key]
            definition.pop("id", None)
            definition.pop("etag", None)
            props = definition["properties"]
            props["annotations"] = [*props.get("annotations", []), owner]
            for node in walk(props):
                kind = REFERENCES.get(node.get("type"))
                if kind:
                    node["referenceName"] = names[kind + "/" + node["referenceName"]]
        return names, definitions, owner


def build_package(snapshot, pipeline, profile_name, profile, parameters=None):
    artifacts, order, active = {}, [], set()
    overrides = profile.artifact_overrides
    # Reject typos in overrides even if the artifact is not a dependency of this run.
    for key, override in overrides.items():
        parts = key.split("/", 1)
        if len(parts) != 2 or parts[0] not in REFERENCES.values():
            raise ValueError("Profile overrides use supported artifact_type/name keys")
        snapshot.get(*parts)
        if not isinstance(override, dict):
            raise ValueError("Artifact overrides must be property objects")

    def visit(kind, name):
        key = kind + "/" + name
        if key in active:
            raise ValueError("Cyclic artifact dependency: " + key)
        if key in artifacts:
            return
        if len(artifacts) >= 500 or len(active) >= 50:
            raise ValueError("Dependency package exceeds artifact/depth limits")
        active.add(key)
        definition = snapshot.get(kind, name)
        definition["name"] = name
        merge(definition["properties"], overrides.get(key, {}))
        props = definition["properties"]
        if kind == "notebook":
            # Notebook source can invoke notebooks without typed artifact references.
            # Rewriting arbitrary Python/Scala/SQL expressions is not safe.
            source = "\n".join("".join(c.get("source", [])) for c in props.get("cells", []))
            if re.search(
                r"%run\b|(?:mssparkutils|notebookutils)\s*\.\s*notebook\s*\.\s*run", source
            ):
                raise ValueError(
                    "Notebook-to-notebook code references are unsupported; "
                    "use pipeline NotebookReference activities"
                )
            if not props.get("bigDataPool"):
                raise ValueError(
                    "Unpublished notebooks require an explicit development bigDataPool"
                )
        if kind == "linked_service" and not props.get("connectVia"):
            if "AutoResolveIntegrationRuntime" not in profile.integration_runtimes:
                raise ValueError(
                    "Profile must permit AutoResolveIntegrationRuntime for this linked service"
                )
        for node in walk(props):
            ref_type = node.get("type", "")
            if not isinstance(ref_type, str):
                continue
            if ref_type.endswith("Reference") or "referenceName" in node:
                reference = literal_reference(node.get("referenceName"), ref_type)
                if ref_type in REFERENCES:
                    visit(REFERENCES[ref_type], reference)
                elif ref_type in RUNTIMES:
                    if reference not in getattr(profile, RUNTIMES[ref_type]):
                        raise PermissionError(
                            f"Runtime binding {reference!r} is not permitted by the test profile"
                        )
                else:
                    raise ValueError("Unsupported artifact/runtime reference: " + ref_type)
            required = {
                "ExecutePipeline": ("pipeline", "PipelineReference"),
                "SynapseNotebook": ("notebook", "NotebookReference"),
                "ExecuteDataFlow": ("dataflow", "DataFlowReference"),
            }.get(ref_type)
            if required:
                key_name, expected_type = required
                reference = node.get("typeProperties", {}).get(key_name)
                if not isinstance(reference, dict) or reference.get("type") != expected_type:
                    raise ValueError(f"{ref_type} requires a typed literal {expected_type}")
                if (
                    ref_type == "ExecutePipeline"
                    and node.get("typeProperties", {}).get("waitOnCompletion", True) is not True
                ):
                    raise ValueError(
                        "Branch packages require waitOnCompletion=true for child pipelines; "
                        "asynchronous child launch completeness cannot be established safely"
                    )
            if ref_type in {
                "SynapseSparkJobDefinition",
                "ExecuteSSISPackage",
                "ExecuteWranglingDataflow",
            }:
                raise ValueError("Unsupported branch activity: " + ref_type)
        active.remove(key)
        artifacts[key] = definition
        order.append(key)

    visit("pipeline", pipeline)
    resolved = {**copy.deepcopy(profile.parameters), **copy.deepcopy(parameters or {})}
    declarations = artifacts["pipeline/" + pipeline]["properties"].get("parameters", {})
    unknown = resolved.keys() - declarations.keys()
    if unknown:
        raise ValueError("Unknown pipeline parameters: " + ", ".join(sorted(unknown)))
    for name, declaration in declarations.items():
        if name not in resolved:
            if "defaultValue" not in declaration:
                raise ValueError("Missing pipeline parameter: " + name)
            resolved[name] = copy.deepcopy(declaration["defaultValue"])
        if str(declaration.get("type", "")).lower() in {"securestring", "secureobject"}:

            def remember(value):
                if isinstance(value, str):
                    register_secret(value)
                elif isinstance(value, dict):
                    for child in value.values():
                        remember(child)
                elif isinstance(value, list):
                    for child in value:
                        remember(child)

            remember(resolved[name])
    return ExecutionPackage(snapshot, pipeline, profile_name, profile, resolved, artifacts, order)
