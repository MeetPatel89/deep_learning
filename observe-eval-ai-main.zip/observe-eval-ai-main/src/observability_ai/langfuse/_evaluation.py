"""Adapt core evaluator results at the optional SDK boundary."""

from collections.abc import Callable, Sequence
from inspect import isawaitable
from typing import Any

from langfuse.experiment import Evaluation, EvaluatorFunction

from ..evaluation.results import EvaluationOutput, EvaluationResult, Evaluator


def _sdk_evaluations(output: EvaluationOutput) -> list[Evaluation]:
    results: tuple[EvaluationResult, ...]
    if isinstance(output, EvaluationResult):
        results = (output,)
    elif isinstance(output, Sequence) and not isinstance(output, (str, bytes)):
        results = tuple(output)
    else:
        raise TypeError("evaluators must return EvaluationResult values")
    converted: list[Evaluation] = []
    for result in results:
        if not isinstance(result, EvaluationResult):
            raise TypeError("evaluators must return EvaluationResult values")
        if result.data_type == "TEXT":
            raise ValueError("SDK experiment and batch evaluations do not support TEXT")
        converted.append(
            Evaluation(
                name=result.name,
                value=result.value,
                data_type=result.data_type,
                comment=result.comment,
                metadata=dict(result.metadata),
            )
        )
    return converted


def _adapt_evaluator(
    evaluator: Evaluator,
    *,
    on_error: Callable[[str], None] | None = None,
) -> EvaluatorFunction:
    if not callable(evaluator):
        raise TypeError("evaluators must contain callable evaluators")

    async def adapted(
        *,
        input: object,
        output: object,
        expected_output: object,
        metadata: dict[str, Any] | None,
        **kwargs: object,
    ) -> list[Evaluation]:
        try:
            result = evaluator(
                input=input,
                output=output,
                expected_output=expected_output,
                metadata=metadata,
            )
            evaluated = await result if isawaitable(result) else result
            return _sdk_evaluations(evaluated)
        except Exception as exc:
            if on_error is not None:
                on_error(f"{adapted.__name__}: {type(exc).__name__}: {exc}")
            raise

    adapted.__name__ = getattr(evaluator, "__name__", type(evaluator).__name__)
    return adapted


def _validate_integer(name: str, value: int, *, minimum: int = 1) -> None:
    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError(f"{name} must be an integer")
    if value < minimum:
        raise ValueError(f"{name} must be at least {minimum}")
