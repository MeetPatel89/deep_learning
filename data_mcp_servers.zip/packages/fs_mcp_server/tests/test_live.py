import os

import pytest
from fs_mcp_server.config import get_config
from fs_mcp_server.server import FSService


@pytest.mark.live
def test_live_cloud_listing():
    store = os.environ.get("FS_MCP_LIVE_STORE")
    if not store or not os.environ.get("FS_MCP_CONFIG"):
        pytest.skip("Set FS_MCP_CONFIG and FS_MCP_LIVE_STORE explicitly")
    result = FSService(get_config()).list_paths(store, limit=5)
    assert "items" in result


@pytest.mark.azurite
def test_azurite_blob_compatible_listing(monkeypatch):
    config = os.environ.get("FS_MCP_AZURITE_CONFIG")
    store = os.environ.get("FS_MCP_AZURITE_STORE")
    if not config or not store:
        pytest.skip("Set FS_MCP_AZURITE_CONFIG and FS_MCP_AZURITE_STORE explicitly")
    monkeypatch.setenv("FS_MCP_CONFIG", config)
    service = FSService(get_config())
    assert service.config.stores[store].protocol == "abfss"
    assert "items" in service.list_paths(store, limit=5)
