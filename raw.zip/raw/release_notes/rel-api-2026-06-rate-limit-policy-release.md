---
doc_id: REL-API-2026-06
title: June 2026 API Gateway Rate-Limit Policy Release Notes
doc_type: release_note
service_id: svc_internal_api_gateway
owner_group: Release Management
visibility: internal
status: published
created_at: "2026-06-18T17:30:00"
updated_at: "2026-06-19T09:30:00"
related_records:
  - CHG-2420
  - KI-307
source_facts:
  - CHG-2420
  - svc_internal_api_gateway
difficulty_tags:
  - change-context
  - plan-specific-behavior
---

# June 2026 API Gateway Rate-Limit Policy Release Notes

## Release summary

June release included new API Gateway rate-limit policy for Internal API Gateway. The change was tracked through CHG-2420 and owned by Platform Engineering.

June release included new API Gateway rate-limit policy.

Release was expected to improve burst control and platform stability. The release note is internal change context for Service Desk L1, Platform Engineering, and Release Management.

## Services affected

Primary service:

- Internal API Gateway, service ID svc_internal_api_gateway.

Dependencies in scope:

- Kong.
- Vault.
- Splunk.

## Changes included

Included changes:

- Deployment of a new rate-limit policy.
- Gateway validation after deployment.
- Post-change monitoring for 429 volume and client impact.

CHG-2420 planned start was 2026-06-18T20:00:00 and planned end was 2026-06-18T20:45:00. The change was updated at 2026-06-18T20:50:00 as completed.

## Expected behavior

Expected behavior after release:

- Internal API Gateway continues routing API traffic.
- Rate limits continue to protect platform stability.
- Burst handling is more controlled.
- Clients receive 429 Too Many Requests only when traffic exceeds applicable limits.

If Business-tier clients report unexpected 429 responses after the release, compare the timing to CHG-2420 and review KI-307.

## Post-release observations

INC-1302 was opened at 2026-06-18T21:05:00 after Business-tier clients reported unexpected 429 errors. Platform Engineering reviewed Splunk and compared applied policy against customer entitlement.

The incident showed that some clients had stricter burst limits applied than entitlement allowed. Platform Engineering adjusted the applied rate-limit policy.

## Known issues added after release

Known issue KI-307 was added after Business-tier clients reported unexpected 429 responses. The approved customer-safe summary is:

"We are reviewing the applied API traffic policy for the affected client."

Internal teams should use RUNBOOK-API-005 for client ID collection, Splunk review, and entitlement comparison.

## Related records

- CHG-2420: Deploy New API Gateway Rate-Limit Policy.
- KI-307: API Clients Receive Unexpected 429 Responses After Rate-Limit Policy Update.
