"""Comparison planning and execution."""
