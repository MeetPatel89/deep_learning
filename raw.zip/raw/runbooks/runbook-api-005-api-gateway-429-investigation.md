---
doc_id: RUNBOOK-API-005
title: API Gateway 429 Investigation Runbook
doc_type: runbook
service_id: svc_internal_api_gateway
owner_group: Platform Engineering
visibility: internal
status: active
created_at: "2026-05-22T10:00:00"
updated_at: "2026-06-19T12:00:00"
related_records:
  - KI-307
  - CHG-2420
  - INC-1302
  - KB-311
  - POL-COMMS-001
source_facts:
  - KI-307
  - svc_internal_api_gateway
difficulty_tags:
  - procedural
  - plan-specific-behavior
  - action-sequencing
---

# API Gateway 429 Investigation Runbook

## Purpose

This runbook describes how to investigate unexpected HTTP 429 Too Many Requests responses from Internal API Gateway. The main known issue is KI-307, where clients receive unexpected 429 errors after a rate-limit policy update.

Internal API Gateway is owned by Platform Engineering. Service Desk L1 should collect the required evidence before escalation.

## When to use this runbook

Use this runbook when:

- An API client reports unexpected 429 Too Many Requests.
- Errors begin after a rate-limit policy deployment.
- The client is Business-tier and reports burst rejection.
- Multiple clients in the same tier report similar behavior.
- The ticket references CHG-2420 or the June 2026 rate-limit policy release.

Do not assume every 429 is an incident. Some 429 responses are expected when a client exceeds entitlement. This runbook is for cases where the rate-limit behavior appears inconsistent with customer tier or recent policy deployment timing.

## Required inputs

Confirm the client ID and customer tier. Also collect:

| Input | Purpose |
| --- | --- |
| Affected endpoint | Helps Platform Engineering locate gateway logs. |
| Approximate timestamp | Needed for Splunk search and policy correlation. |
| Customer tier | Required to compare entitlement against applied policy. |
| Error code | Confirm HTTP 429 Too Many Requests. |
| Recent change reference | Links the issue to CHG-2420 or other policy deployment. |

Do not collect secrets, API keys, tokens, or credentials in the ticket.

## Initial triage

1. Confirm that the client is receiving HTTP 429 Too Many Requests.
2. Confirm the client ID and customer tier.
3. Ask for affected endpoint and approximate timestamp.
4. Check recent API Gateway policy changes.
5. If errors began after CHG-2420, link KI-307.
6. If the client is Business-tier, note that KI-307 affects Business-tier clients more often than Enterprise clients.

Service Desk L1 should escalate to Platform Engineering when the applied policy may not match entitlement.

## Investigation steps

For Platform Engineering:

1. Inspect 429 volume in Splunk for the client ID and affected endpoint.
2. Compare current 429 volume against expected behavior for the customer tier.
3. Review recent API Gateway policy changes, including CHG-2420.
4. Compare applied rate-limit policy against customer entitlement.
5. Determine whether stricter burst limits were applied to the client group.
6. Adjust the applied policy if it does not match entitlement.
7. Confirm 429 volume normalizes after adjustment.

The key distinction is whether the client exceeded entitlement or whether the gateway applied a policy that does not match entitlement.

## Decision points

Use these decision points:

- If the client exceeded entitlement, provide normal 429 guidance and do not open a platform incident.
- If the client tier is unknown, collect tier before escalation.
- If Splunk shows no elevated 429 volume, verify timestamp and endpoint.
- If errors began after a policy deployment, compare applied policy to entitlement.
- If applied policy does not match entitlement, escalate to Platform Engineering for correction.

Escalate to Platform Engineering if applied policy does not match entitlement.

## Workaround or recovery steps

When KI-307 matches:

1. Confirm client ID, endpoint, approximate timestamp, and customer tier.
2. Inspect 429 volume in Splunk.
3. Compare applied rate-limit policy against customer entitlement.
4. Adjust the applied policy after Platform Engineering confirms mismatch.
5. Monitor 429 volume after adjustment.
6. Ask Service Desk L1 to confirm the customer-safe update has been sent.

INC-1302 was resolved after Platform Engineering adjusted the applied rate-limit policy.

## Escalation criteria

Escalate to Platform Engineering when:

- Business-tier clients report unexpected 429 after a policy release.
- Multiple clients report the same pattern.
- The applied policy appears stricter than entitlement.
- Splunk shows elevated 429 volume after CHG-2420.
- Service Desk L1 cannot determine whether the 429 behavior is expected.

Notify Release Management if the incident appears tied to a recently completed API Gateway change.

## Customer-safe communication

Use POL-COMMS-001 and KB-311 for external wording. Approved KI-307 summary:

"We are reviewing the applied API traffic policy for the affected client."

Avoid stating that an internal policy configuration mistake occurred. Do not expose applied policy internals, entitlement mismatch analysis, or gateway configuration detail in customer-facing text.

## Related records

- KI-307: API Clients Receive Unexpected 429 Responses After Rate-Limit Policy Update.
- CHG-2420: Deploy New API Gateway Rate-Limit Policy.
- INC-1302: Business-Tier API Clients Receive 429 Errors After Rate-Limit Policy Deployment.
- KB-311: API 429 Too Many Requests Troubleshooting.
- POL-COMMS-001: Customer-Safe Communication Policy.

