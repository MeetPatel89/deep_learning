---
doc_id: KI-221
title: Payments Dashboard Data Freshness Delay After Synapse/Fabric Refresh Failure
doc_type: known_issue
service_id: svc_payments_reporting
owner_group: Data Applications
visibility: internal
status: active
created_at: "2026-06-16T00:30:00"
updated_at: "2026-06-16T11:00:00"
related_records:
  - CHG-2411
  - INC-1217
  - PRB-304
  - RUNBOOK-PAY-007
source_facts:
  - KI-221
  - svc_payments_reporting
difficulty_tags:
  - azure-data-stack
  - source-vs-reporting-layer
  - customer-safe-summary
servicenow:
  table: u_known_issue
  number: KI00221
  state: Active
  business_service: Payments Reporting Service
  cmdb_ci: Payments Reporting Pipeline
  assignment_group: Data Applications
  related_change: CHG002411
  related_incident: INC001217
  related_problem: PRB000304
  workaround_available: true
  visibility: internal
  contains_customer_safe_wording: true
---

# Payments Dashboard Data Freshness Delay After Synapse/Fabric Refresh Failure

## Record details

| Field | Value |
| --- | --- |
| Table | u_known_issue |
| Number | KI00221 |
| State | Active |
| Business service | Payments Reporting Service |
| Configuration item | Payments Reporting Pipeline |
| Assignment group | Data Applications |
| Related change | CHG002411 |
| Related incident | INC001217 |
| Related problem | PRB000304 |
| Workaround available | true |
| Visibility | internal |
| Contains customer-safe wording | true |

## Summary

KI-221 documents a Payments Reporting Service freshness issue where dashboards and exports remain behind even though upstream processing appears successful. Payments dashboard data can be stale even when the Databricks transformation job succeeds.

The issue is usually reported as dashboard data freshness delay, stale reporting view, payment export mismatch, or latest partition not reflected in Fabric. It is linked to CHG-2411 and INC-1217.

## Affected service

Affected service:

- Payments Reporting Service, service ID svc_payments_reporting.

Owning and escalation group:

- Data Applications.

Relevant dependencies:

- Azure Synapse Analytics.
- Microsoft Fabric.
- Azure SQL Database.
- Azure Databricks.
- Internal API Gateway.

## Symptoms

Support should look for this pattern:

- Payments dashboard data is stale by more than four hours.
- Databricks transformation job shows successful completion.
- Azure SQL Database staging tables contain current payment transaction records.
- Synapse or Fabric reporting layer still shows the previous data refresh watermark.
- Business users report that exported payment totals do not match the operational transaction view.

Azure SQL Database staging tables can contain current payment transaction records while Synapse or Fabric still shows an old refresh watermark.

## Root cause

The downstream Synapse/Fabric reporting refresh can skip the latest partition when the Databricks transformation succeeds but the Azure SQL Database control-table watermark is not advanced correctly.

This is an internal root-cause detail. Customer-facing updates should not over-explain control-table behavior and should use the customer-safe summary below.

## Workaround

Workaround is to validate the Azure SQL Database control-table watermark, confirm the latest Databricks output partition, rerun Synapse/Fabric refresh, and backfill from the last successful payment partition if needed.

Recommended sequence:

1. Confirm dashboard staleness duration.
2. Check Databricks transformation completion.
3. Validate Azure SQL Database staging table freshness.
4. Compare the Azure SQL Database control-table watermark to the latest Databricks output partition.
5. Rerun Synapse/Fabric reporting refresh.
6. Backfill from the last successful payment partition if the latest partition was skipped.
7. Ask Service Desk L1 to confirm dashboard and export totals with business users.

## Escalation guidance

Escalation group is Data Applications. Escalate when L1 confirms dashboard staleness and source transaction availability, when export totals do not match expected reporting totals, or when watermark and partition state cannot be reconciled.

If the symptoms began after CHG-2411, note the change-to-incident relationship and notify Release Management.

## Customer-safe summary

Customer-safe summary is: Reporting data is delayed, but source payment transactions are not lost.

This wording is appropriate when source transactions are confirmed available but the reporting layer is behind.

## Related records

- CHG-2411: Update Databricks Runtime and Synapse/Fabric Refresh Pipeline for Payments Reporting Service.
- INC-1217: Payments Dashboard Stale After Refresh Pipeline Update.
- PRB-304: Payments Reporting Watermark Not Advanced After Successful Databricks Transformation.
- RUNBOOK-PAY-007: Payments Reporting Data Freshness Runbook.

