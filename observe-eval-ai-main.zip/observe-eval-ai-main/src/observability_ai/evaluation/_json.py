"""Strict JSON decoding for evaluator inputs and judge responses."""

from json import loads
from math import isfinite


def _reject_constant(value: str) -> object:
    raise ValueError("non-finite JSON numbers are not supported")


def _unique_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON object keys are not supported")
        result[key] = value
    return result


def _finite_float(value: str) -> float:
    number = float(value)
    if not isfinite(number):
        raise ValueError("JSON numbers must be finite")
    return number


def _strict_json(text: str) -> object:
    return loads(
        text,
        parse_constant=_reject_constant,
        parse_float=_finite_float,
        object_pairs_hook=_unique_object,
    )
