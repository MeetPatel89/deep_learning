import bz2
import gzip
import lzma
import zipfile
from pathlib import Path

import polars as pl
import pytest
from data_mcp_core.formats import (
    detect_format,
    iter_file_batches,
    read_dataset,
    scan_dataset,
    write_dataset,
)
from polars.testing import assert_frame_equal


@pytest.fixture
def data():
    return pl.DataFrame({"id": [1, 2], "name": ["alice", "café"]})


@pytest.mark.parametrize(
    "format,extension",
    [
        ("csv", "csv"),
        ("parquet", "parquet"),
        ("ndjson", "jsonl"),
        ("ipc", "feather"),
        ("excel", "xlsx"),
    ],
)
def test_native_writer_reader_roundtrip(tmp_path, data, format, extension):
    path = str(tmp_path / f"data.{extension}")
    write_dataset(data, path, format)
    assert detect_format(path)["format"] == format
    assert_frame_equal(read_dataset(path), data)
    batches = list(iter_file_batches(path, batch_size=1))
    assert sum(frame.height for frame in batches) == 2


@pytest.mark.parametrize(
    "extension,compress", [("gz", gzip.compress), ("bz2", bz2.compress), ("xz", lzma.compress)]
)
def test_compressed_csv(tmp_path, extension, compress):
    path = tmp_path / f"data.csv.{extension}"
    path.write_bytes(compress(b"id;name\n1;alice\n2;bob\n"))
    detected = detect_format(str(path))
    assert detected["delimiter"] == ";"
    assert read_dataset(str(path)).height == 2


def test_zstd_zip_and_members(tmp_path):
    import zstandard

    payload = b"id,name\n1,alice\n"
    zstd = tmp_path / "data.csv.zst"
    zstd.write_bytes(zstandard.ZstdCompressor().compress(payload))
    assert read_dataset(str(zstd)).height == 1
    path = tmp_path / "data.csv.zip"
    with zipfile.ZipFile(path, "w") as archive:
        archive.writestr("data.csv", payload)
    assert read_dataset(str(path)).height == 1
    with zipfile.ZipFile(path, "a") as archive:
        archive.writestr("other.csv", payload)
    with pytest.raises(ValueError, match="archive_member"):
        read_dataset(str(path))
    assert read_dataset(str(path), options={"archive_member": "data.csv"}).height == 1


def test_json_text_fixed_width_and_xml(tmp_path, data):
    path = tmp_path / "data.json"
    data.write_json(path)
    assert_frame_equal(read_dataset(str(path)), data)
    log = tmp_path / "data.log"
    log.write_text("first\nsecond\n")
    assert read_dataset(str(log)).to_dicts() == [{"line": "first"}, {"line": "second"}]
    fwf = tmp_path / "data.fwf"
    fwf.write_text("01 alice\n02 bob  \n")
    assert read_dataset(
        str(fwf), options={"column_specs": {"id": [0, 2], "name": [3, 8]}}
    ).to_dicts() == [{"id": "01", "name": "alice"}, {"id": "02", "name": "bob"}]
    xml = tmp_path / "data.xml"
    xml.write_text(
        '<root><row id="1"><name>alice</name></row><row id="2"><name>bob</name></row></root>'
    )
    frame = read_dataset(
        str(xml),
        options={"record_xpath": "/root/row", "fields": {"id": "@id", "name": "name/text()"}},
    )
    assert frame.to_dicts() == [{"id": "1", "name": "alice"}, {"id": "2", "name": "bob"}]
    with pytest.raises(ValueError, match="record_xpath"):
        read_dataset(str(xml))


def test_orc_and_avro_use_arrow_and_polars(tmp_path, data):
    import fastavro
    import pyarrow.orc as orc

    path = tmp_path / "data.orc"
    orc.write_table(data.to_arrow(), path)
    assert_frame_equal(read_dataset(str(path)), data)
    path = tmp_path / "data.avro"
    schema = {
        "type": "record",
        "name": "Data",
        "fields": [{"name": "id", "type": "long"}, {"name": "name", "type": "string"}],
    }
    with path.open("wb") as handle:
        fastavro.writer(handle, schema, data.to_dicts())
    assert_frame_equal(read_dataset(str(path)), data)


def test_ods_and_legacy_formats(tmp_path, data):
    from odf.opendocument import OpenDocumentSpreadsheet
    from odf.table import Table, TableCell, TableRow
    from odf.text import P

    document = OpenDocumentSpreadsheet()
    table = Table(name="Data")
    for values in [["id", "name"], [1, "alice"], [2, "café"]]:
        row = TableRow()
        for value in values:
            cell = (
                TableCell(valuetype="float", value=value)
                if isinstance(value, int)
                else TableCell(valuetype="string")
            )
            cell.addElement(P(text=str(value)))
            row.addElement(cell)
        table.addElement(row)
    document.spreadsheet.addElement(table)
    path = tmp_path / "data.ods"
    document.save(str(path))
    assert_frame_equal(read_dataset(str(path)), data)
    pd = pytest.importorskip("pandas")
    pyreadstat = pytest.importorskip("pyreadstat")
    frame = pd.DataFrame(data.to_dicts())
    for extension, writer in [
        ("dta", pyreadstat.write_dta),
        ("sav", pyreadstat.write_sav),
        ("xpt", pyreadstat.write_xport),
    ]:
        path = tmp_path / f"data.{extension}"
        kwargs = {"file_format_version": 5} if extension == "xpt" else {}
        writer(frame, str(path), **kwargs)
        read = read_dataset(str(path))
        assert read.height == 2
        assert read.columns == ["id", "name"]


def test_delta_time_travel_append_merge_and_restore(tmp_path, data):
    path = str(tmp_path / "delta")
    write_dataset(data, path, "delta", {"mode": "overwrite"})
    write_dataset(pl.DataFrame({"id": [3], "name": ["third"]}), path, "delta", {"mode": "append"})
    assert detect_format(path)["format"] == "delta"
    assert read_dataset(path).height == 3
    assert_frame_equal(read_dataset(path, options={"version": 0}), data)
    write_dataset(
        pl.DataFrame({"id": [2, 4], "name": ["updated", "fourth"]}),
        path,
        "delta",
        {"mode": "merge", "predicate": "source.id = target.id"},
    )
    assert read_dataset(path).sort("id")["name"].to_list() == [
        "alice",
        "updated",
        "third",
        "fourth",
    ]


def test_parquet_hive_directory_and_empty_schema(tmp_path):
    directory = tmp_path / "hive" / "year=2026"
    directory.mkdir(parents=True)
    pl.DataFrame({"id": [1, 2]}).write_parquet(directory / "part.parquet")
    frame = read_dataset(str(tmp_path / "hive"))
    assert frame["year"].to_list() == [2026, 2026]
    empty = tmp_path / "empty.parquet"
    pl.DataFrame(schema={"id": pl.Int64}).write_parquet(empty)
    batches = list(iter_file_batches(str(empty)))
    assert batches[0].schema == {"id": pl.Int64}
    assert sum(frame.height for frame in batches) == 0


def test_explicit_legacy_encoding_and_staging_cleanup(tmp_path, monkeypatch):
    path = tmp_path / "latin.csv"
    path.write_text("id;name\n1;café\n", encoding="cp1252")
    assert (
        read_dataset(str(path), "csv", {"encoding": "cp1252", "delimiter": ";"})["name"][0]
        == "café"
    )
    import data_mcp_core.formats as formats

    created = []
    original = formats.tempfile.TemporaryDirectory

    def scratch(*args, **kwargs):
        context = original(*args, **kwargs)
        created.append(Path(context.name))
        return context

    monkeypatch.setattr(formats.tempfile, "TemporaryDirectory", scratch)
    compressed = tmp_path / "data.csv.gz"
    compressed.write_bytes(gzip.compress(b"id\n1\n"))
    with pytest.raises(RuntimeError):
        with scan_dataset(str(compressed)):
            raise RuntimeError("abort")
    assert created and all(not path.exists() for path in created)


def test_iceberg_metadata_file(tmp_path):
    pytest.importorskip("pyiceberg")
    import pyarrow as pa
    from pyiceberg.catalog.sql import SqlCatalog

    catalog = SqlCatalog("test", uri="sqlite:///:memory:", warehouse=tmp_path.as_uri())
    catalog.create_namespace("test")
    table = catalog.create_table("test.data", pa.schema([pa.field("id", pa.int64())]))
    table.append(pa.table({"id": [1, 2]}))
    assert read_dataset(table.metadata_location).to_dicts() == [{"id": 1}, {"id": 2}]


def test_remote_compressed_and_excel_staging(tmp_path, data):
    import fsspec
    from data_mcp_core.stores import StoreConfig, resolve_store

    memory = fsspec.filesystem("memory")
    memory.pipe("bucket/test-data/data.csv.gz", gzip.compress(b"id,name\n1,alice\n"))
    compressed = resolve_store(
        StoreConfig(protocol="s3", bucket="bucket", root="test-data"), "data.csv.gz"
    )
    compressed._filesystem = memory
    assert read_dataset(compressed).to_dicts() == [{"id": 1, "name": "alice"}]
    path = tmp_path / "cloud.xlsx"
    data.write_excel(path)
    memory.pipe("bucket/test-data/cloud.xlsx", path.read_bytes())
    excel = resolve_store(compressed.store, "cloud.xlsx")
    excel._filesystem = memory
    assert_frame_equal(read_dataset(excel), data)


def test_glob_datasets_do_not_follow_escaping_symlinks(tmp_path):
    from data_mcp_core.stores import StoreConfig, resolve_store

    root = tmp_path / "root"
    root.mkdir()
    outside = tmp_path / "outside.parquet"
    pl.DataFrame({"id": [99]}).write_parquet(outside)
    (root / "escape.parquet").symlink_to(outside)
    with pytest.raises(PermissionError):
        read_dataset(resolve_store(StoreConfig(root=str(root)), "*.parquet"), "parquet")
