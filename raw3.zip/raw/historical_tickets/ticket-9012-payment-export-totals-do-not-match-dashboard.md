---
doc_id: TICKET-9012
title: Payment Export Totals Do Not Match Dashboard
doc_type: historical_ticket
service_id: svc_payments_reporting
owner_group: Service Desk L1
visibility: internal
status: closed
created_at: "2026-06-16T08:10:00"
updated_at: "2026-06-16T11:45:00"
related_records:
  - INC-1217
  - KI-221
  - RUNBOOK-PAY-007
source_facts:
  - KI-221
  - svc_payments_reporting
difficulty_tags:
  - historical-resolution
  - source-vs-reporting-layer
servicenow:
  table: incident
  number: INC009012
  parent_incident: INC001217
  state: Closed
  impact: 2
  urgency: 2
  priority: 3
  priority_label: "3 - Moderate"
  category: Data
  subcategory: Reporting
  business_service: Payments Reporting Service
  cmdb_ci: Payments Reporting Pipeline
  assignment_group: Data Applications
  opened_by_group: Service Desk L1
  contact_type: Email
  related_known_issue: KI00221
  visibility: internal
  contains_customer_safe_wording: false
---

# Payment Export Totals Do Not Match Dashboard

## Record details

| Field | Value |
| --- | --- |
| Table | incident |
| Number | INC009012 |
| Parent incident | INC001217 |
| State | Closed |
| Impact | 2 |
| Urgency | 2 |
| Priority | 3 - Moderate |
| Category | Data |
| Subcategory | Reporting |
| Business service | Payments Reporting Service |
| Configuration item | Payments Reporting Pipeline |
| Assignment group | Data Applications |
| Opened by group | Service Desk L1 |
| Contact type | Email |
| Related known issue | KI00221 |
| Visibility | internal |
| Contains customer-safe wording | false |

## Ticket summary

TICKET-9012 was opened after a business user reported that exported payment totals did not match dashboard totals. The ticket was linked to INC-1217 because the symptoms matched the stale reporting issue already under investigation.

This ticket is useful for future retrieval because it describes KI-221 using business phrasing rather than platform phrasing.

## User report

The user reported that a payment export generated during the morning review did not match the dashboard totals expected for the same reporting period. The user did not report missing source transactions; the concern was that the reporting view and export were inconsistent.

The ticket was opened at 2026-06-16T08:10:00, after INC-1217 had been resolved but while related user reports were still being reconciled.

## Triage notes

Service Desk L1 collected:

- Affected dashboard name.
- Export time.
- Expected reporting period.
- User-visible dashboard timestamp.
- Whether other business users saw the same totals.

Source transaction records were present in Azure SQL Database staging tables. Service Desk L1 escalated to Data Applications because the source-vs-reporting-layer pattern matched KI-221.

## Related incident or known issue

Related records:

- INC-1217: Payments Dashboard Stale After Refresh Pipeline Update.
- KI-221: Payments Dashboard Data Freshness Delay After Synapse/Fabric Refresh Failure.
- RUNBOOK-PAY-007: Payments Reporting Data Freshness Runbook.

The incident notes showed that Databricks transformation completed successfully while Synapse/Fabric still showed the previous refresh watermark. That explained why an export could look inconsistent with the expected dashboard period.

## Resolution

Resolution followed RUNBOOK-PAY-007. Data Applications confirmed the latest Databricks output partition, reran the Synapse/Fabric reporting refresh, and used the backfill from the last successful payment partition where needed.

After the reporting layer refreshed, the export and dashboard totals aligned for the expected reporting period.

## Customer-facing update

Customer-facing update stated that reporting data was delayed but source transactions were not lost.

The update avoided internal details about control-table watermark behavior, Databricks output partition handling, and Synapse/Fabric refresh mechanics.

## Closure notes

Closed at 2026-06-16T11:45:00. Closure reason: known issue matched, reporting layer refreshed, user-visible export and dashboard totals confirmed aligned.

The ticket remains linked to KI-221 for future cases where a payment export mismatch is caused by stale reporting rather than source transaction loss.

## Related records

- INC-1217: Payments Dashboard Stale After Refresh Pipeline Update.
- KI-221: Payments Dashboard Data Freshness Delay After Synapse/Fabric Refresh Failure.
- RUNBOOK-PAY-007: Payments Reporting Data Freshness Runbook.

