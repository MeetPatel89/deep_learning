---
doc_id: TASK-PRB-411
title: PRB-411 Problem Tasks
doc_type: problem_task
service_id: svc_internal_api_gateway
owner_group: Platform Engineering
visibility: internal
status: in_progress
created_at: "2026-06-19T09:30:00"
updated_at: "2026-06-21T10:00:00"
related_records:
  - PRB-411
  - KI-307
  - RUNBOOK-API-005
source_facts:
  - KI-307
  - svc_internal_api_gateway
difficulty_tags:
  - root-cause
  - task-decomposition
servicenow:
  table: problem_task
  parent: PRB000411
  task_numbers:
    - PTASK0003001
    - PTASK0003002
    - PTASK0003003
  visibility: internal
  contains_customer_safe_wording: false
---

# PRB-411 Problem Tasks

## Record details

| Field | Value |
| --- | --- |
| Table | problem_task |
| Parent | PRB000411 |
| Task numbers | PTASK0003001, PTASK0003002, PTASK0003003 |
| Visibility | internal |
| Contains customer-safe wording | false |

## PTASK0003001 — Confirm entitlement mismatch root cause in policy mapping

| Field | Value |
| --- | --- |
| Number | PTASK0003001 |
| Short description | Confirm entitlement mismatch root cause in policy mapping |
| Assignment group | Platform Engineering |
| State | Closed Complete |
| Opened at | 2026-06-19T09:30:00 |
| Closed at | 2026-06-19T16:00:00 |

Platform Engineering reviewed the policy mapping used by the CHG-2420 rate-limit deployment and confirmed the root cause identified during INC-1302: the new rate-limit policy applied stricter burst limits to some client groups because the applied policy mapping did not match the tier entitlement for those groups. Business-tier client groups were more likely to hit the mismatch than Enterprise clients.

The confirmation was recorded against PRB-411, and the problem state was set to Known Error.

## PTASK0003002 — Document known error KI-307 and update RUNBOOK-API-005

| Field | Value |
| --- | --- |
| Number | PTASK0003002 |
| Short description | Document known error KI-307 and update RUNBOOK-API-005 |
| Assignment group | Platform Engineering |
| State | Closed Complete |
| Opened at | 2026-06-19T09:45:00 |
| Closed at | 2026-06-19T12:00:00 |

Platform Engineering documented the known error in KI-307, including symptoms, the workaround (confirm customer tier, check applied rate-limit policy, escalate entitlement mismatch to Platform Engineering), and the approved customer-safe summary.

RUNBOOK-API-005 was updated so that Service Desk L1 collects client ID, endpoint, timestamp, and tier before escalation, and so that Platform Engineering compares applied rate-limit policy against customer entitlement as a standard investigation step.

## PTASK0003003 — Add tier-entitlement validation to policy deployment pipeline

| Field | Value |
| --- | --- |
| Number | PTASK0003003 |
| Short description | Add tier-entitlement validation to policy deployment pipeline |
| Assignment group | Platform Engineering |
| State | Open / In Progress |
| Opened at | 2026-06-19T10:00:00 |
| Closed at | — |

This task covers the permanent fix: adding an automated validation step to the rate-limit policy deployment pipeline that compares the applied burst limits for each client group against the tier entitlement before the policy goes live. The goal is to catch entitlement mismatches during change validation rather than after client impact.

The task remains in progress as of 2026-06-21T10:00:00, matching the PRB-411 known-error status. Until it is complete, support should continue to use KI-307 and RUNBOOK-API-005 for matching reports after rate-limit policy changes.
