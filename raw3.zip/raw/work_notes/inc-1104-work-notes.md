---
doc_id: WN-INC-1104
title: Work Notes for INC-1104 Employee Portal Login Failures
doc_type: work_notes
service_id: svc_identity_gateway
owner_group: IAM Platform
visibility: internal
status: closed
created_at: "2026-06-12T23:20:00"
updated_at: "2026-06-13T03:45:00"
related_records:
  - INC-1104
  - KI-104
  - RUNBOOK-SSO-003
  - CHG-2407
source_facts:
  - KI-104
  - svc_identity_gateway
difficulty_tags:
  - internal-only-detail
  - timeline-reconstruction
servicenow:
  table: sys_journal_field
  element: work_notes
  parent: INC001104
  parent_table: incident
  visibility: internal
  contains_customer_safe_wording: false
---

# Work Notes for INC-1104 Employee Portal Login Failures

## Record details

| Field | Value |
| --- | --- |
| Table | sys_journal_field |
| Element | work_notes |
| Parent | INC001104 |
| Parent table | incident |
| Visibility | internal |
| Contains customer-safe wording | false |

## Work notes

These are the internal work notes recorded on INC001104. They contain internal diagnostic detail, including stale IdP metadata and cache refresh steps, and must not be copied into customer-facing communication. Use the KI-104 customer-safe summary for external updates.

### 2026-06-12T23:20:00 — Service Desk L1

First reports received of Employee Portal sign-in failures. Users describe an invalid SAML response error before reaching the portal. Opened INC-1104 and began scope confirmation. Contact type is phone.

### 2026-06-12T23:30:00 — Service Desk L1

Confirmed at least three separate users affected across two locations. Some users can log in normally while others cannot, so this is not a full authentication outage. Captured exact error text: invalid SAML response.

### 2026-06-12T23:45:00 — Service Desk L1

Checked the change calendar for identity-related activity in the last 24 hours. Found CHG-2407, Okta signing certificate rotation for Identity Gateway, with a maintenance window of 2026-06-12T22:00:00 to 23:00:00. First incident report came in 18 minutes after the planned window ended. Noted CHG-2407 on the incident.

### 2026-06-12T23:55:00 — Service Desk L1

Symptom pattern matches KI-104: invalid SAML response, partial impact across users, onset shortly after identity maintenance. Linked KI-104 as the candidate known issue. Multi-user impact on a Tier 1 service after an identity change meets the escalation criteria in POL-ESC-001.

### 2026-06-13T00:05:00 — Service Desk L1

Escalated to IAM Platform per POL-ESC-001 with CHG-2407 and KI-104 noted as candidates. Handing platform investigation to IAM Platform; Service Desk L1 retains user communication and retest coordination.

### 2026-06-13T00:25:00 — IAM Platform

Reviewed the Identity Gateway path following RUNBOOK-SSO-003. Working diagnosis is that a subset of gateway nodes is still evaluating sign-in responses against stale IdP metadata cached before the certificate rotation, which explains why impact depends on which node handles the request. Preparing metadata cache refresh.

### 2026-06-13T00:40:00 — IAM Platform

Executed the Identity Gateway metadata cache refresh across gateway nodes using the standard refresh procedure. Nodes now pulling current identity provider metadata. Monitoring sign-in attempts for continued invalid SAML response errors.

### 2026-06-13T01:05:00 — IAM Platform

Verified the active IdP certificate thumbprint on the gateway path. Thumbprint matches the certificate rotated in CHG-2407. Invalid SAML response error rate dropping since the cache refresh. Asked Service Desk L1 to coordinate user retest.

### 2026-06-13T02:10:00 — Service Desk L1

Retest completed with previously affected users. Most affected users confirmed successful Employee Portal sign-in. Remaining reports being handled as user-specific retry and session cleanup cases.

### 2026-06-13T03:45:00 — IAM Platform

No new multi-user failures since retest. Resolving INC-1104. Root-cause follow-up transferred to PRB-202. KI-104 remains active until a permanent fix is recorded. RUNBOOK-SSO-003 confirmed current for cache refresh and thumbprint validation steps.

## Related records

- INC-1104: Employee Portal Login Failures After Okta Certificate Rotation.
- KI-104: SSO Metadata Cache Delay After Certificate Rotation.
- RUNBOOK-SSO-003: Identity Gateway SSO Login Failure Runbook.
- CHG-2407: Rotate Okta Signing Certificate for Identity Gateway.
