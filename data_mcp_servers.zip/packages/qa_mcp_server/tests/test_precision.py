from decimal import Decimal

import polars as pl
import pytest
from qa_mcp_server.models import CompareOptions, OutputOptions, ParquetSource
from qa_mcp_server.service import compare

from .conftest import read_dump


@pytest.mark.parametrize("budget", [1024, 0.00001])
def test_decimal_tolerance_boundary(run_compare, budget):
    result = run_compare(
        [{"id": 1, "v": Decimal("1.0")}],
        [{"id": 1, "v": Decimal("1.3")}],
        primary_keys=["id"],
        numeric_tolerance=0.3,
        memory_budget_mb=budget,
    )
    assert result["counts"]["matched"] == 1


@pytest.mark.parametrize("dtype", [pl.Datetime("ns"), pl.Time, pl.Duration("ns")])
@pytest.mark.parametrize("budget", [1024, 0.00001])
def test_nanosecond_values_do_not_collapse(tmp_path, dtype, budget):
    expected = pl.DataFrame({"id": [1, 2], "v": [1, 2]}).with_columns(pl.col("v").cast(dtype))
    actual = expected.with_columns((pl.col("v").cast(pl.Int64) + 1).cast(dtype))
    epath, apath = tmp_path / "e.parquet", tmp_path / "a.parquet"
    expected.write_parquet(epath)
    actual.write_parquet(apath)
    result = compare(
        ParquetSource(path=epath),
        ParquetSource(path=apath),
        CompareOptions(primary_keys=["id"], memory_budget_mb=budget),
        OutputOptions(output_dir=tmp_path),
    )
    assert result["counts"]["mismatched"] == 2
    assert read_dump(result)["expected.v"].n_unique() == 2
    keyed_on_time = compare(
        ParquetSource(path=epath),
        ParquetSource(path=apath),
        CompareOptions(primary_keys=["v"], memory_budget_mb=budget),
        OutputOptions(output_dir=tmp_path),
    )
    assert keyed_on_time["counts"] == {
        "matched": 0,
        "mismatched": 1,
        "missing_in_actual": 1,
        "extra_in_actual": 1,
    }
