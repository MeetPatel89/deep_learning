import asyncio
import sys
from pathlib import Path

import anyio
import pytest
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from qa_mcp_server.models import CompareOptions, InlineSource, OutputOptions
from qa_mcp_server.server import compare_datasets, inspect_dataset, mcp


def test_three_tools_have_source_schemas():
    tools = asyncio.run(mcp.list_tools())
    assert {tool.name for tool in tools} == {
        "compare_datasets",
        "inspect_dataset",
        "test_sql_connection",
    }
    compare = next(tool for tool in tools if tool.name == "compare_datasets")
    assert "expected" in compare.inputSchema["properties"]
    assert compare.inputSchema["properties"]["expected"]["discriminator"]["propertyName"] == "type"


def test_conflicting_primary_keys_fail(tmp_path):
    source = InlineSource(rows=[{"id": 1, "other": 2}])
    with pytest.raises(ValueError, match="conflicts"):
        compare_datasets(
            source,
            source,
            primary_keys=["id"],
            compare_options=CompareOptions(primary_keys=["other"]),
            output_options=OutputOptions(output_dir=tmp_path),
        )
    assert inspect_dataset(source, sample_size=0)["sample"] == []


def test_stdio_protocol_round_trip(tmp_path):
    async def exercise():
        parameters = StdioServerParameters(command=sys.executable, args=["-m", "qa_mcp_server"])
        async with stdio_client(parameters) as (reader, writer):
            async with ClientSession(reader, writer) as session:
                await session.initialize()
                assert len((await session.list_tools()).tools) == 3
                inspection = await session.call_tool(
                    "inspect_dataset",
                    {
                        "source": {"type": "inline", "rows": [{"id": 1, "v": "a"}]},
                    },
                )
                assert not inspection.isError
                assert inspection.structuredContent["row_count"] == 1
                result = await session.call_tool(
                    "compare_datasets",
                    {
                        "expected": {"type": "inline", "rows": [{"id": 1, "v": "a"}]},
                        "actual": {"type": "inline", "rows": [{"id": 1, "v": "b"}]},
                        "primary_keys": ["id"],
                        "output_options": {"output_dir": str(tmp_path)},
                    },
                )
                assert not result.isError
                assert result.structuredContent["counts"]["mismatched"] == 1
                assert Path(result.structuredContent["report_files"][0]).is_file()
                invalid = await session.call_tool(
                    "compare_datasets",
                    {
                        "expected": {"type": "inline", "rows": [{"id": 1}]},
                        "actual": {"type": "inline", "rows": [{"id": 1}]},
                        "primary_keys": ["missing"],
                        "output_options": {"output_dir": str(tmp_path)},
                    },
                )
                assert invalid.isError

    anyio.run(exercise)
