"""Inline rows are already resident; infer their schema across the whole input."""

from collections.abc import Iterator

import polars as pl

from qa_mcp_server.models import InlineSource


def iter_inline_batches(source: InlineSource, batch_size: int) -> Iterator[pl.DataFrame]:
    if any(not row for row in source.rows):
        raise ValueError("Inline rows must contain at least one column")
    frame = pl.from_dicts(source.rows, infer_schema_length=None) if source.rows else pl.DataFrame()
    if frame.is_empty():
        yield frame
    else:
        yield from frame.iter_slices(batch_size)
