---
doc_id: TASK-INC-1217
title: INC-1217 Incident Tasks
doc_type: incident_task
service_id: svc_payments_reporting
owner_group: Data Applications
visibility: internal
status: closed
created_at: "2026-06-15T23:15:00"
updated_at: "2026-06-16T04:15:00"
related_records:
  - INC-1217
  - KI-221
  - RUNBOOK-PAY-007
source_facts:
  - KI-221
  - svc_payments_reporting
difficulty_tags:
  - action-sequencing
  - task-decomposition
servicenow:
  table: incident_task
  parent: INC001217
  task_numbers:
    - INCT0002001
    - INCT0002002
    - INCT0002003
  visibility: internal
  contains_customer_safe_wording: false
---

# INC-1217 Incident Tasks

## Record details

| Field | Value |
| --- | --- |
| Table | incident_task |
| Parent | INC001217 |
| Task numbers | INCT0002001, INCT0002002, INCT0002003 |
| Visibility | internal |
| Contains customer-safe wording | false |

Three incident tasks were created under INC001217 to structure the investigation and recovery. The task sequence follows RUNBOOK-PAY-007: confirm the user-facing symptom and source availability first, then validate the internal watermark and partition state, then rerun the reporting refresh and verify freshness.

## INCT0002001 — Confirm dashboard staleness and source transaction availability

| Field | Value |
| --- | --- |
| Number | INCT0002001 |
| Short description | Confirm dashboard staleness and source transaction availability |
| Assignment group | Service Desk L1 |
| State | Closed Complete |
| Opened at | 2026-06-15T23:15:00 |
| Closed at | 2026-06-16T00:25:00 |

Service Desk L1 confirmed with multiple business users that Payments Reporting dashboards showed a stale reporting period and that exported payment totals did not match the operational transaction view. L1 recorded the affected dashboard names, visible timestamps, and expected reporting period.

Source transaction availability was confirmed with Data Applications: Azure SQL Database staging tables contained current payment transaction records, so the issue was reporting freshness rather than data loss. The symptom pattern was matched to KI-221 and escalated.

## INCT0002002 — Validate control-table watermark and latest Databricks partition

| Field | Value |
| --- | --- |
| Number | INCT0002002 |
| Short description | Validate control-table watermark and latest Databricks partition |
| Assignment group | Data Applications |
| State | Closed Complete |
| Opened at | 2026-06-16T00:30:00 |
| Closed at | 2026-06-16T02:00:00 |

Data Applications confirmed the Databricks transformation job had completed successfully, then compared the Azure SQL Database control-table watermark against the latest Databricks output partition. The watermark had not advanced after the successful transformation, so the Synapse/Fabric reporting refresh had skipped the latest partition.

The finding matched the KI-221 root-cause pattern and the timing correlated with CHG-2411, which completed at 2026-06-15T22:30:00. The watermark and latest partition state were validated as the precondition for the refresh rerun.

## INCT0002003 — Rerun Synapse/Fabric reporting refresh and verify freshness

| Field | Value |
| --- | --- |
| Number | INCT0002003 |
| Short description | Rerun Synapse/Fabric reporting refresh and verify freshness |
| Assignment group | Data Applications |
| State | Closed Complete |
| Opened at | 2026-06-16T02:05:00 |
| Closed at | 2026-06-16T04:15:00 |

Data Applications reran the Synapse/Fabric reporting refresh starting at 2026-06-16T02:10:00 and completed a backfill from the last successful payment partition at 2026-06-16T03:05:00 to cover the skipped interval.

Verification confirmed the dashboard advanced to the expected reporting period and regenerated export totals matched the operational transaction view. Service Desk L1 confirmed with business users, and the incident was resolved at 2026-06-16T04:15:00.
