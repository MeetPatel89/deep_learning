---
doc_id: TASK-CHG-2407
title: Change Tasks for CHG-2407 Okta Signing Certificate Rotation
doc_type: change_task
service_id: svc_identity_gateway
owner_group: IAM Platform
visibility: internal
status: closed
created_at: "2026-06-11T09:00:00"
updated_at: "2026-06-13T11:00:00"
related_records:
  - CHG-2407
  - INC-1104
  - POL-CAB-001
source_facts:
  - CHG-2407
  - svc_identity_gateway
difficulty_tags:
  - change-context
  - action-sequencing
servicenow:
  table: change_task
  parent: CHG002407
  task_numbers:
    - CTASK0001001
    - CTASK0001002
    - CTASK0001003
    - CTASK0001004
  visibility: internal
  contains_customer_safe_wording: false
---

# Change Tasks for CHG-2407 Okta Signing Certificate Rotation

## Record details

| Field | Value |
| --- | --- |
| Table | change_task |
| Parent | CHG002407 |
| Task numbers | CTASK0001001, CTASK0001002, CTASK0001003, CTASK0001004 |
| Visibility | internal |
| Contains customer-safe wording | false |

## Overview

Four change tasks were executed under CHG002407, which was approved through the CAB process per POL-CAB-001. Three tasks cover the pre-change, implementation, and post-change phases of the certificate rotation. A fourth task was added after INC-1104 for post-implementation review. All tasks are Closed Complete.

## CTASK0001001 — Pre-change validation of current certificate state

| Field | Value |
| --- | --- |
| Number | CTASK0001001 |
| Short description | Pre-change validation of current certificate state |
| Assignment group | IAM Platform |
| State | Closed Complete |
| Opened at | 2026-06-11T09:00:00 |
| Closed at | 2026-06-12T21:45:00 |

Before the maintenance window, IAM Platform confirmed the active Okta signing certificate state, the expected rotation target, and the rollback path of restoring the previous certificate trust configuration. Pre-change checks confirmed Employee Portal sign-in was operating normally going into the window.

The task closed shortly before the window opened at 2026-06-12T22:00:00 with all pre-change conditions confirmed.

## CTASK0001002 — Implement Okta signing certificate rotation

| Field | Value |
| --- | --- |
| Number | CTASK0001002 |
| Short description | Implement Okta signing certificate rotation |
| Assignment group | IAM Platform |
| State | Closed Complete |
| Opened at | 2026-06-12T22:00:00 |
| Closed at | 2026-06-12T22:40:00 |

IAM Platform applied the Okta signing certificate rotation for Identity Gateway inside the planned window. The implementation followed the normal identity maintenance sequence and completed without error at the implementation level.

The task closed at 2026-06-12T22:40:00 with the new certificate active on the identity provider side.

## CTASK0001003 — Post-change validation of sign-in path

| Field | Value |
| --- | --- |
| Number | CTASK0001003 |
| Short description | Post-change validation of sign-in path |
| Assignment group | IAM Platform |
| State | Closed Complete |
| Opened at | 2026-06-12T22:40:00 |
| Closed at | 2026-06-12T23:00:00 |

Post-change validation confirmed that Identity Gateway accepted the active IdP certificate thumbprint and that a test sign-in to Employee Portal succeeded. No universal outage was observed before closure, and the change was marked successful at the planned end time of 2026-06-12T23:00:00.

The validation scope was the primary sign-in path. It did not include confirming that every Identity Gateway node had refreshed IdP metadata.

## CTASK0001004 — Post-implementation review after INC-1104

| Field | Value |
| --- | --- |
| Number | CTASK0001004 |
| Short description | Post-implementation review after INC-1104 |
| Assignment group | IAM Platform |
| State | Closed Complete |
| Opened at | 2026-06-13T09:00:00 |
| Closed at | 2026-06-13T11:00:00 |

INC-1104 was opened at 2026-06-12T23:18:00, 18 minutes after the change window closed, after users reported invalid SAML response errors and partial Employee Portal login failures. This review task examined why post-change validation did not catch the condition.

The review concluded that the CTASK0001003 validation covered the primary sign-in path but did not cover per-node metadata refresh, so a subset of Identity Gateway nodes continued using stale IdP metadata after the rotation. The condition is documented as known issue KI-104, and the permanent-fix evaluation is tracked under PRB-202. The review recommended adding per-node metadata refresh verification to future identity certificate rotation changes.

## Related records

- CHG-2407: Rotate Okta Signing Certificate for Identity Gateway.
- INC-1104: Employee Portal Login Failures After Okta Certificate Rotation.
- POL-CAB-001: Change Advisory Board Approval Policy.
