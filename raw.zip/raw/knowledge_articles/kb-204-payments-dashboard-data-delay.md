---
doc_id: KB-204
title: Payments Dashboard Data Delay
doc_type: knowledge_article
service_id: svc_payments_reporting
owner_group: Service Desk L1
visibility: customer_safe
status: published
created_at: "2026-05-30T12:00:00"
updated_at: "2026-06-16T13:00:00"
related_records:
  - RUNBOOK-PAY-007
  - KI-221
  - POL-COMMS-001
source_facts:
  - KI-221
  - svc_payments_reporting
difficulty_tags:
  - customer-safe
  - less-detailed-than-runbook
---

# Payments Dashboard Data Delay

## Summary

Use this article when a user reports that a Payments Reporting dashboard or export appears delayed. Reporting data can be delayed while source transactions remain intact.

Explain that reporting data can be delayed while source transactions remain intact.

This article is customer-safe. It should not include internal reporting-layer mechanics in the user-facing response. Use RUNBOOK-PAY-007 for internal investigation when Service Desk L1 confirms the issue is not a simple timing misunderstanding.

## Symptoms

Users may report:

- The payments dashboard has not updated to the expected reporting period.
- A payment export is older than expected.
- Export totals do not match the dashboard totals they expected to see.
- Multiple users see the same stale reporting period.

Avoid describing this as data loss unless Data Applications has confirmed data loss. The known issue guidance states that reporting data may be delayed while source payment transactions are not lost.

## What support should check first

Provide Service Desk L1 checks for affected dashboard, export time, and expected reporting period.

1. Ask which dashboard or export is affected.
2. Record the visible dashboard timestamp or reporting period.
3. Record when the export was generated.
4. Ask what reporting period the user expected.
5. Confirm whether multiple users see the same delay.
6. Check whether there is an active known issue or incident for Payments Reporting Service.

Do not mention Azure SQL control-table internals in customer-facing text.

## Information to collect

Collect:

- Affected dashboard or export name.
- Expected reporting period.
- Time the user noticed the delay.
- Export generation time, if an export is involved.
- Whether the report affects one user or multiple business users.
- Any business deadline affected by the delay.

Do not request real account numbers, payment identifiers, or sensitive customer data in the ticket.

## Recommended next step

If the dashboard is only slightly behind, confirm the expected refresh timing with the user. If the dashboard is stale beyond the expected refresh interval or multiple users report the same delay, direct unresolved stale reporting issues to Data Applications.

Service Desk L1 should reference RUNBOOK-PAY-007 for internal handling after the initial customer-safe checks are complete.

## Customer-safe response guidance

Use this response as the starting point:

"Reporting data is delayed, but source payment transactions are not lost."

Support can add: "We are checking the affected dashboard or export and will update you when the reporting view has refreshed."

Do not provide details about internal platform components, data-control mechanisms, refresh internals, or partition handling in customer-facing text.

## When to escalate

Escalate to Data Applications when:

- The stale dashboard is confirmed.
- The delay affects multiple business users.
- Export totals do not match expected reporting totals.
- The affected reporting period is older than expected.
- The issue appears after a reporting pipeline release.

Include the dashboard name, export time, expected period, and user-visible staleness duration in the escalation.

## Related records

- RUNBOOK-PAY-007: internal runbook reference for Service Desk L1 escalation.
- KI-221: internal known issue reference.
- POL-COMMS-001: customer-safe communication policy.

Use only approved customer-safe wording when referencing these records outside support.
