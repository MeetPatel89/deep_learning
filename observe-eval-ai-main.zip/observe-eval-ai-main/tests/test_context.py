"""Verify propagated trace dimensions and active recording-span identifiers."""

from asyncio import TaskGroup, sleep
from dataclasses import replace

from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from pytest import raises

from observability_ai import (
    LangfuseSettings,
    Telemetry,
    TraceAttributes,
    current_observation_id,
    current_trace_id,
)


def test_propagation_merges_and_restores_after_errors(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Nested and explicit dimensions override only specified fields and keys."""
    telemetry, exporter = otel
    outer = TraceAttributes(
        session_id="outer",
        user_id="user",
        tags=("outer",),
        metadata={"tenant": "outer", "keep": "yes"},
    )
    with telemetry.propagate(outer):
        with raises(RuntimeError):
            with telemetry.propagate(
                TraceAttributes(session_id="inner", metadata={"tenant": "inner"})
            ):
                with telemetry.observe(
                    "explicit",
                    attributes=TraceAttributes(
                        tags=("explicit",), metadata={"tenant": "explicit"}
                    ),
                ):
                    with telemetry.observe("descendant"):
                        pass
                raise RuntimeError("restore the outer scope")
        with telemetry.observe("restored"):
            pass
    with telemetry.observe("outside"):
        pass
    spans = {span.name: span for span in exporter.get_finished_spans()}
    explicit = spans["explicit"].attributes
    assert explicit is not None
    assert explicit["langfuse.session.id"] == "inner"
    assert explicit["langfuse.user.id"] == "user"
    assert explicit["langfuse.trace.tags"] == ("explicit",)
    assert explicit["langfuse.trace.metadata.tenant"] == "explicit"
    assert explicit["langfuse.trace.metadata.keep"] == "yes"
    descendant = spans["descendant"].attributes
    assert descendant is not None
    assert descendant["langfuse.trace.tags"] == ("outer",)
    assert descendant["langfuse.trace.metadata.tenant"] == "inner"
    assert spans["restored"].attributes == {
        **outer.as_otel_attributes(),
        "langfuse.observation.type": "span",
    }
    assert spans["outside"].attributes == {"langfuse.observation.type": "span"}


async def test_propagation_follows_tasks_without_cross_request_leaks(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Each task inherits dimensions at creation and can override its own scope."""
    telemetry, exporter = otel

    async def child(request: str, index: int) -> None:
        await sleep(0)
        with telemetry.propagate(TraceAttributes(user_id=f"user-{index}")):
            with telemetry.observe(f"{request}-{index}"):
                await sleep(0)

    async def request(name: str) -> None:
        async with TaskGroup() as group:
            with telemetry.propagate(TraceAttributes(session_id=name)):
                for index in range(2):
                    group.create_task(child(name, index))

    async with TaskGroup() as group:
        group.create_task(request("one"))
        group.create_task(request("two"))
    for span in exporter.get_finished_spans():
        request_name, index = span.name.split("-")
        assert span.attributes is not None
        assert span.attributes["langfuse.session.id"] == request_name
        assert span.attributes["langfuse.user.id"] == f"user-{index}"


def test_current_ids_use_raw_and_facade_context(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Current IDs follow nesting, while handle IDs survive span completion."""
    telemetry, _ = otel
    assert current_trace_id() is current_observation_id() is None
    with telemetry.observe("root") as observation:
        assert current_trace_id() == observation.trace_id
        assert current_observation_id() == observation.observation_id
        assert observation.trace_id is not None and len(observation.trace_id) == 32
        assert observation.observation_id is not None
        assert len(observation.observation_id) == 16
        with telemetry.tracer("raw").start_as_current_span("child") as child:
            assert current_trace_id() == observation.trace_id
            assert (
                current_observation_id() == f"{child.get_span_context().span_id:016x}"
            )
        assert current_observation_id() == observation.observation_id
    assert observation.trace_id is not None
    assert current_trace_id() is current_observation_id() is None


def test_unsampled_ids_are_not_current_scoring_targets(
    settings: LangfuseSettings,
) -> None:
    """An unsampled handle has valid IDs, but current-ID helpers decline scoring."""
    exporter = InMemorySpanExporter()
    with Telemetry(
        replace(settings, sample_ratio=0),
        service_name="ids",
        service_version="1",
        span_processor=SimpleSpanProcessor(exporter),
    ) as telemetry:
        with telemetry.observe("unsampled") as observation:
            assert observation.trace_id is not None
            assert observation.observation_id is not None
            assert current_trace_id() is current_observation_id() is None
    assert not exporter.get_finished_spans()
