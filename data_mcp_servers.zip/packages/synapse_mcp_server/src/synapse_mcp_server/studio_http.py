"""Versioned, capture-pinned adapter for Studio's undocumented debug protocol.

No guessed endpoints are enabled. A workspace operator supplies a sanitized,
authenticated protocol capture and pins its digest in configuration. Unsupported
contracts fail before authentication; published-run APIs are never a fallback.
"""

import copy
import hashlib
import json
import re
from datetime import datetime
from pathlib import Path
from urllib.parse import quote

import httpx
from data_mcp_core.auth import SYNAPSE_SCOPE, get_token
from data_mcp_core.guards import require


class UnsupportedStudioContract(ValueError):
    pass


def lookup(value, path):
    for key in path.split("."):
        if not isinstance(value, dict) or key not in value:
            raise UnsupportedStudioContract(f"Studio response contract changed: missing {path}")
        value = value[key]
    return value


def render(template, context):
    if isinstance(template, dict):
        return {k: render(v, context) for k, v in template.items()}
    if isinstance(template, list):
        return [render(v, context) for v in template]
    if isinstance(template, str) and template.startswith("$"):
        if template[1:] not in context:
            raise UnsupportedStudioContract("Unknown Studio request placeholder: " + template)
        return copy.deepcopy(context[template[1:]])
    return template


class StudioHTTPAdapter:
    VERSION = "studio-debug-capture-v1"

    def __init__(self, config, workspace, client=None):
        self.config = config
        self.workspace = workspace
        self.settings = config.workspaces[workspace]
        self.client = client
        self.contract = None

    def validate(self, package=None, expected_digest=None):
        require(self.settings, "allow_run")
        settings = self.settings.studio_http
        if not settings.contract_path or not settings.contract_sha256:
            raise UnsupportedStudioContract(
                "studio_http requires an authenticated, sanitized Studio debug capture: "
                "configure studio_http.contract_path and contract_sha256. "
                "This backend is not integration-validated; no live fallback is permitted."
            )
        data = Path(settings.contract_path).expanduser().read_bytes()
        checksum = hashlib.sha256(data).hexdigest()
        if checksum != settings.contract_sha256 or (
            expected_digest and checksum != expected_digest
        ):
            raise UnsupportedStudioContract(
                "Studio contract digest changed; revalidate the adapter"
            )
        contract = json.loads(data)
        if contract.get("version") != self.VERSION:
            raise UnsupportedStudioContract("Unsupported Studio debug contract version")
        validation = contract.get("validation", {})
        if validation.get("workspace") != self.settings.name or not validation.get(
            "authenticated_at"
        ):
            raise UnsupportedStudioContract(
                "Studio capture must identify its authenticated dev workspace"
            )
        try:
            datetime.fromisoformat(validation["authenticated_at"].replace("Z", "+00:00"))
        except (TypeError, ValueError) as error:
            raise UnsupportedStudioContract("Invalid capture authentication timestamp") from error
        operations = contract.get("operations", {})
        for operation in ("submit", "status", "activities", "cancel"):
            spec = operations.get(operation, {})
            path = spec.get("path", "")
            # The no-live exception is limited to dedicated debug endpoints, never arbitrary HTTP.
            static_segments = [s.lower() for s in path.split("/") if "{" not in s]
            debug_routes = {
                "debug",
                "debugruns",
                "pipelinedebugruns",
                "debugpipelineruns",
                "createdebugrun",
                "createdebugpipelinerun",
                "debugrun",
                "querydebugactivityruns",
                "querydebugpipelineruns",
            }
            if (
                not path.startswith("/")
                or path.startswith("//")
                or any(c in path for c in ("..", "\\", "%", "?", "#", ":"))
                or not debug_routes.intersection(static_segments)
                or {"createrun", "start", "stop", "publish"}.intersection(static_segments)
                or spec.get("method") not in {"GET", "POST"}
            ):
                raise UnsupportedStudioContract(
                    "Only dedicated, workspace-relative debug endpoints are allowed"
                )
            if operation == "submit" and spec["method"] != "POST":
                raise UnsupportedStudioContract("Debug submission must use POST")
            if operation != "submit" and "{run_id}" not in path:
                raise UnsupportedStudioContract(
                    "Debug result operations must be scoped to a recorded run"
                )
            if not isinstance(spec.get("fixture"), dict) or "response" not in spec["fixture"]:
                raise UnsupportedStudioContract(
                    "Each Studio operation requires a sanitized response fixture"
                )
            if "request" not in spec["fixture"]:
                raise UnsupportedStudioContract(
                    "Each Studio operation requires a sanitized request fixture"
                )
            response_field = {
                "submit": "run_id_field",
                "status": "status_field",
                "activities": "items_field",
            }.get(operation)
            if response_field:
                if not isinstance(spec.get(response_field), str):
                    raise UnsupportedStudioContract("Missing response field mapping: " + operation)
                lookup(spec["fixture"]["response"], spec[response_field])
            for template in (spec.get("body"), spec.get("query", {})):
                render(
                    template,
                    {
                        key: None
                        for key in (
                            "pipeline",
                            "parameters",
                            "package",
                            "run_id",
                            "recursive",
                            "continuation",
                        )
                    },
                )
            if operation == "activities" and spec.get("continuation_field"):
                templates = json.dumps([spec.get("body"), spec.get("query")])
                if '"$continuation"' not in templates:
                    raise UnsupportedStudioContract("Activity pagination requires $continuation")
        if package:
            kinds = {key.split("/", 1)[0] for key in package.order}
            if kinds - set(contract.get("supported_artifacts", [])):
                raise UnsupportedStudioContract(
                    "Studio contract does not support this dependency package"
                )
            # A contract must consume the entire package, avoiding omitted definitions.
            body = json.dumps(operations["submit"].get("body"))
            if '"$package"' not in body:
                raise UnsupportedStudioContract("Submission must embed the complete $package")
            template = contract.get(
                "package_template",
                {"pipeline": "$pipeline", "parameters": "$parameters", "artifacts": "$artifacts"},
            )
            encoded = json.dumps(template)
            if '"$artifacts"' not in encoded:
                placeholders = {
                    "pipeline": "pipelines",
                    "dataset": "datasets",
                    "linked_service": "linked_services",
                    "notebook": "notebooks",
                    "data_flow": "data_flows",
                }
                for kind in kinds:
                    if f'"${placeholders[kind]}"' not in encoded:
                        raise UnsupportedStudioContract(
                            "Package template omits artifact kind: " + kind
                        )
            if '"$parameters"' not in encoded and '"$parameters"' not in body:
                raise UnsupportedStudioContract("Submission must include the frozen parameters")
        self.contract = contract
        return checksum

    def _request(self, operation, context):
        require(self.settings, "allow_run")
        self.validate(expected_digest=context.get("contract_digest"))
        spec = self.contract["operations"][operation]
        path = spec["path"]
        for placeholder in re.findall(r"\{([^}]+)\}", path):
            if placeholder not in {"pipeline", "run_id"}:
                raise UnsupportedStudioContract("Unknown debug path placeholder")
            value = context.get(placeholder)
            if not isinstance(value, str) or not value or value in {".", ".."}:
                raise UnsupportedStudioContract("Invalid debug run or pipeline identifier")
            path = path.replace("{" + placeholder + "}", quote(value, safe=""))
        params = render(spec.get("query", {}), context)
        body = render(spec.get("body"), context)
        token = get_token(self.config.auth_profile(self.settings.auth), SYNAPSE_SCOPE)
        if self.client is None:
            self.client = httpx.Client(
                base_url=self.settings.endpoint, timeout=30, follow_redirects=False
            )
        response = self.client.request(
            spec["method"],
            path,
            params=params,
            json=body,
            headers={"Authorization": "Bearer " + token.token},
        )
        if response.status_code in {404, 405, 410}:
            raise UnsupportedStudioContract(
                "Studio debug endpoint is unsupported or changed; no live fallback"
            )
        response.raise_for_status()
        if operation == "cancel" and not response.content:
            return {}
        try:
            data = response.json()
        except ValueError as error:
            raise UnsupportedStudioContract("Studio returned a non-JSON debug response") from error
        if not isinstance(data, dict):
            raise UnsupportedStudioContract("Studio returned a non-object debug response")
        return data

    def submit(self, package, contract_digest):
        self.validate(package, contract_digest)
        package_context = {
            "pipeline": package.pipeline,
            "parameters": package.parameters,
            "artifacts": package.artifacts,
            "pipeline_definition": package.artifacts["pipeline/" + package.pipeline],
        }
        for kind, plural in {
            "pipeline": "pipelines",
            "dataset": "datasets",
            "linked_service": "linked_services",
            "notebook": "notebooks",
            "data_flow": "data_flows",
        }.items():
            package_context[plural] = [
                value for key, value in package.artifacts.items() if key.startswith(kind + "/")
            ]
        template = self.contract.get(
            "package_template",
            {"pipeline": "$pipeline", "parameters": "$parameters", "artifacts": "$artifacts"},
        )
        context = {
            "pipeline": package.pipeline,
            "parameters": package.parameters,
            "package": render(template, package_context),
            "contract_digest": contract_digest,
        }
        result = self._request("submit", context)
        identifier = lookup(result, self.contract["operations"]["submit"]["run_id_field"])
        if not isinstance(identifier, str) or not identifier:
            raise UnsupportedStudioContract("Studio returned an invalid debug run ID")
        return identifier

    def status(self, record, run_id):
        context = {
            "run_id": run_id,
            "pipeline": record["provenance"]["pipeline"],
            "contract_digest": record["contract_digest"],
        }
        result = self._request("status", context)
        state = lookup(result, self.contract["operations"]["status"]["status_field"])
        if state not in {
            "Queued",
            "InProgress",
            "Canceling",
            "Cancelling",
            "Succeeded",
            "Failed",
            "Cancelled",
            "Canceled",
        }:
            raise UnsupportedStudioContract("Unknown Studio debug run status")
        return {**result, "runId": run_id, "status": state}

    def activities(self, record, run_id):
        items, continuation, seen = [], None, set()
        for _ in range(100):
            result = self._request(
                "activities",
                {
                    "run_id": run_id,
                    "pipeline": record["provenance"]["pipeline"],
                    "continuation": continuation,
                    "contract_digest": record["contract_digest"],
                },
            )
            spec = self.contract["operations"]["activities"]
            page = lookup(result, spec["items_field"])
            if not isinstance(page, list) or any(not isinstance(item, dict) for item in page):
                raise UnsupportedStudioContract("Invalid Studio activity result page")
            items.extend(page)
            continuation = (
                lookup(result, spec["continuation_field"])
                if spec.get("continuation_field")
                else None
            )
            if not continuation:
                return items
            if not isinstance(continuation, str) or continuation in seen:
                raise UnsupportedStudioContract("Studio activity pagination did not advance")
            seen.add(continuation)
        raise UnsupportedStudioContract("Studio activity result pagination exceeded limit")

    def cancel(self, record, run_id):
        return self._request(
            "cancel",
            {
                "run_id": run_id,
                "recursive": True,
                "pipeline": record["provenance"]["pipeline"],
                "contract_digest": record["contract_digest"],
            },
        )

    def close(self):
        if self.client:
            self.client.close()
