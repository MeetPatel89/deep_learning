"""Null-safe keyed comparison and exact normalized multiset comparison."""

import json
import math
from dataclasses import dataclass
from decimal import Decimal, localcontext
from typing import Any

import polars as pl

from qa_mcp_server.models import CompareOptions

ROW_INDEX = "__qa_row_index"
STATUSES = ("matched", "mismatched", "missing_in_actual", "extra_in_actual")


@dataclass
class Record:
    status: str
    expected: dict[str, Any] | None
    actual: dict[str, Any] | None
    mismatch_columns: list[str]
    occurrences: int = 1
    side: str | None = None
    duplicate_count: int | None = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "expected": self.expected,
            "actual": self.actual,
            "mismatch_columns": self.mismatch_columns,
            "occurrences": self.occurrences,
            "side": self.side,
            "duplicate_count": self.duplicate_count,
        }


def common_dtype(types: list[pl.DataType]) -> pl.DataType:
    types = [dtype for dtype in types if dtype != pl.Null]
    if not types:
        return pl.String
    # Python row iterators truncate temporal values to microseconds. Preserve their
    # exact identity in both the streaming reports and the disk-backed comparator.
    if any(
        dtype == pl.Time
        or isinstance(dtype, pl.Duration)
        or (isinstance(dtype, pl.Datetime) and dtype.time_unit == "ns")
        for dtype in types
    ):
        return pl.String
    if all(dtype.is_numeric() for dtype in types):
        if any(dtype.is_float() for dtype in types):
            return pl.Float64
        if any(dtype.is_decimal() for dtype in types):
            scale = max(getattr(dtype, "scale", 0) or 0 for dtype in types)
            return pl.Decimal(38, scale)
        if all(dtype.is_unsigned_integer() for dtype in types):
            return pl.UInt64
        if pl.UInt64 in types:
            return pl.Decimal(38, 0)
        return pl.Int64
    if all(dtype == types[0] for dtype in types) and not types[0].is_nested():
        return types[0]
    if all(dtype == pl.Date or isinstance(dtype, pl.Datetime) for dtype in types):
        zones = {dtype.time_zone for dtype in types if isinstance(dtype, pl.Datetime)}
        if len(zones) <= 1:
            return pl.Datetime("us", next(iter(zones), None))
    return pl.String


def canonicalize(
    frame: pl.DataFrame, schema: dict[str, pl.DataType], rename: dict[str, str]
) -> pl.DataFrame:
    frame = frame.rename({name: target for name, target in rename.items() if name in frame})
    expressions = []
    for column, dtype in schema.items():
        if column not in frame:
            expressions.append(pl.lit(None, dtype=dtype).alias(column))
        elif frame.schema[column].is_nested() and dtype == pl.String:
            expressions.append(
                pl.col(column).map_elements(
                    lambda value: json.dumps(
                        value.to_list() if isinstance(value, pl.Series) else value,
                        sort_keys=True,
                        default=str,
                    ),
                    return_dtype=pl.String,
                )
            )
        elif dtype == pl.String and isinstance(frame.schema[column], pl.Duration):
            unit = frame.schema[column].time_unit
            factor = {"ns": 1, "us": 1000, "ms": 1_000_000}[unit]
            expressions.append(
                (pl.col(column).cast(pl.Int64).cast(pl.Decimal(38, 0)) * factor)
                .cast(pl.String)
                .add(pl.lit(" ns"))
                .alias(column)
            )
        elif dtype == pl.String and frame.schema[column] == pl.Time:
            expressions.append(pl.col(column).dt.strftime("%H:%M:%S%.9f"))
        elif dtype == pl.String and isinstance(frame.schema[column], pl.Datetime):
            zone = "%z" if frame.schema[column].time_zone else ""
            expressions.append(pl.col(column).dt.strftime("%Y-%m-%dT%H:%M:%S%.9f" + zone))
        else:
            expressions.append(pl.col(column).cast(dtype, strict=True))
    return frame.select(*expressions, pl.col(ROW_INDEX))


def normalized_expr(column: str, dtype: pl.DataType, options: CompareOptions) -> pl.Expr:
    expression = pl.col(column)
    if dtype == pl.String:
        if options.trim_strings:
            expression = expression.str.strip_chars()
        if options.case_insensitive:
            expression = expression.str.to_lowercase()
    if dtype.is_float():
        # Hashing must give the same bucket to +0/-0 and every NaN representation.
        expression = pl.when(expression == 0).then(0.0).otherwise(expression)
        expression = pl.when(expression.is_nan()).then(float("nan")).otherwise(expression)
    return expression


def key_expressions(
    schema: dict[str, pl.DataType], keys: list[str], options: CompareOptions
) -> list[pl.Expr]:
    return [
        normalized_expr(column, schema[column], options).alias(f"k{i}")
        for i, column in enumerate(keys)
    ]


def _prepare(
    frame: pl.DataFrame,
    schema: dict[str, pl.DataType],
    keys: list[str],
    options: CompareOptions,
    side: str,
    schema_difference: bool = False,
) -> pl.DataFrame:
    prepared = frame.select(
        *key_expressions(schema, keys, options),
        *[pl.col(column).alias(f"{side}{i}") for i, column in enumerate(schema)],
        pl.col(ROW_INDEX).alias("order"),
    )
    # Null keys are never paired if null equality is disabled. In multiset mode,
    # a missing schema column is also distinct from a present null-valued column.
    invalid = pl.any_horizontal([pl.col(f"k{i}").is_null() for i in range(len(keys))])
    unique = invalid if not options.treat_null_as_equal else pl.lit(False)
    if schema_difference:
        unique = pl.lit(True)
    return prepared.with_columns(
        pl.when(unique).then(pl.lit(side)).otherwise(pl.lit("")).alias("null_side"),
        pl.when(unique).then(pl.col("order")).otherwise(pl.lit(0)).alias("null_id"),
    )


def values_equal(expected: Any, actual: Any, options: CompareOptions) -> bool:
    if expected is None or actual is None:
        return options.treat_null_as_equal and expected is None and actual is None
    if isinstance(expected, str) and isinstance(actual, str):
        if options.trim_strings:
            expected, actual = expected.strip(), actual.strip()
        if options.case_insensitive:
            expected, actual = expected.lower(), actual.lower()
    if isinstance(expected, (float, Decimal)) and isinstance(actual, (float, Decimal)):
        if math.isnan(expected) and math.isnan(actual):
            return True
    if expected == actual:
        return True
    if (
        options.numeric_tolerance
        and isinstance(expected, (int, float, Decimal))
        and isinstance(actual, (int, float, Decimal))
        and not isinstance(expected, bool)
        and not isinstance(actual, bool)
    ):
        if isinstance(expected, Decimal) or isinstance(actual, Decimal):
            with localcontext() as context:
                context.prec = 80
                return abs(expected - actual) <= Decimal(str(options.numeric_tolerance))
        return abs(expected - actual) <= options.numeric_tolerance
    return False


def row_record(
    expected: dict[str, Any] | None,
    actual: dict[str, Any] | None,
    columns: list[str],
    keys: list[str],
    options: CompareOptions,
    schema_difference: set[str],
) -> Record:
    if expected is None:
        return Record("extra_in_actual", None, actual, [])
    if actual is None:
        return Record("missing_in_actual", expected, None, [])
    mismatch = [
        column
        for column in columns
        if column not in keys
        and (
            column in schema_difference
            or not values_equal(expected[column], actual[column], options)
        )
    ]
    return Record("mismatched" if mismatch else "matched", expected, actual, mismatch)


def compare_frames(
    expected: pl.DataFrame,
    actual: pl.DataFrame,
    schema: dict[str, pl.DataType],
    options: CompareOptions,
    schema_difference: set[str],
):
    """Yield records; occurrence ranks prevent a duplicate-key Cartesian product."""
    columns = list(schema)
    keys = options.primary_keys or columns
    group_keys = [f"k{i}" for i in range(len(keys))] + ["null_side", "null_id"]
    multiset = not options.primary_keys
    left = _prepare(expected, schema, keys, options, "e", multiset and bool(schema_difference))
    right = _prepare(actual, schema, keys, options, "a", multiset and bool(schema_difference))
    if multiset:
        left = left.group_by(group_keys, maintain_order=True).agg(
            pl.len().cast(pl.UInt64).alias("ecount"),
            *[pl.col(f"e{i}").first() for i in range(len(columns))],
        )
        right = right.group_by(group_keys, maintain_order=True).agg(
            pl.len().cast(pl.UInt64).alias("acount"),
            *[pl.col(f"a{i}").first() for i in range(len(columns))],
        )
    else:
        # Window operations preserve input order within each key.
        for side, frame in (("e", left), ("a", right)):
            duplicate_keys = [f"k{i}" for i in range(len(keys))]
            duplicates = frame.with_columns(pl.len().over(duplicate_keys).alias("duplicates"))
            for row in duplicates.filter(pl.col("duplicates") > 1).iter_rows(named=True):
                values = {column: row[f"{side}{i}"] for i, column in enumerate(columns)}
                yield Record(
                    "duplicate_key",
                    values if side == "e" else None,
                    values if side == "a" else None,
                    [],
                    side="expected" if side == "e" else "actual",
                    duplicate_count=row["duplicates"],
                )
        left = left.with_columns(pl.int_range(pl.len()).over(group_keys).alias("occurrence"))
        right = right.with_columns(pl.int_range(pl.len()).over(group_keys).alias("occurrence"))
        group_keys += ["occurrence"]
        left = left.with_columns(pl.lit(True).alias("epresent"))
        right = right.with_columns(pl.lit(True).alias("apresent"))
    joined = left.join(right, on=group_keys, how="full", coalesce=True, nulls_equal=True)
    if multiset:
        for row in joined.iter_rows(named=True):
            ec, ac = row["ecount"] or 0, row["acount"] or 0
            e = {column: row[f"e{i}"] for i, column in enumerate(columns)} if ec else None
            a = {column: row[f"a{i}"] for i, column in enumerate(columns)} if ac else None
            if common := min(ec, ac):
                yield Record("matched", e, a, [], common)
            if ec > ac:
                yield Record("missing_in_actual", e, None, [], ec - ac)
            if ac > ec:
                yield Record("extra_in_actual", None, a, [], ac - ec)
        return
    flags = []
    for i, (column, dtype) in enumerate(schema.items()):
        if column in keys:
            continue
        e, a = normalized_expr(f"e{i}", dtype, options), normalized_expr(f"a{i}", dtype, options)
        equal = e.eq_missing(a) if options.treat_null_as_equal else (e == a).fill_null(False)
        if dtype.is_numeric() and options.numeric_tolerance:
            # Avoid unsigned underflow and signed integer overflow in subtraction.
            ne, na = (
                (e.cast(pl.Decimal(38, 0)), a.cast(pl.Decimal(38, 0)))
                if dtype.is_integer()
                else (e, a)
            )
            tolerance = (
                pl.lit(Decimal(str(options.numeric_tolerance)))
                if not dtype.is_float()
                else pl.lit(options.numeric_tolerance)
            )
            equal = equal | ((ne - na).abs() <= tolerance).fill_null(False)
        if column in schema_difference:
            equal = pl.lit(False)
        flags.append((~equal).alias(f"f{i}"))
    joined = joined.with_columns(flags)
    for row in joined.iter_rows(named=True):
        e = {column: row[f"e{i}"] for i, column in enumerate(columns)} if row["epresent"] else None
        a = {column: row[f"a{i}"] for i, column in enumerate(columns)} if row["apresent"] else None
        if e is None or a is None:
            yield row_record(e, a, columns, keys, options, schema_difference)
        else:
            mismatch = [
                column for i, column in enumerate(columns) if column not in keys and row[f"f{i}"]
            ]
            yield Record("mismatched" if mismatch else "matched", e, a, mismatch)
