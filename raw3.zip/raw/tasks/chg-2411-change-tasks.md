---
doc_id: TASK-CHG-2411
title: CHG-2411 Change Tasks
doc_type: change_task
service_id: svc_payments_reporting
owner_group: Data Applications
visibility: internal
status: closed
created_at: "2026-06-14T09:00:00"
updated_at: "2026-06-16T11:00:00"
related_records:
  - CHG-2411
  - INC-1217
  - POL-CAB-001
source_facts:
  - CHG-2411
  - svc_payments_reporting
difficulty_tags:
  - change-context
  - action-sequencing
servicenow:
  table: change_task
  parent: CHG002411
  task_numbers:
    - CTASK0002001
    - CTASK0002002
    - CTASK0002003
    - CTASK0002004
  visibility: internal
  contains_customer_safe_wording: false
---

# CHG-2411 Change Tasks

## Record details

| Field | Value |
| --- | --- |
| Table | change_task |
| Parent | CHG002411 |
| Task numbers | CTASK0002001, CTASK0002002, CTASK0002003, CTASK0002004 |
| Visibility | internal |
| Contains customer-safe wording | false |

Four change tasks were created under CHG002411, the Databricks runtime and Synapse/Fabric refresh pipeline update for Payments Reporting Service. Because CHG-2411 was classified High risk, the change required CAB approval per POL-CAB-001; approval was recorded before the implementation window of 2026-06-15T21:00:00 to 2026-06-15T22:30:00. All tasks are Closed Complete.

## CTASK0002001 — Pre-change validation of pipeline state and backout snapshot

| Field | Value |
| --- | --- |
| Number | CTASK0002001 |
| Short description | Pre-change validation of pipeline state and backout snapshot |
| Assignment group | Data Applications |
| State | Closed Complete |
| Opened at | 2026-06-14T09:00:00 |
| Closed at | 2026-06-15T20:45:00 |

Before the change window, Data Applications validated that the payments reporting pipeline was in a healthy state: recent Databricks transformation runs successful, Azure SQL staging and control data consistent, and Synapse/Fabric reporting layer current. A backout snapshot of the pipeline configuration was captured to support rollback if implementation failed.

Pre-change validation completed with no blocking findings, and the change was cleared to proceed within the approved window.

## CTASK0002002 — Update Databricks runtime and deploy refresh pipeline changes

| Field | Value |
| --- | --- |
| Number | CTASK0002002 |
| Short description | Update Databricks runtime and deploy refresh pipeline changes |
| Assignment group | Data Applications |
| State | Closed Complete |
| Opened at | 2026-06-15T21:00:00 |
| Closed at | 2026-06-15T22:00:00 |

Within the change window, Data Applications updated the Databricks runtime and deployed the Synapse/Fabric reporting refresh pipeline changes. The deployment completed without errors and no rollback was required during the window.

## CTASK0002003 — Post-change validation of transformation and refresh completion

| Field | Value |
| --- | --- |
| Number | CTASK0002003 |
| Short description | Post-change validation of transformation and refresh completion |
| Assignment group | Data Applications |
| State | Closed Complete |
| Opened at | 2026-06-15T22:00:00 |
| Closed at | 2026-06-15T22:30:00 |

At the end of the window, post-change validation confirmed that the Databricks transformation path completed, the reporting refresh pipeline ran after the runtime update, and Payments Reporting Service dashboards and exports were available. The change record was marked completed at 2026-06-15T22:35:00.

The validation checked job completion status but did not independently verify control-table watermark advancement, which became relevant in the post-implementation review.

## CTASK0002004 — Post-implementation review after INC-1217

| Field | Value |
| --- | --- |
| Number | CTASK0002004 |
| Short description | Post-implementation review after INC-1217 |
| Assignment group | Data Applications |
| State | Closed Complete |
| Opened at | 2026-06-16T09:00:00 |
| Closed at | 2026-06-16T11:00:00 |

INC-1217 was opened at 2026-06-15T23:05:00, shortly after the change completed, for stale Payments Reporting dashboards. The post-implementation review found that the post-change validation had confirmed transformation job success but had not confirmed that the Azure SQL control-table watermark advanced, so the Synapse/Fabric refresh skipping the latest partition went undetected until users reported stale dashboards.

The review linked the failure pattern to KI-221, recommended that future post-change validation for this pipeline include an explicit watermark advancement check, and handed permanent remediation tracking to PRB-304.
