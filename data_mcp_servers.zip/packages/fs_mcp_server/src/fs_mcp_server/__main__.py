from fs_mcp_server.server import main

main()
