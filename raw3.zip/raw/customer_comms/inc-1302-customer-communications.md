---
doc_id: COMM-INC-1302
title: INC-1302 Customer Communications
doc_type: customer_communication
service_id: svc_internal_api_gateway
owner_group: Service Desk L1
visibility: customer_safe
status: closed
created_at: "2026-06-18T21:30:00"
updated_at: "2026-06-19T01:30:00"
related_records:
  - INC-1302
  - KI-307
  - POL-COMMS-001
source_facts:
  - KI-307
  - svc_internal_api_gateway
difficulty_tags:
  - customer-safe
  - permission-boundary
servicenow:
  table: u_customer_communication
  number: COMM0003001
  parent: INC001302
  parent_table: incident
  channel: Email
  visibility: customer_safe
  contains_customer_safe_wording: true
---

# INC-1302 Customer Communications

## Record details

| Field | Value |
| --- | --- |
| Table | u_customer_communication |
| Number | COMM0003001 |
| Parent | INC001302 |
| Parent table | incident |
| Channel | Email |
| Visibility | customer_safe |
| Contains customer-safe wording | true |

## Communication guidance

All outbound updates for this incident use the approved customer-safe wording from KI-307. Wording was approved per POL-COMMS-001. Outbound messages do not reference internal policy configuration detail.

## Outbound updates

### 2026-06-18T21:30:00 — Initial acknowledgement (Email)

We have received your report of HTTP 429 Too Many Requests responses from the API. We are reviewing the applied API traffic policy for the affected client. While the review is in progress, please continue normal retry handling: honor the Retry-After header when present and use exponential backoff for retried requests. We will send a further update as the review progresses.

### 2026-06-18T23:00:00 — Progress update (Email)

Our review is ongoing. We are reviewing the applied API traffic policy for the affected client. No action is required from you at this time. Please continue to honor the Retry-After header on any 429 responses and avoid immediate retries of rejected requests. We will notify you when the review is complete.

### 2026-06-19T01:00:00 — Pre-resolution update (Email)

We have completed our review of the applied API traffic policy for the affected client and have made an adjustment. Please retry your normal API traffic and confirm whether requests now complete as expected. If you continue to see HTTP 429 responses, reply to this message with the affected endpoint and an approximate timestamp.

### 2026-06-19T01:30:00 — Closure update (Email)

Following the review of the applied API traffic policy for the affected client, your confirmation retest completed successfully and we are closing this report. If the issue recurs, please open a new request and include the affected endpoint, approximate timestamp, and error code. Thank you for your patience.
