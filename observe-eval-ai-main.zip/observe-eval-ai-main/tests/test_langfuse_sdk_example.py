"""Exercise the ported SDK example with native spans and fake model responses."""

from asyncio import TaskGroup
from importlib.util import module_from_spec, spec_from_file_location
from json import loads
from pathlib import Path
from types import ModuleType
from unittest.mock import Mock

from pytest import MonkeyPatch, fixture, importorskip, mark, raises

importorskip("langfuse", reason="requires observe-eval-ai[langfuse]")
importorskip("model_runtime", reason="requires observe-eval-ai[model-runtime]")

from langfuse import Langfuse  # noqa: E402
from langfuse.api import Prompt_Text  # noqa: E402
from langfuse.model import TextPromptClient  # noqa: E402
from model_runtime import (  # noqa: E402
    Message,
    ModelRequest,
    ModelRouter,
    ModelRuntime,
    ProviderUnavailableError,
    RetryPolicy,
)
from opentelemetry.sdk.trace.export.in_memory_span_exporter import (  # noqa: E402
    InMemorySpanExporter,
)
from opentelemetry.trace import StatusCode  # noqa: E402

from observability_ai.langfuse import (  # noqa: E402
    propagate_attributes,
    start_as_current_observation,
)


@fixture
def example() -> ModuleType:
    """Import the executable example without running main or reading dotenv."""
    path = Path(__file__).resolve().parents[1] / "examples" / "langfuse_sdk_example.py"
    spec = spec_from_file_location("sdk_example", path)
    assert spec is not None and spec.loader is not None
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@mark.parametrize("capture", [None, "false", "TrUe"])
async def test_concurrent_generations_propagate_context_usage_and_prompt(
    sdk: tuple[Langfuse, InMemorySpanExporter],
    example: ModuleType,
    monkeypatch: MonkeyPatch,
    capture: str | None,
) -> None:
    """Each native generation preserves its parent, dimensions, and capture choice."""
    if capture is not None:
        monkeypatch.setenv(
            "OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT", capture
        )
    client, exporter = sdk
    runtime = ModelRuntime(ModelRouter({"chat": (example._DemoModel(), "demo-model")}))
    prompt = TextPromptClient(
        Prompt_Text(
            name="managed-question",
            version=2,
            prompt="{{question}}",
            labels=[],
            tags=[],
            config={},
        )
    )
    with start_as_current_observation(client, name="test chat"):
        with propagate_attributes(
            session_id="session-123",
            user_id="user-456",
            tags=["phase-3"],
            metadata={"approach": "langfuse-sdk"},
        ):
            async with TaskGroup() as tasks:
                for index in range(2):
                    tasks.create_task(
                        example._complete_generation(
                            client,
                            runtime,
                            "chat",
                            ModelRequest(
                                messages=(Message.user(f"private prompt {index}"),),
                                temperature=0.2,
                                max_output_tokens=20,
                            ),
                            prompt=prompt,
                        )
                    )
    client.flush()
    spans = exporter.get_finished_spans()
    assert len(spans) == 3
    root = next(span for span in spans if span.name == "test chat")
    generations = [span for span in spans if span.name == "chat demo-model"]
    assert len(generations) == 2
    assert generations[0].context != generations[1].context
    for generation in generations:
        assert generation.parent == root.context
        attributes = generation.attributes
        assert attributes is not None
        assert attributes["langfuse.observation.type"] == "generation"
        assert attributes["session.id"] == "session-123"
        assert attributes["user.id"] == "user-456"
        assert attributes["langfuse.trace.tags"] == ("phase-3",)
        assert attributes["langfuse.trace.metadata.approach"] == "langfuse-sdk"
        assert attributes["langfuse.observation.model.name"] == "demo-model"
        usage = attributes["langfuse.observation.usage_details"]
        assert isinstance(usage, str)
        assert loads(usage) == {"input": 5, "output": 3, "cache_read_input_tokens": 2}
        parameters = attributes["langfuse.observation.model.parameters"]
        assert isinstance(parameters, str)
        assert loads(parameters) == {"temperature": 0.2, "max_tokens": 20}
        assert attributes["langfuse.observation.prompt.name"] == "managed-question"
        assert attributes["langfuse.observation.prompt.version"] == 2
        if capture == "TrUe":
            assert "private prompt" in str(attributes["langfuse.observation.input"])
            assert "vector space" in str(attributes["langfuse.observation.output"])
        else:
            assert "langfuse.observation.input" not in attributes
            assert "langfuse.observation.output" not in attributes


async def test_example_records_and_reraises_model_failure(
    sdk: tuple[Langfuse, InMemorySpanExporter],
    example: ModuleType,
    monkeypatch: MonkeyPatch,
) -> None:
    """A failed runtime call ends one errored generation and preserves its error."""
    client, exporter = sdk
    model = example._DemoModel()

    async def fail(*args: object, **kwargs: object) -> None:
        raise ProviderUnavailableError("provider unavailable")

    monkeypatch.setattr(model, "complete", fail)
    runtime = ModelRuntime(
        ModelRouter({"chat": (model, "demo-model")}),
        retry_policy=RetryPolicy(max_attempts=1),
    )
    with raises(ProviderUnavailableError):
        await example._complete_generation(
            client, runtime, "chat", ModelRequest.from_text("x")
        )
    client.flush()
    spans = exporter.get_finished_spans()
    assert len(spans) == 1
    assert spans[0].status.status_code is StatusCode.ERROR
    assert any(event.name == "exception" for event in spans[0].events)


async def test_default_main_uses_demo_models_and_scores_parent(
    sdk: tuple[Langfuse, InMemorySpanExporter],
    example: ModuleType,
    monkeypatch: MonkeyPatch,
) -> None:
    """Execute the default CLI flow without provider calls, dotenv files, or HTTP."""
    client, exporter = sdk
    create_score = Mock()
    monkeypatch.setattr(client, "create_score", create_score)
    monkeypatch.setattr(example, "build_langfuse_client", lambda settings: client)
    monkeypatch.setattr(example, "load_dotenv", Mock())
    monkeypatch.setenv("LANGFUSE_PUBLIC_KEY", "pk-example")
    monkeypatch.setenv("LANGFUSE_SECRET_KEY", "sk-example")
    monkeypatch.setattr("sys.argv", ["langfuse_sdk_example.py"])
    await example.main()
    spans = exporter.get_finished_spans()
    assert len(spans) == 3
    root = next(span for span in spans if span.name == "example concurrent chat")
    assert root.context is not None
    create_score.assert_called_once()
    assert (
        create_score.call_args.kwargs["observation_id"]
        == f"{root.context.span_id:016x}"
    )
    assert create_score.call_args.kwargs["name"] == "completed"
    assert create_score.call_args.kwargs["value"] == 1.0
