---
doc_id: KB-311
title: API 429 Too Many Requests Troubleshooting
doc_type: knowledge_article
service_id: svc_internal_api_gateway
owner_group: Service Desk L1
visibility: customer_safe
status: published
created_at: "2026-05-24T12:00:00"
updated_at: "2026-06-19T13:00:00"
related_records:
  - RUNBOOK-API-005
  - KI-307
  - POL-COMMS-001
source_facts:
  - KI-307
  - svc_internal_api_gateway
difficulty_tags:
  - customer-safe
  - less-detailed-than-runbook
servicenow:
  table: kb_knowledge
  number: KB0000311
  kb_category: Knowledge
  workflow_state: Published
  business_service: Client API Access
  cmdb_ci: Internal API Gateway
  assignment_group: Service Desk L1
  visibility: customer_safe
  contains_customer_safe_wording: true
---

# API 429 Too Many Requests Troubleshooting

## Record details

| Field | Value |
| --- | --- |
| Table | kb_knowledge |
| Number | KB0000311 |
| KB category | Knowledge |
| Workflow state | Published |
| Business service | Client API Access |
| Configuration item | Internal API Gateway |
| Assignment group | Service Desk L1 |
| Visibility | customer_safe |
| Contains customer-safe wording | true |

## Summary

Use this article when a client reports HTTP 429 responses from an API. HTTP 429 means Too Many Requests. It usually indicates that request volume has reached a traffic limit, but support should review the affected client and timing before deciding whether the response is expected.

Explain that HTTP 429 means Too Many Requests.

This article is customer-safe. Use RUNBOOK-API-005 for internal investigation when the issue appears related to API Gateway policy behavior.

## Symptoms

Clients may report:

- HTTP 429 Too Many Requests.
- API calls rejected during a burst.
- Affected endpoint returns 429 more often than expected.
- The issue began after an API traffic policy release.
- Business-tier traffic appears affected more often than Enterprise-tier traffic.

Avoid promising that all 429 responses are incorrect. Some are expected when traffic exceeds entitlement.

## What support should check first

Ask for client ID, affected endpoint, approximate timestamp, and customer tier.

Service Desk L1 should also confirm:

- Whether the client changed request volume recently.
- Whether the issue affects one endpoint or several.
- Whether the client sees continuous 429 responses or only burst-time responses.
- Whether any active incident or known issue references API traffic policy review.

Do not request secrets, tokens, API keys, or credentials.

## Information to collect

Collect:

- Client ID.
- Affected endpoint.
- Approximate timestamp.
- Customer tier.
- Example error code, confirming 429 Too Many Requests.
- Whether the client has changed traffic volume.

Keep the ticket free of sensitive request payloads and credentials.

## Recommended next step

If the client appears to have exceeded expected traffic limits, provide normal 429 guidance. If the client reports unexpected 429 behavior after a policy change or the tier does not appear to match the observed throttling behavior, route the ticket to Service Desk L1 for escalation using RUNBOOK-API-005.

Service Desk L1 should direct unresolved 429 reports to Platform Engineering when policy review is needed.

## Customer-safe response guidance

Use customer-safe language about reviewing applied API traffic policy.

"We are reviewing the applied API traffic policy for the affected client."

Do not expose internal policy misconfiguration details. Do not state that a policy mistake occurred unless Platform Engineering provides approved wording.

## When to escalate

Escalate when:

- The client provides the required ID, endpoint, timestamp, and tier.
- 429 responses began after a rate-limit policy update.
- Business-tier clients report unexpected burst rejection.
- The observed behavior appears inconsistent with the client's tier.
- Multiple clients report the same 429 pattern.

Escalate unresolved cases to Platform Engineering through RUNBOOK-API-005.

## Related records

- RUNBOOK-API-005: internal runbook reference for Service Desk L1 escalation.
- KI-307: internal known issue reference.
- POL-COMMS-001: customer-safe communication policy.

Use only approved customer-safe wording when referencing these records outside support.
