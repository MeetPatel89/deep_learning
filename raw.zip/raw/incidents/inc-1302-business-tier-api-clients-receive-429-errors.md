---
doc_id: INC-1302
title: Business-Tier API Clients Receive 429 Errors After Rate-Limit Policy Deployment
doc_type: incident
service_id: svc_internal_api_gateway
owner_group: Platform Engineering
visibility: internal
status: resolved
created_at: "2026-06-18T21:05:00"
updated_at: "2026-06-19T01:20:00"
related_records:
  - CHG-2420
  - KI-307
  - PRB-411
  - RUNBOOK-API-005
  - KB-311
  - POL-COMMS-001
source_facts:
  - CHG-2420
  - KI-307
  - svc_internal_api_gateway
difficulty_tags:
  - multi-hop
  - plan-specific-behavior
  - temporal-reasoning
---

# Business-Tier API Clients Receive 429 Errors After Rate-Limit Policy Deployment

## Incident summary

INC-1302 was opened after Business-tier API clients reported unexpected 429 Too Many Requests responses following CHG-2420. CHG-2420 completed at 2026-06-18T20:45:00, and the incident was opened at 2026-06-18T21:05:00. Incident began after CHG-2420 completed.

Platform Engineering owned final remediation.

## Impact

The impact was concentrated among Business-tier clients. Business-tier clients were affected more often than Enterprise clients. Affected clients received HTTP 429 responses and could not send bursts at the expected entitlement level.

The gateway continued routing traffic; this was not a full Internal API Gateway outage. The incident was a rate-limit policy mismatch affecting allowed burst behavior for some client groups.

## Timeline

| Time | Event |
| --- | --- |
| 2026-06-18T20:00:00 | CHG-2420 change window opened. |
| 2026-06-18T20:45:00 | CHG-2420 planned window ended. |
| 2026-06-18T20:50:00 | Change record updated as completed. |
| 2026-06-18T21:05:00 | INC-1302 opened for Business-tier 429 reports. |
| 2026-06-18T21:18:00 | Service Desk L1 collected client ID, endpoint, timestamp, and tier from initial reports. |
| 2026-06-18T21:40:00 | Platform Engineering reviewed Splunk for elevated 429 volume. |
| 2026-06-18T22:00:00 | KI-307 opened for unexpected 429 after rate-limit policy update. |
| 2026-06-18T22:35:00 | Applied policy compared against customer entitlement for affected client groups. |
| 2026-06-18T23:20:00 | Platform Engineering identified stricter burst limits for some clients. |
| 2026-06-19T00:25:00 | Applied rate-limit policy adjusted. |
| 2026-06-19T01:20:00 | Incident resolved after 429 volume normalized for affected clients. |

## Observed symptoms

Observed symptoms:

- API clients received 429 Too Many Requests.
- Business-tier clients were affected more often than Enterprise clients.
- Errors started after the rate-limit policy deployment.
- Some clients had stricter burst limits applied than their entitlement allowed.
- Splunk showed elevated 429 volume for affected client groups.

The symptoms matched KI-307 and were routed to Platform Engineering.

## Investigation notes

Service Desk L1 collected the client ID, affected endpoint, approximate timestamp, and customer tier. Platform Engineering inspected Splunk for 429 volume and compared applied rate-limit policy against entitlement.

The incident did not show a general routing failure in Internal API Gateway. Instead, the issue was plan-specific behavior after CHG-2420. Business-tier clients were more likely to hit the mismatch because their applied burst settings were stricter than expected.

## Resolution

Platform Engineering adjusted the applied rate-limit policy. After the adjustment, 429 volume dropped for the affected Business-tier client group and follow-up checks showed the policy aligned to entitlement.

No customer credential, secret, or client data was placed in the incident record.

## Customer communication

Customer-facing updates used the KI-307 safe wording:

"We are reviewing the applied API traffic policy for the affected client."

Support did not state that an internal policy mistake occurred.

## Follow-up actions

- Link future Business-tier 429 reports after CHG-2420 to KI-307 when symptoms match.
- Keep RUNBOOK-API-005 current with client ID, tier, Splunk, and entitlement-check steps.
- Track PRB-411 for the known error condition.
- Notify Release Management that the incident followed CHG-2420.

## Related records

- CHG-2420: Deploy New API Gateway Rate-Limit Policy.
- KI-307: API Clients Receive Unexpected 429 Responses After Rate-Limit Policy Update.
- PRB-411: API Rate-Limit Policy Entitlement Mismatch.
- RUNBOOK-API-005: API Gateway 429 Investigation Runbook.
- KB-311: API 429 Too Many Requests Troubleshooting.
- POL-COMMS-001: Customer-Safe Communication Policy.

