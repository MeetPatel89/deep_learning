"""Task-local trace dimensions and identifiers from the active OTel span."""

from collections.abc import Iterator
from contextlib import contextmanager
from contextvars import ContextVar

from opentelemetry.trace import get_current_span

from .attributes import TraceAttributes

_trace_attributes: ContextVar[TraceAttributes | None] = ContextVar(
    "observability_ai.trace_attributes", default=None
)


def _merged_attributes(explicit: TraceAttributes | None) -> TraceAttributes:
    inherited = _trace_attributes.get() or TraceAttributes()
    if explicit is None:
        return inherited
    if not isinstance(explicit, TraceAttributes):
        raise TypeError("attributes must be TraceAttributes or None")
    return TraceAttributes(
        session_id=explicit.session_id or inherited.session_id,
        user_id=explicit.user_id or inherited.user_id,
        tags=explicit.tags or inherited.tags,
        metadata={**inherited.metadata, **explicit.metadata},
    )


@contextmanager
def _propagate(attributes: TraceAttributes) -> Iterator[None]:
    if not isinstance(attributes, TraceAttributes):
        raise TypeError("attributes must be TraceAttributes")
    token = _trace_attributes.set(_merged_attributes(attributes))
    try:
        yield
    finally:
        _trace_attributes.reset(token)


def current_trace_id() -> str | None:
    """Return a 32-digit hex ID only while the active span is recording."""
    span = get_current_span()
    context = span.get_span_context()
    if span.is_recording() and context.is_valid:
        return f"{context.trace_id:032x}"
    return None


def current_observation_id() -> str | None:
    """Return a 16-digit hex ID only while the active span is recording."""
    span = get_current_span()
    context = span.get_span_context()
    if span.is_recording() and context.is_valid:
        return f"{context.span_id:016x}"
    return None
