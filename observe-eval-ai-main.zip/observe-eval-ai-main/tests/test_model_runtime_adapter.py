"""Exercise the optional model adapter through real runtime requests."""

from asyncio import TaskGroup, sleep
from collections.abc import AsyncIterator, Sequence
from json import loads

from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.trace import SpanKind, StatusCode, get_current_span
from pytest import MonkeyPatch, importorskip, mark, raises

from observability_ai import Telemetry, TraceAttributes
from observability_ai.adapters import model_runtime_observer

importorskip("model_runtime", reason="requires observe-eval-ai[model-runtime]")

from model_runtime import (  # noqa: E402
    FinishReason,
    Message,
    ModelCapabilities,
    ModelRequest,
    ModelResponse,
    ModelRouter,
    ModelRuntime,
    ModelRuntimeError,
    ProviderUnavailableError,
    RateLimitError,
    RetryPolicy,
    StreamEnd,
    StreamEvent,
    TextDelta,
    Usage,
)
from model_runtime.observability import OTelTraceObserver  # noqa: E402


class _Model:
    """Yield deterministic completions or streams without a provider client."""

    capabilities = ModelCapabilities(streaming=True)

    def __init__(self, outcomes: Sequence[ModelResponse | ModelRuntimeError]) -> None:
        self._outcomes = iter(outcomes)

    async def complete(self, model_id: str, request: ModelRequest) -> ModelResponse:
        """Yield to concurrent requests before returning the next outcome."""
        await sleep(0)
        outcome = next(self._outcomes)
        if isinstance(outcome, ModelRuntimeError):
            raise outcome
        return outcome

    async def stream(
        self, model_id: str, request: ModelRequest
    ) -> AsyncIterator[StreamEvent]:
        """Yield the configured response as a normalized model stream."""
        response = await self.complete(model_id, request)
        yield TextDelta(response.text)
        yield StreamEnd(response=response, usage=response.usage)


def _response() -> ModelResponse:
    return ModelResponse(
        Message.assistant("private answer"),
        usage=Usage(input_tokens=7, output_tokens=3, cached_tokens=2),
        finish_reason=FinishReason.STOP,
        model="returned-model",
    )


@mark.parametrize("streaming", [False, True])
@mark.parametrize(
    "trace",
    [
        None,
        TraceAttributes(
            session_id="session-123",
            user_id="user-456",
            tags=("adapter", "模型"),
            metadata={"tenant": "docs"},
        ),
    ],
)
async def test_one_generation_per_logical_request(
    otel: tuple[Telemetry, InMemorySpanExporter],
    trace: TraceAttributes | None,
    streaming: bool,
) -> None:
    """The native observer keeps parentage, dimensions, usage, and content defaults."""
    telemetry, exporter = otel
    observer = model_runtime_observer(telemetry, provider_name="test", trace=trace)
    assert type(observer) is OTelTraceObserver
    assert not exporter.get_finished_spans()
    response = _response()
    runtime = ModelRuntime(
        ModelRouter({"chat": (_Model([response]), "configured-model")}),
        observer=observer,
    )
    request = ModelRequest.from_text(
        "private prompt", temperature=0.2, max_output_tokens=100
    )
    with telemetry.observe("request", attributes=trace) as parent:
        if streaming:
            events = [event async for event in runtime.stream("chat", request)]
            assert events == [
                TextDelta(response.text),
                StreamEnd(response=response, usage=response.usage),
            ]
        else:
            assert await runtime.complete("chat", request) is response
        assert get_current_span() is parent.span

    generation, root = exporter.get_finished_spans()
    assert generation.name == "chat configured-model"
    assert generation.parent == root.context
    assert generation.kind is SpanKind.CLIENT
    assert generation.status.status_code is StatusCode.OK
    assert generation.instrumentation_scope is not None
    assert (
        generation.instrumentation_scope.name
        == "observability_ai.adapters.model_runtime"
    )
    attributes = generation.attributes
    assert attributes is not None
    assert attributes["langfuse.observation.type"] == "generation"
    assert attributes["gen_ai.provider.name"] == "test"
    assert attributes["gen_ai.request.model"] == "configured-model"
    assert attributes["gen_ai.response.model"] == "returned-model"
    assert attributes["gen_ai.request.temperature"] == 0.2
    assert attributes["gen_ai.request.max_tokens"] == 100
    assert attributes["gen_ai.usage.input_tokens"] == 7
    assert attributes["gen_ai.usage.output_tokens"] == 3
    assert attributes["gen_ai.usage.cache_read.input_tokens"] == 2
    assert "private prompt" not in str(attributes)
    assert "private answer" not in str(attributes)
    if trace is None:
        assert "langfuse.session.id" not in attributes
    else:
        assert trace.as_otel_attributes().items() <= attributes.items()


@mark.parametrize(
    ("environment", "override", "captured"),
    [("TrUe", None, True), ("true", False, False), ("false", True, True)],
)
async def test_capture_setting_passes_through(
    otel: tuple[Telemetry, InMemorySpanExporter],
    monkeypatch: MonkeyPatch,
    environment: str,
    override: bool | None,
    captured: bool,
) -> None:
    """An explicit bool overrides the library's standard environment flag."""
    telemetry, exporter = otel
    monkeypatch.setenv(
        "OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT", environment
    )
    runtime = ModelRuntime(
        ModelRouter({"chat": (_Model([_response()]), "model")}),
        observer=model_runtime_observer(
            telemetry, provider_name="test", capture_message_content=override
        ),
    )
    await runtime.complete("chat", ModelRequest.from_text("private prompt"))
    (generation,) = exporter.get_finished_spans()
    attributes = generation.attributes
    assert attributes is not None
    if captured:
        input_json = attributes["gen_ai.input.messages"]
        output_json = attributes["gen_ai.output.messages"]
        assert isinstance(input_json, str) and isinstance(output_json, str)
        assert loads(input_json)[0]["parts"][0]["content"] == "private prompt"
        assert loads(output_json)[0]["parts"][0]["content"] == "private answer"
    else:
        assert "gen_ai.input.messages" not in attributes
        assert "gen_ai.output.messages" not in attributes


async def test_retries_and_terminal_errors_use_native_span_lifecycle(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Retries remain events on one generation, and terminal errors restore context."""
    telemetry, exporter = otel
    error = ProviderUnavailableError("provider failed", retryable=False)
    runtime = ModelRuntime(
        ModelRouter(
            {"chat": (_Model([RateLimitError("retry"), _response(), error]), "model")}
        ),
        observer=model_runtime_observer(telemetry, provider_name="test"),
        retry_policy=RetryPolicy(initial_delay=0, max_delay=0),
    )
    request = ModelRequest.from_text("private prompt")
    with telemetry.observe("request") as parent:
        await runtime.complete("chat", request)
        with raises(ProviderUnavailableError) as caught:
            await runtime.complete("chat", request)
        assert caught.value is error
        assert get_current_span() is parent.span

    success, failure, root = exporter.get_finished_spans()
    assert success.parent == failure.parent == root.context
    assert [event.name for event in success.events] == ["model_runtime.retry"]
    assert failure.status.status_code is StatusCode.ERROR
    assert [event.name for event in failure.events] == ["exception"]


async def test_shared_observer_preserves_concurrent_request_parents(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Factory wiring preserves the native observer's task-local active spans."""
    telemetry, exporter = otel
    runtime = ModelRuntime(
        ModelRouter({"chat": (_Model([_response(), _response()]), "model")}),
        observer=model_runtime_observer(telemetry, provider_name="test"),
    )

    async def request(name: str) -> None:
        with telemetry.observe(name) as parent:
            await runtime.complete("chat", ModelRequest.from_text(name))
            assert get_current_span() is parent.span

    async with TaskGroup() as tasks:
        tasks.create_task(request("request-0"))
        tasks.create_task(request("request-1"))

    spans = exporter.get_finished_spans()
    assert len(spans) == 4
    roots = [span for span in spans if span.parent is None]
    assert len(roots) == 2
    assert roots[0].context != roots[1].context
    for root in roots:
        children = [span for span in spans if span.parent == root.context]
        assert len(children) == 1
        assert children[0].name == "chat model"


def test_native_configuration_validation_is_preserved(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """The factory does not bypass model-runtime's provider validation."""
    telemetry, exporter = otel
    with raises(ValueError, match="provider_name"):
        model_runtime_observer(telemetry, provider_name=" ")
    assert not exporter.get_finished_spans()
