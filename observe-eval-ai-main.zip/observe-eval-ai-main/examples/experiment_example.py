"""Evaluate JSONL text normalization with deterministic checks and an optional judge.

Requires Langfuse credentials and the ``langfuse`` extra. ``--judge`` additionally
requires the ``model-runtime`` extra, ANTHROPIC_API_KEY, and ANTHROPIC_MODEL. It
sends each example to that provider and may incur charges. The default task and
evaluators make no model-provider calls; the SDK still exports experiment data.
"""

from argparse import ArgumentParser
from collections.abc import Mapping
from functools import partial
from importlib.util import find_spec
from os import getenv
from pathlib import Path

from dotenv import load_dotenv
from langfuse.api import DatasetItem
from langfuse.experiment import ExperimentItem

from observability_ai import LangfuseSettings
from observability_ai.evaluation import (
    EvaluationResult,
    Evaluator,
    ExactMatch,
    JudgeRubric,
    LengthWithin,
    ModelRuntimeJudge,
)
from observability_ai.langfuse import (
    ExperimentRunner,
    RegressionDetected,
    RegressionGate,
    build_langfuse_client,
    load_jsonl,
)


def normalize(*, item: ExperimentItem, **kwargs: object) -> str:
    """Collapse whitespace in string input without reading the reference answer."""
    value = item.input if isinstance(item, DatasetItem) else item.get("input")
    if not isinstance(value, str):
        raise TypeError("normalization input must be a string")
    return " ".join(value.split())


async def _judge(
    *,
    model: str,
    api_key: str,
    input: object,
    output: object,
    expected_output: object,
    metadata: Mapping[str, object] | None,
) -> EvaluationResult:
    # Keep model dependencies optional. Scope the provider client to this call
    # so it is closed on the SDK evaluator's event loop, including on failures.
    from anthropic import AsyncAnthropic
    from model_runtime import AnthropicAdapter, ModelRouter, ModelRuntime, RetryPolicy

    async with AsyncAnthropic(api_key=api_key, max_retries=0, timeout=30.0) as provider:
        runtime = ModelRuntime(
            ModelRouter({"judge": (AnthropicAdapter(client=provider), model)}),
            retry_policy=RetryPolicy(max_attempts=1),
        )
        judge = ModelRuntimeJudge(
            runtime,
            "judge",
            JudgeRubric(
                "normalization_quality",
                "Check whether the output preserves the input's words and order "
                "while collapsing whitespace to single spaces and removing "
                "leading/trailing whitespace. Compare with the reference. "
                "Score 1 for a correct normalization and 0 otherwise.",
            ),
        )
        return await judge(
            input=input,
            output=output,
            expected_output=expected_output,
            metadata=metadata,
        )


def main() -> None:
    """Run local examples, print aggregate scores, and exit nonzero on regression."""
    parser = ArgumentParser(description=__doc__)
    parser.add_argument(
        "dataset",
        nargs="?",
        type=Path,
        default=Path(__file__).with_name("normalization.jsonl"),
        help="JSONL input/reference data (default: bundled normalization.jsonl)",
    )
    parser.add_argument(
        "--judge", action="store_true", help="enable the paid model judge"
    )
    parser.add_argument("--run-name", help="optional experiment run label")
    args = parser.parse_args()

    # Validate local data before constructing any client.
    try:
        data = load_jsonl(args.dataset)
    except (OSError, ValueError) as exc:
        parser.error(str(exc))
    if not data:
        parser.error("dataset must contain at least one item")
    if any(
        not isinstance(item.input, str) or not isinstance(item.expected_output, str)
        for item in data
    ):
        parser.error("every item must have string input and expected_output")

    root = Path(__file__).resolve().parents[1]
    load_dotenv(root / ".env")
    load_dotenv(root / "observability" / ".env")
    evaluators: list[Evaluator] = [ExactMatch(), LengthWithin(min_length=1)]
    thresholds = {"exact_match": 1.0, "length_within": 1.0}
    if args.judge:
        if find_spec("model_runtime") is None:
            parser.error("--judge requires observe-eval-ai[model-runtime]")
        model = getenv("ANTHROPIC_MODEL", "").strip()
        api_key = getenv("ANTHROPIC_API_KEY", "").strip()
        if not model or not api_key:
            parser.error("--judge requires ANTHROPIC_MODEL and ANTHROPIC_API_KEY")
        evaluators.append(partial(_judge, model=model, api_key=api_key))
        thresholds["normalization_quality"] = 0.9

    client = build_langfuse_client(LangfuseSettings.from_env())
    try:
        report = ExperimentRunner(client).run(
            "text-normalization",
            data=data,
            task=normalize,
            evaluators=evaluators,
            run_name=args.run_name,
            max_concurrency=4,
        )
        print(
            f"Items: {report.completed_count}/{report.total_count} completed; "
            f"{report.failed_count} failed; "
            f"{len(report.evaluator_failures)} evaluator failures"
        )
        for name, value in sorted(report.metric_means.items()):
            print(f"{name}: {value:.3f} ({report.metric_counts[name]} scores)")
        try:
            RegressionGate(thresholds).check(report)
        except RegressionDetected as exc:
            raise SystemExit(f"Regression gate failed: {exc}") from exc
        print("Regression gate passed (this does not confirm backend ingestion).")
    finally:
        client.shutdown()


if __name__ == "__main__":
    main()
