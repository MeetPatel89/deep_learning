"""Immutable trace dimensions and observation types understood by Langfuse."""

from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Literal

from opentelemetry.util.types import AttributeValue

type ObservationType = Literal[
    "span",
    "generation",
    "agent",
    "tool",
    "chain",
    "retriever",
    "embedding",
    "evaluator",
    "guardrail",
    "event",
]

_LANGFUSE_ATTRIBUTE_MAX_LENGTH = 200


@dataclass(frozen=True, slots=True)
class TraceAttributes:
    """Trace-level Langfuse dimensions to copy onto each observation.

    Use ``Telemetry.propagate`` or pass explicit values to ``Telemetry.observe``
    where these dimensions should be filterable. For raw OTel spans, pass the dictionary
    returned by ``as_otel_attributes`` when starting the span.
    """

    session_id: str | None = None
    user_id: str | None = None
    tags: Sequence[str] = ()
    metadata: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize collections and reject values Langfuse would discard."""
        self._validate_optional_identifier("session_id", self.session_id)
        self._validate_optional_identifier("user_id", self.user_id)

        if isinstance(self.tags, str):
            raise TypeError("tags must be a sequence of strings")
        normalized_tags = tuple(self.tags)
        for tag in normalized_tags:
            self._validate_text("tag", tag)

        if not isinstance(self.metadata, Mapping):
            raise TypeError("metadata must be a mapping of strings to strings")
        normalized_metadata = dict(self.metadata)
        for key, value in normalized_metadata.items():
            self._validate_text("metadata key", key, ascii_only=True)
            self._validate_text(f"metadata[{key!r}]", value)

        object.__setattr__(self, "tags", normalized_tags)
        object.__setattr__(self, "metadata", MappingProxyType(normalized_metadata))

    def as_otel_attributes(self) -> dict[str, AttributeValue]:
        """Return a fresh dictionary of Langfuse's raw OTel trace attributes."""
        attributes: dict[str, AttributeValue] = {}
        if self.session_id is not None:
            attributes["langfuse.session.id"] = self.session_id
        if self.user_id is not None:
            attributes["langfuse.user.id"] = self.user_id
        if self.tags:
            attributes["langfuse.trace.tags"] = tuple(self.tags)
        attributes.update(
            {
                f"langfuse.trace.metadata.{key}": value
                for key, value in self.metadata.items()
            }
        )
        return attributes

    @staticmethod
    def _validate_optional_identifier(name: str, value: str | None) -> None:
        if value is not None:
            TraceAttributes._validate_text(name, value, ascii_only=True)

    @staticmethod
    def _validate_text(name: str, value: str, *, ascii_only: bool = False) -> None:
        if not isinstance(value, str):
            raise TypeError(f"{name} must be a string")
        if not value:
            raise ValueError(f"{name} must not be empty")
        if ascii_only and not value.isascii():
            raise ValueError(f"{name} must contain only US-ASCII characters")
        if len(value) > _LANGFUSE_ATTRIBUTE_MAX_LENGTH:
            raise ValueError(
                f"{name} must contain at most "
                f"{_LANGFUSE_ATTRIBUTE_MAX_LENGTH} characters"
            )
