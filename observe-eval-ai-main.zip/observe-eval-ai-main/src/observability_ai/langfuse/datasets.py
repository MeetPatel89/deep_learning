"""Local dataset records and explicit access to Langfuse-hosted datasets."""

from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from langfuse import Langfuse
from langfuse._client.datasets import DatasetClient
from langfuse.api import Dataset, DatasetItem

from ..config import _validate_text
from ..evaluation._json import _strict_json
from ..evaluation.results import _metadata_snapshot


@dataclass(frozen=True, slots=True)
class DatasetItemRecord:
    """A local item with shallow, read-only metadata and optional remote identity.

    Input, expected output, and nested metadata remain application-owned. An
    explicit ``id`` updates that item when uploaded through ``add_items``.
    """

    input: object
    expected_output: object = None
    metadata: Mapping[str, object] = field(default_factory=dict)
    id: str | None = None
    source_trace_id: str | None = None
    source_observation_id: str | None = None

    def __post_init__(self) -> None:
        """Validate optional identities and snapshot metadata."""
        for name in ("id", "source_trace_id", "source_observation_id"):
            value = getattr(self, name)
            if value is not None:
                _validate_text(name, value)
        if self.source_observation_id is not None and self.source_trace_id is None:
            raise ValueError("source_observation_id requires source_trace_id")
        object.__setattr__(self, "metadata", _metadata_snapshot(self.metadata))


def load_jsonl(path: str | Path) -> tuple[DatasetItemRecord, ...]:
    """Load UTF-8 JSON objects locally, skipping blank lines without SDK calls.

    Each object requires ``input`` and accepts the other record fields. Unknown
    fields, duplicate keys, non-finite numbers, and invalid records raise a
    ``ValueError`` containing the path and line number. File errors propagate.
    """
    source = Path(path)
    records: list[DatasetItemRecord] = []
    allowed = {
        "input",
        "expected_output",
        "metadata",
        "id",
        "source_trace_id",
        "source_observation_id",
    }
    with source.open(encoding="utf-8") as lines:
        for number, line in enumerate(lines, 1):
            if not line.strip():
                continue
            try:
                value = _strict_json(line)
                if not isinstance(value, dict):
                    raise TypeError("each dataset item must be an object")
                if "input" not in value:
                    raise ValueError("each dataset item requires input")
                if value.keys() - allowed:
                    raise ValueError("unknown dataset item fields")
                records.append(DatasetItemRecord(**value))
            except (TypeError, ValueError) as exc:
                raise ValueError(f"{source}:{number}: {exc}") from exc
    return tuple(records)


class DatasetRepository:
    """Fetch and upload datasets through an application-owned SDK client."""

    def __init__(self, client: Langfuse) -> None:
        """Reuse the supplied client without owning its lifecycle."""
        self._client = client

    def get(self, name: str, version: datetime | None = None) -> DatasetClient:
        """Fetch the native dataset, optionally pinned to a version timestamp."""
        _validate_text("name", name)
        if version is not None and not isinstance(version, datetime):
            raise TypeError("version must be a datetime")
        return self._client.get_dataset(name, version=version)

    def create(
        self,
        name: str,
        description: str | None = None,
        metadata: Mapping[str, object] | None = None,
    ) -> Dataset:
        """Create a remote dataset and return the SDK's dataset value."""
        _validate_text("name", name)
        if description is not None and not isinstance(description, str):
            raise TypeError("description must be a string")
        dimensions = (
            dict(_metadata_snapshot(metadata)) if metadata is not None else None
        )
        return self._client.create_dataset(
            name=name, description=description, metadata=dimensions
        )

    def add_items(
        self, name: str, items: Iterable[DatasetItemRecord]
    ) -> tuple[DatasetItem, ...]:
        """Validate all records, then upload in order; writes are not transactional.

        Records with explicit IDs update existing items. An SDK failure propagates
        and may follow earlier successful uploads. No implicit retries are added.
        """
        _validate_text("name", name)
        snapshot = tuple(items)
        if any(not isinstance(item, DatasetItemRecord) for item in snapshot):
            raise TypeError("items must contain DatasetItemRecord values")
        return tuple(
            self._client.create_dataset_item(
                dataset_name=name,
                input=item.input,
                expected_output=item.expected_output,
                metadata=dict(item.metadata),
                id=item.id,
                source_trace_id=item.source_trace_id,
                source_observation_id=item.source_observation_id,
            )
            for item in snapshot
        )
