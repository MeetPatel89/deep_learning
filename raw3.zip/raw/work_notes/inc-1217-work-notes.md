---
doc_id: WN-INC-1217
title: INC-1217 Work Notes
doc_type: work_notes
service_id: svc_payments_reporting
owner_group: Data Applications
visibility: internal
status: closed
created_at: "2026-06-15T23:10:00"
updated_at: "2026-06-16T04:15:00"
related_records:
  - INC-1217
  - KI-221
  - RUNBOOK-PAY-007
  - CHG-2411
source_facts:
  - KI-221
  - svc_payments_reporting
difficulty_tags:
  - internal-only-detail
  - timeline-reconstruction
servicenow:
  table: sys_journal_field
  element: work_notes
  parent: INC001217
  parent_table: incident
  visibility: internal
  contains_customer_safe_wording: false
---

# INC-1217 Work Notes

## Record details

| Field | Value |
| --- | --- |
| Table | sys_journal_field |
| Element | work_notes |
| Parent | INC001217 |
| Parent table | incident |
| Visibility | internal |
| Contains customer-safe wording | false |

## Work notes

These are the internal work notes recorded on INC001217. Entries contain Azure SQL control-table watermark, Databricks output partition, and Synapse/Fabric refresh details that must not appear in customer-facing communications.

### 2026-06-15T23:10:00 — Service Desk L1

Multiple business users report Payments Reporting dashboards showing a stale reporting period. One user also reports that exported payment totals do not match the operational transaction view. Collected affected dashboard names, visible dashboard timestamps, and expected reporting period. Incident opened via self-service portal at 23:05.

### 2026-06-15T23:24:00 — Service Desk L1

Confirmed with three separate business users that the same stale reporting period is visible. Dashboard is behind the expected refresh. Noted that CHG002411 (Databricks runtime and Synapse/Fabric refresh pipeline update) completed at 22:30, roughly 35 minutes before the incident was opened. Escalating to Data Applications per KB-204 guidance.

### 2026-06-15T23:50:00 — Data Applications

Checked the Databricks transformation job for the payments reporting pipeline. Job shows successful completion for the latest run. No transformation errors. Beginning source-vs-reporting comparison.

### 2026-06-16T00:20:00 — Data Applications

Azure SQL Database staging tables contain current payment transaction records through the expected period. Source side is healthy; no transaction loss. This is a reporting-layer freshness issue, not a data availability issue.

### 2026-06-16T00:55:00 — Data Applications

Synapse/Fabric reporting layer still shows the previous data refresh watermark. Compared the Azure SQL control-table watermark against the latest Databricks output partition: the transformation produced the latest partition, but the control-table watermark was not advanced. The downstream refresh therefore skipped the newest partition. Symptom pattern matches KI-221, and the timing matches CHG002411; linking both to the incident. PRB-304 candidate for root cause tracking.

### 2026-06-16T01:30:00 — Data Applications

Following RUNBOOK-PAY-007. Validated the control-table watermark state and confirmed the latest Databricks output partition is complete and consistent. Decision: rerun the Synapse/Fabric reporting refresh, then backfill from the last successful payment partition if the latest partition remains skipped.

### 2026-06-16T02:10:00 — Data Applications

Synapse/Fabric reporting refresh rerun started after watermark validation.

### 2026-06-16T03:05:00 — Data Applications

Refresh rerun completed. Backfill from the last successful payment partition completed to cover the skipped interval. Reporting layer watermark now reflects the latest partition.

### 2026-06-16T03:40:00 — Data Applications

Verification: dashboard reporting period advanced to expected timestamp; regenerated payment export totals match the operational transaction view. Asked Service Desk L1 to confirm with the reporting business users.

### 2026-06-16T04:15:00 — Service Desk L1

Business users confirm dashboards and exports are current. Customer updates sent using only the KI-221 customer-safe wording per POL-COMMS-001; no watermark or control-table detail included. Incident resolved.
