# Worked examples: producer licenses, appointments and contracts

Version 2.0 • Updated 2026-09-26

Companion to the [enterprise implementation design](02-implementation-design.md) and [constitution](01-semantic-layer-constitution.md).

These four tables are a teaching example and a small regression fixture. They do not define the size of the company database, the complete query algebra, the retrieval strategy, the workflow technology or the application's domain boundaries. Technology decisions in the enterprise design take precedence over limitations of this fixture. No sample codes, business keys or identity assumptions should be copied into an unrelated domain.

The workbook assessment and its exact header ranges remain in the constitution. This appendix preserves the supplied schemas, clarifications, illustrative queries and grain distinctions.

## Sample assumptions


These are configuration decisions, not reasons to redesign the architecture or stop building it.

| ID | Subject | Working treatment in examples | Required before production publication |
|---|---|---|---|
| A01 | Active status | Entity-specific mapped active status set; no automatic termination-date condition | Populate real codes, including whether several statuses mean active; promote any additional reviewed conditions to a predicate. |
| A02 | Pet category | Canonical value `product_category.pet` with a separate literal set for each contract source | Populate real source literals and mapping validity. |
| A03 | Which contracts qualify | Either Agent_Contracts or Agency_Contracts; contract status unrestricted unless requested | Approve scope and whether a default requires active contracts. |
| A04 | Producer_Key identity | Same business identity across the relationships shown | Verify global namespace or bind approved crosswalk relationships. |
| A05 | License/appointment grain and identity | The supplied columns do not establish a business key. Composite keys below are hypotheses only. | Identify physical-row key, business identity, current/history/version rules, and uniqueness evidence before labeling `COUNT_BIG(*)` a business-record count. |
| A06 | Individual records | Nonaggregated license details | If the term means legal individuals, an authoritative classification source is needed. |
| A07 | Detail scope | Show both same-license and producer-cohort readings | A reviewed example establishes the desired default; otherwise ask one focused clarification at runtime. |
| A08 | Physical schema and types | `dbo` and illustrative types | Introspect Azure SQL; bind actual schema, lengths, nullability, collation and temporal types. |
| A09 | Access policy | Only authorized base/contract/license data participates | Configure real permissions, secured views or RLS; do not invent tenant columns. |

Status and category codes in demonstrations are synthetic. `ACTIVE` is not asserted to be your actual status code. Source-specific parameter names deliberately allow the two contract tables to use different encodings.


## A. Worked domain model

### A.1 Entity registry

| Semantic ID | Physical source supplied | Proposed row meaning | Candidate identity | Important limitation |
|---|---|---|---|---|
| `license` | `Producer_Licenses` | Proposed subject: a license/authorization held by a producer for a jurisdiction; whether a row represents a current state, version, or raw source row is unknown | **Unverified hypotheses:** `License_Id`; `(Producer_Key, License_Id)`; or a business combination such as `(Producer_Key, State, License_Number)` | Confirm business meaning, current/history behavior, duplicates/renewals, normalization and nullable components |
| `appointment` | `Producer_Appointments` | Proposed subject: a producer's appointment in a jurisdiction; row/version semantics are unknown | **Unverified hypotheses:** `Appointment_Id`; `(Producer_Key, Appointment_Id)`; or a business combination involving `Producer_Key` and `State` | Confirm lifecycle, duplicate/historical behavior and uniqueness scope |
| `agent_contract` | `Agent_Contracts` | Contract relationship recorded in the agent source; row/version semantics are unknown | **Unverified hypothesis:** `(Producer_Key, Contract_Id)` within this source | Table name alone does not prove legal person classification |
| `agency_contract` | `Agency_Contracts` | Contract relationship recorded in the agency source; row/version semantics are unknown | **Unverified hypothesis:** `(Producer_Key, Contract_Id)` within this source | Do not infer coverage of individual agency members |

“Row grain” is the business sentence **what one row represents**. A key is a separate statement **which column combination identifies one such thing**, within a stated scope. A physical primary key proves uniqueness of physical rows, but a surrogate `License_Id` may identify a database row/version and say nothing about whether two rows represent the same business license.

Keep three key concepts separate:

| Metadata assertion | Question it answers | Example shape; not confirmed for these tables |
|---|---|---|
| `physical_row_key` | Which stored row can be referenced uniquely? | `License_Id` if database inspection confirms it is a primary key |
| `business_identity` | Which columns identify the same real-world license across duplicates or loads? | A jurisdiction-qualified license number plus producer identity, if the owner confirms this meaning |
| `version_identity` | Which row represents which version/as-of state of that business license? | Business identity plus source effective timestamp or snapshot ID, if such fields exist |

The supplied license table has no explicit effective-from, effective-to, snapshot, or source-version field. If it contains several rows for the same business license and has no reliable current/version marker, the application cannot silently choose one. The publisher should block a business-license count until the owner selects a supported row population or supplies a history-aware source. It can expose a separately named physical source-row count if that is useful and authorized.

For example, `(Producer_Key, State, License_Number)` might be a candidate only if `License_Number` is a jurisdiction-issued identifier and the same business license cannot have multiple simultaneously valid rows under that combination. If one number covers multiple license lines, even that combination could be too coarse. Validate the business meaning first, then test uniqueness and null rules across the full relevant population. A sample or a successful primary-key check alone does not settle it.

The catalog stores these as separate structured assertions rather than one free-text `grain` field:

```json
{
  "row_semantics": {
    "statement": "One current license authorization for one producer and jurisdiction.",
    "approval_status": "example_only"
  },
  "physical_row_key": {
    "field_ids": ["license.license_id"],
    "evidence": "source primary-key constraint",
    "verified": false
  },
  "business_identity": {
    "field_ids": ["license.producer_key", "license.state", "license.license_number"],
    "scope": "jurisdiction and producer",
    "null_policy": "reject",
    "owner_approved": false,
    "uniqueness_assertion_id": "license_business_identity_unique"
  },
  "versioning": {
    "mode": "unknown",
    "current_row_predicate_id": null,
    "effective_time_fields": []
  }
}
```

These are intentionally unapproved example values. In particular, the JSON does **not** claim those three columns are your actual license identity. A publisher must reject production release while approval, key evidence or a necessary version rule is missing.

To profile a proposed key in Azure SQL, a data engineer can inspect nulls and repeated combinations:

```sql
SELECT Producer_Key, State, License_Number, COUNT_BIG(*) AS Row_Count
FROM dbo.Producer_Licenses
GROUP BY Producer_Key, State, License_Number
HAVING COUNT_BIG(*) > 1
    OR Producer_Key IS NULL
    OR State IS NULL
    OR License_Number IS NULL;
```

Run equivalent profiles for `License_Id`, candidate appointment keys and relevant populations. These results identify collisions to investigate; they do not tell you whether a repeated combination means duplicate ingestion, multiple license lines, renewal/history or an invalid key proposal. Even zero collisions do not prove the combination means one business license. The data owner decides what counts; the engineer checks whether the source satisfies it.

A shared `Producer_Key` means a contract and a license belong to the same identified producer only after namespace compatibility is established. If an agency contract belongs to an agency and a license to a person, inheritance of the agency's contract requires an explicit person–agency affiliation relationship. No such affiliation fields are supplied. The design must never invent that join.

### A.2 Field inventory and suggested descriptions

Descriptions below are authoring proposals, except the confirmed license term-date alias. Physical data types were not supplied; inspect the database before entering them as facts.

| Entity | Semantic field / source column | Suggested meaning and use |
|---|---|---|
| license | `producer_key` / `Producer_Key` | Identity of the producer associated with this license; relationship key; not a license key |
| license | `license_id` / `License_Id` | License record identifier; verify uniqueness scope |
| license | `license_number` / `License_Number` | Business license number; preserve text formatting and leading zeroes |
| license | `state` / `State` | State/jurisdiction recorded for the license; exact domain must be approved |
| license | `status` / `Status` | Stored license status code; map through `license_status` |
| license | `termination_date` / `Termination_Date` | License termination date; aliases include “term date,” “license term date”; absent date queried with `IS NULL` |
| appointment | `producer_key` / `Producer_Key` | Producer identity for the appointment |
| appointment | `appointment_id` / `Appointment_Id` | Appointment record identifier; verify uniqueness scope |
| appointment | `state` / `State` | State/jurisdiction for the appointment |
| appointment | `status` / `Status` | Stored appointment status code; map through `appointment_status` |
| appointment | `termination_date` / `Termination_Date` | Appointment termination date; context-specific term-date alias |
| agent_contract | `producer_key` / `Producer_Key` | Contract holder identity in the agent-contract namespace |
| agent_contract | `contract_id` / `Contract_Id` | Contract record identifier within source and approved identity scope |
| agent_contract | `contract_type` / `Contract_Type` | Contract classification; do not interpret as producer type without a definition |
| agent_contract | `status` / `Status` | Stored agent-contract status; its own mapping scope |
| agent_contract | `product_category` / `Product_Category` | Stored category; binding to `product_category` canonical values |
| agency_contract | `producer_key` / `Producer_Key` | Contract holder identity in the agency-contract namespace |
| agency_contract | `contract_id` / `Contract_Id` | Contract record identifier within agency source |
| agency_contract | `contract_type` / `Contract_Type` | Agency contract classification |
| agency_contract | `status` / `Status` | Stored agency-contract status; separate from license status |
| agency_contract | `product_category` / `Product_Category` | Agency-source category encoding |

An alias lookup for “term date” can return both license and appointment fields. The query's selected base entity and the user's clarification resolve the sample to the license field. Store the confirmed usage as a verified example rather than globally removing the alias from appointment metadata.

### A.3 Canonical values and synthetic binding illustration

| Canonical value | Field binding | Synthetic literal set | Reason for distinct binding |
|---|---|---|---|
| `license_status.active` | `license.status` | `["ACTIVE"]` | License codes may differ from appointment codes |
| `appointment_status.active` | `appointment.status` | `["A"]` | Demonstrates a separate status encoding |
| `product_category.pet` | `agent_contract.product_category` | `["PET"]` | Agent-source product code |
| `product_category.pet` | `agency_contract.product_category` | `["P"]` | Agency-source product code |

Each domain can have descriptions and aliases. A canonical status may bind to several literals if the business says several statuses belong in an active population. Conversely, “active or pending” is two canonical concepts if pending is not a kind of active. Do not merge them because an embedding puts them close together.

### A.4 Predicate definitions

Expression subset used by this fixture:

```text
Expression := all(Expression[]) | any(Expression[]) | not(Expression)
            | compare(operator, FieldRef, TypedParameter)
            | is_null(FieldRef) | is_not_null(FieldRef)
            | in_value_set(FieldRef, CanonicalValueRef)
FieldRef   := {entity_role, field_id}
operator   := eq | ne | lt | le | gt | ge
```

Only the compiler owns the mapping to SQL. Empty `all`/`any` nodes are rejected in the baseline sample profile. Set membership cannot contain SQL or table names. A resolved empty set is a separate outcome, not an instruction to remove the filter.

```json
{
  "id": "license.active",
  "entity_id": "license",
  "definition_status": "draft",
  "expression": {
    "op": "in_value_set",
    "field": "license.status",
    "value_id": "license_status.active"
  },
  "explanation": "Status belongs to the reviewed active license status set."
}
```

This proposal deliberately does not add a termination condition. If reviewed examples establish an active rule requiring one, replace its expression with an `all` of the status test and the approved temporal condition, version it, and rerun affected examples. The first sample's explicit no-term-date condition remains an independent filter and can be simplified when it is redundant.

### A.5 Metrics

| ID | Base | Aggregation | Required predicate | Category eligibility |
|---|---|---|---|---|
| `license.source_row_count` | license | `COUNT_BIG(*)` physical rows | None | Optional approved relationship condition |
| `license.active_record_count` | license | `COUNT_BIG(*)` over validated active business-record population | `license.active` | Optional; blocked until row/version semantics are approved |
| `appointment.source_row_count` | appointment | `COUNT_BIG(*)` physical rows | None | Optional approved relationship condition |
| `appointment.active_record_count` | appointment | `COUNT_BIG(*)` over validated active business-record population | `appointment.active` | Optional; blocked until row/version semantics are approved |

Use the active metric for sample questions 2 and 3 once its counted-row population is verified. Category stays a parameterized population constraint, so “Pet” and another category do not require separate metric definitions. `COUNT_BIG` returns a large integer; it does not make the count semantically correct. If a table stores multiple versions per license, the metric first needs a reviewed current/as-of row rule or a historical-version definition. Do not replace these metrics with distinct producer counts.

If a later question asks “count by contract category,” a producer can qualify for several categories. That count is not additive across categories. Declare this before exposing the grouping; do not let the user infer the category totals equal the overall count.


## B. Worked relationship contracts

### B.1 The relationship graph for these tables

```mermaid
flowchart LR
    L[license] -->|has agent contract: EXISTS| AC[agent_contract]
    L -->|has agency contract: EXISTS| GC[agency_contract]
    AP[appointment] -->|has agent contract: EXISTS| AC
    AP -->|has agency contract: EXISTS| GC
    L -->|derive distinct qualifying Producer_Key| CO[eligible_producer cohort]
    CO -->|include active licenses: LEFT expansion| LD[license detail role]
```

Every arrow is an explicitly approved directed operation. The cohort is a query-local derived relation; it is not an invented physical producer table. The two license nodes represent different query roles over the same source. There is no license–appointment join and no inferred agent–agency affiliation path.

For each license record, matching contract rows can be zero, one or many. For each contract, matching license rows can likewise be many. The underlying key correspondence is many-to-many. An `EXISTS` operation returns only a Boolean qualification for the outer row, so **the operation has no output fanout even when the relationship is many-to-many**.

### B.2 Split correspondence facts from query operations

Persist one relationship row per approved correspondence and one or more operation rows for its permitted uses. This avoids a universal `join_type: LEFT` that would be inappropriate for every question.

```json
{
  "relationship": {
    "id": "license.agent_contract_by_producer",
    "source_entity": "license",
    "target_entity": "agent_contract",
    "source_role": "base_license",
    "target_role": "qualifying_contract",
    "key_pairs": [
      {"source_field": "license.producer_key", "target_field": "agent_contract.producer_key"}
    ],
    "identity_namespace": "producer_shared",
    "namespace_status": "requires_confirmation",
    "source_to_target": "zero_to_many",
    "target_to_source": "zero_to_many",
    "null_key_behavior": "no_match",
    "required_predicates": [],
    "status": "draft"
  },
  "operation": {
    "id": "license.has_agent_contract",
    "relationship_id": "license.agent_contract_by_producer",
    "purpose": "qualify_base",
    "operator": "exists",
    "required_sql_form": "correlated_exists",
    "output_grain": "unchanged",
    "can_project_target_fields": false,
    "target_filters_scope": "inside_exists",
    "output_multiplicity_per_base_row": "zero_or_one",
    "permitted_target_filters": [
      "agent_contract.product_category",
      "agent_contract.status",
      "agent_contract.contract_type"
    ]
  }
}
```

Create analogous contracts for license→agency_contract and appointment→each contract source. The compiler can use a shared implementation, but each instantiated contract still names concrete endpoints and permissions. A generic “join anything with Producer_Key” rule is prohibited.

The identity namespace above is an example awaiting confirmation. Publication blocks operations that depend on it until it is verified or replaced with a reviewed crosswalk. A column's matching type does not prove matching identity.

### B.3 Four relationship purposes illustrated here

| Purpose | Relational operation | What happens to base rows | Output grain and predicate scope |
|---|---|---|---|
| Qualify by related evidence | `EXISTS` | Keep only bases with a match | Base grain unchanged; target criteria inside existence |
| Exclude by related evidence | `NOT EXISTS` | Keep only bases without a match | Base grain unchanged; avoid `NOT IN` null pitfalls |
| Enrich with a single related record | `LEFT JOIN` | Preserve all eligible bases | Requires at-most-one matching target; filters on included target in ON/target subquery |
| Include all matching child details | `LEFT JOIN` expansion, or grouped child result | Preserve bases when requested | Flat grain becomes base×child; no base aggregate after expansion without an approved rewrite |

An inner enrichment is a different operation with a different population contract. If it is not approved, the model cannot request it. If a user explicitly wants only bases having a child, represent that as a qualification step, then attach details if needed. This keeps population intent separate from display shape.

### B.4 Exact left-join enforcement

For a preserving license expansion, the logical contract is:

```json
{
  "id": "eligible_producer.include_active_licenses",
  "source_entity": "eligible_producer",
  "target_entity": "license",
  "operator": "expand_left",
  "required_sql_join": "LEFT",
  "key_pairs": [{"source_field": "producer_key", "target_field": "license.producer_key"}],
  "target_predicate_ids": ["license.active"],
  "preserve": "all_eligible_source_keys",
  "output_grain": "producer_key_plus_license_record_or_unmatched_placeholder",
  "aggregate_after_expansion": "requires_approved_aggregate_plan",
  "target_filter_placement": "ON_or_prefiltered_target",
  "target_post_filters": "prohibited_without_explicit_population_operation"
}
```

The compiler emits `LEFT JOIN ... ON ... AND active_predicate`. A validator checks this operation's lineage, exact field binding, mandatory target conditions and protected base population. It rejects moving the active condition to `WHERE`.

Checking for the word LEFT is not sufficient. For example, `WHERE child.Status = @active OR child.License_Id IS NULL` can still lose a producer that has only inactive licenses: a real child matched the original join, so no null placeholder was produced. Prefilter the child or put the active condition in ON. Do not apply an after-the-fact null workaround.

The database optimizer may implement equivalent logic with different physical join algorithms. Validate the emitted logical query against its contract, not the optimizer's choice of hash/merge/nested-loop operators.


## C. Worked semantic query proposals

### C.1 Public proposal versus trusted plan

Use three distinct types:

1. `ProposedSemanticQuery`: model-authored IDs, logical filters and desired response shape. Untrusted.
2. `ValidatedSemanticPlan`: server-resolved canonical IDs, predicates, bindings, operations, grain and policy obligations.
3. `CompiledQueryArtifact`: immutable SQL AST/text, ordered typed parameters, manifest, versions, principal/policy scope, expiry and hash.

The model cannot supply a principal ID, waive a policy, change a relationship contract, select credentials or declare its own validation success. A JSON-schema-conforming proposal can still be wrong; semantic checks are a separate stage.

### C.2 Complete illustrative proposal for sample 2

```json
{
  "ir_version": 1,
  "catalog_release": "producer-demo-v1",
  "kind": "aggregate",
  "base_entity": "license",
  "metric_ids": ["license.active_record_count"],
  "group_by": [],
  "base_filters": [],
  "relationship_filter": {
    "op": "any",
    "items": [
      {
        "operation_id": "license.has_agent_contract",
        "target_filters": [
          {"field_id": "agent_contract.product_category", "op": "in_resolved_set", "resolution_id": "res_pet_example"}
        ]
      },
      {
        "operation_id": "license.has_agency_contract",
        "target_filters": [
          {"field_id": "agency_contract.product_category", "op": "in_resolved_set", "resolution_id": "res_pet_example"}
        ]
      }
    ]
  },
  "output": {"shape": "scalar"}
}
```

The active predicate belongs to the metric definition. The compiler obtains its approved status-value bindings automatically. The Pet handle is checked for both requested fields. The `any` node means either contract source qualifies. Replacing it with `all` would require both sources and answers a different question.

Sample 3 changes the base/metric/operation prefixes to appointment. Sample S1-row is a `detail` query selecting the six license fields, with `license.active` and `{field_id: "license.termination_date", op: "is_null"}` as base filters plus the same relationship qualification. S1-cohort uses the dedicated `cohort_detail` shape below; do not translate it into S1-row by moving its filters.

### C.3 Shape rules for these examples

| Kind | Allowed payload | Important invariant |
|---|---|---|
| `detail` | Base projection, base filters, existence/absence conditions, stable sort and pagination | One row per base record; no implicit DISTINCT |
| `aggregate` | One base metric initially, approved group dimensions, base/related filters | No expanding child before base aggregation |
| `cohort_detail` | Typed cohort derivation, child inclusion operation, explicit shape | Deduplicate only the cohort keys; preserve child records |

`cohort_detail` has a reviewed template for this domain:

```json
{
  "kind": "cohort_detail",
  "cohort": {
    "source_entity": "license",
    "key_fields": ["license.producer_key"],
    "base_filters": [{"field_id": "license.termination_date", "op": "is_null"}],
    "qualification_template_id": "license.pet_contract_in_either_source",
    "resolution_id": "res_pet_example"
  },
  "include": {
    "operation_id": "eligible_producer.include_active_licenses",
    "fields": ["license.license_id", "license.license_number", "license.state", "license.status", "license.termination_date"]
  },
  "output": {"shape": "flat_preserving_cohort"}
}
```

This is the kind-specific body; the real request also includes `ir_version` and `catalog_release` from the common envelope. `qualification_template_id` expands to the same two approved existence operations and Pet handle, not arbitrary SQL. The derived cohort and its inclusion operator are typed query templates registered by the compiler; they are not rows claiming a nonexistent physical `eligible_producer` table in SQLite. A later general derived-entity schema can extend this without changing physical entity bindings.

Choose a JSON Schema with `oneOf` for each kind, enumerated operators, `additionalProperties: false`, bounded nesting and array sizes. Validate required fields at every nested level. A future operator or shape requires a schema/compiler version change; do not quietly accept unknown fields.


## D. The three sample questions in T-SQL

### D.1 Common assumptions and parameter bindings

The SQL below uses the four supplied tables under the illustrative `dbo` schema. It assumes approved shared Producer_Key identity, approved one-row-per-counted-business-record source population (or a bound view that provides it), the status-only active definitions in appendix A, and Pet eligibility from either contract source. None of those grain or key assertions was verifiable from the workbook. If a license or appointment table contains duplicate business identities or multiple history versions, the production catalog must select an approved current/as-of population or block the business-record metric. The compiler cannot turn an unverified `COUNT_BIG(*)` into a business count. It substitutes configured secured objects and mandatory restrictions. These SQL blocks demonstrate business semantics; they are not a complete security deployment.

| Variable | Synthetic value | Provenance |
|---|---|---|
| `@license_active_0` | `ACTIVE` | `license_status.active` bound to license.Status |
| `@appointment_active_0` | `A` | `appointment_status.active` bound to appointment.Status |
| `@pet_agent_0` | `PET` | `product_category.pet` bound to Agent_Contracts.Product_Category |
| `@pet_agency_0` | `P` | Same concept bound to Agency_Contracts.Product_Category |

Use one placeholder per binding if the real mapping contains multiple literals. Contract Status is deliberately unrestricted in these examples: the original count questions ask for active licenses/appointments **having Pet contracts**, not explicitly active contracts. If a reviewed business default requires active contracts, expose that default in the interpretation and use a versioned contract predicate inside each existence check.

The grouping of `EXISTS(...) OR EXISTS(...)` is essential: it must remain beneath the base status/date conjunction. Otherwise one branch can accidentally bypass base filters.

### D.2 Question 1, reading A: each returned license has no term date

Original: “Fetch all individual records with no term date for Pet product category. For those records I need all active licenses.”

With “individual records” interpreted as nonaggregated license records and the confirmed term-date field, the precise interpretation is:

> Return each active license whose license termination date is absent and whose producer has a Pet contract in either approved source.

```sql
SELECT
    l.Producer_Key,
    l.License_Id,
    l.License_Number,
    l.State,
    l.Status,
    l.Termination_Date
FROM dbo.Producer_Licenses AS l
WHERE l.Termination_Date IS NULL
  AND l.Status IN (@license_active_0)
  AND (
      EXISTS (
          SELECT 1
          FROM dbo.Agent_Contracts AS ac
          WHERE ac.Producer_Key = l.Producer_Key
            AND ac.Product_Category IN (@pet_agent_0)
      )
      OR EXISTS (
          SELECT 1
          FROM dbo.Agency_Contracts AS gc
          WHERE gc.Producer_Key = l.Producer_Key
            AND gc.Product_Category IN (@pet_agency_0)
      )
  )
ORDER BY l.Producer_Key, l.License_Id;
```

Output grain is one license record. No contract columns are projected because contracts are only eligibility evidence. Multiple Pet contracts do not duplicate a license. There is no need for a left join in this reading: the requested result consists of licenses, and both the active and date conditions intentionally filter them.

The ORDER BY assumes the proposed composite identity is unique. If not, add the actual record-key fields to the semantic projection/order before implementing pagination. Interactive results use explicit paging; the unbounded SQL above describes the complete logical result.

### D.3 Question 1, reading B: first qualify producers, then include all active licenses

The second plausible interpretation preserves the two stages of “for those records”:

> Identify producers who have at least one license with no termination date and a Pet contract. For every such producer, return all active licenses, preserving the producer even if there are none.

This uses only the four supplied tables. The qualifying license and included license are different roles; the included active license does **not** automatically inherit the qualifying no-term-date condition.

```sql
WITH eligible_producers AS (
    SELECT DISTINCT q.Producer_Key
    FROM dbo.Producer_Licenses AS q
    WHERE q.Termination_Date IS NULL
      AND q.Producer_Key IS NOT NULL
      AND (
          EXISTS (
              SELECT 1
              FROM dbo.Agent_Contracts AS ac
              WHERE ac.Producer_Key = q.Producer_Key
                AND ac.Product_Category IN (@pet_agent_0)
          )
          OR EXISTS (
              SELECT 1
              FROM dbo.Agency_Contracts AS gc
              WHERE gc.Producer_Key = q.Producer_Key
                AND gc.Product_Category IN (@pet_agency_0)
          )
      )
)
SELECT
    ep.Producer_Key,
    l.License_Id,
    l.License_Number,
    l.State,
    l.Status,
    l.Termination_Date
FROM eligible_producers AS ep
LEFT JOIN dbo.Producer_Licenses AS l
  ON l.Producer_Key = ep.Producer_Key
 AND l.Status IN (@license_active_0)
ORDER BY ep.Producer_Key, l.License_Id;
```

`DISTINCT` here is a deliberate operation that constructs a **producer cohort** from qualifying license rows. It is not a patch for inflated counts. The child license rows are not deduplicated. A qualifying producer with no active license gets one row with null child fields. An active license with a future term date can be included under the status-only active rule.

The proposed identity requires non-null License_Id; the result assembler can use it to distinguish a matched child from an unmatched placeholder. If actual identities differ, use the confirmed non-null child key or a compiler-generated match marker. A nested response would represent that unmatched producer as `licenses: []`, not as one all-null license object.

If the intended base is **each qualifying license**, rather than one producer, preserve the qualifying license key and return `(qualifying_license_id, included_active_license_id)` pairs. That can legitimately repeat an included license for several qualifying licenses of the same producer. It is a third output grain and must be requested explicitly; the producer-cohort query intentionally collapses qualifying licenses to one producer key.

### D.4 How the application chooses between the two readings

The workbook currently has no examples. Register the owner's preferred interpretation as the approved example, including its population and output grain. Until then, the application can ask:

> Should every returned license have no term date, or should that condition select producers and then return all their active licenses?

This clarification is about filter scope, not which physical column “term date” means; the user has already settled the column. The runtime should not ask again once the scope is settled in conversation or an approved domain example makes it unambiguous.

If “individual” means a person rather than detail records, the four sources do not provide an explicit person-type field. A catalog description can reveal that an existing source has that guaranteed population, but a table name alone cannot prove it. Otherwise an additional classification binding is required.

### D.5 Question 2: count active license records with Pet contracts

```sql
SELECT COUNT_BIG(*) AS Active_License_Record_Count
FROM dbo.Producer_Licenses AS l
WHERE l.Status IN (@license_active_0)
  AND (
      EXISTS (
          SELECT 1
          FROM dbo.Agent_Contracts AS ac
          WHERE ac.Producer_Key = l.Producer_Key
            AND ac.Product_Category IN (@pet_agent_0)
      )
      OR EXISTS (
          SELECT 1
          FROM dbo.Agency_Contracts AS gc
          WHERE gc.Producer_Key = l.Producer_Key
            AND gc.Product_Category IN (@pet_agency_0)
      )
  );
```

One qualifying row from the verified license population contributes one, regardless of how many Pet contracts its producer has. A producer with two distinct active licenses contributes two. This question has no explicit no-term-date condition; do not copy that condition from question 1. A reviewed active definition can include it, but the status-only demonstration does not. If the table has multiple active physical rows for one business license, this SQL counts those rows and is not a valid business-license count until a row/version rule is applied.

The result is zero when there are no qualifying rows in the catalog-approved license population. A database error, unknown mapping, timeout or absent authorization is not a zero result. The service distinguishes those outcomes.

### D.6 Question 3: count active appointment records with Pet contracts

```sql
SELECT COUNT_BIG(*) AS Active_Appointment_Record_Count
FROM dbo.Producer_Appointments AS a
WHERE a.Status IN (@appointment_active_0)
  AND (
      EXISTS (
          SELECT 1
          FROM dbo.Agent_Contracts AS ac
          WHERE ac.Producer_Key = a.Producer_Key
            AND ac.Product_Category IN (@pet_agent_0)
      )
      OR EXISTS (
          SELECT 1
          FROM dbo.Agency_Contracts AS gc
          WHERE gc.Producer_Key = a.Producer_Key
            AND gc.Product_Category IN (@pet_agency_0)
      )
  );
```

The query does not involve Producer_Licenses. A producer can have a qualifying active appointment without an active license in this dataset, and the question as written still counts that appointment. If eligibility legally or operationally requires a license, that is a separately approved business predicate, not an inferred join.

### D.7 Why raw joins fail for these counts

Suppose a producer has two active licenses and three Pet contract rows across the approved sources:

```text
License rows:       L1  L2                 correct contribution: 2
Pet contract rows:  C1  C2  C3
Detail join rows:   L1-C1 L1-C2 L1-C3
                   L2-C1 L2-C2 L2-C3       incorrect COUNT(*): 6
Existence filter:   L1 qualifies
                   L2 qualifies           correct COUNT(*): 2
```

`COUNT(DISTINCT License_Number)` is not a general repair because different legitimate records can share a number. `COUNT(DISTINCT Producer_Key)` counts producers. Even a correct distinct record key is an unnecessary masking layer when existence directly expresses the request.

An alternative is a union of distinct qualifying Producer_Key values joined to licenses. That can be correct if the cohort key is guaranteed unique and authorization applies inside both branches. Use correlated EXISTS as the initial compiler form because it states membership directly. Evaluate performance before substituting an equivalent reviewed form.

If contract details must be combined later, use `UNION ALL` with a source discriminator and source-qualified contract identity. `Contract_Id` alone is not guaranteed unique across Agent_Contracts and Agency_Contracts. Avoid silently deduplicating two legitimate contracts from different sources.

### D.8 Meaningful variations

| New question | Plan change |
|---|---|
| “Active Pet contracts” | Add source-specific contract active predicate inside each existence branch |
| “Agent contracts only” | Use only the approved agent-contract operation; disclose scope |
| “Both agent and agency Pet contracts” | Combine the two existence conditions with AND |
| “No Pet contracts” | Negate the complete either-source membership: `NOT EXISTS(agent Pet) AND NOT EXISTS(agency Pet)` |
| “License counts by state” | Group the license base by approved license.State; eligibility remains existence |
| “Appointment counts by state” | Group the appointment base by appointment.State |
| “All active licenses for Pet producers, even with a term date” | Remove the explicit no-term filter unless active predicate itself requires it |
| “As of last year” | Require an approved historical source/predicate; current status alone cannot reconstruct past activity |

Business scope, graph selection and predicate placement are data in the plan. They should not be hidden in the LLM's reasoning or buried in a prose prompt.


## E. Synthetic fixtures and verification scope

### E.1 Synthetic fixture used to check the design

The following is invented test data, not data extracted from the workbook. The workbook contains no business records. Nonessential columns have ordinary placeholder values; L11 and L31 deliberately share a License_Number to show why it is not a reliable distinct-count key.

| Producer | License ID | Status | Termination date |
|---|---|---|---|
| P1 | L11 | ACTIVE | NULL |
| P1 | L12 | ACTIVE | 2030-01-01 |
| P1 | L13 | INACTIVE | NULL |
| P2 | L21 | INACTIVE | NULL |
| P3 | L31 | ACTIVE | NULL |
| P4 | L41 | ACTIVE | NULL |
| P5 | L51 | ACTIVE | NULL |
| P6 | L61 | ACTIVE | NULL |
| P8 | L81 | ACTIVE | 2030-01-01 |

| Producer | Appointment ID | Status | Termination date |
|---|---|---|---|
| P1 | A11 | A | NULL |
| P1 | A12 | A | 2030-01-01 |
| P2 | A21 | A | NULL |
| P3 | A31 | A | NULL |
| P4 | A41 | A | NULL |
| P5 | A51 | A | NULL |
| P8 | A81 | A | NULL |

| Producer | Agent contracts | Agency contracts | Eligibility observation |
|---|---|---|---|
| P1 | Two PET | One P | Three qualifying contracts must not multiply base records |
| P2 | One PET | None | Pet producer with no active license; has active appointment |
| P3 | None | One P, contract status INACTIVE | Qualifies when contract status is unrestricted |
| P4 | One LIFE | None | Does not qualify |
| P5 | One PET | Two P | Source-overlapping Contract_Id is allowed; membership still Boolean |
| P6 | None | One L | Does not qualify |
| P8 | One PET | None | Qualifies for status-only counts but lacks a no-term-date license |

Expected answers:

| Example | Expected result |
|---|---|
| S1-row | `(P1,L11)`, `(P3,L31)`, `(P5,L51)`; 3 license rows |
| S1-cohort | `(P1,L11)`, `(P1,L12)`, `(P2,NULL)`, `(P3,L31)`, `(P5,L51)`; 5 flat rows representing 4 producers |
| S2 | 5 active license records: L11, L12, L31, L51, L81 |
| S3 | 6 active appointment records: A11, A12, A21, A31, A51, A81 |
| Incorrect join count for S2 | 11 instead of 5 |
| Incorrect added no-term filter for S2 | 3 instead of 5 |

### E.2 Verification actually performed for this document

The four SQL examples were extracted from this Markdown and executed against an in-memory SQLite fixture after only removing the `dbo.` qualifier and replacing `COUNT_BIG` with `COUNT`. Their result identities/counts matched the expectations above. Additional checks confirmed that adding a matching contract leaves the counts unchanged, null producer keys do not match each other, no matching contracts yields zero, and moving the active child predicate to WHERE drops P2 from the preserving detail query.

The supplied SQLite DDL was executed successfully with foreign keys enabled; an invalid value/domain reference was rejected. Embedded JSON examples were parsed, and Markdown fences were checked. These are document/example checks. **No connection to Azure SQL was supplied, so T-SQL driver behavior, permissions, query plans, performance and production data semantics have not been integration-tested.** The production compiler, policy engine and workflow are specified in the enterprise design. They have not been deployed or integration-tested in this task.

