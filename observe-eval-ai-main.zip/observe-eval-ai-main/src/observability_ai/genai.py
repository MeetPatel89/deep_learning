"""Pure GenAI and Langfuse attribute helpers without optional library imports."""

from math import isfinite

from opentelemetry.util.types import AttributeValue

from .config import _validate_text


def model_attributes(
    *,
    provider_name: str,
    request_model: str,
    operation_name: str = "chat",
    response_model: str | None = None,
) -> dict[str, AttributeValue]:
    """Return GenAI model identity attributes, omitting an unknown response model.

    All supplied names must be nonblank strings. ``operation_name`` also accepts
    operations such as ``embeddings`` and provider-specific custom values.
    This helper never inspects or captures message content.
    """
    _validate_text("provider_name", provider_name)
    _validate_text("request_model", request_model)
    _validate_text("operation_name", operation_name)
    attributes: dict[str, AttributeValue] = {
        "gen_ai.operation.name": operation_name,
        "gen_ai.provider.name": provider_name,
        "gen_ai.request.model": request_model,
    }
    if response_model is not None:
        _validate_text("response_model", response_model)
        attributes["gen_ai.response.model"] = response_model
    return attributes


def usage_attributes(
    *,
    input_tokens: int,
    output_tokens: int,
    cached_tokens: int = 0,
) -> dict[str, AttributeValue]:
    """Return OTel usage with cache reads included in the input token total.

    Counts must be nonnegative integers, with cached tokens a subset of input.
    Zero input/output counts are retained; a zero cache count is omitted.
    Langfuse normalizes these OTel counts during ingestion, so do not subtract
    cached tokens from ``input_tokens`` before calling this helper.
    """
    _validate_usage(input_tokens, output_tokens, cached_tokens)
    attributes: dict[str, AttributeValue] = {
        "gen_ai.usage.input_tokens": input_tokens,
        "gen_ai.usage.output_tokens": output_tokens,
    }
    if cached_tokens:
        attributes["gen_ai.usage.cache_read.input_tokens"] = cached_tokens
    return attributes


def langfuse_usage_details(
    *,
    input_tokens: int,
    output_tokens: int,
    cached_tokens: int = 0,
) -> dict[str, int]:
    """Split inclusive input usage into exclusive Langfuse SDK usage buckets.

    Use the result as flat ``usage_details`` for a Langfuse generation, not as
    OTel ``gen_ai.usage.*`` attributes. Input excludes cache reads here so each
    token is counted once. Validation matches ``usage_attributes``; a zero cache
    count is omitted. The SDK itself is not required to use this function.
    """
    _validate_usage(input_tokens, output_tokens, cached_tokens)
    details = {"input": input_tokens - cached_tokens, "output": output_tokens}
    if cached_tokens:
        details["cache_read_input_tokens"] = cached_tokens
    return details


def _validate_usage(
    input_tokens: int,
    output_tokens: int,
    cached_tokens: int,
) -> None:
    for name, value in (
        ("input_tokens", input_tokens),
        ("output_tokens", output_tokens),
        ("cached_tokens", cached_tokens),
    ):
        if not isinstance(value, int) or isinstance(value, bool):
            raise TypeError(f"{name} must be an integer")
        if value < 0:
            raise ValueError(f"{name} must not be negative")
    if cached_tokens > input_tokens:
        raise ValueError("cached_tokens must not exceed input_tokens")


def tool_attributes(
    *, name: str, call_id: str | None = None, description: str | None = None
) -> dict[str, AttributeValue]:
    """Describe a tool and optionally identify its particular invocation."""
    _validate_text("name", name)
    attributes: dict[str, AttributeValue] = {}
    for key, value in (
        ("name", name),
        ("call.id", call_id),
        ("description", description),
    ):
        if value is not None:
            _validate_text(key, value)
            attributes[f"gen_ai.tool.{key}"] = value
    return attributes


def agent_attributes(
    *, name: str, agent_id: str | None = None, description: str | None = None
) -> dict[str, AttributeValue]:
    """Describe an agent without capturing its instructions or messages."""
    _validate_text("name", name)
    attributes: dict[str, AttributeValue] = {}
    for key, value in (("name", name), ("id", agent_id), ("description", description)):
        if value is not None:
            _validate_text(key, value)
            attributes[f"gen_ai.agent.{key}"] = value
    return attributes


def prompt_attributes(*, name: str, version: int) -> dict[str, AttributeValue]:
    """Link a managed prompt by name and positive integer version."""
    _validate_text("name", name)
    if not isinstance(version, int) or isinstance(version, bool):
        raise TypeError("version must be an integer")
    if version < 1:
        raise ValueError("version must be positive")
    return {
        "langfuse.observation.prompt.name": name,
        "langfuse.observation.prompt.version": version,
    }


def cost_details(
    *,
    input_cost: float | None = None,
    output_cost: float | None = None,
    total_cost: float | None = None,
) -> dict[str, AttributeValue]:
    """Return supplied finite, nonnegative USD costs, retaining explicit zeros.

    Omitted costs remain unknown; no total is inferred from partial costs.
    """
    attributes: dict[str, AttributeValue] = {}
    for name, value in (
        ("input", input_cost),
        ("output", output_cost),
        ("total", total_cost),
    ):
        if value is None:
            continue
        if not isinstance(value, (int, float)) or isinstance(value, bool):
            raise TypeError(f"{name}_cost must be a number")
        if not isfinite(value) or value < 0:
            raise ValueError(f"{name}_cost must be finite and nonnegative")
        attributes[f"langfuse.observation.cost_details.{name}"] = value
    return attributes


__all__ = [
    "agent_attributes",
    "cost_details",
    "langfuse_usage_details",
    "model_attributes",
    "prompt_attributes",
    "tool_attributes",
    "usage_attributes",
]
