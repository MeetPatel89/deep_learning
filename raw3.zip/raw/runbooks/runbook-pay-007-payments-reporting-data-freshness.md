---
doc_id: RUNBOOK-PAY-007
title: Payments Reporting Data Freshness Runbook
doc_type: runbook
service_id: svc_payments_reporting
owner_group: Data Applications
visibility: internal
status: active
created_at: "2026-05-28T10:00:00"
updated_at: "2026-06-16T12:30:00"
related_records:
  - KI-221
  - CHG-2411
  - INC-1217
  - KB-204
  - POL-COMMS-001
source_facts:
  - KI-221
  - svc_payments_reporting
difficulty_tags:
  - procedural
  - azure-data-stack
  - action-sequencing
servicenow:
  table: kb_knowledge
  number: KB0000407
  kb_category: Runbook
  workflow_state: Published
  business_service: Payments Reporting Service
  cmdb_ci: Payments Reporting Pipeline
  assignment_group: Data Applications
  visibility: internal
  contains_customer_safe_wording: false
---

# Payments Reporting Data Freshness Runbook

## Record details

| Field | Value |
| --- | --- |
| Table | kb_knowledge |
| Number | KB0000407 |
| KB category | Runbook |
| Workflow state | Published |
| Business service | Payments Reporting Service |
| Configuration item | Payments Reporting Pipeline |
| Assignment group | Data Applications |
| Visibility | internal |
| Contains customer-safe wording | false |

## Purpose

This runbook describes how to investigate Payments Reporting Service data freshness issues, including stale dashboards, payment export mismatches, and reporting views where the latest partition is not reflected in Synapse/Fabric.

The primary known issue is KI-221. The runbook is internal and includes Azure data stack details needed by Data Applications.

## When to use this runbook

Use this runbook when:

- Payment operations reports stale dashboard data.
- A dashboard is behind by more than four hours.
- Exported payment totals do not match the operational transaction view.
- Source transaction records appear current but the reporting layer is behind.
- The report starts after CHG-2411 or another Payments Reporting pipeline change.

Confirm dashboard staleness duration before escalating. A short expected reporting delay may not be an incident, but stale data beyond the expected refresh period should be investigated.

## Required inputs

Collect:

| Input | Purpose |
| --- | --- |
| Dashboard or export name | Identifies the affected reporting output. |
| Current dashboard timestamp | Confirms the reporting watermark visible to users. |
| Expected reporting period | Defines the freshness gap. |
| Export time | Helps compare export totals against the dashboard period. |
| Source transaction availability | Distinguishes reporting delay from source data issue. |
| Recent change record | Supports temporal review against CHG-2411. |

Service Desk L1 should collect user-facing details, then escalate to Data Applications when the issue appears to be reporting freshness rather than user access.

## Initial triage

1. Confirm dashboard staleness duration.
2. Confirm whether multiple business users see the same reporting delay.
3. Record the dashboard or export name and the expected reporting period.
4. Check whether a recent Payments Reporting change completed.
5. If the stale view follows CHG-2411, link the incident to CHG-2411 and KI-221.
6. Use customer-safe wording from KB-204 until Data Applications confirms internal details.

## Investigation steps

For Data Applications:

1. Check whether Databricks transformation completed successfully.
2. Validate Azure SQL Database staging table freshness.
3. Compare Azure SQL Database control-table watermark to the latest Databricks output partition.
4. Confirm whether Synapse or Fabric still shows the previous data refresh watermark.
5. Determine whether the reporting layer skipped the latest partition.
6. Rerun Synapse/Fabric reporting refresh.
7. Backfill from the last successful payment partition if needed.
8. Verify dashboard data and payment export totals after refresh.

These steps are ordered to separate source transaction availability from reporting-layer freshness. Do not assume a successful Databricks job means the dashboard is current.

## Decision points

Use these decision points:

- If source transaction records are not current, this runbook may not be sufficient and Data Applications should investigate upstream availability.
- If Databricks transformation did not complete, resolve transformation failure before rerunning reporting refresh.
- If Azure SQL Database staging tables are current and Databricks succeeded, compare watermark and partition state.
- If the watermark is behind or the latest partition was skipped, rerun reporting refresh and backfill from the last successful payment partition.
- If watermark or partition state cannot be reconciled, escalate within Data Applications.

Escalate to Data Applications if watermark or partition state cannot be reconciled. Service Desk L1 should not attempt internal data stack recovery.

## Workaround or recovery steps

The KI-221 recovery path is:

1. Validate the Azure SQL Database control-table watermark.
2. Confirm the latest Databricks output partition.
3. Rerun Synapse/Fabric reporting refresh.
4. Backfill from the last successful payment partition if needed.
5. Confirm the dashboard has advanced to the expected reporting period.
6. Compare payment export totals after the refresh.
7. Update the incident with customer-safe resolution wording.

INC-1217 used this sequence and was resolved after the reporting refresh rerun and partition backfill.

## Escalation criteria

Escalate to Data Applications when:

- Dashboard staleness is confirmed beyond the expected refresh interval.
- Source transaction records are present but reporting is behind.
- Export totals do not match expected dashboard totals.
- Watermark and partition state cannot be reconciled.
- The issue follows CHG-2411 or another reporting pipeline change.

Notify Release Management when the incident appears tied to a recently completed change.

## Customer-safe communication

Use POL-COMMS-001 and KB-204 for user-facing language. Approved KI-221 summary:

"Reporting data is delayed, but source payment transactions are not lost."

Avoid customer-facing discussion of control-table watermarks, partitions, Synapse/Fabric mechanics, or Databricks job internals unless Data Applications approves specific wording.

## Related records

- KI-221: Payments Dashboard Data Freshness Delay After Synapse/Fabric Refresh Failure.
- CHG-2411: Update Databricks Runtime and Synapse/Fabric Refresh Pipeline for Payments Reporting Service.
- INC-1217: Payments Dashboard Stale After Refresh Pipeline Update.
- KB-204: Payments Dashboard Data Delay.
- POL-COMMS-001: Customer-Safe Communication Policy.

