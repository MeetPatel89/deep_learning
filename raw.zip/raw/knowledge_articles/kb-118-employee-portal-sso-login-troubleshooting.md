---
doc_id: KB-118
title: Employee Portal SSO Login Troubleshooting
doc_type: knowledge_article
service_id: svc_identity_gateway
owner_group: Service Desk L1
visibility: customer_safe
status: published
created_at: "2026-05-25T12:00:00"
updated_at: "2026-06-14T11:00:00"
related_records:
  - RUNBOOK-SSO-003
  - KI-104
  - POL-COMMS-001
source_facts:
  - KI-104
  - svc_identity_gateway
difficulty_tags:
  - customer-safe
  - less-detailed-than-runbook
---

# Employee Portal SSO Login Troubleshooting

## Summary

Use this article for basic Employee Portal SSO login troubleshooting. It is intended for Service Desk L1 and customer-safe response drafting. It does not replace RUNBOOK-SSO-003 for internal platform investigation.

Employee Portal sign-in failures may occur for a single user or for multiple users after identity maintenance. Support may validate enterprise sign-in configuration after identity maintenance when the issue is broader than one user.

Mention that support may validate enterprise sign-in configuration after identity maintenance.

## Symptoms

Users may report:

- They cannot complete Employee Portal sign-in.
- They receive an invalid sign-in response message.
- A coworker can sign in while they cannot.
- The issue started after a scheduled sign-in maintenance window.

For customer-safe communication, describe the issue as a sign-in configuration review, not as an internal platform defect.

## What support should check first

Provide basic login troubleshooting steps for Employee Portal.

1. Ask the user to retry Employee Portal sign-in in a fresh browser session.
2. Confirm whether the user is reaching the enterprise sign-in page.
3. Record the exact visible error text.
4. Ask whether other users in the same team or location are affected.
5. Check whether recent identity maintenance is noted in support communications.
6. If multiple users are affected, stop treating the issue as a single-user browser problem.

Do not mention internal metadata cache behavior.

## Information to collect

Collect:

- Affected application: Employee Portal.
- Approximate time of failed sign-in.
- Whether the user saw an invalid sign-in response message.
- Whether coworkers are affected.
- Whether the issue began after scheduled identity maintenance.

Do not request passwords, secrets, tokens, or screenshots containing sensitive account data.

## Recommended next step

For a single-user issue, continue standard login troubleshooting and confirm the user can reach the enterprise sign-in page.

For unresolved multi-user issues, direct unresolved multi-user issues to Service Desk L1 for escalation. Service Desk L1 should review RUNBOOK-SSO-003 and route to IAM Platform when the issue matches the known SSO maintenance pattern.

## Customer-safe response guidance

Use this wording when the issue appears related to scheduled identity maintenance:

"We are validating the enterprise sign-in configuration after scheduled identity maintenance."

Avoid adding internal diagnostic detail. Keep the update focused on the sign-in experience and the fact that support is validating the configuration.

## When to escalate

Escalate through Service Desk L1 when:

- More than one user is affected.
- The issue begins after identity maintenance.
- The visible error indicates an invalid sign-in response.
- Basic retry and browser-session checks do not resolve the issue.

Service Desk L1 should route unresolved platform symptoms to IAM Platform using RUNBOOK-SSO-003.

## Related records

- RUNBOOK-SSO-003: internal runbook reference for Service Desk L1 escalation.
- KI-104: internal known issue reference.
- POL-COMMS-001: customer-safe communication policy.

Use only approved customer-safe wording when referencing these records outside support.
