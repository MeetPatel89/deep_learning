"""Verify SDK construction, observation exports, and explicit client ownership."""

from unittest.mock import Mock

from pytest import MonkeyPatch, importorskip

importorskip("langfuse", reason="requires observe-eval-ai[langfuse]")

from langfuse import Langfuse  # noqa: E402
from langfuse import propagate_attributes as sdk_propagate  # noqa: E402
from opentelemetry.sdk.trace import TracerProvider  # noqa: E402
from opentelemetry.sdk.trace.export.in_memory_span_exporter import (  # noqa: E402
    InMemorySpanExporter,
)
from opentelemetry.sdk.trace.sampling import (  # noqa: E402
    ParentBased,
    TraceIdRatioBased,
)
from opentelemetry.trace import get_tracer_provider  # noqa: E402

from observability_ai import LangfuseSettings, __version__  # noqa: E402
from observability_ai.langfuse import (  # noqa: E402
    build_langfuse_client,
    propagate_attributes,
    start_as_current_observation,
)


def test_factory_maps_settings_without_changing_globals(
    monkeypatch: MonkeyPatch,
) -> None:
    """Explicit project and sampling settings reach a local provider and SDK."""
    constructor = Mock(spec=Langfuse)
    monkeypatch.setattr("observability_ai.langfuse.client.Langfuse", constructor)
    global_provider = get_tracer_provider()
    settings = LangfuseSettings(
        "pk-test",
        "sk-test",
        "http://localhost:3000/prefix/",
        environment="staging",
        release="build-42",
        sample_ratio=0.25,
    )
    result = build_langfuse_client(settings)
    provider = constructor.call_args.kwargs["tracer_provider"]
    try:
        assert isinstance(provider, TracerProvider)
        assert provider is not global_provider
        assert isinstance(provider.sampler, ParentBased)
        assert isinstance(provider.sampler._root, TraceIdRatioBased)
        assert provider.sampler._root.rate == 0.25
        assert (
            provider.resource.attributes["service.name"] == "observability-ai.langfuse"
        )
        assert provider.resource.attributes["service.version"] == __version__
        constructor.assert_called_once_with(
            public_key="pk-test",
            secret_key="sk-test",
            base_url="http://localhost:3000/prefix",
            environment="staging",
            release="build-42",
            sample_rate=0.25,
            tracer_provider=provider,
            span_exporter=None,
        )
        assert result is constructor.return_value
        assert get_tracer_provider() is global_provider
    finally:
        provider.shutdown()


def test_factory_preserves_injected_provider_and_exporter(
    monkeypatch: MonkeyPatch,
    settings: LangfuseSettings,
) -> None:
    """A supplied provider is passed through without another exporter or sampler."""
    constructor = Mock(spec=Langfuse)
    monkeypatch.setattr("observability_ai.langfuse.client.Langfuse", constructor)
    provider = TracerProvider()
    exporter = InMemorySpanExporter()
    try:
        build_langfuse_client(
            settings, tracer_provider=provider, span_exporter=exporter
        )
        assert constructor.call_args.kwargs["tracer_provider"] is provider
        assert constructor.call_args.kwargs["span_exporter"] is exporter
    finally:
        provider.shutdown()


def test_native_helpers_export_nested_sdk_observations(
    sdk: tuple[Langfuse, InMemorySpanExporter],
) -> None:
    """Re-exports retain SDK types, propagation, and shared OTel parent context."""
    client, exporter = sdk
    global_provider = get_tracer_provider()
    assert propagate_attributes is sdk_propagate
    assert start_as_current_observation is Langfuse.start_as_current_observation
    with start_as_current_observation(client, name="parent") as parent:
        with propagate_attributes(session_id="sdk-session", tags=["sdk"]):
            with start_as_current_observation(
                client, name="generation", as_type="generation", model="demo"
            ) as generation:
                generation.update(usage_details={"input": 5, "output": 3})
                assert parent.trace_id == generation.trace_id
    client.flush()
    spans = exporter.get_finished_spans()
    assert len(spans) == 2
    child, root = spans
    assert child.parent == root.context
    for span in spans:
        assert span.attributes is not None
        assert span.attributes["session.id"] == "sdk-session"
        assert span.attributes["langfuse.trace.tags"] == ("sdk",)
        assert span.attributes["langfuse.environment"] == "test"
        assert span.attributes["langfuse.release"] == "sdk-test"
    assert get_tracer_provider() is global_provider
