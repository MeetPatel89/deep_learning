---
doc_id: POL-ESC-001
title: Incident Severity and Escalation Policy
doc_type: policy
service_id: null
owner_group: Service Desk L1
visibility: internal
status: active
created_at: "2026-05-10T09:00:00"
updated_at: "2026-06-10T09:00:00"
related_records: []
source_facts:
  - support_groups
difficulty_tags:
  - escalation-policy
  - severity-classification
---

# Incident Severity and Escalation Policy

## Purpose

This policy defines how Service Desk L1 classifies and escalates incidents for Nautilus Financial Systems internal ITSM support. It is intended to keep Tier 1 service incidents moving to the correct owning group without requiring L1 to complete deep platform diagnosis first.

Service Desk L1 performs initial triage. Initial triage includes confirming user impact, affected service, timing, visible symptoms, and whether a documented workaround is available.

## Scope

This policy applies to incidents and support tickets involving internal enterprise services, including:

- Identity Gateway, owned by IAM Platform.
- Payments Reporting Service, owned by Data Applications.
- Internal API Gateway, owned by Platform Engineering.

It also applies to change-adjacent incidents where Release Management needs notification because a symptom appears after a completed change.

## Policy rules

Tier 1 service incidents affecting multiple users should be treated as at least high priority. This rule applies even when business impact is still being confirmed, because Tier 1 services are shared dependencies.

Escalate to the owning support group when the documented workaround fails or when the issue affects multiple business users. The owning support group is responsible for final remediation when the issue is tied to service internals, a known issue, or a recent change.

Release Management should be notified when an incident appears related to a recent completed change. This is a notification requirement, not a reassignment rule. The owning technical group still handles remediation unless Release Management specifically accepts coordination ownership.

For current Tier 1 services, use these routing paths:

| Service | Owning support group | Common escalation trigger |
| --- | --- | --- |
| Identity Gateway | IAM Platform | Invalid SAML response, partial login failures, recent identity maintenance |
| Payments Reporting Service | Data Applications | Stale dashboard, export mismatch, source records present while reporting lags |
| Internal API Gateway | Platform Engineering | Unexpected 429 responses, rate-limit entitlement mismatch |

## Support expectations

Service Desk L1 should do enough triage to make the escalation useful:

- Confirm affected service or likely service.
- Capture the exact user-facing symptom.
- Determine whether one user, a group, or many users are affected.
- Check for a matching known issue or runbook.
- Record any documented workaround attempted and the result.
- Check whether a recent completed change is a plausible trigger.

L1 should not delay escalation while trying to prove an internal root cause. If multiple users are affected and the symptoms match an active known issue, the ticket should move to the owning group with a concise evidence summary.

## Escalation or communication guidance

When escalating, include:

- Incident or ticket ID.
- Service candidate.
- Affected user group or business function.
- Start time or first reported time.
- Relevant change record, if any.
- Known issue or runbook reference.
- Workaround attempted.

When a recent completed change is involved, add Release Management as a watcher or notify them through the normal change-related incident path. Examples include INC-1104 after CHG-2407, INC-1217 after CHG-2411, and INC-1302 after CHG-2420.

## Examples

If branch users report invalid SAML response errors shortly after an identity certificate rotation, classify as high priority, link KI-104 if symptoms match, escalate to IAM Platform, and notify Release Management because CHG-2407 is a recent completed change.

If payment operations reports that exported payment totals do not match dashboard totals and source transaction records are available, classify as high priority when multiple business users are affected and escalate to Data Applications.

If Business-tier API clients report unexpected 429 responses after an API Gateway policy deployment, collect client ID, endpoint, timestamp, and tier, then escalate to Platform Engineering for policy entitlement review.

## Related records

No specific records are attached to this policy. Use service catalog entries and active known issues for service-specific routing.

