---
doc_id: REL-PAYMENTS-2026-06
title: June 2026 Payments Reporting Pipeline Release Notes
doc_type: release_note
service_id: svc_payments_reporting
owner_group: Release Management
visibility: internal
status: published
created_at: "2026-06-15T17:30:00"
updated_at: "2026-06-16T09:30:00"
related_records:
  - CHG-2411
  - KI-221
source_facts:
  - CHG-2411
  - svc_payments_reporting
difficulty_tags:
  - change-context
  - azure-data-stack
---

# June 2026 Payments Reporting Pipeline Release Notes

## Release summary

June release updated Databricks runtime and Synapse/Fabric reporting refresh behavior for Payments Reporting Service. The release was tracked through CHG-2411 and owned by Data Applications.

June release updated Databricks runtime and Synapse/Fabric reporting refresh behavior.

Release was expected to improve reporting refresh reliability. Because the service supports payment operations dashboards and exports, Release Management classified this as important change context for Service Desk L1 and Data Applications.

## Services affected

Primary service:

- Payments Reporting Service, service ID svc_payments_reporting.

Dependencies in scope:

- Azure Synapse Analytics.
- Microsoft Fabric.
- Azure SQL Database.
- Azure Databricks.
- Internal API Gateway.

## Changes included

Included changes:

- Databricks runtime update.
- Synapse/Fabric reporting refresh pipeline update.
- Post-release validation of Payments Reporting Service dashboards and exports.

CHG-2411 planned start was 2026-06-15T21:00:00 and planned end was 2026-06-15T22:30:00. The change was marked completed and later linked to INC-1217.

## Expected behavior

Expected behavior after release:

- Payment dashboards should continue to refresh normally.
- Payment exports should match the expected reporting period.
- Reporting refresh reliability should improve.
- No user workflow change should be required.

If support receives stale dashboard or export mismatch reports after the release, compare the symptom timing against CHG-2411 and review KI-221.

## Post-release observations

Post-release reports showed that dashboard freshness could lag even after the Databricks transformation completed successfully. In INC-1217, Azure SQL Database staging tables contained current transaction records while the Synapse/Fabric reporting layer still showed the previous refresh watermark.

The incident was resolved by rerunning the reporting refresh and backfilling from the last successful payment partition.

## Known issues added after release

Known issue KI-221 was added after post-release dashboard freshness reports. The safe summary is:

"Reporting data is delayed, but source payment transactions are not lost."

Internal teams should use RUNBOOK-PAY-007 for the watermark, partition, refresh rerun, and backfill sequence.

## Related records

- CHG-2411: Update Databricks Runtime and Synapse/Fabric Refresh Pipeline for Payments Reporting Service.
- KI-221: Payments Dashboard Data Freshness Delay After Synapse/Fabric Refresh Failure.
