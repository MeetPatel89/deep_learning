---
doc_id: SVC-CAT-IDENTITY-001
title: Identity Gateway Service Catalog Entry
doc_type: service_catalog
service_id: svc_identity_gateway
owner_group: IAM Platform
visibility: internal
status: active
created_at: "2026-05-01T09:00:00"
updated_at: "2026-06-14T09:30:00"
related_records:
  - KI-104
  - RUNBOOK-SSO-003
source_facts:
  - svc_identity_gateway
difficulty_tags:
  - ownership-routing
  - dependency-awareness
---

# Identity Gateway Service Catalog Entry

## Service summary

Identity Gateway handles enterprise SSO access for internal applications. The service is used when employees authenticate into internal business applications, including Employee Portal. It is a Tier 1 internal service because a sign-in failure can block access to multiple downstream business workflows.

The service performs enterprise sign-in handoff, validates identity-provider responses, and routes authenticated access toward the internal application layer. Identity Gateway is not the owner of the applications behind the sign-in page, but it is the primary ownership point when the failure occurs before a user reaches an application session.

## Business purpose

Nautilus Financial Systems uses the Identity Gateway to provide consistent SSO behavior for internal users. The practical business purpose is to avoid separate sign-in handling for each internal application and to give support teams a single place to triage enterprise sign-in symptoms.

For retrieval and routing purposes, questions about "Employee Portal login failed," "invalid SAML response," or "some users can sign in and others cannot" should be treated as Identity Gateway candidates until evidence points to a downstream application issue.

## Owning team

IAM Platform owns Identity Gateway. Service Desk L1 performs initial intake, confirms scope, captures user-facing symptoms, and applies documented troubleshooting steps. Service Desk L1 should escalate unresolved SSO platform issues to IAM Platform.

IAM Platform is responsible for final remediation when the issue involves SSO metadata, identity maintenance, certificate validation, or repeated partial login failures after a documented workaround.

## Key dependencies

Dependencies include Okta, Employee Portal, and Internal API Gateway.

| Dependency | Support relevance |
| --- | --- |
| Okta | Identity provider used in the enterprise sign-in path. Recent identity maintenance can affect the sign-in exchange. |
| Employee Portal | Common user-facing application where SSO failures are noticed first. |
| Internal API Gateway | Internal routing dependency used after successful authentication for some application paths. |

## Supported users and systems

The primary supported users are employees accessing internal systems through enterprise SSO. The most common system named in support contacts is Employee Portal, but the same gateway path can affect other internal applications.

Service Desk L1 should capture whether the issue affects one user, a branch or team, or many users across locations. That distinction is important because a single-user issue may remain with standard access support, while a multi-user failure after identity maintenance should move quickly to IAM Platform.

## Common incident patterns

Common Identity Gateway incidents include:

- Users cannot log into Employee Portal.
- The sign-in flow returns an invalid SAML response message.
- The issue begins after identity maintenance or certificate rotation.
- Some users can log in while others cannot.
- Failures are inconsistent across sessions or user groups.

Known issue KI-104 covers the pattern where some Identity Gateway nodes may continue using stale IdP metadata after certificate rotation. RUNBOOK-SSO-003 contains the procedural steps for triage and cache refresh.

## Initial triage guidance

Service Desk L1 should first confirm scope and timing:

- Number of affected users.
- Application reached by the user, usually Employee Portal.
- Exact error text, especially invalid SAML response.
- Whether an identity-related change occurred in the last 24 hours.
- Whether any users in the same group can sign in successfully.

If the failure began shortly after identity maintenance, check KI-104 and RUNBOOK-SSO-003 before treating the case as a generic access request.

## Escalation guidance

Escalate to IAM Platform when:

- The issue affects multiple business users.
- Invalid SAML response errors persist after basic browser and session checks.
- A recent identity change is linked to the symptoms.
- The documented workaround in RUNBOOK-SSO-003 does not clear the issue.
- Certificate thumbprint validation or gateway metadata refresh is required.

Notify Release Management if the incident appears tied to a recently completed change such as CHG-2407.

## Related records

- KI-104: SSO metadata cache delay after certificate rotation.
- RUNBOOK-SSO-003: Identity Gateway SSO Login Failure Runbook.

