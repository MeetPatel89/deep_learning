import asyncio
import json
import sys

import anyio
import pytest
from data_mcp_core.stores import StoreConfig
from fs_mcp_server.config import FSConfig
from fs_mcp_server.server import TOOLSETS, FSService, create_server
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


@pytest.fixture
def service(tmp_path):
    return FSService(
        FSConfig(
            stores={"local": StoreConfig(root=str(tmp_path), allow_write=True, allow_delete=True)}
        )
    )


def test_discovery_content_pagination_and_sandbox(service, tmp_path):
    service.write_text("local", "a.txt", "first\nsecond\nthird\n")
    service.write_text("local", "nested/b.txt", "needle\n")
    assert service.list_stores()["stores"]["local"]["allow_write"]
    page = service.list_paths("local", recursive=True, limit=1)
    assert page["continuation"]
    second = service.list_paths("local", recursive=True, limit=1, continuation=page["continuation"])
    assert second["items"] != page["items"]
    assert service.get_path_info("local", "a.txt")["size"] == 19
    assert service.summarize_directory("local")["file_count"] == 2
    assert len(service.find_files("local", glob="*.txt")["items"]) == 2
    assert service.read_text("local", "a.txt", head=1)["text"] == "first\n"
    assert service.read_text("local", "a.txt", tail=1)["text"] == "third\n"
    assert service.read_text("local", "a.txt", line_start=1, line_end=2)["text"] == "second\n"
    assert service.read_text("local", "a.txt", byte_start=0, byte_end=5)["text"] == "first"
    assert service.read_text("local", "a.txt", max_chars=3)["truncated"]
    assert service.search_text("local", "needle")["matches"][0]["path"] == "nested/b.txt"
    with pytest.raises(PermissionError):
        service.read_text("local", "../outside")
    outside = tmp_path.parent / "outside.txt"
    outside.write_text("secret")
    (tmp_path / "link").symlink_to(outside)
    assert "link" not in [item["name"] for item in service.list_paths("local")["items"]]
    with pytest.raises(PermissionError):
        service.read_text("local", "link")


def test_dataset_queries_profiles_validation_and_conversion(service):
    rows = [
        {"id": 1, "v": "a", "amount": 1.0},
        {"id": 2, "v": None, "amount": 2.0},
        {"id": 2, "v": "b", "amount": 3.0},
    ]
    service.write_dataset("local", "data.parquet", rows)
    inspected = service.inspect_dataset("local", "data.parquet")
    assert inspected["row_count"] == 3
    assert service.detect_format("local", "data.parquet")["format"] == "parquet"
    assert service.preview_dataset(
        "local", "data.parquet", filter_expression="id=2", columns=["v"]
    )["rows"] == [{"v": None}, {"v": "b"}]
    assert (
        service.preview_dataset("local", "data.parquet", mode="tail", limit=1)["rows"][0]["amount"]
        == 3.0
    )
    assert (
        len(service.preview_dataset("local", "data.parquet", mode="random", limit=2)["rows"]) == 2
    )
    profile = service.profile_dataset("local", "data.parquet")["columns"]
    assert profile["v"]["null_count"] == 1
    assert profile["amount"]["q50"] == 2.0
    validation = service.validate_dataset(
        "local",
        "data.parquet",
        [
            {"type": "not_null", "column": "v"},
            {"type": "unique", "column": "id"},
            {"type": "range", "column": "amount", "min": 1, "max": 2},
            {"type": "allowed_values", "column": "v", "values": ["a", "b"]},
            {"type": "regex", "column": "v", "pattern": "^[ab]$"},
        ],
    )
    assert not validation["valid"]
    assert [rule["invalid_rows"] for rule in validation["rules"]] == [1, 2, 1, 1, 1]
    datasets = {"d": {"store": "local", "path": "data.parquet"}}
    result = service.query_datasets(
        datasets, "SELECT id, SUM(amount) AS total FROM d GROUP BY id ORDER BY id"
    )
    assert result["rows"] == [{"id": 1, "total": 1.0}, {"id": 2, "total": 5.0}]
    for query in [
        "SELECT * FROM read_csv('/etc/passwd')",
        "SELECT * FROM unknown",
        "DELETE FROM d",
    ]:
        with pytest.raises(PermissionError):
            service.query_datasets(datasets, query)
    service.query_datasets(
        datasets,
        "SELECT * FROM d",
        output_store="local",
        output_path="query.csv",
        output_format="csv",
    )
    service.convert_dataset("local", "data.parquet", "local", "converted.jsonl", "ndjson")
    assert service.inspect_dataset("local", "converted.jsonl")["row_count"] == 3


def test_file_operations_dry_run_and_transfer(service, tmp_path):
    service.write_text("local", "a.txt", "a")
    service.copy_path("local", "a.txt", "b.txt")
    service.move_path("local", "b.txt", "nested/c.txt")
    assert not (tmp_path / "b.txt").exists()
    assert service.delete_path("local", "a.txt")["dry_run"]
    assert (tmp_path / "a.txt").exists()
    service.delete_path("local", "a.txt", dry_run=False)
    assert not (tmp_path / "a.txt").exists()
    assert service.write_text("local", "dry.txt", "text", dry_run=True)["dry_run"]
    assert not (tmp_path / "dry.txt").exists()
    service.config.stores["destination"] = StoreConfig(
        root=str(tmp_path / "destination"), allow_write=True
    )
    service.transfer("local", "nested", "destination", "copy", recursive=True)
    assert (tmp_path / "destination" / "copy" / "c.txt").read_text() == "a"
    with pytest.raises(PermissionError):
        service.delete_path("local", "", recursive=True, dry_run=False)
    with pytest.raises(ValueError):
        service.copy_path("local", "nested", "nested/child", recursive=True)


GATED = [
    ("write_text", {"store": "local", "path": "x", "text": "x"}, "allow_write"),
    ("write_dataset", {"store": "local", "path": "x.csv", "rows": []}, "allow_write"),
    ("make_directory", {"store": "local", "path": "x"}, "allow_write"),
    ("copy_path", {"store": "local", "source_path": "x", "destination_path": "y"}, "allow_write"),
    ("move_path", {"store": "local", "source_path": "x", "destination_path": "y"}, "allow_write"),
    ("move_path", {"store": "local", "source_path": "x", "destination_path": "y"}, "allow_delete"),
    ("delete_path", {"store": "local", "path": "x"}, "allow_delete"),
    (
        "transfer",
        {
            "source_store": "local",
            "source_path": "x",
            "destination_store": "local",
            "destination_path": "y",
        },
        "allow_write",
    ),
    (
        "convert_dataset",
        {
            "store": "local",
            "path": "x",
            "output_store": "local",
            "output_path": "y",
            "output_format": "csv",
        },
        "allow_write",
    ),
    (
        "query_datasets",
        {
            "datasets": {"d": {"store": "local", "path": "x"}},
            "query": "SELECT * FROM d",
            "output_store": "local",
            "output_path": "y",
        },
        "allow_write",
    ),
    ("delta_write", {"store": "local", "path": "x", "rows": []}, "allow_write"),
    ("delta_optimize", {"store": "local", "path": "x"}, "allow_write"),
    ("delta_vacuum", {"store": "local", "path": "x"}, "allow_delete"),
    ("delta_restore", {"store": "local", "path": "x", "version": 0}, "allow_write"),
]


@pytest.mark.parametrize("name,arguments,flag", GATED)
def test_every_mutating_filesystem_tool_is_guarded(tmp_path, name, arguments, flag):
    flags = {"allow_write": True, "allow_delete": True, flag: False}
    service = FSService(FSConfig(stores={"local": StoreConfig(root=str(tmp_path), **flags)}))
    with pytest.raises(PermissionError, match=flag):
        getattr(service, name)(**arguments)
    assert not list(tmp_path.iterdir())


def test_delta_metadata_history_maintenance(service, tmp_path):
    service.delta_write("local", "table", [{"id": 1}], mode="overwrite")
    service.delta_write("local", "table", [{"id": 2}])
    described = service.delta_describe("local", "table")
    assert described["version"] == 1
    assert described["file_count"] == 2
    assert len(service.delta_history("local", "table")["history"]) == 2
    assert len(service.delta_list_files("local", "table")["items"]) == 2
    assert service.delta_optimize("local", "table", dry_run=True)["dry_run"]
    service.delta_restore("local", "table", version=0)
    assert service.inspect_dataset("local", "table")["row_count"] == 1
    assert service.delta_vacuum("local", "table")["dry_run"]
    with pytest.raises(ValueError):
        service.delta_vacuum("local", "table", retention_hours=1)


def test_toolsets_and_adls_registration(tmp_path):
    server = create_server(FSConfig(enabled_toolsets=["discovery"]))
    assert {tool.name for tool in asyncio.run(server.list_tools())} == set(TOOLSETS["discovery"])
    local = create_server(FSConfig(stores={"local": StoreConfig(root=str(tmp_path))}))
    assert not (set(TOOLSETS["adls"]) & {tool.name for tool in asyncio.run(local.list_tools())})
    cloud = create_server(
        FSConfig(
            stores={"lake": StoreConfig(protocol="abfss", account_name="lake", container="raw")}
        )
    )
    assert set(TOOLSETS["adls"]) <= {tool.name for tool in asyncio.run(cloud.list_tools())}


def test_filesystem_stdio_roundtrip(tmp_path):
    config = tmp_path / "fs.toml"
    config.write_text(f"[stores.local]\nroot={json.dumps(str(tmp_path))}\nallow_write=true\n")

    async def exercise():
        params = StdioServerParameters(
            command=sys.executable, args=["-m", "fs_mcp_server"], env={"FS_MCP_CONFIG": str(config)}
        )
        async with stdio_client(params) as (reader, writer):
            async with ClientSession(reader, writer) as session:
                await session.initialize()
                assert len((await session.list_tools()).tools) == 28
                written = await session.call_tool(
                    "write_dataset",
                    {"store": "local", "path": "stdio.parquet", "rows": [{"id": 1}]},
                )
                assert not written.isError
                inspected = await session.call_tool(
                    "inspect_dataset", {"store": "local", "path": "stdio.parquet"}
                )
                assert inspected.structuredContent["row_count"] == 1
                denied = await session.call_tool(
                    "delete_path", {"store": "local", "path": "stdio.parquet", "dry_run": False}
                )
                assert denied.isError

    anyio.run(exercise)
