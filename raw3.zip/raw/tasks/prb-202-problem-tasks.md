---
doc_id: TASK-PRB-202
title: Problem Tasks for PRB-202 Identity Gateway Metadata Cache Inconsistency
doc_type: problem_task
service_id: svc_identity_gateway
owner_group: IAM Platform
visibility: internal
status: in_progress
created_at: "2026-06-13T10:30:00"
updated_at: "2026-06-17T09:00:00"
related_records:
  - PRB-202
  - KI-104
  - RUNBOOK-SSO-003
source_facts:
  - KI-104
  - svc_identity_gateway
difficulty_tags:
  - root-cause
  - task-decomposition
servicenow:
  table: problem_task
  parent: PRB000202
  task_numbers:
    - PTASK0001001
    - PTASK0001002
    - PTASK0001003
  visibility: internal
  contains_customer_safe_wording: false
---

# Problem Tasks for PRB-202 Identity Gateway Metadata Cache Inconsistency

## Record details

| Field | Value |
| --- | --- |
| Table | problem_task |
| Parent | PRB000202 |
| Task numbers | PTASK0001001, PTASK0001002, PTASK0001003 |
| Visibility | internal |
| Contains customer-safe wording | false |

## Overview

Three problem tasks were opened under PRB000202 following the resolution of INC-1104. Two tasks are complete. The permanent-fix evaluation remains open, which is consistent with the PRB-202 known-error status.

## PTASK0001001 — Reproduce and confirm stale metadata root cause

| Field | Value |
| --- | --- |
| Number | PTASK0001001 |
| Short description | Reproduce and confirm stale metadata root cause |
| Assignment group | IAM Platform |
| State | Closed Complete |
| Opened at | 2026-06-13T10:30:00 |
| Closed at | 2026-06-14T12:00:00 |

IAM Platform reconstructed the INC-1104 failure path in a controlled review of the Identity Gateway metadata handling behavior after certificate rotation. The review confirmed the root cause: a subset of gateway nodes can continue evaluating sign-in responses against stale IdP metadata after a certificate rotation completes successfully.

The confirmed failure mode explains the partial impact observed in INC-1104, where the result of a sign-in attempt depended on which gateway node handled the request. The findings were recorded in PRB-202 as the basis for the known error.

## PTASK0001002 — Document known error KI-104 and update RUNBOOK-SSO-003

| Field | Value |
| --- | --- |
| Number | PTASK0001002 |
| Short description | Document known error KI-104 and update RUNBOOK-SSO-003 |
| Assignment group | IAM Platform |
| State | Closed Complete |
| Opened at | 2026-06-13T10:30:00 |
| Closed at | 2026-06-14T09:30:00 |

IAM Platform documented the known error as KI-104, including the symptom pattern, the internal root cause, the approved workaround, and the customer-safe summary for external communication. RUNBOOK-SSO-003 was updated to include the metadata cache refresh and certificate thumbprint validation steps as the approved recovery sequence.

The task closed after the known-issue record and runbook updates were published for Service Desk L1 and IAM Platform use.

## PTASK0001003 — Evaluate automated metadata cache refresh after certificate rotation

| Field | Value |
| --- | --- |
| Number | PTASK0001003 |
| Short description | Evaluate automated metadata cache refresh after certificate rotation |
| Assignment group | IAM Platform |
| State | Open / In Progress |
| Opened at | 2026-06-13T10:30:00 |
| Closed at | — |

IAM Platform is evaluating an automated metadata cache refresh triggered as part of certificate rotation, so that rotation changes cannot leave nodes on stale metadata. Options under review include a post-rotation refresh step added to the change implementation sequence and a platform-level cache invalidation on certificate trust updates.

This task remains open. Until a permanent fix is implemented and recorded, PRB-202 stays in known-error status and the KI-104 workaround remains the approved recovery path for matching incidents.

## Related records

- PRB-202: Identity Gateway Metadata Cache Inconsistency After IdP Certificate Rotation.
- KI-104: SSO Metadata Cache Delay After Certificate Rotation.
- RUNBOOK-SSO-003: Identity Gateway SSO Login Failure Runbook.
