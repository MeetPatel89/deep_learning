---
doc_id: PRB-202
title: Identity Gateway Metadata Cache Inconsistency After IdP Certificate Rotation
doc_type: problem_record
service_id: svc_identity_gateway
owner_group: IAM Platform
visibility: internal
status: known_error
created_at: "2026-06-13T10:00:00"
updated_at: "2026-06-14T12:00:00"
related_records:
  - KI-104
  - INC-1104
  - RUNBOOK-SSO-003
  - TASK-PRB-202
source_facts:
  - KI-104
  - svc_identity_gateway
difficulty_tags:
  - root-cause
  - internal-only-detail
servicenow:
  table: problem
  number: PRB000202
  state: Known Error
  known_error: true
  impact: 2
  urgency: 2
  priority: 3
  business_service: Employee Portal
  cmdb_ci: Identity Gateway
  assignment_group: IAM Platform
  opened_by_group: IAM Platform
  related_incident: INC001104
  related_change: CHG002407
  related_known_issue: KI00104
  visibility: internal
  contains_customer_safe_wording: false
---

# Identity Gateway Metadata Cache Inconsistency After IdP Certificate Rotation

## Record details

| Field | Value |
| --- | --- |
| Table | problem |
| Number | PRB000202 |
| State | Known Error |
| Known error | true |
| Impact | 2 |
| Urgency | 2 |
| Priority | 3 |
| Business service | Employee Portal |
| Configuration item | Identity Gateway |
| Assignment group | IAM Platform |
| Opened by group | IAM Platform |
| Related incident | INC001104 |
| Related change | CHG002407 |
| Related known issue | KI00104 |
| Visibility | internal |
| Contains customer-safe wording | false |

## Problem summary

PRB-202 tracks the known error behind partial Employee Portal login failures after identity certificate rotation. The problem is associated with Identity Gateway and is owned by IAM Platform.

Root cause is stale IdP metadata on some Identity Gateway nodes after certificate rotation. The issue can cause partial login failures where some users can complete SSO and others receive invalid SAML response errors.

## Related incidents

Primary related incident:

- INC-1104: Employee Portal Login Failures After Okta Certificate Rotation.

Related known issue:

- KI-104: SSO Metadata Cache Delay After Certificate Rotation.

INC-1104 began shortly after CHG-2407 completed and was resolved after the Identity Gateway metadata cache was refreshed and the active certificate thumbprint was verified.

## Root cause analysis

The service can enter an inconsistent state after certificate rotation if not all Identity Gateway nodes refresh IdP metadata promptly. A change can complete successfully from the implementation perspective while a subset of runtime nodes still evaluates sign-in responses against stale metadata.

The failure mode is user-visible as an invalid SAML response. It does not necessarily affect every user at once because the impacted path depends on which Identity Gateway node handles the request.

The root cause is internal to the Identity Gateway metadata handling path after certificate rotation. It is not an Employee Portal application defect and should not be routed as a portal feature issue unless portal behavior fails after authentication succeeds.

## Known error

Known error conditions:

- Recent identity-related change, especially certificate rotation.
- Invalid SAML response errors.
- Mixed login results across affected users.
- Successful sign-in for some users during the same incident window.

The known error is documented as KI-104. Use RUNBOOK-SSO-003 for operational handling.

## Workaround

Cache refresh is the approved workaround.

The operational workaround is:

1. Confirm the symptoms match KI-104.
2. Refresh the Identity Gateway metadata cache.
3. Verify the active IdP certificate thumbprint.
4. Ask Service Desk L1 to retest with affected users.
5. Continue IAM Platform investigation if failures continue after refresh.

## Permanent fix status

Permanent fix status is known error. IAM Platform owns any longer-term remediation to reduce metadata inconsistency after certificate rotation.

Until a permanent change is recorded, support should treat the cache refresh and certificate thumbprint validation as the approved recovery path for matching incidents.

## Communication guidance

Do not expose internal metadata-cache implementation details in customer-facing communication. For external or customer-safe updates, start from the KI-104 customer-safe summary:

"We are validating the enterprise sign-in configuration after scheduled identity maintenance."

Internal work notes may mention stale IdP metadata and cache refresh steps. Customer-facing notes should describe the sign-in configuration validation and avoid internal implementation detail.

## Related records

- KI-104: SSO Metadata Cache Delay After Certificate Rotation.
- INC-1104: Employee Portal Login Failures After Okta Certificate Rotation.
- RUNBOOK-SSO-003: Identity Gateway SSO Login Failure Runbook.
- TASK-PRB-202: Problem tasks opened under PRB-202.
