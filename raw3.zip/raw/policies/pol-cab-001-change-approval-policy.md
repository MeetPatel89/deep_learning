---
doc_id: POL-CAB-001
title: Change Approval and CAB Policy
doc_type: policy
service_id: null
owner_group: Release Management
visibility: internal
status: active
created_at: "2026-05-12T09:00:00"
updated_at: "2026-06-20T09:00:00"
related_records:
  - CHG-2407
  - CHG-2411
  - CHG-2420
  - POL-ESC-001
source_facts:
  - support_groups
difficulty_tags:
  - change-approval
  - cab-policy
  - change-context
servicenow:
  table: kb_knowledge
  number: KB0000904
  kb_category: Policy
  workflow_state: Published
  assignment_group: Release Management
  visibility: internal
  contains_customer_safe_wording: false
---

# Change Approval and CAB Policy

## Record details

| Field | Value |
| --- | --- |
| Table | kb_knowledge |
| Number | KB0000904 |
| KB category | Policy |
| Workflow state | Published |
| Assignment group | Release Management |
| Visibility | internal |
| Contains customer-safe wording | false |

## Purpose

POL-CAB-001 defines how changes are classified, approved, and reviewed at Nautilus Financial Systems. Release Management administers the Change Advisory Board (CAB) and this policy. The implementing technical group owns the change record and its change tasks.

## Change types

| Type | Definition | Approval path |
| --- | --- | --- |
| Standard | Pre-approved, low-risk, repeatable procedure with a documented template. | No CAB. Automatic approval against the standard template. |
| Normal | Planned change that is not pre-approved. All Tier 1 service changes are Normal at minimum. | CAB approval required for Medium and High risk. Low risk requires owning group manager approval only. |
| Emergency | Required to restore service or prevent imminent impact. | Emergency CAB (ECAB) with the owning group lead and Release Management; full CAB review follows after implementation. |

## Risk-based approval requirements

| Risk | Requirements |
| --- | --- |
| Low | Owning group manager approval. Implementation and validation plan on the change record. |
| Medium | CAB approval. Implementation, validation, and rollback plans required. Post-change monitoring window of 24 hours. |
| High | CAB approval plus explicit service owner group sign-off. A named backout decision point inside the window. Post-change monitoring window of 48 hours. |

The CAB meets Tuesday and Thursday. Normal changes must be submitted at least three business days before the planned window. Changes to Tier 1 services may not be scheduled during month-end financial close without a CAB-approved exception.

## Post-implementation review

A post-implementation review (PIR) is mandatory when an incident is opened within 24 hours of a completed change on the same service. The PIR is recorded as a change task on the originating change and must state what the validation plan covered, what it missed, and which known issue or problem record now tracks the gap.

Recorded examples:

- CHG002407 (Medium risk, CAB approved 2026-06-11): INC001104 opened 18 minutes after the window closed. PIR found validation did not cover per-node metadata refresh; gap tracked as KI00104 and PRB000202.
- CHG002411 (High risk, CAB approved 2026-06-14 with Data Applications service owner sign-off): INC001217 opened after the window. PIR found validation confirmed job success but not watermark advancement; gap tracked as KI00221 and PRB000304.
- CHG002420 (Medium risk, CAB approved 2026-06-17): INC001302 opened 20 minutes after the window closed. PIR found validation did not compare applied burst limits against tier entitlements; gap tracked as KI00307 and PRB000411.

## Incident linkage requirements

When an incident is suspected to be change-related, the owning group records the change number on the incident (related_change) and notifies Release Management per POL-ESC-001. Release Management tracks change-to-incident linkage for CAB trend review but does not take over remediation.

## Related records

- CHG-2407: Rotate Okta Signing Certificate for Identity Gateway.
- CHG-2411: Update Databricks Runtime and Synapse/Fabric Refresh Pipeline.
- CHG-2420: Deploy New API Gateway Rate-Limit Policy.
- POL-ESC-001: Incident Severity and Escalation Policy.
