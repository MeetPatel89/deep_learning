"""Shared workspace resolution and SDK result helpers."""

from threading import RLock
from typing import Any

from data_mcp_core.guards import require
from data_mcp_core.results import bounded_result, json_safe

from synapse_mcp_server.clients import ClientRegistry
from synapse_mcp_server.config import SynapseConfig


def field(data: dict, name: str, default=None):
    if name in data:
        return data[name]
    normalized = name.replace("_", "").lower()
    return next(
        (value for key, value in data.items() if key.replace("_", "").lower() == normalized),
        default,
    )


def wait_operation(value) -> Any:
    if hasattr(value, "result"):
        try:
            return value.result(timeout=60)
        except TimeoutError:
            return {"operation_status": value.status(), "pending": True}
    return value


class SynapseBase:
    def __init__(self, config: SynapseConfig, clients: ClientRegistry | None = None):
        self.config = config
        self.clients = clients or ClientRegistry(config)
        self._repositories = {}
        self._execution_store = None
        self._service_lock = RLock()

    def workspace(self, workspace: str, toolset: str):
        if workspace not in self.config.workspaces:
            raise ValueError(f"Unknown workspace: {workspace}")
        settings = self.config.workspaces[workspace]
        if toolset not in self.config.enabled_toolsets or toolset not in settings.enabled_toolsets:
            raise PermissionError(f"{toolset} tools are disabled for this workspace")
        return settings

    def artifact_client(self, workspace: str, toolset: str):
        self.live_workspace(workspace, toolset)
        return self.clients.get(workspace, "artifacts")

    def live_workspace(self, workspace: str, toolset: str):
        settings = self.workspace(workspace, toolset)
        require(settings, "allow_live_env")
        return settings

    def repository(self, workspace: str, backend=None):
        from synapse_mcp_server.repository import GitHubRepository, LocalRepository

        settings = self.config.workspaces[workspace]
        if not settings.repository:
            raise ValueError("Configure repository access; Git never falls back to live artifacts")
        backend = backend or settings.repository.default_backend
        if backend not in {"local", "github"}:
            raise ValueError("repository_backend must be local or github")
        key = (workspace, backend)
        with self._service_lock:
            if key not in self._repositories:
                cls = LocalRepository if backend == "local" else GitHubRepository
                self._repositories[key] = cls(settings)
            return self._repositories[key]

    @property
    def execution_store(self):
        from synapse_mcp_server.execution_store import ExecutionStore

        with self._service_lock:
            if self._execution_store is None:
                self._execution_store = ExecutionStore(self.config.execution_store)
            return self._execution_store

    def close(self):
        self.clients.close()
        for repository in self._repositories.values():
            repository.close()
        if self._execution_store:
            self._execution_store.close()

    def list_workspaces(self) -> dict[str, Any]:
        """List configured workspace aliases, endpoints and operation permissions."""
        return bounded_result(
            {
                "workspaces": {
                    name: {**value.model_dump(exclude={"auth"}), "endpoint": value.endpoint}
                    for name, value in self.config.workspaces.items()
                }
            }
        )

    def get_workspace_info(self, workspace: str) -> dict[str, Any]:
        """Get ARM workspace state, managed endpoints and git configuration."""
        settings = self.live_workspace(workspace, "workspace")
        return bounded_result(
            self.clients.get(workspace, "arm").workspaces.get(
                settings.resource_group, settings.name
            )
        )

    def list_sql_pools(self, workspace: str) -> dict[str, Any]:
        """List dedicated SQL pools and include the serverless endpoint."""
        settings = self.live_workspace(workspace, "workspace")
        items = list(
            self.clients.get(workspace, "arm").sql_pools.list_by_workspace(
                settings.resource_group, settings.name
            )
        )
        return bounded_result(
            {
                "pools": items,
                "serverless": {
                    "server": f"{settings.name}-ondemand.sql.azuresynapse.net",
                    "database": settings.serverless_database,
                },
            }
        )

    def list_spark_pools(self, workspace: str) -> dict[str, Any]:
        """List Spark pool sizing and state from ARM."""
        settings = self.live_workspace(workspace, "workspace")
        return bounded_result(
            {
                "pools": list(
                    self.clients.get(workspace, "arm").big_data_pools.list_by_workspace(
                        settings.resource_group, settings.name
                    )
                )
            }
        )

    def list_integration_runtimes(self, workspace: str) -> dict[str, Any]:
        """List integration runtime definitions and their current status."""
        settings = self.live_workspace(workspace, "workspace")
        client = self.clients.get(workspace, "arm")
        items = []
        for runtime in client.integration_runtimes.list_by_workspace(
            settings.resource_group, settings.name
        ):
            data = json_safe(runtime)
            name = field(data, "name")
            data["status"] = json_safe(
                client.integration_runtime_status.get(settings.resource_group, settings.name, name)
            )
            items.append(data)
        return bounded_result({"runtimes": items})

    def list_role_assignments(
        self,
        workspace: str,
        principal_id: str | None = None,
        scope: str | None = None,
        continuation: str | None = None,
    ) -> dict[str, Any]:
        """List Synapse access-control role assignments."""
        self.live_workspace(workspace, "workspace")
        assignments, next_page = self.clients.get(
            workspace, "accesscontrol"
        ).role_assignments.list_role_assignments(
            principal_id=principal_id,
            scope=scope,
            continuation_token_parameter=continuation,
            cls=lambda response, body, headers: (body, headers.get("x-ms-continuation")),
        )
        return bounded_result(
            {"assignments": field(json_safe(assignments), "value", []), "continuation": next_page}
        )
