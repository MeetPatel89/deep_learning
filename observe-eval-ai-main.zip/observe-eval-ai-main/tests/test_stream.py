"""Verify stream lifetime, protocol forwarding, failures, and consumer isolation."""

from asyncio import CancelledError, TaskGroup, sleep
from collections.abc import AsyncGenerator, AsyncIterator, Generator, Iterator
from contextlib import aclosing, closing
from datetime import datetime
from inspect import signature
from typing import assert_type

from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.trace import StatusCode, get_current_span
from pytest import mark, raises

from observability_ai import Telemetry, TraceAttributes, current_observation_id


def test_stream_is_lazy_and_scoped_to_producer_execution(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """The first iteration chooses the parent; yields preserve consumer context."""
    telemetry, exporter = otel
    observed_ids: list[str | None] = []

    def source() -> Iterator[object]:
        observed_ids.append(current_observation_id())
        with telemetry.tool("producer child"):
            yield item
            # An observation that spans a yield is restored on the next step.
            assert get_current_span().is_recording()
            with telemetry.chain("nested after yield"):
                pass
        observed_ids.append(current_observation_id())
        yield item

    item = object()
    stream = telemetry.stream("stream", source())
    assert not observed_ids and not exporter.get_finished_spans()
    with telemetry.propagate(TraceAttributes(session_id="iteration")):
        with telemetry.agent("consumer") as parent:
            assert next(stream) is item
            assert get_current_span() is parent.span
            assert not exporter.get_finished_spans()
            with telemetry.tool("consumer child"):
                pass
            assert next(stream) is item
            assert get_current_span() is parent.span
            with raises(StopIteration):
                next(stream)
    spans = {span.name: span for span in exporter.get_finished_spans()}
    stream_span = spans["stream"]
    assert spans["producer child"].parent == stream_span.context
    assert spans["nested after yield"].parent == spans["producer child"].context
    assert spans["consumer child"].parent == spans["consumer"].context
    assert stream_span.parent == spans["consumer"].context
    assert observed_ids[0] == observed_ids[1]
    assert stream_span.attributes is not None
    assert stream_span.attributes["langfuse.session.id"] == "iteration"
    assert (
        stream_span.attributes["langfuse.observation.metadata.stream_item_count"] == 2
    )
    timestamp = stream_span.attributes["langfuse.observation.completion_start_time"]
    assert isinstance(timestamp, str)
    assert stream_span.start_time is not None and stream_span.end_time is not None
    assert stream_span.start_time / 1e9 <= datetime.fromisoformat(timestamp).timestamp()
    assert datetime.fromisoformat(timestamp).timestamp() <= stream_span.end_time / 1e9
    assert "langfuse.observation.output" not in stream_span.attributes


def test_stream_forwards_send_throw_and_generator_return(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Decorated generators retain bidirectional behavior, signatures, and results."""
    telemetry, exporter = otel

    def source(value: int) -> Generator[int, int, str]:
        """Receive a value and handle an injected error."""
        received = yield value
        try:
            yield received
        except ValueError:
            yield 3
        return "finished"

    decorated = telemetry.traced(type="generation")(source)
    assert signature(decorated) == signature(source)
    assert decorated.__doc__ == source.__doc__
    stream = assert_type(decorated(1), Generator[int, int, str])
    assert next(stream) == 1
    assert stream.send(2) == 2
    assert stream.throw(ValueError("handled")) == 3
    with raises(StopIteration) as done:
        next(stream)
    assert done.value.value == "finished"
    (span,) = exporter.get_finished_spans()
    assert not span.events
    assert span.attributes is not None
    assert span.attributes["langfuse.observation.metadata.stream_item_count"] == 3


@mark.parametrize("items", [[], [1, 2]])
def test_plain_iterables_and_empty_streams(
    otel: tuple[Telemetry, InMemorySpanExporter],
    items: list[int],
) -> None:
    """Even empty streams end with count zero, without inventing first-chunk time."""
    telemetry, exporter = otel
    assert list(telemetry.stream("list", items, type="retriever")) == items
    (span,) = exporter.get_finished_spans()
    assert span.attributes is not None
    assert span.attributes["langfuse.observation.type"] == "retriever"
    assert span.attributes["langfuse.observation.metadata.stream_item_count"] == len(
        items
    )
    assert ("langfuse.observation.completion_start_time" in span.attributes) is bool(
        items
    )


def test_early_close_runs_cleanup_once_without_error(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Close ends partial streams and runs producer finalizers in context."""
    telemetry, exporter = otel
    cleaned: list[str | None] = []
    previous = get_current_span()

    @telemetry.traced("partial")
    def source() -> Iterator[int]:
        try:
            yield 1
            yield 2
        finally:
            cleaned.append(current_observation_id())

    with closing(telemetry.stream("outer", source())) as stream:
        assert next(stream) == 1
    stream.close()
    assert get_current_span() is previous
    partial, outer = exporter.get_finished_spans()
    assert partial.context is not None
    assert cleaned == [f"{partial.context.span_id:016x}"]
    assert partial.parent == outer.context
    for span in (partial, outer):
        assert not span.events
        assert span.status.status_code is StatusCode.UNSET
        assert span.attributes is not None
        assert span.attributes["langfuse.observation.metadata.stream_item_count"] == 1


def test_stream_failure_keeps_original_exception_and_ends_span(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Producer errors are recorded once with partial count and propagate unchanged."""
    telemetry, exporter = otel
    error = RuntimeError("stream failed")
    previous = get_current_span()

    def source() -> Iterator[int]:
        yield 1
        raise error

    with raises(RuntimeError) as caught:
        list(telemetry.stream("failure", source()))
    assert caught.value is error
    assert get_current_span() is previous
    (span,) = exporter.get_finished_spans()
    assert span.status.status_code is StatusCode.ERROR
    assert [event.name for event in span.events] == ["exception"]
    assert span.attributes is not None
    assert span.attributes["langfuse.observation.metadata.stream_item_count"] == 1


async def test_async_stream_forwards_asend_athrow_and_aclose(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Async generator protocol calls and cleanup run with producer context."""
    telemetry, exporter = otel
    cleaned: list[str | None] = []
    previous = get_current_span()

    @telemetry.traced("async generator", type="generation")
    async def source() -> AsyncGenerator[int, int]:
        try:
            received = yield 1
            try:
                await sleep(0)
                yield received
            except ValueError:
                yield 3
        finally:
            cleaned.append(current_observation_id())

    async with aclosing(source()) as stream:
        assert await anext(stream) == 1
        assert get_current_span() is previous
        assert await stream.asend(2) == 2
        assert await stream.athrow(ValueError("handled")) == 3
        assert not exporter.get_finished_spans()
    await stream.aclose()
    assert get_current_span() is previous
    (span,) = exporter.get_finished_spans()
    assert span.context is not None
    assert cleaned == [f"{span.context.span_id:016x}"]
    assert not span.events
    assert span.attributes is not None
    assert span.attributes["langfuse.observation.metadata.stream_item_count"] == 3


async def test_async_cancellation_preserves_error_and_closes_stream(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Cancellation while awaiting a chunk releases the span and producer resources."""
    telemetry, exporter = otel
    error = CancelledError("cancelled")
    previous = get_current_span()
    cleaned: list[bool] = []

    async def source() -> AsyncIterator[int]:
        try:
            yield 1
            await sleep(0)
            raise error
        finally:
            cleaned.append(get_current_span().is_recording())

    with raises(CancelledError) as caught:
        async for _ in telemetry.stream("cancelled", source()):
            assert get_current_span() is previous
    assert caught.value is error
    assert cleaned == [True]
    assert get_current_span() is previous
    (span,) = exporter.get_finished_spans()
    assert span.end_time is not None
    assert span.status.status_code is StatusCode.ERROR


async def test_concurrent_async_streams_keep_distinct_context(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Each producer inherits its own request parent and propagated dimensions."""
    telemetry, exporter = otel

    async def source() -> AsyncIterator[int]:
        active = get_current_span()
        for item in range(2):
            await sleep(0)
            assert get_current_span() is active
            yield item

    async def consume(name: str) -> None:
        with telemetry.propagate(TraceAttributes(session_id=name)):
            with telemetry.agent(name) as parent:
                async for _ in telemetry.stream(f"{name}/stream", source()):
                    assert get_current_span() is parent.span

    async with TaskGroup() as group:
        group.create_task(consume("one"))
        group.create_task(consume("two"))
    spans = {span.name: span for span in exporter.get_finished_spans()}
    for name in ("one", "two"):
        span = spans[f"{name}/stream"]
        assert span.parent == spans[name].context
        assert span.attributes is not None
        assert span.attributes["langfuse.session.id"] == name


async def test_async_empty_stream_has_no_first_chunk_time(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """An async source that yields nothing still closes with zero items."""
    telemetry, exporter = otel

    async def source() -> AsyncIterator[int]:
        if False:
            yield 1

    assert [item async for item in telemetry.stream("empty", source())] == []
    (span,) = exporter.get_finished_spans()
    assert span.attributes == {
        "langfuse.observation.type": "generation",
        "langfuse.observation.metadata.stream_item_count": 0,
    }


@mark.parametrize("asynchronous", [False, True])
async def test_producer_propagation_does_not_escape_across_yields(
    otel: tuple[Telemetry, InMemorySpanExporter],
    asynchronous: bool,
) -> None:
    """Producer propagation survives resumption without changing consumer dimensions."""
    telemetry, exporter = otel

    def source() -> Iterator[int]:
        with telemetry.propagate(TraceAttributes(user_id="producer")):
            yield 1
            telemetry.event("producer event")

    async def async_source() -> AsyncIterator[int]:
        with telemetry.propagate(TraceAttributes(user_id="producer")):
            yield 1
            await sleep(0)
            telemetry.event("producer event")

    with telemetry.propagate(TraceAttributes(user_id="consumer")):
        if asynchronous:
            async for _ in telemetry.stream("stream", async_source()):
                telemetry.event("consumer event")
        else:
            for _ in telemetry.stream("stream", source()):
                telemetry.event("consumer event")
    spans = {span.name: span for span in exporter.get_finished_spans()}
    for name, user in (("consumer event", "consumer"), ("producer event", "producer")):
        attributes = spans[name].attributes
        assert attributes is not None
        assert attributes["langfuse.user.id"] == user
