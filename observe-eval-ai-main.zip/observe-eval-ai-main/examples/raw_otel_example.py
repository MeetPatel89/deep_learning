"""Trace concurrent child operations to Langfuse without a model or SDK extra."""

from asyncio import TaskGroup, run, sleep
from pathlib import Path

from dotenv import load_dotenv

from observability_ai import LangfuseSettings, Telemetry, TraceAttributes, __version__


async def _child(telemetry: Telemetry, trace: TraceAttributes, index: int) -> None:
    """Keep a child current across an await to demonstrate task-local context."""
    with telemetry.observe(f"child-{index}", type="tool", attributes=trace) as span:
        await sleep(0)
        span.set_attribute("example.child.index", index)
        tracer = telemetry.tracer("observability_ai.examples.raw_otel")
        with tracer.start_as_current_span(
            f"raw-step-{index}", attributes=trace.as_otel_attributes()
        ):
            await sleep(0)


async def main() -> None:
    """Send a parent with concurrent children and print its trace identifier."""
    load_dotenv(Path(__file__).resolve().parents[1] / "observability" / ".env")
    trace = TraceAttributes(
        session_id="observability-ai-phase-1",
        user_id="example-user",
        tags=("observability-ai", "raw-otel"),
        metadata={"approach": "raw-otel", "phase": "1"},
    )
    with Telemetry(
        LangfuseSettings.from_env(),
        service_name="observability-ai-raw-otel-example",
        service_version=__version__,
    ) as telemetry:
        with telemetry.observe("parent", attributes=trace) as parent:
            trace_id = parent.trace_id
            async with TaskGroup() as tasks:
                for index in range(2):
                    tasks.create_task(_child(telemetry, trace, index))
        if not telemetry.force_flush():
            raise RuntimeError("Timed out waiting for the telemetry queue to flush")

    print(f"trace {trace_id}; inspect 'parent' in Langfuse")


if __name__ == "__main__":
    run(main())
