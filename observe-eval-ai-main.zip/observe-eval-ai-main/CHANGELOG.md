# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.7.0] - 2026-09-25

### Added

- Add the installed `observability-ai` CLI with `provision`, `verify`, `apps list`,
  and `where` commands for apps sharing a local Langfuse Compose stack.
- Provision dedicated organizations, projects, generated API key pairs, and
  optional owner users through Langfuse headless initialization by recreating
  only the web service. Verify health and project identity before saving app
  credentials, with confirmation, unattended, and redacted dry-run modes.
- Add frozen, validated provisioning values, all ten startup environment
  variables, literal single-line dotenv parsing and atomic updates, and a public
  app registry that stores neither secret keys nor passwords.
- Support idempotent key reuse, explicit rotation, stack discovery from app
  configuration, and a local lock against concurrent provisioning.
- Pass `LANGFUSE_INIT_PROJECT_RETENTION` to the web container and ignore the
  local provisioning registry and lock directory.
- Document shared-stack provisioning, restart impact, key and password handling,
  reset recovery, and the limits of free headless initialization.

## [0.6.0] - 2026-09-21

### Added

- Add task-local `Telemetry.propagate` scopes and recording-only current trace
  and observation IDs without new dependencies.
- Add immutable `Observation` and `Generation` handles with gated payload
  updates, metadata, levels, model parameters, usage, prompt links, and costs.
- Add generation, retriever, embedding, guardrail, evaluator, and zero-duration
  event helpers, tool invocation attributes, and pure GenAI identity/cost helpers.
- Trace sync and async streams through exhaustion, errors, cancellation, and
  explicit close, preserving generator protocols and isolating producer context.
  Record first-chunk time and item counts without capturing chunks.
- Add redaction before serialization and optional character limits to the frozen
  content capture policy.
- Add the SDK-free `evaluation` package with immutable `EvaluationResult` values,
  a sync/async `Evaluator` protocol, six deterministic checks, and document-ID
  retrieval metrics preserving original ranks and duplicate-document semantics.
- Add `JudgeRubric` and a lazy, optional `ModelRuntimeJudge` with strict JSON
  responses, numeric/category validation, and capture-gated evaluator tracing.
- Add sampled `LiveEvaluation` with injected sinks, sync/async evaluator support,
  explicit or current-span score targets, and deterministic sampling injection.
- Cover evaluation with offline tests and installed base-distribution checks.
- Extend `Scorer` with current-trace targeting, core evaluation results, validated
  multi-score delivery, binary user feedback, and a `LiveEvaluation` sink.
- Add dataset creation, timestamp-versioned fetching, and item uploads through
  `DatasetRepository`, immutable local records, and strict UTF-8 JSONL loading.
- Add `ExperimentRunner` adapters for sync/async item and run evaluators, frozen
  report summaries, and regression gates that reject failed tasks/evaluators,
  empty runs, missing metrics, and below-threshold scores.
- Add historical trace/observation batch evaluation with SDK-owned retries,
  concurrency, resume state, and result statistics.
- Add a JSONL experiment CLI and bundled normalization dataset with deterministic
  checks, nonzero regression exits, and opt-in paid model-runtime judging.
- Cover SDK workflows and examples offline, and expand wheel/sdist checks for
  evaluation exports, SDK module inclusion, live target IDs, and partial async
  stream cleanup.

### Changed

- **Breaking:** `Telemetry.observe` and typed context helpers yield observation
  handles instead of raw OTel spans. Access raw OTel methods through `.span`.
- `Telemetry.traced` now supports generator and async-generator callables.
- Share score validation and `ScoreDataType` between the evaluation core and the
  existing Langfuse `Scorer`, preserving the SDK-facing API and behavior.
- Update the agent example to demonstrate propagated dimensions, explicit
  generation handles, response streaming, and online scores on an ended trace.
- Document migration from raw spans to handles, SDK capture boundaries, judge
  data handling, experiment failure semantics, and the complete evaluation APIs.

### Fixed

- Bypass uv's cache for artifact smoke checks so rebuilds of the same version
  validate the current wheel and source distribution.
- Correct the checkout path in the README's downstream uv source configuration.

## [0.5.0] - 2026-09-13

### Added

- Rename the distribution to `observe-eval-ai` to reflect its tracing and
  evaluation scope while retaining the `observability_ai` import namespace for
  existing applications.
- Add `Telemetry.traced` for sync and async functions, methods, and callable
  instances, preserving signatures, results, exceptions, and OTel task context.
- Add `agent`, `tool`, and `chain` observation helpers and a frozen
  `ContentCapturePolicy` with environment defaults and explicit boolean overrides.
  Gate explicit observation input/output and computed-output attributes with
  JSON serialization that skips unsupported values without interrupting work.
- Add a deterministic agent example combining concurrent tools, native
  model-runtime generations, and a Langfuse SDK score on the root agent.
- Add tests for decorator lifetimes, cancellation, concurrent context and capture
  isolation, serialization failures, shutdown ownership, and the complete agent
  flow; extend installed artifact checks and public API documentation.

### Fixed

- Guard factory-attached span processors at start, pre-end, end, flush, and
  shutdown, logging failures through OpenTelemetry without masking application
  errors. Flush reports failure on exceptions or after shutdown.
- Make processor shutdown idempotent, including concurrent calls and failures,
  for both the telemetry facade and direct provider construction.

## [0.4.0] - 2026-09-13

### Added

- Add the optional `langfuse>=4.7,<5` SDK extra with an import guard and an
  explicit client factory using validated settings and a local, parent-based
  OTel provider. Support provider and span-exporter injection for application
  ownership and offline observation tests.
- Add `Scorer` for validated numeric, categorical, boolean, and text scores,
  with explicit trace/observation targets or native current-observation context.
- Add `PromptRepository` for label/version selection of native text and chat
  prompts, preserving SDK compilation, caching, and generation attribution.
- Re-export native attribute propagation and the observation context method
  with an explicit client argument.
- Port the concurrent model-runtime SDK example with deterministic defaults,
  optional live providers and managed prompts, opt-in message capture, exclusive
  token usage, and a parent completion score.
- Add offline SDK and example tests, missing-extra distribution checks, and
  documentation comparing core OTel instrumentation with SDK features.

## [0.3.0] - 2026-09-13

### Added

- Add optional `model-runtime` and `vectorstore` extras and lazy observer factories
  that reuse each library's instrumentation with the application's `Telemetry`.
  Model calls are Langfuse generations; retrieval roots are retriever observations.
- Map immutable trace dimensions, preserve the native model content-capture
  setting, and provide actionable install hints without importing optional
  libraries until a factory is called.
- Add pure GenAI model and inclusive token-usage attribute helpers plus exclusive
  Langfuse usage buckets that prevent counting cached input tokens twice.
- Add offline adapter tests for completions, streams, retries, errors, task
  context, real SQLite retrieval, and optional imports; expand distribution smoke
  checks to exercise helpers and base installation without extras.
- Document both integrations, root-only retrieval dimensions, and dependency
  source configuration. Pin vectorstore-ai to `v0.1.0` and model-runtime to
  published commit `1d050b4902421de28f57b24777f056ea1b19a75d`: its latest tag,
  `v0.2.1`, predates the required OTel observer and extra.

## [0.2.0] - 2026-09-13

### Added

- Add validated, frozen `LangfuseSettings` with process-environment parsing,
  credential-safe representation, and explicit deployment and sampling settings.
- Port immutable `TraceAttributes` from model-runtime and expose all ten
  `ObservationType` values.
- Add authenticated Langfuse v4 OTLP/HTTP export and an application-owned tracer
  provider with service resources, deployment dimensions, parent-based sampling,
  and injectable span processors.
- Add the `Telemetry` facade for observations, named raw OTel tracers, flushing,
  shutdown, context-manager ownership, and optional global provider registration.
- Add a concurrent raw OTel example, Quickstart and API documentation, offline
  core tests, and installed wheel/sdist checks that exercise parent/child tracing.

## [0.1.0] - 2026-09-13

### Added

- Scaffold the Python 3.14 `observability-ai` distribution with a `src/` layout,
  the public `observability_ai.__version__`, and OpenTelemetry SDK and OTLP/HTTP
  exporter dependencies.
- Add uv dependency locking, Ruff formatting and linting, strict mypy, ty, pytest,
  editor settings, and shared Cursor and Codex repository guidance.
- Add CI quality checks, isolated wheel and source-distribution smoke tests, and
  version-validated tag artifacts with checksums.
- Move the local Langfuse v4 Docker Compose stack, environment template, standalone
  OTLP ingestion smoke test, and backend guide from `model-runtime` into this
  repository.
