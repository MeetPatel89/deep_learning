"""Independently installable filesystem stdio MCP server."""

from functools import wraps

from data_mcp_core.results import bounded_result, redact
from mcp.server.fastmcp import FastMCP

from fs_mcp_server.adls import ADLSTools
from fs_mcp_server.config import FSConfig, get_config
from fs_mcp_server.delta import DeltaTools
from fs_mcp_server.service import FileService

TOOLSETS = {
    "discovery": [
        "list_stores",
        "list_paths",
        "get_path_info",
        "find_files",
        "summarize_directory",
    ],
    "content": ["read_text", "search_text", "detect_format"],
    "datasets": [
        "inspect_dataset",
        "preview_dataset",
        "profile_dataset",
        "query_datasets",
        "validate_dataset",
        "convert_dataset",
    ],
    "delta": [
        "delta_describe",
        "delta_history",
        "delta_list_files",
        "delta_write",
        "delta_optimize",
        "delta_vacuum",
        "delta_restore",
    ],
    "files": [
        "write_text",
        "write_dataset",
        "make_directory",
        "copy_path",
        "move_path",
        "delete_path",
        "transfer",
    ],
    "adls": [
        "get_acl",
        "set_acl",
        "get_properties",
        "set_metadata",
        "list_deleted_paths",
        "undelete_path",
        "generate_sas",
    ],
}


class FSService(DeltaTools, ADLSTools, FileService):
    pass


def _safe_tool(method):
    @wraps(method)
    def call(*args, **kwargs):
        try:
            result = method(*args, **kwargs)
            return result if method.__name__ == "generate_sas" else bounded_result(result)
        except Exception as error:
            raise RuntimeError(redact(str(error))) from None

    return call


def create_server(config: FSConfig | None = None) -> FastMCP:
    config = config or get_config()
    service = FSService(config)
    server = FastMCP("Data Filesystem")
    for toolset in config.enabled_toolsets:
        if toolset == "adls" and not any(
            store.protocol == "abfss" for store in config.stores.values()
        ):
            continue
        for name in TOOLSETS[toolset]:
            server.add_tool(_safe_tool(getattr(service, name)), name=name)
    return server


mcp = create_server()


def main():
    mcp.run(transport="stdio")
