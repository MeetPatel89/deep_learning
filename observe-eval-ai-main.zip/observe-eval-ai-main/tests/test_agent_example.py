"""Verify propagated agent generations, response streaming, and ended-trace scores."""

from asyncio import CancelledError
from collections.abc import AsyncIterator
from dataclasses import replace
from functools import partial
from importlib.util import module_from_spec, spec_from_file_location
from json import loads
from pathlib import Path
from types import ModuleType
from unittest.mock import Mock

from pytest import MonkeyPatch, fixture, importorskip, mark, raises

importorskip("langfuse", reason="requires observe-eval-ai[langfuse]")
importorskip("model_runtime", reason="requires observe-eval-ai[model-runtime]")

from langfuse import Langfuse  # noqa: E402
from model_runtime import (  # noqa: E402
    ModelRouter,
    ModelRuntime,
    ProviderUnavailableError,
    RetryPolicy,
)
from opentelemetry.sdk.trace.export import SimpleSpanProcessor  # noqa: E402
from opentelemetry.sdk.trace.export.in_memory_span_exporter import (  # noqa: E402
    InMemorySpanExporter,
)
from opentelemetry.trace import StatusCode, get_current_span  # noqa: E402

from observability_ai import (  # noqa: E402
    LangfuseSettings,
    Telemetry,
    TraceAttributes,
)
from observability_ai.langfuse import Scorer  # noqa: E402


@fixture
def example() -> ModuleType:
    """Import the example without reading dotenv or constructing telemetry."""
    path = Path(__file__).resolve().parents[1] / "examples" / "agent_example.py"
    spec = spec_from_file_location("agent_example", path)
    assert spec is not None and spec.loader is not None
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@mark.parametrize(
    "environment,flag,captured",
    [
        (None, None, False),
        ("TrUe", None, True),
        ("true", "--no-capture-content", False),
        ("false", "--capture-content", True),
    ],
)
async def test_main_emits_one_nested_trace_and_scores_agent(
    sdk: tuple[Langfuse, InMemorySpanExporter],
    example: ModuleType,
    monkeypatch: MonkeyPatch,
    environment: str | None,
    flag: str | None,
    captured: bool,
) -> None:
    """The CLI propagates dimensions, gates payloads, and scores the ended trace."""
    client, sdk_exporter = sdk
    exporter = InMemorySpanExporter()
    scoring_contexts: list[bool] = []
    create_score = Mock(
        side_effect=lambda **kwargs: scoring_contexts.append(
            get_current_span().is_recording()
        )
    )
    shutdown = Mock(wraps=client.shutdown)
    monkeypatch.setattr(client, "create_score", create_score)
    monkeypatch.setattr(client, "shutdown", shutdown)
    monkeypatch.setattr(example, "build_langfuse_client", lambda settings: client)
    monkeypatch.setattr(
        example,
        "Telemetry",
        partial(Telemetry, span_processor=SimpleSpanProcessor(exporter)),
    )
    monkeypatch.setattr(example, "load_dotenv", Mock())
    monkeypatch.setenv("LANGFUSE_PUBLIC_KEY", "pk-example")
    monkeypatch.setenv("LANGFUSE_SECRET_KEY", "sk-example")
    if environment is not None:
        monkeypatch.setenv(
            "OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT", environment
        )
    monkeypatch.setattr("sys.argv", ["agent_example.py"] + ([flag] if flag else []))
    previous = get_current_span()
    await example.main()
    assert get_current_span() is previous
    shutdown.assert_called_once_with()
    spans = exporter.get_finished_spans()
    assert len(spans) == 7
    assert not sdk_exporter.get_finished_spans()
    root = next(span for span in spans if span.name == "example agent")
    chain = next(span for span in spans if span.name == "research")
    stream = next(span for span in spans if span.name == "answer stream")
    tools = [span for span in spans if span.name in {"definition", "example"}]
    generations = [span for span in spans if span.name == "chat demo-model"]
    assert root.context is not None and root.parent is None
    assert chain.parent == root.context
    assert stream.parent == root.context
    assert stream.attributes is not None
    count = stream.attributes["langfuse.observation.metadata.stream_item_count"]
    assert isinstance(count, int) and count > 0
    assert "langfuse.observation.completion_start_time" in stream.attributes
    assert len(tools) == len(generations) == 2
    for tool in tools:
        assert tool.parent == chain.context
        assert len([span for span in generations if span.parent == tool.context]) == 1
    for span in spans:
        assert span.context is not None
        assert span.context.trace_id == root.context.trace_id
        assert span.attributes is not None
        assert span.attributes["langfuse.session.id"] == "observability-ai-phase-4"
        assert span.attributes["langfuse.user.id"] == "example-user"
        assert span.attributes["langfuse.trace.tags"] == ("observability-ai", "agent")
        assert span.attributes["langfuse.trace.metadata.phase"] == "4"
        expected_type = (
            "agent"
            if span is root
            else "chain"
            if span in (chain, stream)
            else "generation"
            if span in generations
            else "tool"
        )
        assert span.attributes["langfuse.observation.type"] == expected_type
        if span in generations:
            assert span.attributes["gen_ai.usage.input_tokens"] == 7
            assert span.attributes["gen_ai.usage.output_tokens"] == 3
            assert span.attributes["gen_ai.usage.cache_read.input_tokens"] == 2
        if span in tools:
            assert span.attributes["gen_ai.tool.call.id"] == f"call-{span.name}"
        input_key = "langfuse.observation.input"
        output_key = "langfuse.observation.output"
        has_payload = captured and span not in (chain, stream)
        assert (input_key in span.attributes) is has_payload
        assert (output_key in span.attributes) is has_payload
        if has_payload:
            payload = span.attributes[input_key]
            assert isinstance(payload, str)
            assert "vector space" in str(loads(payload))
    assert create_score.call_count == 2
    assert scoring_contexts == [False, False]
    assert [call.kwargs["name"] for call in create_score.call_args_list] == [
        "mentions_topic",
        "length_within",
    ]
    for call in create_score.call_args_list:
        score = call.kwargs
        assert score["trace_id"] == f"{root.context.trace_id:032x}"
        assert score["observation_id"] is None
        assert score["value"] == 1.0 and score["data_type"] == "BOOLEAN"


async def test_model_failure_preserves_error_context_without_success_score(
    otel: tuple[Telemetry, InMemorySpanExporter],
    sdk: tuple[Langfuse, InMemorySpanExporter],
    example: ModuleType,
    monkeypatch: MonkeyPatch,
) -> None:
    """Failed tools end the trace with the model error and skip the success score."""
    telemetry, exporter = otel
    client, _ = sdk
    create_score = Mock()
    monkeypatch.setattr(client, "create_score", create_score)
    model = example._DemoModel()
    error = ProviderUnavailableError("provider unavailable", retryable=False)

    async def fail(*args: object, **kwargs: object) -> None:
        raise error

    monkeypatch.setattr(model, "complete", fail)
    runtime = ModelRuntime(
        ModelRouter({"demo": (model, "demo-model")}),
        retry_policy=RetryPolicy(max_attempts=1),
    )
    previous = get_current_span()
    with raises(ExceptionGroup) as caught:
        await example.run_agent(
            telemetry, runtime, Scorer(client), trace=TraceAttributes()
        )
    assert all(exception is error for exception in caught.value.exceptions)
    assert get_current_span() is previous
    create_score.assert_not_called()
    spans = exporter.get_finished_spans()
    assert len(spans) == 6
    assert all(span.status.status_code is StatusCode.ERROR for span in spans)


async def test_unsampled_agent_does_not_create_orphan_score(
    settings: LangfuseSettings,
    sdk: tuple[Langfuse, InMemorySpanExporter],
    example: ModuleType,
    monkeypatch: MonkeyPatch,
) -> None:
    """A dropped root still completes application work without spans or scores."""
    client, _ = sdk
    create_score = Mock()
    monkeypatch.setattr(client, "create_score", create_score)
    exporter = InMemorySpanExporter()
    with Telemetry(
        replace(settings, sample_ratio=0),
        service_name="dropped",
        service_version="1",
        span_processor=SimpleSpanProcessor(exporter),
    ) as telemetry:
        runtime = ModelRuntime(
            ModelRouter({"demo": (example._DemoModel(), "demo-model")}),
        )
        trace_id, answer = await example.run_agent(
            telemetry, runtime, Scorer(client), trace=TraceAttributes()
        )
    assert len(trace_id) == 32 and "vector space" in answer
    assert not exporter.get_finished_spans()
    create_score.assert_not_called()


async def test_cancelled_delivery_closes_stream_without_scoring(
    otel: tuple[Telemetry, InMemorySpanExporter],
    sdk: tuple[Langfuse, InMemorySpanExporter],
    example: ModuleType,
    monkeypatch: MonkeyPatch,
) -> None:
    """Cancellation ends both active observations and restores propagation state."""
    telemetry, exporter = otel
    client, _ = sdk
    score = Mock()
    monkeypatch.setattr(client, "create_score", score)
    closed: list[bool] = []

    async def cancelled(answer: str) -> AsyncIterator[str]:
        try:
            yield answer[:1]
            raise CancelledError
        finally:
            closed.append(True)

    monkeypatch.setattr(example, "_answer_chunks", cancelled)
    runtime = ModelRuntime(ModelRouter({"demo": (example._DemoModel(), "demo-model")}))
    previous = get_current_span()
    with raises(CancelledError):
        await example.run_agent(
            telemetry,
            runtime,
            Scorer(client),
            trace=TraceAttributes(session_id="cancel"),
        )
    assert closed == [True]
    assert get_current_span() is previous
    score.assert_not_called()
    spans = exporter.get_finished_spans()
    assert len(spans) == 7
    for span in spans:
        if span.name == "answer stream":
            assert span.status.status_code is StatusCode.ERROR
    with telemetry.observe("after cancellation"):
        pass
    assert "langfuse.session.id" not in (
        exporter.get_finished_spans()[-1].attributes or {}
    )
