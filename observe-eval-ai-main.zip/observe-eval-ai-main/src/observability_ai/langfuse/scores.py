"""Validate application scores before handing them to Langfuse's SDK queue."""

from collections.abc import Callable, Iterable, Mapping
from typing import Literal, cast

from langfuse import Langfuse

from ..config import _validate_text
from ..evaluation.results import EvaluationResult, _metadata_snapshot, _validated_value
from ..evaluation.results import ScoreDataType as ScoreDataType


class Scorer:
    """Submit validated scores through an application-owned Langfuse client.

    Numeric scores require finite numbers. Boolean scores accept booleans or
    numeric 0/1 and are sent as numbers. Categorical and text scores require
    nonblank strings; text is limited to 500 characters by Langfuse.
    """

    def __init__(self, client: Langfuse) -> None:
        """Use the supplied client without taking ownership of its lifecycle."""
        self._client = client

    def score(
        self,
        *,
        name: str,
        value: float | str,
        trace_id: str,
        observation_id: str | None = None,
        data_type: ScoreDataType = "NUMERIC",
        comment: str | None = None,
        metadata: Mapping[str, object] | None = None,
    ) -> None:
        """Queue a score for a trace or for one observation within that trace."""
        _validate_text("trace_id", trace_id)
        if observation_id is not None:
            _validate_text("observation_id", observation_id)
        checked = _validated_value(name, value, data_type, comment)
        dimensions = (
            dict(_metadata_snapshot(metadata)) if metadata is not None else None
        )
        if isinstance(checked, str):
            self._client.create_score(
                name=name,
                value=checked,
                trace_id=trace_id,
                observation_id=observation_id,
                data_type=cast('Literal["CATEGORICAL", "TEXT"]', data_type),
                comment=comment,
                metadata=dimensions,
            )
        else:
            self._client.create_score(
                name=name,
                value=checked,
                trace_id=trace_id,
                observation_id=observation_id,
                data_type=cast('Literal["NUMERIC", "BOOLEAN"]', data_type),
                comment=comment,
                metadata=dimensions,
            )

    def score_current(
        self,
        *,
        name: str,
        value: float | str,
        data_type: ScoreDataType = "NUMERIC",
        comment: str | None = None,
    ) -> None:
        """Score the active observation using the SDK's current-span context.

        With no active observation, the SDK logs a warning and sends no score.
        Validation still runs before that SDK behavior.
        """
        checked = _validated_value(name, value, data_type, comment)
        if isinstance(checked, str):
            self._client.score_current_span(
                name=name,
                value=checked,
                data_type=cast('Literal["CATEGORICAL", "TEXT"]', data_type),
                comment=comment,
            )
        else:
            self._client.score_current_span(
                name=name,
                value=checked,
                data_type=cast('Literal["NUMERIC", "BOOLEAN"]', data_type),
                comment=comment,
            )

    def score_current_trace(
        self,
        *,
        name: str,
        value: float | str,
        data_type: ScoreDataType = "NUMERIC",
        comment: str | None = None,
    ) -> None:
        """Score the active trace, with the SDK's warning/no-op when none is active."""
        checked = _validated_value(name, value, data_type, comment)
        if isinstance(checked, str):
            self._client.score_current_trace(
                name=name,
                value=checked,
                data_type=cast('Literal["CATEGORICAL", "TEXT"]', data_type),
                comment=comment,
            )
        else:
            self._client.score_current_trace(
                name=name,
                value=checked,
                data_type=cast('Literal["NUMERIC", "BOOLEAN"]', data_type),
                comment=comment,
            )

    def score_evaluation(
        self,
        result: EvaluationResult,
        *,
        trace_id: str,
        observation_id: str | None = None,
    ) -> None:
        """Queue a core evaluation result, preserving its comment and metadata."""
        if not isinstance(result, EvaluationResult):
            raise TypeError("result must be an EvaluationResult")
        self.score(
            name=result.name,
            value=result.value,
            data_type=result.data_type,
            comment=result.comment,
            metadata=result.metadata,
            trace_id=trace_id,
            observation_id=observation_id,
        )

    def score_many(
        self,
        results: Iterable[EvaluationResult],
        *,
        trace_id: str,
        observation_id: str | None = None,
    ) -> None:
        """Validate a batch before queueing; SDK delivery is not transactional."""
        _validate_text("trace_id", trace_id)
        if observation_id is not None:
            _validate_text("observation_id", observation_id)
        snapshot = tuple(results)
        if any(not isinstance(result, EvaluationResult) for result in snapshot):
            raise TypeError("results must contain EvaluationResult values")
        for result in snapshot:
            self.score_evaluation(
                result, trace_id=trace_id, observation_id=observation_id
            )

    def feedback(
        self, trace_id: str, value: bool | float, comment: str | None = None
    ) -> None:
        """Record a binary user rating as the trace's ``user-feedback`` score."""
        self.score(
            name="user-feedback",
            value=value,
            trace_id=trace_id,
            data_type="BOOLEAN",
            comment=comment,
        )

    def as_live_sink(self) -> Callable[[EvaluationResult, str, str | None], None]:
        """Return a synchronous sink compatible with core ``LiveEvaluation``."""

        def sink(
            result: EvaluationResult, trace_id: str, observation_id: str | None
        ) -> None:
            self.score_evaluation(
                result, trace_id=trace_id, observation_id=observation_id
            )

        return sink
