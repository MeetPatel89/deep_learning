import sqlite3
from unittest.mock import Mock

import openpyxl
import polars as pl
import pytest
from data_mcp_core import sql
from pydantic import TypeAdapter, ValidationError
from qa_mcp_server.models import (
    CSVSource,
    DatasetSource,
    ExcelSource,
    InlineSource,
    ParquetSource,
    SQLConnection,
    SQLSource,
)
from qa_mcp_server.service import inspect
from qa_mcp_server.sources import iter_batches


def test_csv_streaming_delimiter_and_encoding(tmp_path):
    path = tmp_path / "values.csv"
    path.write_text("id;name\n1;café\n2;second\n3;third\n", encoding="cp1252")
    source = CSVSource(path=path, delimiter=";", encoding="cp1252")
    batches = list(iter_batches(source, batch_size=1))
    assert sum(frame.height for frame in batches) == 3
    assert inspect(source, sample_size=1) == {
        "row_count": 3,
        "schema": {"id": "Int64", "name": "String"},
        "sample": [{"id": 1, "name": "café"}],
    }


def test_csv_full_schema_inference_and_header_only(tmp_path):
    path = tmp_path / "mixed.csv"
    path.write_text("v\n1\n2\ntext\n", encoding="utf-8")
    assert inspect(CSVSource(path=path))["schema"] == {"v": "String"}
    path.write_text("id,name\n", encoding="utf-8")
    result = inspect(CSVSource(path=path))
    assert result["row_count"] == 0
    assert set(result["schema"]) == {"id", "name"}


def test_csv_null_values_and_no_header(tmp_path):
    path = tmp_path / "values.csv"
    path.write_text("1,NULL\n2,value\n", encoding="utf-8")
    result = inspect(CSVSource(path=path, has_header=False, null_values="NULL"))
    assert result["sample"][0] == {"column_1": 1, "column_2": None}


def test_parquet_stream_and_empty_schema(tmp_path):
    path = tmp_path / "data.parquet"
    frame = pl.DataFrame({"id": range(11), "name": ["x"] * 11})
    frame.write_parquet(path)
    assert sum(batch.height for batch in iter_batches(ParquetSource(path=path), 3)) == 11
    frame.clear().write_parquet(path)
    result = inspect(ParquetSource(path=path))
    assert result["row_count"] == 0
    assert result["schema"] == {"id": "Int64", "name": "String"}


@pytest.mark.parametrize("sheet", ["Data", 2])
def test_excel_sheet_selection(tmp_path, sheet):
    path = tmp_path / "data.xlsx"
    workbook = openpyxl.Workbook()
    workbook.active.title = "Other"
    data = workbook.create_sheet("Data")
    data.append(["id", "v"])
    data.append([1, "a"])
    data.append([2, "b"])
    workbook.save(path)
    workbook.close()
    result = inspect(ExcelSource(path=path, sheet=sheet))
    assert result["row_count"] == 2
    assert result["sample"] == [{"id": 1, "v": "a"}, {"id": 2, "v": "b"}]


def test_invalid_sources(tmp_path):
    with pytest.raises(ValidationError):
        TypeAdapter(DatasetSource).validate_python({"type": "other", "rows": []})
    with pytest.raises(ValidationError):
        SQLSource(server="server", database="db")
    with pytest.raises(ValidationError):
        SQLSource(server="server", database="db", query="SELECT 1", query_file="file.sql")
    with pytest.raises(FileNotFoundError):
        inspect(CSVSource(path=tmp_path / "missing.csv"))
    with pytest.raises(ValueError):
        inspect(InlineSource(rows=[{}]))
    with pytest.raises(ValueError):
        list(iter_batches(InlineSource(rows=[]), 0))


def test_connection_string_uses_interactive_mfa_and_escapes_values():
    source = SQLConnection(
        server="example.database.windows.net",
        database="db;malicious=yes}",
        username="person@example.org",
    )
    string = sql.connection_string(source)
    assert "Driver={ODBC Driver 18 for SQL Server}" in string
    assert "Server={tcp:example.database.windows.net,1433}" in string
    assert "Database={db;malicious=yes}}}" in string
    assert "Authentication=ActiveDirectoryInteractive" in string
    assert "Encrypt=yes;TrustServerCertificate=no" in string
    assert "UID={person@example.org}" in string
    assert "PWD=" not in string


@pytest.fixture
def mocked_sql(monkeypatch):
    sql.close_connections()
    database = sqlite3.connect(":memory:")
    database.execute("CREATE TABLE data(id INTEGER, value TEXT)")
    database.executemany("INSERT INTO data VALUES (?, ?)", [(i, str(i)) for i in range(5)])
    connection = Mock()
    connection.cursor.side_effect = database.cursor
    connection.close.side_effect = database.close
    opener = Mock(return_value=connection)
    monkeypatch.setattr(sql, "_open_connection", opener)
    yield connection, opener
    sql.close_connections()


def test_sql_preflight_cached_connection_and_batched_query(mocked_sql):
    connection, opener = mocked_sql
    settings = SQLConnection(server="server", database="db", username="person@example.org")
    assert sql.test_connection(settings)["connected"]
    assert sql.test_connection(settings)["connected"]
    source = SQLSource(**settings.model_dump(), query="SELECT * FROM data ORDER BY id")
    batches = list(iter_batches(source, 2))
    assert [frame.height for frame in batches] == [2, 2, 1]
    assert opener.call_count == 1
    assert connection.cursor.call_count == 3
    assert connection.timeout == 30


def test_sql_query_file_and_empty_result_keep_schema(tmp_path, mocked_sql):
    script = tmp_path / "query.sql"
    script.write_text("SELECT * FROM data WHERE id < 0", encoding="utf-8-sig")
    source = SQLSource(server="server", database="db", query_file=script)
    result = inspect(source)
    assert result["row_count"] == 0
    assert set(result["schema"]) == {"id", "value"}


def test_sql_cache_separates_drivers(mocked_sql):
    _, opener = mocked_sql
    sql.get_connection(SQLConnection(server="s", database="d", driver="one"))
    sql.get_connection(SQLConnection(server="s", database="d", driver="two"))
    assert opener.call_count == 2
