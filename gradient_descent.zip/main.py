def main():
    print("Hello from lin-reg-exp!")


if __name__ == "__main__":
    main()
