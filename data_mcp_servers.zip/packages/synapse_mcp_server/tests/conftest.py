import json
import subprocess
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, create_autospec

import pytest
from azure.identity import DefaultAzureCredential
from azure.synapse.artifacts import ArtifactsClient
from azure.synapse.spark import SparkClient
from synapse_mcp_server.clients import ClientRegistry
from synapse_mcp_server.config import (
    BranchTestProfile,
    RepositoryConfig,
    SynapseConfig,
    WorkspaceConfig,
)
from synapse_mcp_server.repository import artifact_path
from synapse_mcp_server.server import SynapseService


@pytest.fixture
def fixture_runs():
    return json.loads((Path(__file__).parent / "fixtures" / "runs.json").read_text())


@pytest.fixture
def synapse(fixture_runs, tmp_path):
    real = ArtifactsClient("https://example.dev.azuresynapse.net", DefaultAzureCredential())
    groups = [
        "pipeline",
        "pipeline_run",
        "trigger",
        "trigger_run",
        "dataset",
        "linked_service",
        "data_flow",
        "notebook",
        "spark_job_definition",
        "sql_script",
        "library",
        "data_flow_debug_session",
    ]
    artifacts = SimpleNamespace(
        **{name: create_autospec(getattr(real, name), spec_set=True) for name in groups}
    )
    real.close()
    artifacts.pipeline_run.get_pipeline_run.side_effect = lambda identifier: fixture_runs["runs"][
        identifier
    ]
    artifacts.pipeline_run.query_activity_runs.side_effect = (
        lambda pipeline, identifier, parameters: {
            "value": fixture_runs["activities"][identifier],
            "continuationToken": None,
        }
    )
    real_spark = SparkClient(
        "https://example.dev.azuresynapse.net", "pool", DefaultAzureCredential()
    )
    spark = SimpleNamespace(
        spark_session=create_autospec(real_spark.spark_session, spec_set=True),
        spark_batch=create_autospec(real_spark.spark_batch, spec_set=True),
    )
    real_spark.close()
    registry = Mock(spec=ClientRegistry)
    registry.get.side_effect = lambda workspace, kind, pool=None: {
        "artifacts": artifacts,
        "spark": spark,
    }[kind]
    config = SynapseConfig(
        execution_store=str(tmp_path / "runs.sqlite3"),
        workspaces={
            "dev": WorkspaceConfig(
                name="workspace",
                allow_live_env=True,
                subscription_id="sub",
                resource_group="group",
                default_dedicated_pool="warehouse",
            )
        },
    )
    return SynapseService(config, registry), artifacts, spark, registry


def git(root, *arguments):
    return subprocess.check_output(["git", *arguments], cwd=root, text=True).strip()


def write_artifact(root, kind, name, properties):
    path = Path(root) / artifact_path(kind, name)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"name": name, "properties": properties}))
    return path


@pytest.fixture
def repo_service(tmp_path):
    root = tmp_path / "repo"
    root.mkdir()
    git(root, "init", "-q", "-b", "main")
    git(root, "config", "user.email", "test@example.invalid")
    git(root, "config", "user.name", "Test")
    write_artifact(
        root,
        "pipeline",
        "P",
        {
            "activities": [
                {"name": "Wait", "type": "Wait", "typeProperties": {"waitTimeInSeconds": 1}}
            ]
        },
    )
    (root / "notes.txt").write_text("original")
    git(root, "add", ".")
    git(root, "commit", "-qm", "initial")
    git(root, "branch", "workspace_publish")
    git(root, "branch", "release")
    git(root, "switch", "-qc", "feature")
    settings = WorkspaceConfig(
        name="example",
        allow_git_write=True,
        allow_run=True,
        repository=RepositoryConfig(local_path=str(root), publish_branch="release"),
        default_test_profile="dev",
        test_profiles={"dev": BranchTestProfile()},
    )
    config = SynapseConfig(workspaces={"dev": settings}, execution_store=str(tmp_path / "runs.db"))
    clients = Mock(spec=ClientRegistry)
    service = SynapseService(config, clients)
    yield service, root, settings, clients
    service.close()
