---
doc_id: POL-COMMS-001
title: Customer-Safe Communication Policy
doc_type: policy
service_id: null
owner_group: Service Desk L1
visibility: internal
status: active
created_at: "2026-05-10T09:00:00"
updated_at: "2026-06-10T09:00:00"
related_records: []
source_facts:
  - support_groups
difficulty_tags:
  - permission-boundary
  - customer-safe-summary
---

# Customer-Safe Communication Policy

## Purpose

This policy defines how support teams translate internal diagnostic information into customer-safe updates. The goal is to provide accurate status without exposing internal implementation details, incomplete analysis, or avoidable wording that creates confusion.

Support responses should not expose internal system names unless approved for customer communication. Internal root-cause details should be translated into customer-safe language.

## Scope

This policy applies to Service Desk L1 responses, incident updates, knowledge article responses, and ticket closure notes that may be sent outside the internal support organization. It covers known issues for Identity Gateway, Payments Reporting Service, and Internal API Gateway.

Internal documents can include diagnostic detail needed by support teams. Customer-facing updates should state the observed impact, what support is checking, and any confirmed safe guidance. They should not describe internal control tables, cache behavior, or configuration mistakes.

## Policy rules

If a known issue has a customer_safe_summary, use that wording as the starting point for external updates.

Avoid mentioning internal control tables, metadata cache internals, or policy configuration mistakes in customer-facing messages. Those details belong in incident, runbook, problem, or known issue records with internal visibility.

Use the following rules:

- Describe the user-visible effect first.
- Avoid naming internal implementation components unless the name is approved for the audience.
- Do not speculate about root cause before the owning group confirms it.
- Do not state that a transaction, request, or entitlement was lost unless confirmed by the owning group.
- Preserve the difference between delayed reporting and missing source data.
- Preserve the difference between expected throttling and policy review.

## Support expectations

Service Desk L1 should keep two separate notes when needed:

| Note type | Allowed content |
| --- | --- |
| Internal work note | Diagnostic evidence, related records, owning group, recent changes, known issue match, workaround status. |
| Customer-safe update | Impact, current action, safe summary, next update expectation, non-sensitive reassurance when confirmed. |

The internal work note can mention records such as KI-104, KI-221, KI-307, CHG-2407, CHG-2411, or CHG-2420. The customer-safe update should use plain language approved in the known issue summary.

## Escalation or communication guidance

When a support agent is unsure whether a detail is customer-safe, escalate the proposed wording to the owning support group or Service Desk L1 lead before sending. If the incident is change-related, Release Management may help coordinate timing and consistency, but technical wording should still be reviewed by the owning group.

Use known issue summaries as baseline wording:

- KI-104: We are validating the enterprise sign-in configuration after scheduled identity maintenance.
- KI-221: Reporting data is delayed, but source payment transactions are not lost.
- KI-307: We are reviewing the applied API traffic policy for the affected client.

## Examples

Internal wording: Some Identity Gateway nodes may still be using stale IdP metadata after certificate rotation.

Customer-safe wording: We are validating the enterprise sign-in configuration after scheduled identity maintenance.

Internal wording: The Azure SQL Database control-table watermark did not advance, so Synapse/Fabric skipped the latest partition.

Customer-safe wording: Reporting data is delayed, but source payment transactions are not lost.

Internal wording: Some clients had stricter burst limits applied than their entitlement allowed.

Customer-safe wording: We are reviewing the applied API traffic policy for the affected client.

## Related records

Use this policy with customer-safe knowledge articles KB-118, KB-204, and KB-311. It is also referenced by runbooks where internal troubleshooting detail must be separated from external updates.

