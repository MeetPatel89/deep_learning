"""Verify opt-in capture, serialization failures, and facade policy isolation."""

from asyncio import TaskGroup, sleep
from collections.abc import Callable
from dataclasses import FrozenInstanceError, replace
from json import loads
from typing import Never, cast, override
from unittest.mock import patch

from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from pytest import LogCaptureFixture, MonkeyPatch, mark, raises

from observability_ai import (
    ContentCapturePolicy,
    LangfuseSettings,
    Telemetry,
    TraceAttributes,
)

_CAPTURE_ENV = "OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT"


@mark.parametrize(
    "value,enabled",
    [
        (None, False),
        ("", False),
        ("false", False),
        ("1", False),
        ("yes", False),
        (" true ", False),
        ("TRUE", True),
        ("TrUe", True),
    ],
)
def test_environment_default_is_snapshotted(
    monkeypatch: MonkeyPatch, value: str | None, enabled: bool
) -> None:
    """Only true enables capture; later environment changes do not mutate policy."""
    if value is not None:
        monkeypatch.setenv(_CAPTURE_ENV, value)
    policy = ContentCapturePolicy()
    assert policy.enabled is enabled
    monkeypatch.setenv(_CAPTURE_ENV, "false" if enabled else "true")
    assert policy.enabled is enabled
    assert ContentCapturePolicy().enabled is not enabled
    with raises(FrozenInstanceError):
        setattr(policy, "enabled", not enabled)


@mark.parametrize("environment", ["true", "false"])
@mark.parametrize("override", [True, False])
def test_explicit_bool_overrides_environment(
    monkeypatch: MonkeyPatch, environment: str, override: bool
) -> None:
    """Explicit choices always win, including disabling an enabled environment."""
    monkeypatch.setenv(_CAPTURE_ENV, environment)
    assert ContentCapturePolicy(enabled=override).enabled is override


@mark.parametrize("value", [0, 1, "true", None])
def test_invalid_capture_override(value: object) -> None:
    """Reject truthy non-booleans before any telemetry is configured."""
    with raises(TypeError, match="enabled must be a bool"):
        ContentCapturePolicy(enabled=cast(bool, value))


@mark.parametrize(
    "payload",
    ["", "private text 模型", 0, False, 1.5, [], {}, {"steps": ["x", None, True]}],
)
def test_json_payloads_round_trip(payload: object) -> None:
    """Empty and false values survive JSON encoding into fresh dictionaries."""
    policy = ContentCapturePolicy(enabled=True)
    attributes = policy.as_otel_attributes(input=payload, output=payload)
    assert set(attributes) == {
        "langfuse.observation.input",
        "langfuse.observation.output",
    }
    for value in attributes.values():
        assert isinstance(value, str)
        assert loads(value) == payload
    attributes.clear()
    assert policy.as_otel_attributes(input=payload)
    assert policy.as_otel_attributes() == {}


class _Unserializable:
    """Detect attempts to fall back to unsafe object representations."""

    @override
    def __str__(self) -> str:
        raise AssertionError("private payload must not be stringified")

    @override
    def __repr__(self) -> str:
        raise AssertionError("private payload must not be represented")


class _FailingDictionary(dict[str, object]):
    """Simulate user container code raising an exception that includes payload text."""

    @override
    def items(self) -> Never:
        """Fail during JSON iteration."""
        raise RuntimeError("private payload in serializer failure")


def test_capture_failures_omit_only_failed_value(caplog: LogCaptureFixture) -> None:
    """Invalid or circular payloads do not leak values or prevent valid output."""
    circular: list[object] = []
    circular.append(circular)
    policy = ContentCapturePolicy(enabled=True)
    for payload in (
        _Unserializable(),
        float("nan"),
        float("inf"),
        circular,
        _FailingDictionary(secret="private payload"),
    ):
        attributes = policy.as_otel_attributes(input=payload, output="valid result")
        assert attributes == {"langfuse.observation.output": '"valid result"'}
    assert len(caplog.records) == 5
    assert "Could not serialize observation input; omitted" in caplog.text
    assert "private payload" not in caplog.text
    assert all(record.exc_info is None for record in caplog.records)
    assert policy.as_otel_attributes(input="valid", output=_Unserializable()) == {
        "langfuse.observation.input": '"valid"'
    }


def test_disabled_policy_does_not_inspect_payloads(caplog: LogCaptureFixture) -> None:
    """No serialization or warnings occur when capture is disabled."""
    assert (
        ContentCapturePolicy(enabled=False).as_otel_attributes(
            input=_Unserializable(), output=_Unserializable()
        )
        == {}
    )
    assert not caplog.records


def test_invalid_facade_policy_fails_before_provider_construction(
    settings: LangfuseSettings,
) -> None:
    """Reject invalid policy injection without creating export resources."""
    with patch("observability_ai.telemetry.build_tracer_provider") as build_provider:
        with raises(TypeError, match="ContentCapturePolicy"):
            Telemetry(
                settings,
                service_name="invalid",
                service_version="1",
                content_capture=cast(ContentCapturePolicy, True),
            )
    build_provider.assert_not_called()


@mark.parametrize("enabled", [False, True])
def test_observation_helpers_share_policy_and_snapshot_payloads(
    settings: LangfuseSettings, enabled: bool
) -> None:
    """Agent, chain, tool, and observe preserve types, dimensions, and gated I/O."""
    exporter = InMemorySpanExporter()
    policy = ContentCapturePolicy(enabled=enabled)
    trace = TraceAttributes(session_id="capture-test")
    original = {"question": "private input"}
    with Telemetry(
        settings,
        service_name="capture-test",
        service_version="1",
        span_processor=SimpleSpanProcessor(exporter),
        content_capture=policy,
    ) as telemetry:
        assert telemetry.content_capture is policy
        with telemetry.agent("agent", attributes=trace, input=original) as agent:
            original["question"] = "changed after entry"
            with telemetry.chain("chain", attributes=trace, input="chain input"):
                with telemetry.tool("tool", attributes=trace, output="tool output"):
                    with telemetry.observe("leaf", attributes=trace, input=False):
                        pass
            agent.set_attributes(policy.as_otel_attributes(output="private answer"))
    leaf, tool, chain, agent_span = exporter.get_finished_spans()
    for child, parent in ((leaf, tool), (tool, chain), (chain, agent_span)):
        assert child.parent == parent.context
    for span in (leaf, tool, chain, agent_span):
        assert span.attributes is not None
        assert span.attributes["langfuse.observation.type"] == (
            "span" if span.name == "leaf" else span.name
        )
        assert span.attributes["langfuse.session.id"] == "capture-test"
        payloads = {
            name: value
            for name, value in span.attributes.items()
            if name in {"langfuse.observation.input", "langfuse.observation.output"}
        }
        assert bool(payloads) is enabled
    assert agent_span.attributes is not None
    if enabled:
        assert agent_span.attributes["langfuse.observation.input"] == (
            '{"question": "private input"}'
        )
        assert (
            agent_span.attributes["langfuse.observation.output"] == '"private answer"'
        )


def test_unsampled_spans_skip_serialization(
    settings: LangfuseSettings, caplog: LogCaptureFixture
) -> None:
    """Even enabled capture performs no payload work for a non-recording span."""
    exporter = InMemorySpanExporter()
    with Telemetry(
        replace(settings, sample_ratio=0),
        service_name="unsampled",
        service_version="1",
        span_processor=SimpleSpanProcessor(exporter),
        content_capture=ContentCapturePolicy(enabled=True),
    ) as telemetry:
        with telemetry.observe("dropped", input=_Unserializable()) as span:
            assert not span.span.is_recording()
    assert not exporter.get_finished_spans()
    assert not caplog.records


async def test_concurrent_facades_keep_capture_choices_local(
    settings: LangfuseSettings, monkeypatch: MonkeyPatch
) -> None:
    """A disabled facade cannot inherit another concurrent facade's capture choice."""
    monkeypatch.setenv(_CAPTURE_ENV, "true")
    exporter = InMemorySpanExporter()
    with (
        Telemetry(
            settings,
            service_name="enabled",
            service_version="1",
            span_processor=SimpleSpanProcessor(exporter),
        ) as enabled,
        Telemetry(
            settings,
            service_name="disabled",
            service_version="1",
            span_processor=SimpleSpanProcessor(exporter),
            content_capture=ContentCapturePolicy(enabled=False),
        ) as disabled,
    ):

        async def observe(telemetry: Telemetry, name: str) -> None:
            with telemetry.agent(name, input="private prompt"):
                await sleep(0)
                with telemetry.tool(f"{name}/tool", output="private answer"):
                    await sleep(0)

        async with TaskGroup() as tasks:
            tasks.create_task(observe(enabled, "enabled"))
            tasks.create_task(observe(disabled, "disabled"))
    spans = exporter.get_finished_spans()
    assert len(spans) == 4
    for span in spans:
        assert span.attributes is not None
        assert any(
            name in span.attributes
            for name in ("langfuse.observation.input", "langfuse.observation.output")
        ) is span.name.startswith("enabled")


def test_redaction_precedes_serialization_and_truncation() -> None:
    """A redactor may replace unsupported values before JSON encoding."""
    policy = ContentCapturePolicy(
        enabled=True, redactor=lambda value: "safe 模型", max_characters=7
    )
    assert policy.as_otel_attributes(input=_Unserializable()) == {
        "langfuse.observation.input": '"safe 模...[truncated]'
    }
    assert ContentCapturePolicy(enabled=True, max_characters=5).as_otel_attributes(
        input="abc"
    ) == {"langfuse.observation.input": '"abc"'}


def test_redactor_failure_is_private_and_does_not_drop_other_payload(
    caplog: LogCaptureFixture,
) -> None:
    """Redaction errors omit only their payload and never log exception details."""

    def redact(value: object) -> object:
        if value == "secret":
            raise RuntimeError("secret in redactor failure")
        return value

    policy = ContentCapturePolicy(enabled=True, redactor=redact)
    assert policy.as_otel_attributes(input="secret", output="ok") == {
        "langfuse.observation.output": '"ok"'
    }
    assert "secret" not in caplog.text
    assert len(caplog.records) == 1 and caplog.records[0].exc_info is None


@mark.parametrize("value", [True, "10", 1.5, 0, -1])
def test_invalid_truncation_limits(value: object) -> None:
    """Only positive integer limits are accepted."""
    with raises((TypeError, ValueError), match="max_characters"):
        ContentCapturePolicy(max_characters=cast(int, value))


def test_invalid_redactor_and_disabled_redaction() -> None:
    """Validate callability and do not invoke user code when capture is disabled."""
    with raises(TypeError, match="redactor"):
        ContentCapturePolicy(redactor=cast(Callable[[object], object], 1))

    def forbidden(value: object) -> object:
        raise AssertionError("disabled redactor must not run")

    assert (
        ContentCapturePolicy(enabled=False, redactor=forbidden).as_otel_attributes(
            input=object()
        )
        == {}
    )
