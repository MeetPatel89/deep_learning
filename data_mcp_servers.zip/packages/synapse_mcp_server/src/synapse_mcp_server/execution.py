"""Explicitly gated pipeline, trigger, Livy and pool operations."""

import asyncio
import time
from typing import Any, Literal

from data_mcp_core.guards import planned_action, require
from data_mcp_core.results import bounded_result
from mcp.server.fastmcp import Context

from synapse_mcp_server.base import field, wait_operation


class ExecutionTools:
    def run_pipeline(
        self,
        workspace: str,
        pipeline: str,
        parameters: dict[str, Any] | None = None,
        reference_pipeline_run_id: str | None = None,
        is_recovery: bool = False,
        start_activity_name: str | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Run an already-published pipeline through the SDK; requires allow_live_env and
        allow_run. Use run_branch_pipeline for unpublished Git definitions.
        """
        require(self.live_workspace(workspace, "execution"), "allow_run")
        if (is_recovery or start_activity_name) and not reference_pipeline_run_id:
            raise ValueError("Recovery requires reference_pipeline_run_id")
        plan = planned_action(
            "run_pipeline",
            dry_run,
            workspace=workspace,
            pipeline=pipeline,
            parameters=parameters or {},
            reference_pipeline_run_id=reference_pipeline_run_id,
            is_recovery=is_recovery,
            start_activity_name=start_activity_name,
        )
        if plan:
            return plan
        return bounded_result(
            self.artifact_client(workspace, "execution").pipeline.create_pipeline_run(
                pipeline,
                parameters=parameters or {},
                reference_pipeline_run_id=reference_pipeline_run_id,
                is_recovery=is_recovery,
                start_activity_name=start_activity_name,
            )
        )

    def cancel_pipeline_run(
        self, workspace: str, run_id: str, recursive: bool = True, dry_run: bool = False
    ) -> dict[str, Any]:
        """Cancel a pipeline and optionally its children (requires allow_run)."""
        require(self.live_workspace(workspace, "execution"), "allow_run")
        plan = planned_action(
            "cancel_pipeline_run", dry_run, workspace=workspace, run_id=run_id, recursive=recursive
        )
        if plan:
            return plan
        self.artifact_client(workspace, "execution").pipeline_run.cancel_pipeline_run(
            run_id, is_recursive=recursive
        )
        return {"cancel_requested": True, "run_id": run_id}

    async def wait_for_pipeline_run(
        self,
        workspace: str,
        run_id: str,
        timeout_seconds: int = 60,
        poll_seconds: float = 5,
        ctx: Context | None = None,
    ) -> dict[str, Any]:
        """Wait for a bounded interval with MCP progress; failed runs include automatic diagnosis
        (requires allow_run).
        """
        require(self.live_workspace(workspace, "execution"), "allow_run")
        if not 1 <= timeout_seconds <= 3600 or not 0.1 <= poll_seconds <= 60:
            raise ValueError("timeout must be 1–3600 seconds; polling must be 0.1–60 seconds")
        started = time.monotonic()
        deadline = started + timeout_seconds
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return {"run_id": run_id, "timed_out": True}
            try:
                run = await asyncio.wait_for(
                    asyncio.to_thread(self._get_run, workspace, run_id, "execution"), remaining
                )
            except TimeoutError:
                return {"run_id": run_id, "timed_out": True}
            status = field(run, "status")
            if ctx:
                await ctx.report_progress(
                    min(time.monotonic() - started, timeout_seconds),
                    timeout_seconds,
                    f"Pipeline {status}",
                )
            if status in {"Succeeded", "Failed", "Cancelled", "Canceled"}:
                result = {"run": run, "timed_out": False}
                if status == "Failed":
                    result["diagnosis"] = await asyncio.to_thread(
                        self._diagnose_pipeline_run, workspace, run_id
                    )
                return bounded_result(result)
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return bounded_result({"run": run, "timed_out": True})
            await asyncio.sleep(min(poll_seconds, remaining))

    def _trigger(self, workspace, trigger, action, dry_run):
        require(self.live_workspace(workspace, "execution"), "allow_run")
        plan = planned_action(action + "_trigger", dry_run, workspace=workspace, trigger=trigger)
        if plan:
            return plan
        operation = getattr(
            self.artifact_client(workspace, "execution").trigger, "begin_" + action + "_trigger"
        )
        return bounded_result({"trigger": trigger, "result": wait_operation(operation(trigger))})

    def start_trigger(self, workspace: str, trigger: str, dry_run: bool = False) -> dict[str, Any]:
        """Start a trigger (requires allow_run)."""
        return self._trigger(workspace, trigger, "start", dry_run)

    def stop_trigger(self, workspace: str, trigger: str, dry_run: bool = False) -> dict[str, Any]:
        """Stop a trigger (requires allow_run)."""
        return self._trigger(workspace, trigger, "stop", dry_run)

    def rerun_trigger_run(
        self, workspace: str, trigger: str, run_id: str, dry_run: bool = False
    ) -> dict[str, Any]:
        """Rerun a trigger instance (requires allow_run)."""
        require(self.live_workspace(workspace, "execution"), "allow_run")
        plan = planned_action(
            "rerun_trigger_run", dry_run, workspace=workspace, trigger=trigger, run_id=run_id
        )
        if plan:
            return plan
        self.artifact_client(workspace, "execution").trigger_run.rerun_trigger_instance(
            trigger, run_id
        )
        return {"rerun_requested": True, "run_id": run_id}

    def create_spark_session(
        self,
        workspace: str,
        pool: str,
        name: str,
        options: dict[str, Any] | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Create a Livy Spark session (requires allow_run)."""
        require(self.live_workspace(workspace, "execution"), "allow_run")
        plan = planned_action(
            "create_spark_session",
            dry_run,
            workspace=workspace,
            pool=pool,
            name=name,
            options=options or {},
        )
        if plan:
            return plan
        from azure.synapse.spark.models import SparkSessionOptions

        request = SparkSessionOptions(name=name, **(options or {}))
        return bounded_result(
            self.clients.get(workspace, "spark", pool).spark_session.create_spark_session(
                request, detailed=True
            )
        )

    def run_spark_statement(
        self,
        workspace: str,
        pool: str,
        session_id: int,
        code: str,
        language: Literal["pyspark", "scala", "sql"] = "pyspark",
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Run PySpark, Scala or Spark SQL in a Livy session (requires allow_run)."""
        require(self.live_workspace(workspace, "execution"), "allow_run")
        plan = planned_action(
            "run_spark_statement",
            dry_run,
            workspace=workspace,
            pool=pool,
            session_id=session_id,
            language=language,
            code=code,
        )
        if plan:
            return plan
        from azure.synapse.spark.models import SparkStatementOptions

        request = SparkStatementOptions(
            code=code, kind={"pyspark": "pyspark", "scala": "spark", "sql": "sql"}[language]
        )
        return bounded_result(
            self.clients.get(workspace, "spark", pool).spark_session.create_spark_statement(
                session_id, request
            )
        )

    def close_spark_session(
        self, workspace: str, pool: str, session_id: int, dry_run: bool = False
    ) -> dict[str, Any]:
        """Close a Livy Spark session (requires allow_run)."""
        require(self.live_workspace(workspace, "execution"), "allow_run")
        plan = planned_action(
            "close_spark_session", dry_run, workspace=workspace, pool=pool, session_id=session_id
        )
        if plan:
            return plan
        self.clients.get(workspace, "spark", pool).spark_session.cancel_spark_session(session_id)
        return {"closed": True, "session_id": session_id}

    def submit_spark_batch(
        self,
        workspace: str,
        pool: str,
        name: str,
        file: str,
        options: dict[str, Any] | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Submit a Livy batch job (requires allow_run)."""
        require(self.live_workspace(workspace, "execution"), "allow_run")
        plan = planned_action(
            "submit_spark_batch",
            dry_run,
            workspace=workspace,
            pool=pool,
            name=name,
            file=file,
            options=options or {},
        )
        if plan:
            return plan
        from azure.synapse.spark.models import SparkBatchJobOptions

        request = SparkBatchJobOptions(name=name, file=file, **(options or {}))
        return bounded_result(
            self.clients.get(workspace, "spark", pool).spark_batch.create_spark_batch_job(
                request, detailed=True
            )
        )

    def _pool_operation(self, workspace, pool, action, dry_run):
        settings = self.live_workspace(workspace, "execution")
        require(settings, "allow_manage")
        plan = planned_action(action + "_sql_pool", dry_run, workspace=workspace, pool=pool)
        if plan:
            return plan
        operation = getattr(self.clients.get(workspace, "arm").sql_pools, "begin_" + action)
        return bounded_result(
            {
                "pool": pool,
                "result": wait_operation(operation(settings.resource_group, settings.name, pool)),
            }
        )

    def pause_sql_pool(self, workspace: str, pool: str, dry_run: bool = False) -> dict[str, Any]:
        """Pause a dedicated SQL pool (requires allow_manage)."""
        return self._pool_operation(workspace, pool, "pause", dry_run)

    def resume_sql_pool(self, workspace: str, pool: str, dry_run: bool = False) -> dict[str, Any]:
        """Resume a dedicated SQL pool (requires allow_manage)."""
        return self._pool_operation(workspace, pool, "resume", dry_run)
