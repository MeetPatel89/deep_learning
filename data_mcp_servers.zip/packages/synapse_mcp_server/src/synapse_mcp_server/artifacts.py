"""Artifact discovery, dependency analysis and guarded authoring."""

import base64
import difflib
import json
from io import BytesIO
from typing import Any

from azure.core.exceptions import ResourceNotFoundError
from data_mcp_core.guards import planned_action, require
from data_mcp_core.results import bounded_result, json_safe, paginate, redact

from synapse_mcp_server.base import field, wait_operation
from synapse_mcp_server.config import ArtifactSource, RepositoryBackend
from synapse_mcp_server.repository import LAYOUT, artifact_path, safe_lines

ARTIFACTS = {
    "pipeline": (
        "pipeline",
        "get_pipelines_by_workspace",
        "get_pipeline",
        "begin_create_or_update_pipeline",
        "begin_delete_pipeline",
        "PipelineResource",
    ),
    "dataset": (
        "dataset",
        "get_datasets_by_workspace",
        "get_dataset",
        "begin_create_or_update_dataset",
        "begin_delete_dataset",
        "DatasetResource",
    ),
    "linked_service": (
        "linked_service",
        "get_linked_services_by_workspace",
        "get_linked_service",
        "begin_create_or_update_linked_service",
        "begin_delete_linked_service",
        "LinkedServiceResource",
    ),
    "data_flow": (
        "data_flow",
        "get_data_flows_by_workspace",
        "get_data_flow",
        "begin_create_or_update_data_flow",
        "begin_delete_data_flow",
        "DataFlowResource",
    ),
    "notebook": (
        "notebook",
        "get_notebooks_by_workspace",
        "get_notebook",
        "begin_create_or_update_notebook",
        "begin_delete_notebook",
        "NotebookResource",
    ),
    "spark_job_definition": (
        "spark_job_definition",
        "get_spark_job_definitions_by_workspace",
        "get_spark_job_definition",
        "begin_create_or_update_spark_job_definition",
        "begin_delete_spark_job_definition",
        "SparkJobDefinitionResource",
    ),
    "sql_script": (
        "sql_script",
        "get_sql_scripts_by_workspace",
        "get_sql_script",
        "begin_create_or_update_sql_script",
        "begin_delete_sql_script",
        "SqlScriptResource",
    ),
    "trigger": (
        "trigger",
        "get_triggers_by_workspace",
        "get_trigger",
        "begin_create_or_update_trigger",
        "begin_delete_trigger",
        "TriggerResource",
    ),
    "library": ("library", "list", "get", "begin_create", "begin_delete", "LibraryResource"),
}


def references(value):
    found = {
        "datasets": set(),
        "linked_services": set(),
        "notebooks": set(),
        "data_flows": set(),
        "pipelines": set(),
    }
    kinds = {
        "DatasetReference": "datasets",
        "LinkedServiceReference": "linked_services",
        "NotebookReference": "notebooks",
        "DataFlowReference": "data_flows",
        "PipelineReference": "pipelines",
    }

    def walk(item):
        if isinstance(item, dict):
            kind = kinds.get(item.get("type"))
            name = field(item, "referenceName")
            if kind and isinstance(name, str):
                found[kind].add(name)
            for child in item.values():
                walk(child)
        elif isinstance(item, list):
            for child in item:
                walk(child)

    walk(value)
    return {key: sorted(names) for key, names in found.items()}


class ArtifactTools:
    def _git_snapshot(self, workspace, branch, repository_backend):
        self.workspace(workspace, "artifacts")
        repository = self.repository(workspace, repository_backend)
        if branch is None:
            branch = repository.config.collaboration_branch
            if repository.backend == "local":
                branch = repository.git("symbolic-ref", "--short", "HEAD")
        return repository.snapshot(branch)

    def _artifact_source(self, workspace, source):
        if source == "git":
            self.workspace(workspace, "artifacts")
        elif source == "live":
            self.live_workspace(workspace, "artifacts")
        else:
            raise ValueError("source must be git or live")

    def _artifact_ops(self, workspace, artifact_type):
        if artifact_type not in ARTIFACTS:
            raise ValueError("Unsupported artifact type; use " + ", ".join(ARTIFACTS))
        mapping = ARTIFACTS[artifact_type]
        return getattr(self.artifact_client(workspace, "artifacts"), mapping[0]), mapping

    def _get_artifact(self, workspace, artifact_type, name):
        operations, mapping = self._artifact_ops(workspace, artifact_type)
        return json_safe(getattr(operations, mapping[2])(name))

    def list_artifacts(
        self,
        workspace: str,
        artifact_type: str = "pipeline",
        limit: int = 100,
        continuation: str | None = None,
        source: ArtifactSource = "git",
        branch: str | None = None,
        repository_backend: RepositoryBackend | None = None,
    ) -> dict[str, Any]:
        """List pipelines, datasets, linked services, data flows, notebooks, jobs, SQL scripts,
        triggers or libraries.
        """
        self._artifact_source(workspace, source)
        if source == "git":
            snapshot = self._git_snapshot(workspace, branch, repository_backend)
            return {
                **paginate(
                    snapshot.list(artifact_type),
                    limit,
                    continuation,
                    f"git:{workspace}:{artifact_type}:{snapshot.fingerprint}",
                ),
                **snapshot.metadata(),
            }
        operations, mapping = self._artifact_ops(workspace, artifact_type)
        return paginate(
            list(getattr(operations, mapping[1])()),
            limit,
            continuation,
            f"artifacts:{workspace}:{artifact_type}",
        )

    def get_artifact(
        self,
        workspace: str,
        artifact_type: str,
        name: str,
        source: ArtifactSource = "git",
        branch: str | None = None,
        repository_backend: RepositoryBackend | None = None,
    ) -> dict[str, Any]:
        """Read Git JSON by default; source=live requires allow_live_env. Secrets are redacted."""
        self._artifact_source(workspace, source)
        if source == "git":
            return bounded_result(
                self._git_snapshot(workspace, branch, repository_backend).get(artifact_type, name)
            )
        return bounded_result(self._get_artifact(workspace, artifact_type, name))

    def search_artifacts(
        self,
        workspace: str,
        text: str,
        artifact_types: list[str] | None = None,
        case_sensitive: bool = False,
        limit: int = 100,
        source: ArtifactSource = "git",
        branch: str | None = None,
        repository_backend: RepositoryBackend | None = None,
    ) -> dict[str, Any]:
        """Find artifacts referencing a table, path, parameter or literal string."""
        if not text or not 1 <= limit <= 1000:
            raise ValueError("Supply search text and a valid limit")
        matches = []
        self._artifact_source(workspace, source)
        snapshot = (
            self._git_snapshot(workspace, branch, repository_backend) if source == "git" else None
        )
        needle = text if case_sensitive else text.casefold()
        for kind in artifact_types or list(LAYOUT if snapshot else ARTIFACTS):
            if snapshot:
                artifacts = snapshot.list(kind)
            else:
                operations, mapping = self._artifact_ops(workspace, kind)
                artifacts = getattr(operations, mapping[1])()
            for artifact in artifacts:
                definition = redact(artifact)
                encoded = json.dumps(definition, ensure_ascii=False)
                haystack = encoded if case_sensitive else encoded.casefold()
                if needle in haystack:
                    position = haystack.index(needle)
                    matches.append(
                        {
                            "type": kind,
                            "name": field(definition, "name"),
                            "snippet": encoded[max(0, position - 100) : position + len(text) + 100],
                        }
                    )
                    if len(matches) >= limit:
                        return bounded_result({"matches": matches, "truncated": True})
        return bounded_result({"matches": matches, "truncated": False})

    def analyze_pipeline(
        self,
        workspace: str,
        pipeline: str,
        recursive: bool = True,
        max_depth: int = 10,
        source: ArtifactSource = "git",
        branch: str | None = None,
        repository_backend: RepositoryBackend | None = None,
    ) -> dict[str, Any]:
        """Analyze activity dependencies and artifact references, including nested ExecutePipeline
        activities.
        """
        if not 0 <= max_depth <= 20:
            raise ValueError("max_depth must be between 0 and 20")
        seen = set()
        self._artifact_source(workspace, source)
        snapshot = (
            self._git_snapshot(workspace, branch, repository_backend) if source == "git" else None
        )

        def read(kind, name):
            return (
                snapshot.get(kind, name) if snapshot else self._get_artifact(workspace, kind, name)
            )

        def analyze(name, depth):
            if name in seen:
                return {"name": name, "cycle_or_repeated_reference": True}
            if len(seen) >= 100:
                return {"name": name, "truncated": True}
            seen.add(name)
            definition = read("pipeline", name)
            properties = definition.get("properties", definition)
            nodes, edges = [], []

            def activities(items, prefix=""):
                for activity in items:
                    activity_name = prefix + activity["name"]
                    nodes.append({"name": activity_name, "type": activity.get("type")})
                    for dependency in field(activity, "dependsOn", []):
                        edges.append(
                            {
                                "from": prefix + dependency["activity"],
                                "to": activity_name,
                                "conditions": field(dependency, "dependencyConditions", []),
                            }
                        )
                    typed = field(activity, "typeProperties", {})
                    for key in (
                        "activities",
                        "ifTrueActivities",
                        "ifFalseActivities",
                        "defaultActivities",
                    ):
                        activities(field(typed, key, []), activity_name + "/")
                    for case in typed.get("cases", []):
                        activities(case.get("activities", []), activity_name + "/")

            activities(properties.get("activities", []))
            refs = references(properties)
            # Resolve linked services referenced indirectly through datasets.
            linked = set(refs["linked_services"])
            for dataset in refs["datasets"]:
                try:
                    linked.update(references(read("dataset", dataset))["linked_services"])
                except ResourceNotFoundError:
                    pass
            refs["linked_services"] = sorted(linked)
            result = {
                "name": name,
                "parameters": properties.get("parameters", {}),
                "activities": nodes,
                "edges": edges,
                "references": refs,
            }
            if recursive and depth < max_depth:
                result["child_pipelines"] = [
                    analyze(child, depth + 1) for child in refs["pipelines"]
                ]
            elif recursive and refs["pipelines"]:
                result["truncated"] = True
            return result

        return bounded_result(analyze(pipeline, 0))

    def upsert_artifact(
        self,
        workspace: str,
        artifact_type: str,
        name: str,
        artifact: dict[str, Any],
        dry_run: bool = True,
        source: ArtifactSource = "git",
        branch: str | None = None,
        repository_backend: RepositoryBackend | None = None,
        expected_revision: str | None = None,
    ) -> dict[str, Any]:
        """Edit feature-branch JSON (allow_git_write); defaults to dry-run. GitHub edits commit.
        Explicit source=live requires allow_live_env and allow_manage and bypasses Git.
        """
        self._artifact_source(workspace, source)
        if source == "git":
            return self._edit_git_artifact(
                workspace,
                artifact_type,
                name,
                artifact,
                branch,
                repository_backend,
                expected_revision,
                dry_run,
            )
        settings = self.workspace(workspace, "artifacts")
        require(settings, "allow_manage")
        operations, mapping = self._artifact_ops(workspace, artifact_type)
        try:
            old = self._get_artifact(workspace, artifact_type, name)
        except ResourceNotFoundError:
            old = {}
        diff = "\n".join(
            difflib.unified_diff(
                json.dumps(redact(old), indent=2, sort_keys=True).splitlines(),
                json.dumps(redact(artifact), indent=2, sort_keys=True).splitlines(),
                fromfile="current",
                tofile="proposed",
            )
        )
        warning = "Edits target the live workspace and bypass its git repository."
        plan = planned_action(
            "upsert_artifact",
            dry_run,
            workspace=workspace,
            type=artifact_type,
            name=name,
            diff=diff,
            warning=warning,
        )
        if plan:
            return bounded_result(plan)
        if artifact_type == "library":
            content = base64.b64decode(artifact["content_base64"], validate=True)
            wait_operation(operations.begin_create(name))
            operations.append("append", name, BytesIO(content))
            result = wait_operation(operations.begin_flush(name))
        else:
            from azure.synapse.artifacts import models

            body = getattr(models, mapping[5]).deserialize(artifact)
            result = wait_operation(getattr(operations, mapping[3])(name, body))
        return bounded_result({"artifact": result, "warning": warning})

    def delete_artifact(
        self,
        workspace: str,
        artifact_type: str,
        name: str,
        dry_run: bool = True,
        source: ArtifactSource = "git",
        branch: str | None = None,
        repository_backend: RepositoryBackend | None = None,
        expected_revision: str | None = None,
    ) -> dict[str, Any]:
        """Delete feature-branch JSON; source=live requires allow_live_env and allow_manage."""
        self._artifact_source(workspace, source)
        if source == "git":
            return self._edit_git_artifact(
                workspace,
                artifact_type,
                name,
                None,
                branch,
                repository_backend,
                expected_revision,
                dry_run,
            )
        require(self.workspace(workspace, "artifacts"), "allow_manage")
        plan = planned_action(
            "delete_artifact", dry_run, workspace=workspace, type=artifact_type, name=name
        )
        if plan:
            return plan
        operations, mapping = self._artifact_ops(workspace, artifact_type)
        return bounded_result(
            {"deleted": True, "result": wait_operation(getattr(operations, mapping[4])(name))}
        )

    def _edit_git_artifact(self, workspace, kind, name, value, branch, backend, expected, dry_run):
        require(self.workspace(workspace, "artifacts"), "allow_git_write")
        if not branch:
            raise ValueError("Specify the feature branch explicitly for Git writes")
        repository = self.repository(workspace, backend)
        repository.writable(branch)
        snapshot = repository.snapshot(branch)
        path = artifact_path(kind, name, repository.config.artifact_root)
        encoded = repository.changes({path: value})[path]
        if value is None and path not in snapshot.files:
            raise FileNotFoundError("Git artifact not found: " + path)
        diff = "\n".join(
            difflib.unified_diff(
                safe_lines(snapshot.files.get(path)),
                safe_lines(encoded),
                fromfile="current/" + path,
                tofile="proposed/" + path,
            )
        )
        if dry_run:
            return bounded_result({"dry_run": True, "diff": diff, **snapshot.metadata()})
        if not expected:
            raise ValueError("expected_revision is required; use the revision from the dry-run")
        return bounded_result(repository.edit(branch, kind, name, value, expected))
