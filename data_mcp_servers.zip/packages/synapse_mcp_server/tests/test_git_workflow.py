import base64
import json
import subprocess

import httpx
import pytest
from synapse_mcp_server.branch_package import build_package
from synapse_mcp_server.config import (
    BranchTestProfile,
    RepositoryConfig,
    WorkspaceConfig,
)
from synapse_mcp_server.repository import (
    GitHubRepository,
    LocalRepository,
    RevisionConflict,
    artifact_path,
    branch_name,
)

from .conftest import git, write_artifact


def test_git_default_and_uncommitted_snapshot(repo_service):
    service, root, _, clients = repo_service
    first = service.list_artifacts("dev")
    write_artifact(root, "pipeline", "P", {"activities": [], "description": "uncommitted"})
    assert (
        service.get_artifact("dev", "pipeline", "P")["properties"]["description"] == "uncommitted"
    )
    second = service.list_artifacts("dev")
    assert first["content_fingerprint"] != second["content_fingerprint"]
    assert second["uncommitted"]
    assert service.search_artifacts("dev", "uncommitted")["matches"][0]["name"] == "P"
    with pytest.raises(FileNotFoundError, match="no live fallback"):
        service.get_artifact("dev", "pipeline", "Missing")
    with pytest.raises(ValueError, match="unsupported"):
        service.list_artifacts("dev", "library")
    clients.get.assert_not_called()


@pytest.mark.parametrize("branch", ["main", "workspace_publish", "release"])
def test_protected_branches_cannot_mutate_even_with_live_access(repo_service, branch):
    service, _, settings, _ = repo_service
    settings.allow_live_env = settings.allow_manage = True
    repository = service.repository("dev")
    revision = repository.resolve(branch)
    calls = [
        lambda: service.upsert_artifact("dev", "pipeline", "P", {"properties": {}}, branch=branch),
        lambda: repository.commit(branch, revision, "bad"),
        lambda: repository.push(branch, revision, ""),
        lambda: repository.create_branch(branch, "feature", revision),
    ]
    for call in calls:
        with pytest.raises(PermissionError, match="Protected"):
            call()


def test_isolated_worktree_and_commit_preserve_user_changes(repo_service):
    service, root, _, _ = repo_service
    repository = service.repository("dev")
    revision = repository.resolve("feature")
    service.create_git_branch("dev", "other", revision, base_branch="feature", dry_run=False)
    (root / "notes.txt").write_text("unrelated staged")
    git(root, "add", "notes.txt")
    (root / "notes.txt").write_text("unrelated unstaged")
    status = git(root, "status", "--porcelain")
    service.upsert_artifact(
        "dev",
        "pipeline",
        "Other",
        {"name": "Other", "properties": {"activities": []}},
        branch="other",
        expected_revision=revision,
        dry_run=False,
    )
    assert git(root, "branch", "--show-current") == "feature"
    assert git(root, "status", "--porcelain") == status
    assert service.get_artifact("dev", "pipeline", "Other", branch="other")["name"] == "Other"
    result = service.commit_git_branch("dev", "other", revision, "Add pipeline", dry_run=False)
    assert result["revision"] != revision
    assert git(root, "show", "other:notes.txt") == "original"
    assert git(root, "status", "--porcelain") == status


def test_commit_current_branch_preserves_unrelated_index_and_rejects_stale_head(repo_service):
    service, root, _, _ = repo_service
    repository = service.repository("dev")
    revision = repository.resolve("feature")
    (root / "notes.txt").write_text("staged")
    git(root, "add", "notes.txt")
    (root / "notes.txt").write_text("unstaged")
    write_artifact(root, "pipeline", "P", {"activities": [], "description": "changed"})
    service.commit_git_branch("dev", "feature", revision, "Change P", dry_run=False)
    assert git(root, "show", "HEAD:notes.txt") == "original"
    assert git(root, "show", ":notes.txt") == "staged"
    assert (root / "notes.txt").read_text() == "unstaged"
    assert git(root, "diff", "--cached", "--name-only") == "notes.txt"
    with pytest.raises(RevisionConflict):
        service.commit_git_branch("dev", "feature", revision, "stale", dry_run=False)


def test_local_delete_and_expected_push(repo_service, tmp_path):
    service, root, _, _ = repo_service
    repository = service.repository("dev")
    revision = repository.resolve("feature")
    remote = tmp_path / "remote.git"
    subprocess.check_call(["git", "init", "--bare", "-q", str(remote)])
    git(root, "remote", "add", "origin", str(remote))
    service.push_git_branch("dev", "feature", revision, "", dry_run=False)
    service.delete_artifact(
        "dev", "pipeline", "P", branch="feature", expected_revision=revision, dry_run=False
    )
    committed = service.commit_git_branch("dev", "feature", revision, "Delete P", dry_run=False)
    with pytest.raises(RevisionConflict):
        service.push_git_branch("dev", "feature", committed["revision"], "", dry_run=False)
    service.push_git_branch("dev", "feature", committed["revision"], revision, dry_run=False)
    assert git(remote, "rev-parse", "refs/heads/feature") == committed["revision"]


@pytest.mark.parametrize("name", ["../P", "P/child", "P\\child", "%2e%2e", "P\nother", ":P"])
def test_artifact_path_boundaries(name):
    with pytest.raises(ValueError):
        artifact_path("pipeline", name)


@pytest.mark.parametrize(
    "name", ["-x", "main~1", "refs/heads/main", "a..b", "a@{1}", "a.lock", "../x"]
)
def test_literal_branch_names(name):
    with pytest.raises(ValueError):
        branch_name(name)


def test_symlinks_and_snapshot_race_are_rejected(repo_service, monkeypatch, tmp_path):
    service, root, _, _ = repo_service
    outside = tmp_path / "secret.json"
    outside.write_text('{"properties":{}}')
    (root / "pipeline/P.json").unlink()
    (root / "pipeline/P.json").symlink_to(outside)
    with pytest.raises(PermissionError):
        service.list_artifacts("dev")
    (root / "pipeline/P.json").unlink()
    write_artifact(root, "pipeline", "P", {"activities": []})
    repository = service.repository("dev")
    original = repository._working_files
    count = 0

    def changing(checkout):
        nonlocal count
        count += 1
        files = original(checkout)
        files["pipeline/P.json"] += str(count).encode()
        return files

    monkeypatch.setattr(repository, "_working_files", changing)
    with pytest.raises(RevisionConflict, match="capturing"):
        repository.snapshot("feature")


def test_snapshot_packages_dependencies_and_profile_without_editing_files(repo_service):
    service, root, settings, _ = repo_service
    write_artifact(
        root,
        "pipeline",
        "P",
        {
            "activities": [
                {
                    "name": "Child",
                    "type": "ExecutePipeline",
                    "typeProperties": {
                        "pipeline": {"type": "PipelineReference", "referenceName": "Child"}
                    },
                }
            ],
            "parameters": {"date": {"type": "string"}},
        },
    )
    write_artifact(
        root,
        "pipeline",
        "Child",
        {
            "activities": [
                {
                    "name": "Notebook",
                    "type": "SynapseNotebook",
                    "typeProperties": {
                        "notebook": {"type": "NotebookReference", "referenceName": "N"}
                    },
                },
                {
                    "name": "Flow",
                    "type": "ExecuteDataFlow",
                    "typeProperties": {
                        "dataflow": {"type": "DataFlowReference", "referenceName": "F"}
                    },
                },
            ]
        },
    )
    write_artifact(
        root,
        "notebook",
        "N",
        {"bigDataPool": {"type": "BigDataPoolReference", "referenceName": "prod"}, "cells": []},
    )
    write_artifact(
        root,
        "data_flow",
        "F",
        {
            "type": "MappingDataFlow",
            "typeProperties": {
                "sources": [{"dataset": {"type": "DatasetReference", "referenceName": "D"}}]
            },
        },
    )
    write_artifact(
        root,
        "dataset",
        "D",
        {
            "type": "Json",
            "linkedServiceName": {"type": "LinkedServiceReference", "referenceName": "L"},
        },
    )
    write_artifact(root, "linked_service", "L", {"type": "AzureBlobStorage", "typeProperties": {}})
    profile = BranchTestProfile(
        parameters={"date": "today"},
        spark_pools=["dev"],
        integration_runtimes=["AutoResolveIntegrationRuntime"],
        artifact_overrides={"notebook/N": {"bigDataPool": {"referenceName": "dev"}}},
    )
    snapshot = service.repository("dev").snapshot("feature")
    package = build_package(snapshot, "P", "dev", profile)
    assert set(package.order) == {
        "pipeline/P",
        "pipeline/Child",
        "notebook/N",
        "data_flow/F",
        "dataset/D",
        "linked_service/L",
    }
    assert package.parameters == {"date": "today"}
    assert snapshot.get("notebook", "N")["properties"]["bigDataPool"]["referenceName"] == "prod"
    assert package.artifacts["notebook/N"]["properties"]["bigDataPool"]["referenceName"] == "dev"
    names, definitions, _ = package.stage("abc")
    assert (
        definitions["pipeline/P"]["properties"]["activities"][0]["typeProperties"]["pipeline"][
            "referenceName"
        ]
        == names["pipeline/Child"]
    )
    assert package.order.index("linked_service/L") < package.order.index("data_flow/F")
    assert LocalRepository(settings).snapshot("feature").fingerprint == snapshot.fingerprint


@pytest.mark.parametrize(
    "reference,match",
    [
        (
            {"type": "NotebookReference", "referenceName": "@pipeline().parameters.name"},
            "Parameterized notebook",
        ),
        ({"type": "PipelineReference", "referenceName": "Missing"}, "no live fallback"),
        ({"type": "CredentialReference", "referenceName": "published"}, "Unsupported"),
        ({"type": "BigDataPoolReference", "referenceName": "prod"}, "not permitted"),
    ],
)
def test_package_rejects_unresolved_references_before_clients(repo_service, reference, match):
    service, root, settings, clients = repo_service
    write_artifact(root, "pipeline", "P", {"activities": [], "test": reference})
    with pytest.raises((ValueError, PermissionError, FileNotFoundError), match=match):
        service.run_branch_pipeline("dev", "P", "feature")
    clients.get.assert_not_called()


def test_github_snapshot_pins_blobs_and_commit_uses_atomic_expected_head(tmp_path):
    calls = []
    definition = {"name": "P", "properties": {"activities": []}}

    def handler(request):
        calls.append(request)
        path = request.url.path
        if path.endswith("/git/ref/heads/feature"):
            return httpx.Response(200, json={"object": {"sha": "a" * 40}})
        if "/git/trees/" in path:
            assert path.endswith("a" * 40)
            return httpx.Response(
                200,
                json={
                    "tree": [
                        {
                            "path": "pipeline/P.json",
                            "type": "blob",
                            "mode": "100644",
                            "sha": "b" * 40,
                        }
                    ]
                },
            )
        if "/git/blobs/" in path:
            return httpx.Response(
                200,
                json={
                    "encoding": "base64",
                    "content": base64.b64encode(json.dumps(definition).encode()).decode(),
                },
            )
        if path == "/graphql":
            body = json.loads(request.content)
            assert body["variables"]["input"]["expectedHeadOid"] == "a" * 40
            return httpx.Response(
                200,
                json={
                    "data": {
                        "createCommitOnBranch": {
                            "commit": {"oid": "c" * 40, "url": "https://example.invalid/commit"}
                        }
                    }
                },
            )
        raise AssertionError(str(request.url))

    settings = WorkspaceConfig(
        name="example",
        allow_git_write=True,
        repository=RepositoryConfig(github_repository="org/repo", github_token="test-token"),
    )
    with httpx.Client(
        base_url="https://api.github.com", transport=httpx.MockTransport(handler)
    ) as client:
        repository = GitHubRepository(settings, client)
        snapshot = repository.snapshot("feature")
        assert snapshot.get("pipeline", "P") == definition
        assert (
            repository.commit("feature", "a" * 40, "edit", {"pipeline/P.json": definition})[
                "revision"
            ]
            == "c" * 40
        )
        with pytest.raises(RevisionConflict):
            repository.commit("feature", "d" * 40, "stale", {"pipeline/P.json": definition})
        assert len([r for r in calls if r.method == "POST"]) == 1


def test_github_rejects_truncated_tree_and_graphql_conflict():
    settings = WorkspaceConfig(
        name="example",
        allow_git_write=True,
        repository=RepositoryConfig(github_repository="org/repo", github_token="secret"),
    )

    def handler(request):
        if request.url.path == "/graphql":
            return httpx.Response(200, json={"errors": [{"message": "expected head changed"}]})
        if "/git/ref/" in request.url.path:
            return httpx.Response(200, json={"object": {"sha": "a" * 40}})
        return httpx.Response(200, json={"tree": [], "truncated": True})

    with httpx.Client(
        base_url="https://api.github.com", transport=httpx.MockTransport(handler)
    ) as client:
        repository = GitHubRepository(settings, client)
        with pytest.raises(ValueError, match="truncated"):
            repository.snapshot("feature")
        with pytest.raises(RevisionConflict):
            repository.commit(
                "feature", "a" * 40, "update", {"pipeline/P.json": {"properties": {}}}
            )


def test_scoped_commit_preserves_other_staged_artifacts(repo_service):
    service, root, _, _ = repo_service
    repository = service.repository("dev")
    expected = repository.resolve("feature")
    write_artifact(root, "pipeline", "Unrelated", {"activities": []})
    git(root, "add", "pipeline/Unrelated.json")
    write_artifact(root, "pipeline", "P", {"activities": [], "description": "edit"})
    result = service.commit_git_branch(
        "dev", "feature", expected, "Change only P", paths=["pipeline/P.json"], dry_run=False
    )
    assert result["paths"] == ["pipeline/P.json"]
    assert git(root, "diff", "--cached", "--name-only") == "pipeline/Unrelated.json"


def test_diffs_never_embed_unregistered_artifact_secrets(repo_service):
    service, root, _, _ = repo_service
    secret = "unregistered-private-artifact-value"
    body = {
        "name": "Service",
        "properties": {
            "type": "AzureBlobStorage",
            "typeProperties": {"connectionString": {"type": "SecureString", "value": secret}},
        },
    }
    planned = service.upsert_artifact("dev", "linked_service", "Service", body, branch="feature")
    assert secret not in json.dumps(planned)
    write_artifact(root, "linked_service", "Service", body["properties"])
    assert secret not in json.dumps(service.diff_git_branch("dev", "feature"))


def test_artifact_root_isolation_and_no_git_write_permission(repo_service):
    service, root, settings, clients = repo_service
    settings.repository.artifact_root = "synapse"
    write_artifact(root / "synapse", "pipeline", "Scoped", {"activities": []})
    assert [v["name"] for v in service.list_artifacts("dev")["items"]] == ["Scoped"]
    settings.allow_git_write = False
    with pytest.raises(PermissionError, match="allow_git_write"):
        service.upsert_artifact("dev", "pipeline", "Scoped", {"properties": {}}, branch="feature")
    clients.get.assert_not_called()


def test_github_branch_creation_and_explicit_draft_pr(repo_service):
    service, root, settings, _ = repo_service
    settings.repository.github_repository = "org/repo"
    settings.repository.github_token = "unused-with-injected-client"
    snapshot = service.repository("dev").snapshot("feature")
    requests = []

    def handler(request):
        requests.append(request)
        if request.method == "GET" and "/git/ref/" in request.url.path:
            return httpx.Response(200, json={"object": {"sha": snapshot.commit}})
        if request.url.path.endswith("/git/refs"):
            assert json.loads(request.content)["ref"] == "refs/heads/new"
            return httpx.Response(201, json={})
        if "/git/trees/" in request.url.path:
            return httpx.Response(
                200,
                json={
                    "tree": [
                        {"path": path, "mode": "100644", "type": "blob", "sha": "blob"}
                        for path in snapshot.files
                    ]
                },
            )
        if "/git/blobs/" in request.url.path:
            return httpx.Response(
                200,
                json={
                    "encoding": "base64",
                    "content": base64.b64encode(snapshot.files["pipeline/P.json"]).decode(),
                },
            )
        if request.url.path.endswith("/pulls"):
            body = json.loads(request.content)
            assert body["draft"] and body["base"] == "main" and body["head"] == "feature"
            return httpx.Response(
                201, json={"number": 1, "html_url": "https://example.invalid/pr/1"}
            )
        raise AssertionError(request.url)

    repository = GitHubRepository(
        settings,
        httpx.Client(base_url="https://api.github.com", transport=httpx.MockTransport(handler)),
    )
    service._repositories["dev", "github"] = repository
    service.prepare_git_pr("dev", "feature", "Prepare")
    assert requests == []
    repository.create_branch("new", "feature", snapshot.commit)
    result = service.create_draft_pr("dev", "feature", snapshot.commit, "Draft")
    assert result["draft"] and not result["has_matching_successful_test"]
    with pytest.raises(RevisionConflict):
        service.create_draft_pr("dev", "feature", "stale", "Draft")
    assert len([r for r in requests if r.url.path.endswith("/pulls")]) == 1
