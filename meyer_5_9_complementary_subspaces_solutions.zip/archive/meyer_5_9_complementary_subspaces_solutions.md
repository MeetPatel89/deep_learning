---
title: "Meyer Section 5.9: Complementary Subspaces"
subtitle: "Detailed Solutions to Exercises 5.9.1--5.9.20"
author: "Study edition"
date: ""
geometry: "margin=0.85in"
fontsize: 10pt
linestretch: 1.08
header-includes:
  - \usepackage{amsmath,amssymb,mathtools}
  - \usepackage{booktabs,longtable,array}
  - \usepackage{microtype}
  - \usepackage{fancyhdr}
  - \usepackage{enumitem}
  - \allowdisplaybreaks
  - \pagestyle{fancy}
  - \fancyhf{}
  - \lhead{\small Meyer 5.9}
  - \rhead{\small Complementary Subspaces}
  - \cfoot{\thepage}
  - \setlength{\headheight}{14pt}
  - \setlist[itemize]{topsep=3pt,itemsep=2pt}
  - \setlist[enumerate]{topsep=3pt,itemsep=2pt}
---

# Meyer Section 5.9: Complementary Subspaces

**Source section:** Carl D. Meyer, *Matrix Analysis and Applied Linear Algebra*, Section 5.9, “Complementary Subspaces.”

**Exercise range:** 5.9.1--5.9.20, with every numbered exercise included.

**Copyright note.** The exercise statements below are restated only briefly. The mathematical data needed for each solution are retained, but the textbook wording is not reproduced at length.

**Notation.** We follow Meyer: \(R(P)\) and \(N(P)\) denote the range and nullspace of \(P\); \(V=X\oplus Y\) means \(V=X+Y\) and \(X\cap Y=\{0\}\); a projector satisfies \(P^2=P\).

## Source-quality notes

Two details in the printed exercise block require explicit care.

1. In Exercise 5.9.10, the equality
   \[
   \|I-uv^T\|_2=\|uv^T\|_2
   \]
   is correct for the intended nontrivial case \(n\ge 2\). For \(n=1\), the condition \(v^Tu=1\) forces \(uv^T=I_1\), so the left side is \(0\) and the right side is \(1\). The solution below proves the intended \(n\ge2\) result and records the one-dimensional exception.
2. In Exercise 5.9.15, the printed lower-right block uses \(A_{12}\). Since the lower-right block must be \((n-r)\times(n-r)\), and since \(Q^{-1}AQ\) is partitioned with lower-right block \(A_{22}\), the dimensionally consistent statement is
   \[
   Q\begin{bmatrix}0&0\\0&A_{22}\end{bmatrix}Q^{-1}
   =(I-P)A(I-P).
   \]
   That is the statement proved below.

## Table of contents

1. Exercises 5.9.1--5.9.4: constructing complements and projections  
2. Exercises 5.9.5--5.9.7: independence, fixed points, range, and nullspace  
3. Exercises 5.9.8--5.9.10: norms of projectors and rank-one projectors  
4. Exercises 5.9.11--5.9.13: coordinate algorithms and projector identities  
5. Exercises 5.9.14--5.9.16: multiple direct sums, block operators, and full-rank factorizations  
6. Exercises 5.9.17--5.9.19: sums, differences, and products of projectors  
7. Exercise 5.9.20: inner, outer, and reflexive pseudoinverses  
8. Appendix: recurring facts from Section 5.9

## Section summary: the core ideas

For subspaces \(X,Y\subseteq V\),

\[
V=X\oplus Y
\quad\Longleftrightarrow\quad
V=X+Y\ \text{and}\ X\cap Y=\{0\}.
\]

Equivalently, every \(v\in V\) has a unique decomposition

\[
v=x+y,\qquad x\in X,\quad y\in Y.
\]

The projector onto \(X\) along \(Y\) is the linear map \(P\) defined by

\[
P(x+y)=x.
\]

Its complementary projector is \(I-P\), which projects onto \(Y\) along \(X\). The central identities are

\[
P^2=P,\qquad
R(P)=X,\qquad
N(P)=Y,
\]
\[
R(I-P)=Y,\qquad
N(I-P)=X.
\]

If the columns of \(X\) and \(Y\) are bases for the corresponding subspaces, then \(B=[X\mid Y]\) is nonsingular and

\[
P=[X\mid 0][X\mid Y]^{-1}
=
B
\begin{bmatrix}
I&0\\
0&0
\end{bmatrix}
B^{-1}.
\]

These formulas are the organizing tools for nearly every exercise in this set.

\newpage

## Exercise 5.9.1

### Brief restatement

Let

\[
x_1=\begin{bmatrix}1\\1\\1\end{bmatrix},
\qquad
x_2=\begin{bmatrix}1\\2\\2\end{bmatrix},
\qquad
y=\begin{bmatrix}1\\2\\3\end{bmatrix},
\]

with \(B_X=\{x_1,x_2\}\) and \(B_Y=\{y\}\). Verify that \(X\) and \(Y\) complement one another in \(\mathbb R^3\), compute the two complementary projectors, project

\[
v=\begin{bmatrix}2\\-1\\1\end{bmatrix}
\]

onto \(Y\) along \(X\), and verify the projector identities.

### Relevant ideas

If the concatenated basis matrix

\[
B=[X\mid Y]
\]

is nonsingular, then \(B_X\cup B_Y\) is a basis for \(\mathbb R^3\), so \(\mathbb R^3=X\oplus Y\). The projector formulas are

\[
P=[X\mid 0]B^{-1},
\qquad
Q=I-P=[0\mid Y]B^{-1}.
\]

### Strategy

1. Show that \(B=[x_1\mid x_2\mid y]\) is nonsingular.
2. Compute \(B^{-1}\).
3. Use the projector formulas.
4. Use \(Qv\) for the requested projection.
5. Verify idempotence and the range/nullspace descriptions.

### Solution

#### (a) Complementarity

Form

\[
B=[x_1\mid x_2\mid y]
=
\begin{bmatrix}
1&1&1\\
1&2&2\\
1&2&3
\end{bmatrix}.
\]

Its determinant is

\[
\begin{aligned}
\det B
&=
1\begin{vmatrix}2&2\\2&3\end{vmatrix}
-
1\begin{vmatrix}1&2\\1&3\end{vmatrix}
+
1\begin{vmatrix}1&2\\1&2\end{vmatrix}\\
&=(6-4)-(3-2)+(2-2)\\
&=2-1+0\\
&=1.
\end{aligned}
\]

Thus \(B\) is nonsingular. Its three columns form a basis for \(\mathbb R^3\). Since the first two columns form a basis for \(X\) and the third forms a basis for \(Y\), every vector has a unique representation as an \(X\)-component plus a \(Y\)-component. Hence

\[
\boxed{\mathbb R^3=X\oplus Y.}
\]

#### (b) The projectors \(P\) and \(Q\)

A direct calculation gives

\[
B^{-1}
=
\begin{bmatrix}
2&-1&0\\
-1&2&-1\\
0&-1&1
\end{bmatrix}.
\]

The projector onto \(X\) along \(Y\) is

\[
\begin{aligned}
P
&=[X\mid 0]B^{-1}\\
&=
\begin{bmatrix}
1&1&0\\
1&2&0\\
1&2&0
\end{bmatrix}
\begin{bmatrix}
2&-1&0\\
-1&2&-1\\
0&-1&1
\end{bmatrix}\\
&=
\begin{bmatrix}
1&1&-1\\
0&3&-2\\
0&3&-2
\end{bmatrix}.
\end{aligned}
\]

The complementary projector onto \(Y\) along \(X\) is

\[
\begin{aligned}
Q
&=I-P\\
&=
\begin{bmatrix}
1&0&0\\
0&1&0\\
0&0&1
\end{bmatrix}
-
\begin{bmatrix}
1&1&-1\\
0&3&-2\\
0&3&-2
\end{bmatrix}\\
&=
\begin{bmatrix}
0&-1&1\\
0&-2&2\\
0&-3&3
\end{bmatrix}.
\end{aligned}
\]

Therefore,

\[
\boxed{
P=
\begin{bmatrix}
1&1&-1\\
0&3&-2\\
0&3&-2
\end{bmatrix},
\qquad
Q=
\begin{bmatrix}
0&-1&1\\
0&-2&2\\
0&-3&3
\end{bmatrix}.
}
\]

#### Coordinate interpretation

Because

\[
B^{-1}v
=
\begin{bmatrix}
2&-1&0\\
-1&2&-1\\
0&-1&1
\end{bmatrix}
\begin{bmatrix}2\\-1\\1\end{bmatrix}
=
\begin{bmatrix}5\\-5\\2\end{bmatrix},
\]

we have the direct-sum decomposition

\[
v=5x_1-5x_2+2y.
\]

The first two terms constitute the \(X\)-component, and the last term is the \(Y\)-component.

#### (c) Projection of \(v\) onto \(Y\) along \(X\)

Use \(Q\):

\[
\begin{aligned}
Qv
&=
\begin{bmatrix}
0&-1&1\\
0&-2&2\\
0&-3&3
\end{bmatrix}
\begin{bmatrix}2\\-1\\1\end{bmatrix}\\
&=
\begin{bmatrix}
2\\4\\6
\end{bmatrix}
=
2\begin{bmatrix}1\\2\\3\end{bmatrix}.
\end{aligned}
\]

Thus

\[
\boxed{\operatorname{proj}_{Y\text{ along }X}(v)=
\begin{bmatrix}2\\4\\6\end{bmatrix}.}
\]

For comparison,

\[
Pv=v-Qv
=
\begin{bmatrix}0\\-5\\-5\end{bmatrix}
=
5x_1-5x_2.
\]

The check

\[
\begin{bmatrix}0\\-5\\-5\end{bmatrix}
+
\begin{bmatrix}2\\4\\6\end{bmatrix}
=
\begin{bmatrix}2\\-1\\1\end{bmatrix}
\]

recovers \(v\).

#### (d) Idempotence

Multiplying \(P\) by itself,

\[
\begin{aligned}
P^2
&=
\begin{bmatrix}
1&1&-1\\
0&3&-2\\
0&3&-2
\end{bmatrix}
\begin{bmatrix}
1&1&-1\\
0&3&-2\\
0&3&-2
\end{bmatrix}\\
&=
\begin{bmatrix}
1&1&-1\\
0&3&-2\\
0&3&-2
\end{bmatrix}\\
&=P.
\end{aligned}
\]

Since \(Q=I-P\) and \(P^2=P\),

\[
\begin{aligned}
Q^2
&=(I-P)^2\\
&=I-2P+P^2\\
&=I-P\\
&=Q.
\end{aligned}
\]

Hence both matrices are idempotent.

#### (e) Ranges and nullspaces

It is useful first to check the action on the basis vectors:

\[
Px_1=x_1,\qquad Px_2=x_2,\qquad Py=0,
\]
\[
Qx_1=0,\qquad Qx_2=0,\qquad Qy=y.
\]

Now every \(z\in\mathbb R^3\) has a unique decomposition

\[
z=a_1x_1+a_2x_2+by.
\]

Therefore,

\[
Pz=a_1x_1+a_2x_2,
\qquad
Qz=by.
\]

It follows immediately that

\[
R(P)=X,\qquad N(P)=Y,
\]
\[
R(Q)=Y,\qquad N(Q)=X.
\]

Equivalently,

\[
\boxed{R(P)=X=N(Q),\qquad N(P)=Y=R(Q).}
\]

> **Final answer.**
> \[
> P=
> \begin{bmatrix}
> 1&1&-1\\
> 0&3&-2\\
> 0&3&-2
> \end{bmatrix},
> \qquad
> Q=
> \begin{bmatrix}
> 0&-1&1\\
> 0&-2&2\\
> 0&-3&3
> \end{bmatrix},
> \]
> \[
> Qv=\begin{bmatrix}2\\4\\6\end{bmatrix},
> \qquad
> P^2=P,\quad Q^2=Q,
> \]
> and
> \[
> R(P)=X=N(Q),\qquad N(P)=Y=R(Q).
> \]

### Learning note

The matrix \(B^{-1}\) converts a vector from standard coordinates into coordinates adapted to the direct sum \(X\oplus Y\). The projector simply keeps one coordinate block and discards the other.

## Exercise 5.9.2

### Brief restatement

Construct two nonzero proper subspaces of \(\mathbb R^5\) whose direct sum is all of \(\mathbb R^5\).

### Strategy

Split the standard basis into two nonempty groups.

### Solution

Let \(e_1,\ldots,e_5\) be the standard basis of \(\mathbb R^5\), and define

\[
X=\operatorname{span}\{e_1,e_2\},
\qquad
Y=\operatorname{span}\{e_3,e_4,e_5\}.
\]

Both subspaces are nontrivial:

\[
\dim X=2,\qquad \dim Y=3,
\]

so neither is \(\{0\}\), and neither is all of \(\mathbb R^5\).

Every vector

\[
v=
\begin{bmatrix}
v_1\\v_2\\v_3\\v_4\\v_5
\end{bmatrix}
\]

can be written as

\[
v=
\underbrace{
\begin{bmatrix}
v_1\\v_2\\0\\0\\0
\end{bmatrix}}_{\in X}
+
\underbrace{
\begin{bmatrix}
0\\0\\v_3\\v_4\\v_5
\end{bmatrix}}_{\in Y}.
\]

Thus \(X+Y=\mathbb R^5\).

If \(z\in X\cap Y\), then \(z\in X\) forces its last three coordinates to be zero, while \(z\in Y\) forces its first two coordinates to be zero. Hence \(z=0\), so

\[
X\cap Y=\{0\}.
\]

Therefore,

\[
\boxed{\mathbb R^5=X\oplus Y.}
\]

> **Final answer.**
> One valid pair is
> \[
> X=\operatorname{span}\{e_1,e_2\},
> \qquad
> Y=\operatorname{span}\{e_3,e_4,e_5\}.
> \]

## Exercise 5.9.3

### Brief restatement

Give an example showing that if \(V=X+Y\) but \(X\cap Y\ne\{0\}\), decomposition into an \(X\)-part and a \(Y\)-part need not be unique.

### Key mechanism

Suppose \(0\ne z\in X\cap Y\), and suppose

\[
v=x+y,\qquad x\in X,\ y\in Y.
\]

Because \(z\in X\) and \(z\in Y\),

\[
v=(x+z)+(y-z)
\]

is another valid decomposition. Since \(z\ne0\), the two components change.

### Explicit example

Take

\[
V=\mathbb R^2,\qquad
X=\operatorname{span}\{e_1\},\qquad
Y=\mathbb R^2.
\]

Then \(X+Y=\mathbb R^2\), but

\[
X\cap Y=X\ne\{0\}.
\]

Choose

\[
v=\begin{bmatrix}2\\1\end{bmatrix}.
\]

Two distinct decompositions are

\[
v=
\underbrace{\begin{bmatrix}1\\0\end{bmatrix}}_{x_1\in X}
+
\underbrace{\begin{bmatrix}1\\1\end{bmatrix}}_{y_1\in Y}
\]

and

\[
v=
\underbrace{\begin{bmatrix}2\\0\end{bmatrix}}_{x_2\in X}
+
\underbrace{\begin{bmatrix}0\\1\end{bmatrix}}_{y_2\in Y}.
\]

The components differ:

\[
x_1\ne x_2,\qquad y_1\ne y_2.
\]

> **Final answer.**
> The example above has \(V=X+Y\) and \(X\cap Y\ne\{0\}\), but the displayed vector \(v\) has two different \(X+Y\) representations.

### Learning note

The condition \(X\cap Y=\{0\}\) is exactly what prevents a nonzero vector from being shifted from one component to the other.

## Exercise 5.9.4

### Brief restatement

Let \(S\) and \(K\) denote the symmetric and skew-symmetric \(n\times n\) real matrices. Prove

\[
\mathbb R^{n\times n}=S\oplus K,
\]

and compute the projection of

\[
A=
\begin{bmatrix}
1&2&3\\
4&5&6\\
7&8&9
\end{bmatrix}
\]

onto \(S\) along \(K\).

### Relevant decomposition

For every real square matrix \(A\),

\[
A=
\frac{A+A^T}{2}
+
\frac{A-A^T}{2}.
\]

### Solution

Define

\[
A_S=\frac{A+A^T}{2},
\qquad
A_K=\frac{A-A^T}{2}.
\]

First,

\[
A_S^T
=
\frac{A^T+A}{2}
=
A_S,
\]

so \(A_S\in S\).

Second,

\[
A_K^T
=
\frac{A^T-A}{2}
=
-\frac{A-A^T}{2}
=
-A_K,
\]

so \(A_K\in K\).

Also,

\[
A_S+A_K
=
\frac{A+A^T+A-A^T}{2}
=
A.
\]

Thus every matrix lies in \(S+K\), so

\[
\mathbb R^{n\times n}=S+K.
\]

To prove the sum is direct, suppose \(M\in S\cap K\). Then

\[
M^T=M
\]

because \(M\) is symmetric, while

\[
M^T=-M
\]

because \(M\) is skew-symmetric. Hence

\[
M=-M,
\]

so \(2M=0\), and therefore \(M=0\). Thus

\[
S\cap K=\{0\}.
\]

Consequently,

\[
\boxed{\mathbb R^{n\times n}=S\oplus K.}
\]

The projection onto \(S\) along \(K\) is the symmetric component:

\[
\operatorname{proj}_{S\text{ along }K}(A)
=
\frac{A+A^T}{2}.
\]

For the given matrix,

\[
A^T=
\begin{bmatrix}
1&4&7\\
2&5&8\\
3&6&9
\end{bmatrix},
\]

so

\[
\begin{aligned}
\frac{A+A^T}{2}
&=
\frac12
\begin{bmatrix}
2&6&10\\
6&10&14\\
10&14&18
\end{bmatrix}\\
&=
\begin{bmatrix}
1&3&5\\
3&5&7\\
5&7&9
\end{bmatrix}.
\end{aligned}
\]

For verification, the skew component is

\[
\frac{A-A^T}{2}
=
\begin{bmatrix}
0&-1&-2\\
1&0&-1\\
2&1&0
\end{bmatrix},
\]

and the two displayed components add to \(A\).

> **Final answer.**
> \[
> \mathbb R^{n\times n}=S\oplus K,
> \qquad
> \operatorname{proj}_{S\text{ along }K}(A)
> =
> \begin{bmatrix}
> 1&3&5\\
> 3&5&7\\
> 5&7&9
> \end{bmatrix}.
> \]

\newpage

## Exercise 5.9.5

### Brief restatement

Let \(B_X=\{x_1,\ldots,x_m\}\) and \(B_Y=\{y_1,\ldots,y_n\}\) be bases for subspaces \(X\) and \(Y\). Relate \(X\cap Y=\{0\}\) to linear independence of the concatenated family, and analyze what ordinary set union does and does not imply.

### (a) Prove the equivalence for the concatenated family

We prove

\[
X\cap Y=\{0\}
\quad\Longleftrightarrow\quad
(x_1,\ldots,x_m,y_1,\ldots,y_n)
\text{ is linearly independent}.
\]

The notation here is a concatenated family: a vector occurring in both bases is counted twice.

#### Forward direction

Assume

\[
X\cap Y=\{0\}.
\]

Suppose

\[
\sum_{i=1}^m\alpha_i x_i
+
\sum_{j=1}^n\beta_j y_j
=0.
\]

Move the \(Y\)-sum to the other side:

\[
\sum_{i=1}^m\alpha_i x_i
=
-\sum_{j=1}^n\beta_j y_j.
\]

The left side belongs to \(X\), and the right side belongs to \(Y\). Therefore their common value lies in \(X\cap Y\). By assumption,

\[
\sum_{i=1}^m\alpha_i x_i=0.
\]

Because \(B_X\) is linearly independent,

\[
\alpha_1=\cdots=\alpha_m=0.
\]

Returning to the original relation gives

\[
\sum_{j=1}^n\beta_j y_j=0.
\]

Because \(B_Y\) is linearly independent,

\[
\beta_1=\cdots=\beta_n=0.
\]

Thus the concatenated family is linearly independent.

#### Reverse direction

Assume the concatenated family is linearly independent. Let \(z\in X\cap Y\). Since \(z\in X\), there are scalars \(\alpha_i\) such that

\[
z=\sum_{i=1}^m\alpha_i x_i.
\]

Since \(z\in Y\), there are scalars \(\beta_j\) such that

\[
z=\sum_{j=1}^n\beta_j y_j.
\]

Subtract:

\[
\sum_{i=1}^m\alpha_i x_i
-
\sum_{j=1}^n\beta_j y_j
=0.
\]

Linear independence of the concatenated family forces every coefficient to be zero. Hence \(z=0\). Therefore

\[
X\cap Y=\{0\}.
\]

So

\[
\boxed{
X\cap Y=\{0\}
\iff
(x_1,\ldots,x_m,y_1,\ldots,y_n)
\text{ is linearly independent}.
}
\]

### (b) Does linear independence of \(B_X\cup B_Y\) imply \(X\cap Y=\{0\}\)?

No. Ordinary set union deletes repeated elements, whereas the concatenated family in part (a) retains them as separate entries.

Take \(V=\mathbb R^3\),

\[
X=\operatorname{span}\{e_1,e_2\},
\qquad
Y=\operatorname{span}\{e_2,e_3\},
\]

with

\[
B_X=\{e_1,e_2\},
\qquad
B_Y=\{e_2,e_3\}.
\]

The set union is

\[
B_X\cup B_Y=\{e_1,e_2,e_3\},
\]

which is linearly independent. However,

\[
X\cap Y=\operatorname{span}\{e_2\}\ne\{0\}.
\]

The duplicated vector \(e_2\) is invisible after ordinary set union, but it is visible in the concatenated family

\[
(e_1,e_2,e_2,e_3),
\]

which is dependent.

Thus

\[
\boxed{\text{No.}}
\]

### (c) If \(B_X\cup B_Y\) is independent, must \(X\) and \(Y\) be complementary?

No. Even if the union is independent, it may fail to span the ambient space.

For example, in \(V=\mathbb R^3\), let

\[
X=\operatorname{span}\{e_1\},
\qquad
Y=\operatorname{span}\{e_2\}.
\]

Then

\[
B_X\cup B_Y=\{e_1,e_2\}
\]

is linearly independent, and \(X\cap Y=\{0\}\). But

\[
X+Y=\operatorname{span}\{e_1,e_2\}
\]

is only the \(xy\)-plane, not all of \(\mathbb R^3\). Hence

\[
\mathbb R^3\ne X\oplus Y.
\]

Therefore,

\[
\boxed{\text{No; independence does not guarantee }X+Y=V.}
\]

> **Final answer.**
> Part (a) holds for the concatenated family. Part (b) is false because ordinary set union can erase shared basis vectors. Part (c) is false because an independent union need not span the ambient space.

### Common pitfall

A *family* or ordered list can contain the same vector twice; a set cannot. The distinction is the entire point of part (b).


## Exercise 5.9.6

### Brief restatement

For a projector \(P\) on a vector space \(V\), prove that its range is exactly its set of fixed points:

\[
R(P)=\{x\in V:Px=x\}.
\]

### Relevant fact

A projector is idempotent:

\[
P^2=P.
\]

### Proof

We prove equality by proving both inclusions.

#### Every fixed point belongs to the range

Suppose \(x\in V\) satisfies

\[
Px=x.
\]

Then \(x\) is explicitly the image under \(P\) of the vector \(x\). Therefore,

\[
x\in R(P).
\]

This proves

\[
\{x\in V:Px=x\}\subseteq R(P).
\]

#### Every vector in the range is a fixed point

Suppose \(x\in R(P)\). By the definition of range, there exists \(y\in V\) such that

\[
x=Py.
\]

Apply \(P\):

\[
Px=P(Py)=P^2y.
\]

Because \(P^2=P\),

\[
Px=Py=x.
\]

Thus \(x\) is a fixed point, proving

\[
R(P)\subseteq\{x\in V:Px=x\}.
\]

Combining the two inclusions,

\[
\boxed{R(P)=\{x\in V:Px=x\}.}
\]

> **Final answer.**
> A vector is in \(R(P)\) exactly when applying \(P\) leaves it unchanged.

### Learning note

For a projector, the range is not merely where outputs land; it is the subspace on which the operator acts as the identity.

## Exercise 5.9.7

### Brief restatement

Suppose \(V=X\oplus Y\), and let \(P\) project onto \(X\) along \(Y\). Prove

\[
R(P)=N(I-P)=X,
\qquad
R(I-P)=N(P)=Y.
\]

### Strategy

Write an arbitrary vector in its unique direct-sum form

\[
v=x+y,\qquad x\in X,\ y\in Y.
\]

Then use

\[
Pv=x,
\qquad
(I-P)v=y.
\]

### Proof

Because \(P\) projects onto \(X\) along \(Y\),

\[
P(x+y)=x.
\]

Similarly,

\[
(I-P)(x+y)
=
x+y-x
=
y.
\]

#### Prove \(R(P)=X\)

For every \(v=x+y\),

\[
Pv=x\in X,
\]

so

\[
R(P)\subseteq X.
\]

Conversely, if \(x\in X\), write \(x=x+0\), where \(0\in Y\). Then

\[
Px=x.
\]

Hence \(x\in R(P)\), so \(X\subseteq R(P)\). Thus

\[
R(P)=X.
\]

#### Prove \(N(P)=Y\)

If \(y\in Y\), then

\[
Py=P(0+y)=0,
\]

so \(Y\subseteq N(P)\).

Conversely, suppose \(v=x+y\in N(P)\). Then

\[
0=Pv=x.
\]

Therefore \(v=y\in Y\), so \(N(P)\subseteq Y\). Hence

\[
N(P)=Y.
\]

#### Prove the identities for \(I-P\)

The operator \(I-P\) sends \(x+y\) to \(y\). Repeating the previous reasoning with \(X\) and \(Y\) interchanged gives

\[
R(I-P)=Y,
\qquad
N(I-P)=X.
\]

One can also connect this directly to Exercise 5.9.6:

\[
\begin{aligned}
v\in N(I-P)
&\iff (I-P)v=0\\
&\iff Pv=v\\
&\iff v\in R(P).
\end{aligned}
\]

Therefore \(N(I-P)=R(P)\). Similarly, \(N(P)=R(I-P)\).

> **Final answer.**
> \[
> \boxed{R(P)=N(I-P)=X,\qquad R(I-P)=N(P)=Y.}
> \]

### Learning note

A projector and its complement exchange range and nullspace. This duality is repeatedly used in the later projector identities.

\newpage

## Exercise 5.9.8

### Brief restatement

Prove that every nonzero projector \(P\) satisfies

\[
\|P\|_2\ge1,
\]

and characterize the equality case.

### Relevant definition

The induced matrix \(2\)-norm is

\[
\|P\|_2
=
\max_{z\ne0}\frac{\|Pz\|_2}{\|z\|_2}.
\]

### Part 1: the lower bound

Because \(P\ne0\), its range contains a nonzero vector \(x\). By Exercise 5.9.6, every vector in \(R(P)\) is fixed:

\[
Px=x.
\]

Therefore,

\[
\frac{\|Px\|_2}{\|x\|_2}
=
\frac{\|x\|_2}{\|x\|_2}
=
1.
\]

Since \(\|P\|_2\) is the maximum of these ratios,

\[
\boxed{\|P\|_2\ge1.}
\]

### Part 2: sufficient condition for equality

Assume

\[
R(P)\perp N(P).
\]

For any \(z\), the direct-sum decomposition associated with \(P\) is

\[
z=x+y,
\qquad
x\in R(P),\quad y\in N(P),
\]

and

\[
Pz=x.
\]

Orthogonality gives the Pythagorean identity

\[
\|z\|_2^2
=
\|x+y\|_2^2
=
\|x\|_2^2+\|y\|_2^2
\ge
\|x\|_2^2.
\]

Thus

\[
\|Pz\|_2=\|x\|_2\le\|z\|_2
\]

for every \(z\). Hence

\[
\|P\|_2\le1.
\]

Combined with the lower bound,

\[
\|P\|_2=1.
\]

### Part 3: necessary condition for equality

Now assume

\[
\|P\|_2=1.
\]

Then \(P\) is nonexpansive:

\[
\|Pz\|_2\le\|z\|_2
\qquad\text{for all }z.
\]

Take arbitrary vectors

\[
x\in R(P),
\qquad
y\in N(P).
\]

For every real scalar \(t\),

\[
P(x+ty)=Px+tPy=x.
\]

The norm bound gives

\[
\|x\|_2
=
\|P(x+ty)\|_2
\le
\|x+ty\|_2.
\]

Squaring both sides,

\[
\|x\|_2^2
\le
\|x\|_2^2+2t\,x^Ty+t^2\|y\|_2^2.
\]

Therefore,

\[
2t\,x^Ty+t^2\|y\|_2^2\ge0
\qquad\text{for all }t\in\mathbb R.
\]

If \(y=0\), then \(x^Ty=0\) automatically. Suppose \(y\ne0\). Choose

\[
t=-\frac{x^Ty}{\|y\|_2^2}.
\]

Substitution yields

\[
-\frac{(x^Ty)^2}{\|y\|_2^2}\ge0.
\]

The left side is nonpositive, so it can be nonnegative only when

\[
x^Ty=0.
\]

Since \(x\in R(P)\) and \(y\in N(P)\) were arbitrary,

\[
R(P)\perp N(P).
\]

Thus

\[
\boxed{
\|P\|_2=1
\iff
R(P)\perp N(P).
}
\]

In other words, equality holds exactly when \(P\) is an orthogonal projector.

> **Final answer.**
> Every nonzero projector satisfies \(\|P\|_2\ge1\), with equality exactly when its range is orthogonal to its nullspace.

### Connection to Meyer’s angle formula

For a nontrivial projector, Section 5.9 gives

\[
\|P\|_2=\frac1{\sin\theta},
\]

where \(\theta\) is the minimal angle between \(R(P)\) and \(N(P)\). Equality \(\|P\|_2=1\) is equivalent to \(\sin\theta=1\), hence \(\theta=\pi/2\).

## Exercise 5.9.9

### Brief restatement

For a projector \(P\) with \(P\ne0\) and \(P\ne I\), prove

\[
\|I-P\|_2=\|P\|_2.
\]

### Why the exclusions matter

If \(P=0\), then

\[
\|P\|_2=0,\qquad \|I-P\|_2=\|I\|_2=1.
\]

If \(P=I\), the two values are reversed. Thus both exceptional projectors must be excluded.

### Proof using the angle between complementary subspaces

Let

\[
R=R(P),
\qquad
N=N(P).
\]

Since \(P\ne0\) and \(P\ne I\), both \(R\) and \(N\) are nonzero. Let \(\theta\) be their minimal angle.

Section 5.9 gives

\[
\|P\|_2=\frac1{\sin\theta}.
\]

By Exercise 5.9.7,

\[
R(I-P)=N(P)=N,
\]
\[
N(I-P)=R(P)=R.
\]

Thus the complementary projector \(I-P\) merely reverses the two subspaces. The minimal angle between \(N\) and \(R\) is the same as the minimal angle between \(R\) and \(N\), because the defining expression is symmetric after interchanging the two vectors.

Therefore the same \(\theta\) applies to \(I-P\), and

\[
\|I-P\|_2
=
\frac1{\sin\theta}
=
\|P\|_2.
\]

> **Final answer.**
> \[
> \boxed{\|I-P\|_2=\|P\|_2}
> \]
> for every projector other than \(0\) and \(I\).

\newpage

## Exercise 5.9.10

### Brief restatement

Assume \(u,v\in\mathbb R^{n\times1}\) satisfy

\[
v^Tu=1.
\]

Prove the norm identities for the rank-one matrix \(uv^T\), including the equality with the complementary projector and the Frobenius norm.

### Source edge case

The first equality requires the intended nontrivial case \(n\ge2\). For \(n=1\), \(uv^T=I_1\), so \(\|I-uv^T\|_2=0\) while \(\|uv^T\|_2=1\).

The rest of the proof assumes \(n\ge2\) for the first equality. The formulas for \(\|uv^T\|_2\) and \(\|uv^T\|_F\) hold for every \(n\ge1\).

### Step 1: \(uv^T\) is a projector

Let

\[
P=uv^T.
\]

Then

\[
\begin{aligned}
P^2
&=(uv^T)(uv^T)\\
&=u(v^Tu)v^T\\
&=u(1)v^T\\
&=uv^T\\
&=P.
\end{aligned}
\]

Thus \(P\) is idempotent and hence is a projector.

The condition \(v^Tu=1\) also implies \(u\ne0\) and \(v\ne0\). Therefore \(P\ne0\). Since \(P\) has rank one and \(n\ge2\), \(P\ne I\). Exercise 5.9.9 now gives

\[
\boxed{\|I-uv^T\|_2=\|uv^T\|_2.}
\]

### Step 2: compute the induced \(2\)-norm

For any \(x\in\mathbb R^n\),

\[
uv^Tx=u(v^Tx).
\]

Hence

\[
\|uv^Tx\|_2
=
|v^Tx|\,\|u\|_2.
\]

If \(\|x\|_2=1\), the Cauchy--Schwarz inequality gives

\[
|v^Tx|
\le
\|v\|_2\|x\|_2
=
\|v\|_2.
\]

Therefore,

\[
\|uv^Tx\|_2
\le
\|u\|_2\|v\|_2,
\]

so

\[
\|uv^T\|_2\le\|u\|_2\|v\|_2.
\]

To attain equality, choose

\[
x=\frac{v}{\|v\|_2}.
\]

This vector has norm \(1\), and

\[
v^Tx
=
v^T\frac{v}{\|v\|_2}
=
\frac{\|v\|_2^2}{\|v\|_2}
=
\|v\|_2.
\]

Thus

\[
\left\|uv^T\frac{v}{\|v\|_2}\right\|_2
=
\|u\|_2\|v\|_2.
\]

Consequently,

\[
\boxed{\|uv^T\|_2=\|u\|_2\|v\|_2.}
\]

### Step 3: compute the Frobenius norm

The \((i,j)\)-entry of \(uv^T\) is \(u_i v_j\). Hence

\[
\begin{aligned}
\|uv^T\|_F^2
&=
\sum_{i=1}^n\sum_{j=1}^n (u_i v_j)^2\\
&=
\sum_{i=1}^n u_i^2
\sum_{j=1}^n v_j^2\\
&=
\|u\|_2^2\|v\|_2^2.
\end{aligned}
\]

Taking nonnegative square roots,

\[
\boxed{\|uv^T\|_F=\|u\|_2\|v\|_2.}
\]

Combining the results, for the intended case \(n\ge2\),

\[
\boxed{
\|I-uv^T\|_2
=
\|uv^T\|_2
=
\|u\|_2\|v\|_2
=
\|uv^T\|_F.
}
\]

> **Final answer.**
> The displayed chain is valid for \(n\ge2\). For \(n=1\), only the first equality fails; the remaining norm identities still hold.

### Learning note

A rank-one outer product has exactly one nonzero singular value, and both its spectral norm and Frobenius norm equal that value. The proof above establishes the fact without invoking singular-value theory, which appears later in Meyer.


## Exercise 5.9.11

### Brief restatement

Let \(X\) and \(Y\) be complementary subspaces of \(\mathbb R^n\). If

\[
B=[X\mid Y]
\]

contains bases for \(X\) and \(Y\), explain why the projection of \(v\) onto \(X\) along \(Y\) can be found by solving \(Bz=v\), partitioning \(z\), and returning \(Xz_1\).

### Solution

Because \(X\oplus Y=\mathbb R^n\), the columns of \(B=[X\mid Y]\) form a basis for \(\mathbb R^n\). Therefore \(B\) is nonsingular, and the system

\[
Bz=v
\]

has exactly one solution.

Partition \(z\) compatibly with the columns of \(B\):

\[
z=
\begin{bmatrix}
z_1\\
z_2
\end{bmatrix}.
\]

Then

\[
\begin{aligned}
v
&=Bz\\
&=
[X\mid Y]
\begin{bmatrix}
z_1\\
z_2
\end{bmatrix}\\
&=Xz_1+Yz_2.
\end{aligned}
\]

The vector \(Xz_1\) lies in \(X\), and \(Yz_2\) lies in \(Y\). Since the direct-sum decomposition is unique, \(Xz_1\) is exactly the \(X\)-component of \(v\). Hence

\[
\boxed{p=Xz_1}
\]

is the projection of \(v\) onto \(X\) along \(Y\).

The same conclusion follows from the matrix formula:

\[
\begin{aligned}
Pv
&=[X\mid 0]B^{-1}v\\
&=[X\mid 0]z\\
&=Xz_1.
\end{aligned}
\]

> **Final answer.**
> Solving \(Bz=v\) computes the coordinates of \(v\) in the basis adapted to \(X\oplus Y\); keeping the \(X\)-coordinate block gives \(p=Xz_1\).

### Learning note

This algorithm avoids explicitly forming the projector \(P\). Numerically, solving one linear system is often preferable to computing an inverse.

\newpage

## Exercise 5.9.12

### Brief restatement

Let \(P\) and \(Q\) be projectors.

1. Characterize equality of their ranges using \(PQ\) and \(QP\).
2. Characterize equality of their nullspaces similarly.
3. Show that an affine combination of projectors with a common range is again a projector.

### (a) Equality of ranges

We prove

\[
R(P)=R(Q)
\quad\Longleftrightarrow\quad
PQ=Q\ \text{and}\ QP=P.
\]

#### Forward direction

Assume

\[
R(P)=R(Q)=R.
\]

For every vector \(x\), \(Qx\in R(Q)=R(P)\). Since \(P\) fixes every vector in its range,

\[
P(Qx)=Qx.
\]

Thus

\[
PQx=Qx
\qquad\text{for every }x,
\]

so

\[
PQ=Q.
\]

Similarly, \(Px\in R(P)=R(Q)\), and \(Q\) fixes vectors in \(R(Q)\). Hence

\[
Q(Px)=Px
\]

for every \(x\), so

\[
QP=P.
\]

#### Reverse direction

Assume

\[
PQ=Q,
\qquad
QP=P.
\]

If \(y\in R(Q)\), then \(y=Qx\) for some \(x\). Using \(PQ=Q\),

\[
y=Qx=PQx=P(Qx),
\]

so \(y\in R(P)\). Therefore,

\[
R(Q)\subseteq R(P).
\]

Similarly, if \(y\in R(P)\), then \(y=Px\), and

\[
y=Px=QPx=Q(Px),
\]

so \(y\in R(Q)\). Hence

\[
R(P)\subseteq R(Q).
\]

Thus the ranges are equal.

Therefore,

\[
\boxed{
R(P)=R(Q)
\iff
PQ=Q\ \text{and}\ QP=P.
}
\]

### (b) Equality of nullspaces

We prove

\[
N(P)=N(Q)
\quad\Longleftrightarrow\quad
PQ=P\ \text{and}\ QP=Q.
\]

A projector and its complement satisfy

\[
R(I-P)=N(P),
\qquad
R(I-Q)=N(Q).
\]

Therefore,

\[
N(P)=N(Q)
\iff
R(I-P)=R(I-Q).
\]

Apply part (a) to \(I-P\) and \(I-Q\). Equality of their ranges is equivalent to

\[
(I-P)(I-Q)=I-Q
\]

and

\[
(I-Q)(I-P)=I-P.
\]

Expand the first equation:

\[
I-P-Q+PQ=I-Q.
\]

Cancel \(I-Q\) from both sides:

\[
-P+PQ=0,
\]

so

\[
PQ=P.
\]

Expand the second equation:

\[
I-Q-P+QP=I-P.
\]

Cancel \(I-P\):

\[
-Q+QP=0,
\]

so

\[
QP=Q.
\]

Every step is reversible, so

\[
\boxed{
N(P)=N(Q)
\iff
PQ=P\ \text{and}\ QP=Q.
}
\]

### (c) Affine combinations with a common range

Let \(E_1,\ldots,E_k\) be projectors with the same range \(R\), and let scalars \(\alpha_1,\ldots,\alpha_k\) satisfy

\[
\sum_{j=1}^k\alpha_j=1.
\]

Define

\[
E=\sum_{j=1}^k\alpha_jE_j.
\]

Since all ranges are equal, part (a) gives, for every \(i,j\),

\[
E_iE_j=E_j.
\]

Now compute:

\[
\begin{aligned}
E^2
&=
\left(\sum_{i=1}^k\alpha_iE_i\right)
\left(\sum_{j=1}^k\alpha_jE_j\right)\\
&=
\sum_{i=1}^k\sum_{j=1}^k
\alpha_i\alpha_j E_iE_j\\
&=
\sum_{i=1}^k\sum_{j=1}^k
\alpha_i\alpha_j E_j\\
&=
\left(\sum_{i=1}^k\alpha_i\right)
\left(\sum_{j=1}^k\alpha_jE_j\right)\\
&=1\cdot E\\
&=E.
\end{aligned}
\]

Thus \(E\) is idempotent and hence is a projector.

We can also identify its range. Each \(E_jx\in R\), so \(Ex\in R\), giving \(R(E)\subseteq R\). If \(x\in R\), every \(E_j\) fixes \(x\), so

\[
Ex
=
\sum_j\alpha_jE_jx
=
\left(\sum_j\alpha_j\right)x
=
x.
\]

Hence \(R\subseteq R(E)\). Therefore \(R(E)=R\).

> **Final answer.**
> \[
> R(P)=R(Q)\iff PQ=Q,\ QP=P,
> \]
> \[
> N(P)=N(Q)\iff PQ=P,\ QP=Q,
> \]
> and any affine combination \(\sum_j\alpha_jE_j\) with a common range and \(\sum_j\alpha_j=1\) is a projector onto that common range.

### Learning note

The order of the product matters. Equal ranges give \(PQ=Q\) and \(QP=P\); equal nullspaces reverse the right-hand sides.

## Exercise 5.9.13

### Brief restatement

Prove that every projector \(P\) on \(\mathbb R^n\) satisfies

\[
\operatorname{rank}(P)=\operatorname{trace}(P).
\]

### Relevant representation

Let

\[
r=\dim R(P)=\operatorname{rank}(P).
\]

Choose a basis for \(R(P)\) followed by a basis for \(N(P)\), and place these basis vectors in a nonsingular matrix \(B\). Relative to this basis,

\[
P=
B
\begin{bmatrix}
I_r&0\\
0&0
\end{bmatrix}
B^{-1}.
\]

Set

\[
D=
\begin{bmatrix}
I_r&0\\
0&0
\end{bmatrix}.
\]

### Rank calculation

Multiplication by nonsingular matrices does not change rank, so

\[
\operatorname{rank}(P)
=
\operatorname{rank}(BDB^{-1})
=
\operatorname{rank}(D)
=
r.
\]

### Trace calculation

Using the cyclic trace identity \(\operatorname{trace}(XY)=\operatorname{trace}(YX)\),

\[
\begin{aligned}
\operatorname{trace}(P)
&=
\operatorname{trace}(BDB^{-1})\\
&=
\operatorname{trace}(DB^{-1}B)\\
&=
\operatorname{trace}(D)\\
&=
\operatorname{trace}(I_r)\\
&=r.
\end{aligned}
\]

Therefore,

\[
\boxed{\operatorname{rank}(P)=\operatorname{trace}(P).}
\]

> **Final answer.**
> Both quantities equal \(r=\dim R(P)\).

### Learning note

A projector is similar to a diagonal matrix containing only \(1\)'s and \(0\)'s. Rank counts the \(1\)'s, and trace sums them.

\newpage

## Exercise 5.9.14

### Brief restatement

Let \(X_1,\ldots,X_k\) be subspaces of \(V\), with basis \(B_i\) for \(X_i\). Prove the equivalence of:

1. \(V=X_1+\cdots+X_k\) and each new \(X_j\) intersects the preceding sum only at \(0\);
2. every vector has a unique decomposition \(v=x_1+\cdots+x_k\), \(x_i\in X_i\);
3. the pairwise-disjoint union of the bases is a basis for \(V\).

### Proof structure

We prove the cycle

\[
\text{(i)}\Longrightarrow\text{(ii)}
\Longrightarrow\text{(iii)}
\Longrightarrow\text{(i)}.
\]

### (i) implies (ii)

Assume

\[
V=X_1+\cdots+X_k
\]

and, for every \(j=2,\ldots,k\),

\[
X_j\cap(X_1+\cdots+X_{j-1})=\{0\}.
\]

#### Existence

The equality \(V=X_1+\cdots+X_k\) means precisely that every \(v\in V\) can be written as

\[
v=x_1+\cdots+x_k,
\qquad
x_i\in X_i.
\]

#### Uniqueness

Suppose

\[
v=x_1+\cdots+x_k
\]

and

\[
v=y_1+\cdots+y_k,
\]

where \(x_i,y_i\in X_i\). Subtract:

\[
\sum_{i=1}^k(x_i-y_i)=0.
\]

Hence

\[
x_k-y_k
=
-\sum_{i=1}^{k-1}(x_i-y_i).
\]

The left side belongs to \(X_k\), while the right side belongs to

\[
X_1+\cdots+X_{k-1}.
\]

Therefore,

\[
x_k-y_k
\in
X_k\cap(X_1+\cdots+X_{k-1})
=
\{0\},
\]

so

\[
x_k=y_k.
\]

The remaining relation is

\[
\sum_{i=1}^{k-1}(x_i-y_i)=0.
\]

Apply the same argument to \(X_{k-1}\) and \(X_1+\cdots+X_{k-2}\). Continuing downward gives

\[
x_j=y_j
\qquad
\text{for }j=k,k-1,\ldots,2.
\]

The final relation is \(x_1-y_1=0\), so \(x_1=y_1\). Thus the decomposition is unique.

Therefore (ii) holds.

### (ii) implies (iii)

Assume every \(v\in V\) has one and only one representation

\[
v=x_1+\cdots+x_k,
\qquad x_i\in X_i.
\]

Let

\[
B=B_1\cup\cdots\cup B_k.
\]

#### The basis sets are pairwise disjoint

Suppose a nonzero vector \(b\) belonged to both \(B_i\) and \(B_j\), where \(i\ne j\). Then \(b\) would have two decompositions:

- \(b\) in the \(i\)-th component and \(0\) in all others;
- \(b\) in the \(j\)-th component and \(0\) in all others.

These decompositions are different, contradicting uniqueness. Therefore,

\[
B_i\cap B_j=\varnothing
\qquad(i\ne j).
\]

#### \(B\) spans \(V\)

Take \(v\in V\). By hypothesis,

\[
v=x_1+\cdots+x_k,
\qquad x_i\in X_i.
\]

Since \(B_i\) is a basis for \(X_i\), each \(x_i\) is a linear combination of vectors from \(B_i\). Therefore \(v\) is a linear combination of vectors from \(B\). Hence \(B\) spans \(V\).

#### \(B\) is linearly independent

Suppose a linear combination of vectors from \(B\) equals zero. Group terms according to their subspaces:

\[
z_1+\cdots+z_k=0,
\qquad z_i\in X_i.
\]

This is one decomposition of \(0\). The all-zero decomposition

\[
0=0+\cdots+0
\]

is another. Uniqueness forces

\[
z_i=0
\qquad\text{for every }i.
\]

Within each \(X_i\), the basis \(B_i\) is linearly independent, so every scalar coefficient in the original relation is zero. Therefore \(B\) is linearly independent.

Thus \(B\) is a basis for \(V\), and (iii) holds.

### (iii) implies (i)

Assume

\[
B=B_1\cup\cdots\cup B_k
\]

is a basis for \(V\), and the \(B_i\)'s are pairwise disjoint.

#### The sum is all of \(V\)

Because \(B\) spans \(V\), and every vector in \(B_i\) lies in \(X_i\),

\[
V=X_1+\cdots+X_k.
\]

#### Each new subspace has trivial intersection with the preceding sum

Fix \(j\in\{2,\ldots,k\}\), and let

\[
z\in X_j\cap(X_1+\cdots+X_{j-1}).
\]

Because \(z\in X_j\), write

\[
z=\sum_{b\in B_j}\alpha_b b.
\]

Because \(z\in X_1+\cdots+X_{j-1}\), write

\[
z=\sum_{i=1}^{j-1}\sum_{b\in B_i}\beta_b b.
\]

Subtracting gives a linear relation among vectors in the basis \(B\):

\[
\sum_{b\in B_j}\alpha_b b
-
\sum_{i=1}^{j-1}\sum_{b\in B_i}\beta_b b
=0.
\]

Since \(B\) is linearly independent, every coefficient is zero. In particular, \(z=0\). Thus

\[
X_j\cap(X_1+\cdots+X_{j-1})=\{0\}.
\]

Since \(j\) was arbitrary, (i) follows.

### Conclusion

The three statements are equivalent. When they hold, we write

\[
\boxed{V=X_1\oplus\cdots\oplus X_k.}
\]

> **Final answer.**
> Conditions (i), (ii), and (iii) are equivalent, as established by the implication cycle above.

### Learning note

The most reusable proof move is to isolate the last component and place it in an intersection:

\[
x_k-y_k
\in
X_k\cap(X_1+\cdots+X_{k-1}).
\]

This is the multi-subspace version of the uniqueness proof for \(V=X\oplus Y\).

\newpage

## Exercise 5.9.15

### Brief restatement

Let \(\mathbb R^n=X\oplus Y\), let \(P\) project onto \(X\) along \(Y\), and let

\[
Q=[X\mid Y]
\]

be the change-of-basis matrix formed from bases of the two subspaces. If

\[
Q^{-1}AQ
=
\begin{bmatrix}
A_{11}&A_{12}\\
A_{21}&A_{22}
\end{bmatrix},
\]

derive the four block formulas for \(PAP\), \(PA(I-P)\), \((I-P)AP\), and \((I-P)A(I-P)\).

### Dimension setup

Let

\[
r=\dim X,\qquad s=\dim Y=n-r.
\]

Then

\[
A_{11}\in\mathbb R^{r\times r},
\quad
A_{12}\in\mathbb R^{r\times s},
\quad
A_{21}\in\mathbb R^{s\times r},
\quad
A_{22}\in\mathbb R^{s\times s}.
\]

Define the coordinate projectors

\[
D_X=
\begin{bmatrix}
I_r&0\\
0&0
\end{bmatrix},
\qquad
D_Y=
\begin{bmatrix}
0&0\\
0&I_s
\end{bmatrix}.
\]

Section 5.9 gives

\[
P=QD_XQ^{-1},
\qquad
I-P=QD_YQ^{-1}.
\]

Set

\[
S=Q^{-1}AQ
=
\begin{bmatrix}
A_{11}&A_{12}\\
A_{21}&A_{22}
\end{bmatrix}.
\]

### Compute \(PAP\)

\[
\begin{aligned}
PAP
&=(QD_XQ^{-1})A(QD_XQ^{-1})\\
&=QD_X(Q^{-1}AQ)D_XQ^{-1}\\
&=QD_XSD_XQ^{-1}.
\end{aligned}
\]

Now

\[
D_XS
=
\begin{bmatrix}
I&0\\
0&0
\end{bmatrix}
\begin{bmatrix}
A_{11}&A_{12}\\
A_{21}&A_{22}
\end{bmatrix}
=
\begin{bmatrix}
A_{11}&A_{12}\\
0&0
\end{bmatrix},
\]

and therefore

\[
D_XSD_X
=
\begin{bmatrix}
A_{11}&0\\
0&0
\end{bmatrix}.
\]

Thus

\[
\boxed{
PAP
=
Q
\begin{bmatrix}
A_{11}&0\\
0&0
\end{bmatrix}
Q^{-1}.
}
\]

### Compute \(PA(I-P)\)

\[
\begin{aligned}
PA(I-P)
&=QD_XSD_YQ^{-1}.
\end{aligned}
\]

Since

\[
D_XSD_Y
=
\begin{bmatrix}
0&A_{12}\\
0&0
\end{bmatrix},
\]

we obtain

\[
\boxed{
PA(I-P)
=
Q
\begin{bmatrix}
0&A_{12}\\
0&0
\end{bmatrix}
Q^{-1}.
}
\]

### Compute \((I-P)AP\)

Similarly,

\[
(I-P)AP
=
QD_YSD_XQ^{-1},
\]

and

\[
D_YSD_X
=
\begin{bmatrix}
0&0\\
A_{21}&0
\end{bmatrix}.
\]

Therefore,

\[
\boxed{
(I-P)AP
=
Q
\begin{bmatrix}
0&0\\
A_{21}&0
\end{bmatrix}
Q^{-1}.
}
\]

### Compute \((I-P)A(I-P)\)

Finally,

\[
(I-P)A(I-P)
=
QD_YSD_YQ^{-1},
\]

with

\[
D_YSD_Y
=
\begin{bmatrix}
0&0\\
0&A_{22}
\end{bmatrix}.
\]

Hence

\[
\boxed{
(I-P)A(I-P)
=
Q
\begin{bmatrix}
0&0\\
0&A_{22}
\end{bmatrix}
Q^{-1}.
}
\]

The lower-right block must be \(A_{22}\), not \(A_{12}\), both by block multiplication and by dimensions.

### Interpretation of the four blocks

The basis \(B=B_X\cup B_Y\) splits coordinates into an \(X\)-block and a \(Y\)-block.

- \(A_{11}\) represents the map \(PAP\) restricted from \(X\) to \(X\).
- \(A_{12}\) represents \(PA(I-P)\), which takes the \(Y\)-component, applies \(A\), and retains only the \(X\)-component.
- \(A_{21}\) represents \((I-P)AP\), which takes \(X\) into the \(Y\)-component.
- \(A_{22}\) represents \((I-P)A(I-P)\) restricted from \(Y\) to \(Y\).

For example, if \(x=X\xi\in X\), then its \(B\)-coordinate vector is

\[
[x]_B=
\begin{bmatrix}\xi\\0\end{bmatrix}.
\]

The \(B\)-coordinates of \(PAPx\) are

\[
D_XSD_X
\begin{bmatrix}\xi\\0\end{bmatrix}
=
\begin{bmatrix}A_{11}\xi\\0\end{bmatrix},
\]

so \(A_{11}\) is exactly the matrix of the restricted operator \(PAP|_X:X\to X\).

> **Final answer.**
> \[
> PAP=Q\begin{bmatrix}A_{11}&0\\0&0\end{bmatrix}Q^{-1},
> \]
> \[
> PA(I-P)=Q\begin{bmatrix}0&A_{12}\\0&0\end{bmatrix}Q^{-1},
> \]
> \[
> (I-P)AP=Q\begin{bmatrix}0&0\\A_{21}&0\end{bmatrix}Q^{-1},
> \]
> \[
> (I-P)A(I-P)=Q\begin{bmatrix}0&0\\0&A_{22}\end{bmatrix}Q^{-1}.
> \]

### Learning note

The projectors \(P\) and \(I-P\) act as block selectors. Placing them on the left selects an output block; placing them on the right selects an input block.


\newpage

## Exercise 5.9.16

### Brief restatement

Assume

\[
\mathbb R^n=X\oplus Y,
\qquad
\dim X=r,
\]

and let \(P\) project onto \(X\) along \(Y\). Show that \(P\) has a full-rank factorization

\[
P=XA,
\]

where

\[
X\in\mathbb R^{n\times r},
\qquad
A\in\mathbb R^{r\times n},
\qquad
\operatorname{rank}(X)=\operatorname{rank}(A)=r,
\qquad
AX=I_r.
\]

### Strategy

Use a basis matrix adapted to the direct sum, and partition its inverse by rows.

### Solution

Choose the columns of \(X\in\mathbb R^{n\times r}\) to be a basis for the subspace \(X\). Choose a matrix \(Y\in\mathbb R^{n\times(n-r)}\) whose columns form a basis for the complementary subspace \(Y\).

Because

\[
\mathbb R^n=X\oplus Y,
\]

the combined matrix

\[
B=[X\mid Y]
\]

is nonsingular.

Partition \(B^{-1}\) by rows:

\[
B^{-1}
=
\begin{bmatrix}
A\\
C
\end{bmatrix},
\]

where

\[
A\in\mathbb R^{r\times n},
\qquad
C\in\mathbb R^{(n-r)\times n}.
\]

The projector formula from Section 5.9 gives

\[
\begin{aligned}
P
&=[X\mid0]B^{-1}\\
&=
[X\mid0]
\begin{bmatrix}
A\\
C
\end{bmatrix}\\
&=XA.
\end{aligned}
\]

Thus \(P=XA\).

Now use

\[
B^{-1}B=I_n.
\]

Block multiplication yields

\[
\begin{bmatrix}
A\\
C
\end{bmatrix}
[X\mid Y]
=
\begin{bmatrix}
AX&AY\\
CX&CY
\end{bmatrix}
=
\begin{bmatrix}
I_r&0\\
0&I_{n-r}
\end{bmatrix}.
\]

The upper-left block gives

\[
\boxed{AX=I_r.}
\]

Because the columns of \(X\) are a basis, they are linearly independent, so

\[
\operatorname{rank}(X)=r.
\]

Also,

\[
r=\operatorname{rank}(I_r)=\operatorname{rank}(AX)
\le
\operatorname{rank}(A)
\le r,
\]

where the final inequality follows because \(A\) has only \(r\) rows. Therefore,

\[
\operatorname{rank}(A)=r.
\]

Hence

\[
\boxed{
P=XA,\qquad
\operatorname{rank}(X)=\operatorname{rank}(A)=r,\qquad
AX=I_r.
}
\]

### Verification of idempotence from the factorization

The relation \(AX=I_r\) immediately gives

\[
P^2=(XA)(XA)=X(AX)A=XI_rA=XA=P.
\]

Thus the full-rank factorization makes the projector property transparent.

> **Final answer.**
> Take \(X\) to be a basis matrix for the range subspace, and take \(A\) to be the first \(r\) rows of \([X\mid Y]^{-1}\). Then \(P=XA\), both factors have rank \(r\), and \(AX=I_r\).

### Learning note

The columns of \(X\) synthesize vectors in the range, while \(A\) extracts their \(X\)-coordinates. The identity \(AX=I_r\) says that coordinate extraction followed by synthesis is exact.

\newpage

## Exercise 5.9.17

### Brief restatement

Let \(E\) project onto \(X_1\) along \(Y_1\), and let \(F\) project onto \(X_2\) along \(Y_2\). Prove

\[
E+F\text{ is a projector}
\quad\Longleftrightarrow\quad
EF=FE=0.
\]

Under this condition, determine the range and nullspace of \(E+F\).

### Part 1: characterize idempotence

Because \(E\) and \(F\) are projectors,

\[
E^2=E,
\qquad
F^2=F.
\]

#### If \(EF=FE=0\), then \(E+F\) is a projector

Compute

\[
\begin{aligned}
(E+F)^2
&=E^2+EF+FE+F^2\\
&=E+0+0+F\\
&=E+F.
\end{aligned}
\]

Thus \(E+F\) is idempotent and hence is a projector.

#### If \(E+F\) is a projector, then \(EF=FE=0\)

Assume

\[
(E+F)^2=E+F.
\]

Expanding gives

\[
E+EF+FE+F=E+F,
\]

so

\[
EF+FE=0.
\tag{1}
\]

Left-multiply (1) by \(E\):

\[
E(EF+FE)=0,
\]

which gives

\[
EF+EFE=0.
\tag{2}
\]

Right-multiply (1) by \(E\):

\[
(EF+FE)E=0,
\]

which gives

\[
EFE+FE=0.
\tag{3}
\]

Subtract (3) from (2):

\[
EF-FE=0.
\]

Therefore,

\[
EF=FE.
\]

Together with \(EF+FE=0\), this yields

\[
2EF=0.
\]

Over \(\mathbb R\) or \(\mathbb C\), \(2\ne0\), so

\[
EF=0.
\]

Since \(EF=FE\),

\[
FE=0.
\]

Therefore,

\[
\boxed{
E+F\text{ is a projector}
\iff
EF=FE=0.
}
\]

### Part 2: determine the range

Set

\[
G=E+F.
\]

Assume \(EF=FE=0\).

For every \(z\),

\[
Gz=Ez+Fz\in X_1+X_2.
\]

Hence

\[
R(G)\subseteq X_1+X_2.
\]

Conversely, let

\[
x=x_1+x_2,
\qquad
x_1\in X_1,\quad x_2\in X_2.
\]

Since \(x_1\in R(E)\), there exists \(a\) with \(x_1=Ea\). Then

\[
Fx_1=FEa=0.
\]

Similarly, \(x_2=Fb\) for some \(b\), so

\[
Ex_2=EFb=0.
\]

Therefore,

\[
\begin{aligned}
Gx
&=(E+F)(x_1+x_2)\\
&=Ex_1+Ex_2+Fx_1+Fx_2\\
&=x_1+0+0+x_2\\
&=x.
\end{aligned}
\]

Thus every vector in \(X_1+X_2\) is fixed by \(G\), so it belongs to \(R(G)\). Hence

\[
R(G)=X_1+X_2.
\]

The sum is direct. If \(z\in X_1\cap X_2\), then

\[
Ez=z,\qquad Fz=z.
\]

Consequently,

\[
z=E(Fz)=EFz=0.
\]

Thus

\[
X_1\cap X_2=\{0\},
\]

and

\[
\boxed{R(E+F)=X_1\oplus X_2.}
\]

### Part 3: determine the nullspace

First, if \(z\in Y_1\cap Y_2\), then

\[
Ez=0,\qquad Fz=0,
\]

so

\[
(E+F)z=0.
\]

Therefore,

\[
Y_1\cap Y_2\subseteq N(E+F).
\]

Conversely, suppose

\[
(E+F)z=0.
\]

Then

\[
Ez=-Fz.
\]

Apply \(E\):

\[
Ez=-EFz=0.
\]

It follows from \(Ez=-Fz\) that \(Fz=0\) as well. Hence

\[
z\in N(E)\cap N(F)=Y_1\cap Y_2.
\]

Therefore,

\[
\boxed{N(E+F)=Y_1\cap Y_2.}
\]

> **Final answer.**
> \[
> \boxed{
> E+F\text{ is a projector}
> \iff
> EF=FE=0,
> }
> \]
> and, under this condition,
> \[
> \boxed{
> R(E+F)=X_1\oplus X_2,
> \qquad
> N(E+F)=Y_1\cap Y_2.
> }
> \]

### Learning note

The conditions \(EF=FE=0\) say that each projector annihilates the other projector's range:

\[
X_2\subseteq Y_1,
\qquad
X_1\subseteq Y_2.
\]

That is exactly what prevents cross terms from appearing.

\newpage

## Exercise 5.9.18

### Brief restatement

With \(E\) and \(F\) as in Exercise 5.9.17, prove

\[
E-F\text{ is a projector}
\quad\Longleftrightarrow\quad
EF=FE=F.
\]

Under this condition, determine its range and nullspace.

### Step 1: use the complementary projector

A linear operator \(H\) is a projector if and only if \(I-H\) is a projector, because

\[
H^2=H
\iff
(I-H)^2=I-H.
\]

Set

\[
H=E-F.
\]

Then

\[
I-H
=
I-E+F
=
(I-E)+F.
\]

Both \(I-E\) and \(F\) are projectors. Apply Exercise 5.9.17:

\[
(I-E)+F\text{ is a projector}
\]

if and only if

\[
(I-E)F=0
\]

and

\[
F(I-E)=0.
\]

These equations simplify to

\[
F-EF=0
\]

and

\[
F-FE=0.
\]

Therefore,

\[
EF=F,
\qquad
FE=F.
\]

Every implication is reversible, so

\[
\boxed{
E-F\text{ is a projector}
\iff
EF=FE=F.
}
\]

### Step 2: use Exercise 5.9.17 on \(G=(I-E)+F\)

Assume \(EF=FE=F\). Then

\[
(I-E)F=0,
\qquad
F(I-E)=0.
\]

Exercise 5.9.17 gives

\[
R(G)=R(I-E)\oplus R(F)
\]

and

\[
N(G)=N(I-E)\cap N(F).
\]

Using the range/nullspace identities for complementary projectors,

\[
R(I-E)=N(E)=Y_1,
\]
\[
R(F)=X_2,
\]
\[
N(I-E)=R(E)=X_1,
\]
\[
N(F)=Y_2.
\]

Hence

\[
R(G)=Y_1\oplus X_2
\]

and

\[
N(G)=X_1\cap Y_2.
\]

But

\[
H=E-F=I-G.
\]

A projector and its complement exchange range and nullspace, so

\[
R(H)=N(G),
\qquad
N(H)=R(G).
\]

Therefore,

\[
\boxed{R(E-F)=X_1\cap Y_2}
\]

and

\[
\boxed{N(E-F)=Y_1\oplus X_2.}
\]

> **Final answer.**
> \[
> \boxed{
> E-F\text{ is a projector}
> \iff
> EF=FE=F,
> }
> \]
> and, under this condition,
> \[
> \boxed{
> R(E-F)=X_1\cap Y_2,
> \qquad
> N(E-F)=Y_1\oplus X_2.
> }
> \]

### Interpretation

The identities \(EF=F\) and \(FE=F\) imply

\[
X_2\subseteq X_1
\]

and

\[
Y_1\subseteq Y_2.
\]

Thus \(E-F\) removes from \(X_1\) the component already selected by \(F\).

\newpage

## Exercise 5.9.19

### Brief restatement

Let \(E\) project onto \(X_1\) along \(Y_1\), and let \(F\) project onto \(X_2\) along \(Y_2\). Assume

\[
EF=FE=P.
\]

Prove that \(P\) projects onto \(X_1\cap X_2\) along \(Y_1+Y_2\).

### Step 1: prove that \(P\) is a projector

Using \(P=EF=FE\),

\[
\begin{aligned}
P^2
&=(EF)(EF)\\
&=E(FE)F\\
&=E(EF)F\\
&=E^2F^2\\
&=EF\\
&=P.
\end{aligned}
\]

Thus \(P\) is idempotent and hence is a projector.

### Step 2: compute the range

We prove

\[
R(P)=X_1\cap X_2.
\]

If \(z\in R(P)\), then \(z=Pw\) for some \(w\). Since \(P=EF\),

\[
z=EFw\in R(E)=X_1.
\]

Since \(P=FE\),

\[
z=FEw\in R(F)=X_2.
\]

Thus

\[
R(P)\subseteq X_1\cap X_2.
\]

Conversely, let \(z\in X_1\cap X_2\). Then

\[
Ez=z,
\qquad
Fz=z.
\]

Therefore,

\[
Pz=EFz=Ez=z.
\]

So \(z\) is fixed by \(P\), and hence \(z\in R(P)\). Therefore,

\[
\boxed{R(P)=X_1\cap X_2.}
\]

### Step 3: compute the nullspace

We prove

\[
N(P)=Y_1+Y_2.
\]

#### Show \(Y_1+Y_2\subseteq N(P)\)

Let

\[
z=y_1+y_2,
\qquad
y_1\in Y_1=N(E),
\quad
y_2\in Y_2=N(F).
\]

Using \(P=FE\),

\[
Py_1=FEy_1=0.
\]

Using \(P=EF\),

\[
Py_2=EFy_2=0.
\]

Hence

\[
Pz=Py_1+Py_2=0,
\]

so

\[
Y_1+Y_2\subseteq N(P).
\]

#### Show \(N(P)\subseteq Y_1+Y_2\)

Let \(z\in N(P)\). Decompose \(z\) using \(E\):

\[
z=(I-E)z+Ez.
\]

The first term satisfies

\[
(I-E)z\in R(I-E)=N(E)=Y_1.
\]

For the second term,

\[
F(Ez)=FEz=Pz=0.
\]

Thus

\[
Ez\in N(F)=Y_2.
\]

Therefore,

\[
z\in Y_1+Y_2.
\]

Hence

\[
\boxed{N(P)=Y_1+Y_2.}
\]

Since every projector is the projector onto its range along its nullspace, \(P\) is the projector onto \(X_1\cap X_2\) along \(Y_1+Y_2\).

> **Final answer.**
> \[
> \boxed{
> P=EF=FE
> }
> \]
> is the projector onto
> \[
> \boxed{X_1\cap X_2}
> \]
> along
> \[
> \boxed{Y_1+Y_2}.
> \]

### Learning note

Commuting projectors behave like logical intersection on their ranges. This is an algebraic precursor to the role of commuting orthogonal projections in probability and functional analysis.

\newpage

## Exercise 5.9.20

### Brief restatement

For \(A\in\mathbb C^{m\times n}\):

- an inner pseudoinverse \(A^{-}\in\mathbb C^{n\times m}\) satisfies
  \[
  AA^{-}A=A;
  \]
- an outer pseudoinverse \(X\) satisfies
  \[
  XAX=X;
  \]
- a reflexive pseudoinverse satisfies both.

Part (a) asks for the complete solution set of a consistent system \(Ax=b\). Part (b) prescribes a complement \(M\) of \(R(A)\) and a complement \(L\) of \(N(A)\), and asks for the unique reflexive pseudoinverse with range \(L\) and nullspace \(M\).

### Preliminary projector facts

Let \(A^{-}\) be any inner pseudoinverse.

First,

\[
(AA^{-})^2
=
AA^{-}AA^{-}
=
(AA^{-}A)A^{-}
=
AA^{-},
\]

so \(AA^{-}\) is a projector.

Its range is \(R(A)\). Indeed,

\[
R(AA^{-})\subseteq R(A)
\]

because every column of \(AA^{-}\) is in \(R(A)\). Conversely, if \(y=Az\in R(A)\), then

\[
AA^{-}y
=
AA^{-}Az
=
Az
=
y.
\]

Thus every vector in \(R(A)\) is fixed by \(AA^{-}\), and

\[
R(AA^{-})=R(A).
\]

Similarly,

\[
(A^{-}A)^2
=
A^{-}AA^{-}A
=
A^{-}(AA^{-}A)
=
A^{-}A,
\]

so \(A^{-}A\) is a projector.

Also,

\[
N(A^{-}A)=N(A).
\]

One inclusion is immediate:

\[
Ax=0
\implies
A^{-}Ax=0.
\]

For the reverse inclusion,

\[
A^{-}Ax=0
\implies
Ax=AA^{-}Ax=0.
\]

Therefore \(I-A^{-}A\) is the complementary projector onto \(N(A)\).

### (a) General solution of a consistent system

Assume \(Ax=b\) is consistent. Then

\[
b\in R(A)=R(AA^{-}).
\]

Since a projector fixes its range,

\[
AA^{-}b=b.
\]

Therefore,

\[
A(A^{-}b)=AA^{-}b=b,
\]

so

\[
x_0=A^{-}b
\]

is a particular solution.

Every solution of a consistent system is a particular solution plus a vector in the nullspace. Explicitly:

- If \(x\) is any solution, then
  \[
  A(x-x_0)=Ax-Ax_0=b-b=0,
  \]
  so \(x-x_0\in N(A)\).
- Conversely, if \(h\in N(A)\), then
  \[
  A(x_0+h)=Ax_0+Ah=b+0=b.
  \]

Thus the solution set is

\[
A^{-}b+N(A).
\]

From the preliminary result,

\[
N(A)=R(I-A^{-}A).
\]

Hence

\[
\boxed{
\{x:Ax=b\}
=
A^{-}b+R(I-A^{-}A).
}
\]

Writing the range explicitly,

\[
\boxed{
\{x:Ax=b\}
=
\left\{
A^{-}b+(I-A^{-}A)h:
h\in\mathbb C^n
\right\}.
}
\]

#### Direct verification of the parametrization

For any \(h\),

\[
\begin{aligned}
A\left[A^{-}b+(I-A^{-}A)h\right]
&=AA^{-}b+A(I-A^{-}A)h\\
&=b+(A-AA^{-}A)h\\
&=b.
\end{aligned}
\]

Conversely, if \(Ax=b\), choose \(h=x\). Then

\[
\begin{aligned}
A^{-}b+(I-A^{-}A)x
&=A^{-}Ax+x-A^{-}Ax\\
&=x.
\end{aligned}
\]

So the parametrization produces every solution, not merely some solutions.

> **Final answer for (a).**
> \[
> \boxed{
> \{x:Ax=b\}
> =
> A^{-}b+R(I-A^{-}A)
> =
> \{A^{-}b+(I-A^{-}A)h:h\in\mathbb C^n\}.
> }
> \]

### (b) Reflexive pseudoinverse with prescribed range and nullspace

Assume

\[
\mathbb C^m=R(A)\oplus M
\]

and

\[
\mathbb C^n=L\oplus N(A).
\]

Let

\[
P:\mathbb C^m\to\mathbb C^m
\]

be the projector onto \(R(A)\) along \(M\), and let

\[
Q:\mathbb C^n\to\mathbb C^n
\]

be the projector onto \(L\) along \(N(A)\).

Define

\[
\boxed{X=QA^{-}P.}
\]

We prove that this \(X\) is reflexive, has the prescribed range and nullspace, and is unique.

#### Useful identities for \(P\) and \(Q\)

Because \(P\) fixes \(R(A)\), and every column of \(A\) is in \(R(A)\),

\[
PA=A.
\tag{1}
\]

Because \(I-Q\) projects onto \(N(A)\),

\[
A(I-Q)=0.
\]

Therefore,

\[
AQ=A.
\tag{2}
\]

Also, \(AA^{-}\) is a projector onto \(R(A)\). Since \(P\) maps into \(R(A)\),

\[
AA^{-}P=P.
\tag{3}
\]

Finally, for every \(z\in\mathbb C^n\),

\[
A(A^{-}Az-z)
=
AA^{-}Az-Az
=
0.
\]

Thus

\[
A^{-}Az-z\in N(A)=N(Q),
\]

so \(Q\) annihilates the difference:

\[
QA^{-}Az=Qz.
\]

Hence

\[
QA^{-}A=Q.
\tag{4}
\]

#### Compute \(AX\)

Using (2) and (3),

\[
\begin{aligned}
AX
&=AQA^{-}P\\
&=AA^{-}P\\
&=P.
\end{aligned}
\]

Thus

\[
\boxed{AX=P.}
\tag{5}
\]

#### Compute \(XA\)

Using (1) and (4),

\[
\begin{aligned}
XA
&=QA^{-}PA\\
&=QA^{-}A\\
&=Q.
\end{aligned}
\]

Thus

\[
\boxed{XA=Q.}
\tag{6}
\]

#### Inner pseudoinverse property

Using (5) and (1),

\[
AXA=PA=A.
\]

Therefore \(X\) is an inner pseudoinverse.

#### Outer pseudoinverse property

Using (6),

\[
XAX=QX.
\]

But \(X=QA^{-}P\), so \(QX=X\). Hence

\[
XAX=X.
\]

Therefore \(X\) is an outer pseudoinverse.

Consequently, \(X\) is reflexive.

#### Determine \(R(X)\)

Since \(X=QA^{-}P\),

\[
R(X)\subseteq R(Q)=L.
\]

On the other hand, \(XA=Q\), so

\[
R(Q)=R(XA)\subseteq R(X).
\]

Thus

\[
\boxed{R(X)=L.}
\]

#### Determine \(N(X)\)

If \(m\in M=N(P)\), then

\[
Xm=QA^{-}Pm=0.
\]

Therefore,

\[
M\subseteq N(X).
\]

Conversely, if \(Xz=0\), then by (5),

\[
Pz=AXz=0.
\]

Hence \(z\in N(P)=M\). Thus

\[
\boxed{N(X)=M.}
\]

We have now proved existence.

### Uniqueness

Suppose \(Z\) is any reflexive pseudoinverse of \(A\) satisfying

\[
R(Z)=L,
\qquad
N(Z)=M.
\]

We first identify the projectors \(AZ\) and \(ZA\).

#### \(AZ=P\)

Because \(ZAZ=Z\),

\[
(AZ)^2=AZAZ=A(ZAZ)=AZ,
\]

so \(AZ\) is a projector.

Its range is \(R(A)\):

- \(R(AZ)\subseteq R(A)\);
- if \(y=Aw\in R(A)\), then
  \[
  AZy=AZAw=Aw=y
  \]
  because \(AZA=A\).

Its nullspace is \(N(Z)\):

- if \(Zy=0\), then \(AZy=0\);
- if \(AZy=0\), then
  \[
  Zy=ZAZy=0.
  \]

Thus

\[
R(AZ)=R(A),
\qquad
N(AZ)=N(Z)=M.
\]

The projector onto \(R(A)\) along \(M\) is unique, so

\[
AZ=P.
\tag{7}
\]

#### \(ZA=Q\)

Similarly,

\[
(ZA)^2=ZAZA=(ZAZ)A=ZA,
\]

so \(ZA\) is a projector.

Its range is \(R(Z)=L\):

- \(R(ZA)\subseteq R(Z)\);
- if \(y=Zw\in R(Z)\), then
  \[
  ZAy=ZAZw=Zw=y.
  \]

Its nullspace is \(N(A)\):

- \(N(A)\subseteq N(ZA)\);
- if \(ZAz=0\), then
  \[
  Az=AZAz=0
  \]
  because \(AZA=A\).

Thus

\[
R(ZA)=L,
\qquad
N(ZA)=N(A).
\]

The projector onto \(L\) along \(N(A)\) is unique, so

\[
ZA=Q.
\tag{8}
\]

Now combine (7), (8), the inner property of \(A^{-}\), and the outer property of \(Z\):

\[
\begin{aligned}
QA^{-}P
&=(ZA)A^{-}(AZ)\\
&=Z(AA^{-}A)Z\\
&=ZAZ\\
&=Z.
\end{aligned}
\]

Therefore every reflexive pseudoinverse with the prescribed range and nullspace must equal \(QA^{-}P\). Hence it is unique.

> **Final answer for (b).**
> There is exactly one reflexive pseudoinverse \(X\) satisfying
> \[
> R(X)=L,\qquad N(X)=M,
> \]
> and for every inner pseudoinverse \(A^{-}\),
> \[
> \boxed{X=QA^{-}P.}
> \]
> Moreover,
> \[
> \boxed{AX=P,\qquad XA=Q,}
> \]
> which immediately yields
> \[
> AXA=A,\qquad XAX=X.
> \]

### Conceptual interpretation

The restriction

\[
A|_L:L\to R(A)
\]

is bijective:

- it is injective because \(L\cap N(A)=\{0\}\);
- it is surjective because every \(z\in\mathbb C^n\) decomposes as \(z=\ell+n\), with \(\ell\in L\) and \(n\in N(A)\), and then \(Az=A\ell\).

The unique \(X\) is the inverse of this restricted map on \(R(A)\), extended by zero on \(M\). The formula \(QA^{-}P\) implements precisely that geometric construction.

\newpage

# Appendix: recurring definitions and proof patterns

## A. Direct-sum criteria

For subspaces \(X,Y\subseteq V\),

\[
V=X\oplus Y
\]

is equivalent to either of the following:

1. \(V=X+Y\) and \(X\cap Y=\{0\}\);
2. every \(v\in V\) has a unique decomposition \(v=x+y\);
3. the union of a basis for \(X\) and a basis for \(Y\), with no duplicated vectors, is a basis for \(V\).

The standard uniqueness move is

\[
x_1+y_1=x_2+y_2
\implies
x_1-x_2=y_2-y_1\in X\cap Y.
\]

## B. Projector identities

A linear operator \(P\) is a projector if and only if

\[
P^2=P.
\]

Every projector produces the direct sum

\[
V=R(P)\oplus N(P).
\]

It acts as the identity on its range and as zero on its nullspace:

\[
x\in R(P)\iff Px=x,
\qquad
y\in N(P)\iff Py=0.
\]

The complementary projector satisfies

\[
R(I-P)=N(P),
\qquad
N(I-P)=R(P).
\]

## C. Basis formula for an oblique projector

If

\[
B=[X\mid Y]
\]

is nonsingular, with columns of \(X\) and \(Y\) forming bases for complementary subspaces, then

\[
P=[X\mid0]B^{-1}
=
B
\begin{bmatrix}
I&0\\
0&0
\end{bmatrix}
B^{-1}.
\]

Solving

\[
B
\begin{bmatrix}
z_1\\z_2
\end{bmatrix}
=v
\]

gives

\[
v=Xz_1+Yz_2,
\]

so the two projections are \(Xz_1\) and \(Yz_2\).

## D. Range and nullspace product tests

For projectors \(P,Q\),

\[
R(P)=R(Q)
\iff
PQ=Q,\quad QP=P,
\]

whereas

\[
N(P)=N(Q)
\iff
PQ=P,\quad QP=Q.
\]

Remembering which right-hand side appears is easier if one thinks:

- a projector fixes vectors in its own range;
- a projector annihilates vectors in its own nullspace.

## E. Norm of a projector

For \(P\ne0\),

\[
\|P\|_2\ge1.
\]

Equality holds exactly when

\[
R(P)\perp N(P).
\]

For a nontrivial oblique projector,

\[
\|P\|_2=\frac1{\sin\theta},
\]

where \(\theta\) is the minimal angle between its range and nullspace.

## F. Inner pseudoinverse projectors

If

\[
AA^{-}A=A,
\]

then

\[
AA^{-}
\]

is a projector onto \(R(A)\), and

\[
I-A^{-}A
\]

is a projector onto \(N(A)\). Therefore a consistent system has the solution set

\[
A^{-}b+R(I-A^{-}A).
\]

These identities prepare the way for later treatments of generalized inverses, least squares, and orthogonal projection.
