"""Streaming loaders shared by comparison and inspection."""

from collections.abc import Iterator

import polars as pl
from data_mcp_core import sql

from qa_mcp_server.config import resolve_sql_source
from qa_mcp_server.models import DatasetSource, InlineSource, SQLSource
from qa_mcp_server.sources.files import iter_file_batches
from qa_mcp_server.sources.inline import iter_inline_batches

DEFAULT_BATCH_SIZE = 10_000


def iter_batches(
    source: DatasetSource, batch_size: int = DEFAULT_BATCH_SIZE
) -> Iterator[pl.DataFrame]:
    if batch_size < 1:
        raise ValueError("batch_size must be positive")
    if isinstance(source, SQLSource):
        yield from sql.iter_sql_batches(resolve_sql_source(source), batch_size)
    elif isinstance(source, InlineSource):
        yield from iter_inline_batches(source, batch_size)
    else:
        yield from iter_file_batches(source, batch_size)
