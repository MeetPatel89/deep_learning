"""Run queries with lossless pagination, recursive trees and Polars statistics."""

import base64
import hashlib
import json
from datetime import UTC, datetime, timedelta
from typing import Any

import polars as pl
from data_mcp_core.results import bounded_result, json_safe, paginate, redact
from data_mcp_core.results import continuation as page_token

from synapse_mcp_server.base import field


def utc_datetime(value: str | datetime) -> datetime:
    value = (
        datetime.fromisoformat(value.replace("Z", "+00:00")) if isinstance(value, str) else value
    )
    return value.replace(tzinfo=UTC) if value.tzinfo is None else value.astimezone(UTC)


def duration_ms(run: dict) -> float | None:
    duration = field(run, "durationInMs", field(run, "runDurationInMs"))
    if duration is not None:
        return float(duration)
    start = field(run, "runStart", field(run, "activityRunStart"))
    end = field(run, "runEnd", field(run, "activityRunEnd"))
    return (
        (utc_datetime(end) - utc_datetime(start)).total_seconds() * 1000 if start and end else None
    )


class MonitoringTools:
    def _query_runs(
        self,
        workspace,
        kind,
        after,
        before,
        filters,
        limit,
        continuation,
        pipeline=None,
        run_id=None,
        parameters=None,
        cap_output=False,
    ):
        if not 1 <= limit <= 1000:
            raise ValueError("limit must be between 1 and 1000")
        context = hashlib.sha256(
            json.dumps(
                [workspace, kind, after, before, filters, pipeline, run_id, parameters],
                sort_keys=True,
            ).encode()
        ).hexdigest()
        sdk_token, offset = None, 0
        if continuation:
            try:
                if len(continuation) > 32_000:
                    raise ValueError
                token = json.loads(base64.b64decode(continuation, altchars=b"-_", validate=True))
                if (
                    token["context"] != context
                    or type(token["offset"]) is not int
                    or token["offset"] < 0
                ):
                    raise ValueError
                sdk_token, offset = token["sdk"], token["offset"]
                effective_after, effective_before = (
                    utc_datetime(token["after"]),
                    utc_datetime(token["before"]),
                )
            except (ValueError, TypeError, KeyError) as error:
                raise ValueError("Invalid run continuation token") from error
        else:
            now = datetime.now(UTC)
            effective_before = utc_datetime(before) if before else now
            effective_after = utc_datetime(after) if after else effective_before - timedelta(days=7)
        if effective_after >= effective_before:
            raise ValueError("The run time window must have after < before")
        from azure.synapse.artifacts.models import RunFilterParameters, RunQueryFilter

        settings = RunFilterParameters(
            last_updated_after=effective_after,
            last_updated_before=effective_before,
            continuation_token=sdk_token,
            filters=[
                RunQueryFilter(operand=operand, operator="In", values=values)
                for operand, values in filters
            ],
        )
        client = self.clients.get(workspace, "artifacts")
        if kind == "pipeline":
            response = client.pipeline_run.query_pipeline_runs_by_workspace(settings)
        elif kind == "activity":
            response = client.pipeline_run.query_activity_runs(pipeline, run_id, settings)
        else:
            response = client.trigger_run.query_trigger_runs_by_workspace(settings)
        data = json_safe(response)
        items = data.get("value", [])
        if parameters:
            items = [
                item
                for item in items
                if all(
                    field(item, "parameters", {}).get(key) == value
                    for key, value in parameters.items()
                )
            ]
        page = (
            paginate(items, limit, page_token(offset, context), context, max_chars=45_000)["items"]
            if cap_output
            else items[offset : offset + limit]
        )
        next_offset = offset + len(page)
        next_sdk = sdk_token
        if next_offset >= len(items):
            next_sdk, next_offset = field(data, "continuationToken"), 0
        token = None
        if next_offset or next_sdk:
            token = base64.urlsafe_b64encode(
                json.dumps(
                    {
                        "context": context,
                        "sdk": next_sdk,
                        "offset": next_offset,
                        "after": effective_after.isoformat(),
                        "before": effective_before.isoformat(),
                    }
                ).encode()
            ).decode()
        return {
            "items": redact(page),
            "continuation": token,
            "window": {
                "after": effective_after.isoformat(),
                "before": effective_before.isoformat(),
            },
        }

    def query_pipeline_runs(
        self,
        workspace: str,
        pipeline: str | None = None,
        statuses: list[str] | None = None,
        after: str | None = None,
        before: str | None = None,
        parameters: dict[str, Any] | None = None,
        limit: int = 100,
        continuation: str | None = None,
    ) -> dict[str, Any]:
        """Query runs by pipeline, status, updated UTC window and parameter equality; resume with
        continuation.
        """
        self.live_workspace(workspace, "monitoring")
        filters = []
        if pipeline:
            filters.append(("PipelineName", [pipeline]))
        if statuses:
            filters.append(("Status", statuses))
        return self._query_runs(
            workspace,
            "pipeline",
            after,
            before,
            filters,
            limit,
            continuation,
            parameters=parameters,
            cap_output=True,
        )

    def _get_run(self, workspace, run_id, toolset=None):
        if toolset:
            self.live_workspace(workspace, toolset)
        return json_safe(
            self.clients.get(workspace, "artifacts").pipeline_run.get_pipeline_run(run_id)
        )

    def get_pipeline_run(self, workspace: str, run_id: str) -> dict[str, Any]:
        """Get a pipeline run, resolved parameters, status and timing."""
        self.live_workspace(workspace, "monitoring")
        return bounded_result(self._get_run(workspace, run_id))

    def query_activity_runs(
        self,
        workspace: str,
        run_id: str,
        pipeline: str | None = None,
        statuses: list[str] | None = None,
        after: str | None = None,
        before: str | None = None,
        limit: int = 100,
        continuation: str | None = None,
    ) -> dict[str, Any]:
        """Query activity input, output, error and timings for a pipeline run."""
        self.live_workspace(workspace, "monitoring")
        if pipeline is None:
            run = self._get_run(workspace, run_id)
            pipeline = field(run, "pipelineName")
        filters = [("Status", statuses)] if statuses else []
        return self._query_runs(
            workspace,
            "activity",
            after,
            before,
            filters,
            limit,
            continuation,
            pipeline,
            run_id,
            cap_output=True,
        )

    def _activity_runs(self, workspace, run):
        start = field(run, "runStart")
        after = (utc_datetime(start) - timedelta(days=1)).isoformat() if start else None
        before = (datetime.now(UTC) + timedelta(minutes=5)).isoformat()
        token, seen, items = None, set(), []
        for _ in range(100):
            page = self._query_runs(
                workspace,
                "activity",
                after,
                before,
                [],
                1000,
                token,
                pipeline=field(run, "pipelineName"),
                run_id=field(run, "runId"),
            )
            items.extend(page["items"])
            token = page["continuation"]
            if not token:
                return items
            if token in seen:
                raise RuntimeError("Azure repeated an activity continuation token")
            seen.add(token)
        raise RuntimeError("Activity query exceeds 100 pages; narrow the query")

    def get_activity_run(self, workspace: str, run_id: str, activity_run_id: str) -> dict[str, Any]:
        """Get one activity attempt by its activity_run_id (includes resolved input, output and
        error).
        """
        self.live_workspace(workspace, "monitoring")
        run = self._get_run(workspace, run_id)
        for activity in self._activity_runs(workspace, run):
            if field(activity, "activityRunId") == activity_run_id:
                return bounded_result(activity)
        raise ValueError("Activity run was not found")

    def query_trigger_runs(
        self,
        workspace: str,
        trigger: str | None = None,
        statuses: list[str] | None = None,
        after: str | None = None,
        before: str | None = None,
        limit: int = 100,
        continuation: str | None = None,
    ) -> dict[str, Any]:
        """Query trigger runs in an updated UTC window."""
        self.live_workspace(workspace, "monitoring")
        filters = []
        if trigger:
            filters.append(("TriggerName", [trigger]))
        if statuses:
            filters.append(("Status", statuses))
        return self._query_runs(
            workspace, "trigger", after, before, filters, limit, continuation, cap_output=True
        )

    def _run_tree(self, workspace, run_id, max_depth=10, max_runs=100):
        visited = set()

        def visit(identifier, depth):
            if identifier in visited:
                return {"run_id": identifier, "cycle_or_repeated_reference": True, "children": []}
            if len(visited) >= max_runs:
                return {"run_id": identifier, "truncated": True, "children": []}
            visited.add(identifier)
            run = self._get_run(workspace, identifier)
            activities = self._activity_runs(workspace, run)
            node = {
                "run_id": identifier,
                "pipeline": field(run, "pipelineName"),
                "status": field(run, "status"),
                "duration_ms": duration_ms(run),
                "run": run,
                "activities": activities,
                "children": [],
            }
            for activity in activities:
                output = field(activity, "output", {}) or {}
                child = (
                    field(output, "pipelineRunId")
                    if field(activity, "activityType") == "ExecutePipeline"
                    else None
                )
                if child:
                    if depth >= max_depth:
                        node["children"].append(
                            {"run_id": child, "truncated": True, "children": []}
                        )
                    else:
                        node["children"].append(visit(child, depth + 1))
            return node

        return visit(run_id, 0)

    def get_run_tree(
        self, workspace: str, run_id: str, max_depth: int = 10, max_runs: int = 100
    ) -> dict[str, Any]:
        """Walk ExecutePipeline child runs, including activity states and durations."""
        self.live_workspace(workspace, "monitoring")
        if not 0 <= max_depth <= 20 or not 1 <= max_runs <= 100:
            raise ValueError("Invalid run tree caps")
        return bounded_result(self._run_tree(workspace, run_id, max_depth, max_runs))

    def pipeline_run_stats(
        self,
        workspace: str,
        pipeline: str | None = None,
        after: str | None = None,
        before: str | None = None,
        max_runs: int = 10_000,
    ) -> dict[str, Any]:
        """Aggregate run success rates, duration percentiles and failures with Polars."""
        self.live_workspace(workspace, "monitoring")
        if not 1 <= max_runs <= 100_000:
            raise ValueError("max_runs must be between 1 and 100000")
        runs, token, seen = [], None, set()
        # A stable explicit window avoids changing it across pages.
        before = before or datetime.now(UTC).isoformat()
        after = after or (utc_datetime(before) - timedelta(days=7)).isoformat()
        while len(runs) < max_runs:
            page = self._query_runs(
                workspace,
                "pipeline",
                after,
                before,
                [("PipelineName", [pipeline])] if pipeline else [],
                min(1000, max_runs - len(runs)),
                token,
            )
            runs.extend(page["items"])
            token = page["continuation"]
            if not token:
                break
            if token in seen:
                raise RuntimeError("Azure repeated a run continuation token")
            seen.add(token)
        if not runs:
            return {
                "run_count": 0,
                "success_rate": None,
                "duration_ms": {},
                "failures": [],
                "truncated": False,
            }
        frame = pl.DataFrame(
            {
                "status": [field(run, "status", "Unknown") for run in runs],
                "duration": [duration_ms(run) for run in runs],
                "message": [field(run, "message", "") or "" for run in runs],
            },
            schema={"status": pl.String, "duration": pl.Float64, "message": pl.String},
        )
        quantiles = frame.select(
            [
                pl.col("duration").quantile(q, interpolation="linear").alias(name)
                for q, name in ((0.5, "p50"), (0.9, "p90"), (0.95, "p95"), (0.99, "p99"))
            ]
        ).to_dicts()[0]
        return bounded_result(
            {
                "run_count": len(runs),
                "success_rate": frame.filter(pl.col("status") == "Succeeded").height / len(runs),
                "statuses": frame.group_by("status").len().to_dicts(),
                "duration_ms": quantiles,
                "failures": frame.filter(pl.col("status") == "Failed")
                .group_by("message")
                .len()
                .sort("len", descending=True)
                .head(20)
                .to_dicts(),
                "truncated": token is not None,
                "continuation": token,
            }
        )

    def compare_pipeline_runs(
        self, workspace: str, expected_run_id: str, actual_run_id: str
    ) -> dict[str, Any]:
        """Compare resolved parameters, activity attempts, durations and Copy row counts."""
        self.live_workspace(workspace, "monitoring")
        expected, actual = (
            self._get_run(workspace, expected_run_id),
            self._get_run(workspace, actual_run_id),
        )
        left, right = field(expected, "parameters", {}) or {}, field(actual, "parameters", {}) or {}
        differences = {
            key: {"expected": left.get(key), "actual": right.get(key)}
            for key in left.keys() | right.keys()
            if (key in left) != (key in right) or left.get(key) != right.get(key)
        }

        def index(run):
            groups = {}
            for activity in sorted(
                self._activity_runs(workspace, run),
                key=lambda item: field(item, "activityRunStart", "") or "",
            ):
                name = field(activity, "activityName")
                groups.setdefault(name, []).append(activity)
            return groups

        left_activities, right_activities = index(expected), index(actual)
        comparisons = []
        for name in sorted(left_activities.keys() | right_activities.keys()):
            first, second = left_activities.get(name, []), right_activities.get(name, [])
            for attempt in range(max(len(first), len(second))):
                a, b = (
                    first[attempt] if attempt < len(first) else {},
                    second[attempt] if attempt < len(second) else {},
                )

                def metrics(activity):
                    output = field(activity, "output", {}) or {}
                    return {
                        "status": field(activity, "status"),
                        "duration_ms": duration_ms(activity),
                        "rows_read": field(output, "rowsRead"),
                        "rows_written": field(output, "rowsCopied", field(output, "rowsWritten")),
                    }

                comparisons.append(
                    {
                        "activity": name,
                        "attempt": attempt,
                        "expected": metrics(a),
                        "actual": metrics(b),
                    }
                )
        return bounded_result(
            {
                "parameter_differences": differences,
                "expected_duration_ms": duration_ms(expected),
                "actual_duration_ms": duration_ms(actual),
                "activities": comparisons,
            }
        )
