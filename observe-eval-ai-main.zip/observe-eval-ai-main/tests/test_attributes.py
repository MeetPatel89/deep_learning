"""Preserve model-runtime's validated, immutable Langfuse dimensions."""

from dataclasses import FrozenInstanceError, replace
from typing import cast

from pytest import mark, raises

from observability_ai import TraceAttributes


def test_attributes_snapshot_inputs_and_return_fresh_mappings() -> None:
    """Caller mutation cannot change dimensions already assigned to a trace."""
    tags = ["example", "café"]
    metadata = {"tenant": "docs", "label": "café"}
    trace = TraceAttributes(
        session_id="session-123", user_id="user-456", tags=tags, metadata=metadata
    )
    tags.append("changed")
    metadata["tenant"] = "changed"
    attributes = trace.as_otel_attributes()
    assert attributes == {
        "langfuse.session.id": "session-123",
        "langfuse.user.id": "user-456",
        "langfuse.trace.tags": ("example", "café"),
        "langfuse.trace.metadata.tenant": "docs",
        "langfuse.trace.metadata.label": "café",
    }
    attributes.clear()
    assert trace.as_otel_attributes()["langfuse.trace.metadata.tenant"] == "docs"
    assert trace.tags == ("example", "café")
    with raises(TypeError):
        cast(dict[str, str], trace.metadata)["tenant"] = "new"
    with raises(FrozenInstanceError):
        setattr(trace, "user_id", "new")


def test_optional_attributes_and_length_boundary() -> None:
    """Absent dimensions are omitted; every text field accepts 200 characters."""
    assert TraceAttributes().as_otel_attributes() == {}
    text = "s" * 200
    trace = TraceAttributes(
        session_id=text, user_id=text, tags=[text], metadata={text: "é" * 200}
    )
    assert len(trace.as_otel_attributes()) == 4


@mark.parametrize(
    ("field", "value", "error", "message"),
    [
        ("session_id", "", ValueError, "empty"),
        ("user_id", "", ValueError, "empty"),
        ("session_id", "s" * 201, ValueError, "at most 200"),
        ("user_id", "u" * 201, ValueError, "at most 200"),
        ("session_id", "séance", ValueError, "US-ASCII"),
        ("user_id", "usér", ValueError, "US-ASCII"),
        ("user_id", 3, TypeError, "string"),
        ("tags", "single-tag", TypeError, "sequence"),
        ("tags", [""], ValueError, "empty"),
        ("tags", ["t" * 201], ValueError, "at most 200"),
        ("tags", [42], TypeError, "string"),
        ("metadata", [], TypeError, "mapping"),
        ("metadata", {"": "v"}, ValueError, "empty"),
        ("metadata", {"ténant": "v"}, ValueError, "US-ASCII"),
        ("metadata", {"k" * 201: "v"}, ValueError, "at most 200"),
        ("metadata", {"k": "v" * 201}, ValueError, "at most 200"),
        ("metadata", {"k": ""}, ValueError, "empty"),
        ("metadata", {1: "v"}, TypeError, "string"),
        ("metadata", {"k": 1}, TypeError, "string"),
    ],
)
def test_invalid_trace_dimensions(
    field: str, value: object, error: type[Exception], message: str
) -> None:
    """Reject dimensions that cannot be faithfully represented in Langfuse."""
    with raises(error, match=message):
        replace(TraceAttributes(), **{field: value})  # type: ignore[arg-type]
