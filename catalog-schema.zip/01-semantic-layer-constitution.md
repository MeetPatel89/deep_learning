# Semantic-layer constitution for an enterprise NL-to-SQL platform

Version: 2.0 enterprise design • Revised 2026-09-26

Companions: [Enterprise implementation design](02-implementation-design.md) and [worked sample domain](03-worked-examples.md).

## 1. Purpose and status

The semantic layer is the governed interface between business questions and database queries. It defines what data means, which populations and records an answer represents, how concepts map to stored values, which relationships may be traversed, and which query operations are valid. Its executable contracts are consumed by deterministic application code.

**Recommended architecture:** a durable LangGraph workflow routes a question to authorized business domains; hybrid lexical/vector retrieval, reranking and a typed semantic graph assemble relevant context; the LLM proposes a typed business query using those definitions; deterministic resolvers, planners and compilers bind values, enforce grain/relationship contracts and produce parameterized SQL; source permissions and runtime controls govern execution. A shared catalog database publishes consistent releases to SQLite snapshots, search indexes and graph projections. Agent Skills can package domain procedures.

The target is a production application over a large company database with many domains and tables. Producer_Licenses, Producer_Appointments, Agent_Contracts and Agency_Contracts are teaching examples and regression fixtures. They do not define platform capacity or cap the supported query language. Development phases limit the domains and operators released to users while preserving the enterprise architecture from the first production deployment.

This constitution specifies the target rules. It does not assert that the supplied database already meets them. `MUST` denotes a release or execution requirement; `SHOULD` denotes a recommended practice with a documented exception; `MAY` denotes an optional extension.

The reviewed workbook is a **header-only catalog template**, not a populated semantic model. Azure SQL Database remains the operational target. The user approved a shared authoritative catalog database with SQLite published snapshots for production. “Term date” meaning license termination date and status mappings are clarifications for the sample domain. Other concrete business definitions below are illustrative until approved for an onboarded domain. The companion documents distinguish target architecture, sample assumptions and verified facts.

## 2. Evidence and workbook assessment

Inspected the attachment named `semantic_catalogue.xlsx` retrieved from the referenced conversation, rather than assuming the earlier `/mnt/data` path existed in this Windows workspace. Workbook SHA-256: `51133d92a8967e4ae60c1f915d555ab246adf537ef772086ed193698cffca8f1`. All worksheet cell contents were inspected. There are five sheets and no populated definition rows, formulas, or query examples in their cells.

| Workbook location | Existing fields | Assessment |
|---|---|---|
| `meta_tables!A1:B1` | `TABLE_NAME`, `BUSINESS_DESCRIPTION` | Good entity inventory start; needs stable identity, source, grain, keys, owner, lifecycle and security. |
| `meta_columns!A1:F1` | `TABLE_NAME`, `COLUMN_NAME`, `DATA_TYPE`, `BUSINESS_COLUMN_NAME`, `ENUM_MAPPING`, `BUSINESS_DESCRIPTION` | Good field inventory start; needs null semantics, roles, permitted operations, sensitivity, and typed binding. |
| `meta_enum_mappings!A1:E1` | `ENUM_MAPPING`, `LITERAL_VALUE`, `CANONICAL_NAME`, `ALIASES`, `BUSINESS_DESCRIPTION` | Correct separation of stored value and business label; needs concept IDs, source-specific bindings, validity and ambiguity rules. |
| `meta_joins!A1:F1` | `JOIN_NAME`, `LEFT_TABLE_NAME`, `RIGHT_TABLE_NAME`, `TYPE`, `ON`, `CARDINALITY` | Already recognizes join type and cardinality as separate facts; needs scoped operations, preservation, filter placement, grain and evidence. |
| `meta_examples!A1:C1` | `EXAMPLE_NAME`, `EXAMPLE_DESCRIPTION`, `EXAMPLE_SQL` | Useful starting point; needs expected intent, versioned plans, fixtures and expected answers. |

Preserve these concepts. Extend them through a versioned importer and validated catalog schema. Excel may remain a business-authoring interface. The runtime MUST consume a published immutable catalog snapshot, not arbitrary edits to a live workbook.

## 3. Foundational commitments

| Rule | What it requires | Why it exists |
|---|---|---|
| C01 Meaning precedes SQL | Identify population, output grain, predicates and metric before compilation. | Syntactically valid SQL can answer the wrong question. |
| C02 IDs precede names | Reference stable semantic IDs; bind physical names separately. | Renames and source migrations should not rewrite prompts and saved queries. |
| C03 Facts precede similarity | Resolve labels to authoritative records and bindings. | Search similarity is not proof that a stored code is correct. |
| C04 Contracts precede join syntax | Select an approved relationship operation; compiler owns SQL form. | A plausible join can lose rows or multiply measures. |
| C05 Unknown stays unknown | Missing rules produce clarification or unsupported errors. | Invention creates confident, untraceable answers. |
| C06 Authorization covers every stage | Scope metadata, value resolution, source access, results and caches. | A protected value can leak without ever appearing in a final result row. |
| C07 Versions travel together | Pin catalog, mapping, policy and compiler versions to each compiled artifact. | An answer must be attributable to the rules actually used. |
| C08 Tests prove specific guarantees | Test populations, grain, nulls, duplicates and policy boundaries. | Successful parsing and a few happy-path examples are insufficient. |
| C09 One implementation of a business rule | Predicates and metrics are referenced by ID. | Repeated status/date logic drifts across queries. |
| C10 Versioned expressiveness | A general typed query algebra has an explicit capability registry; each release enables tested operators by domain and workload class. | Broad enterprise coverage requires planned extension without accepting ungoverned SQL. |
| C11 Enterprise retrieval | The first production release includes hybrid retrieval, reranking and graph dependency expansion. | Domain ambiguity and relevant-schema discovery already exist in a large database. |
| C12 Coherent publication | Every request pins a manifest binding catalog, search, graph, model and compiler artifacts; authorization remains current. | Independently updated indexes must not combine incompatible definitions. |
| C13 Durable execution | Production workflows persist state, support clarification/resume, enforce budgets and recover safely. | Multi-user systems face timeouts, retries, restarts and long queries from the outset. |
| C14 Measured rollout | Each domain/operator release passes semantic, security, retrieval, target-engine and operational gates. | A few sample queries cannot establish enterprise readiness. |

## 4. Components: what, why, required contents and enforcement

### 4.1 Domain and business glossary

**What:** named concepts such as producer, individual, agency, license, appointment, contract, active and Pet product category. A glossary describes business intent and distinguishes homonyms.

**Why:** the same word can refer to different fields or entities. “Active” may have separate definitions for licenses, appointments and contracts. “Individual” may describe a legal person type, a contract type, or simply a request for detail rows.

**Minimum contents:** stable concept ID, label, definition, aliases, scope, owner, related entity/field/predicate IDs, provenance, status and version. An alias MUST NOT silently merge different concepts. Ambiguous aliases return alternatives.

**Enforcement:** catalog publication detects alias collisions within a scope. Interpretation records which concept was chosen and why. No universal `active = Status = 'A'` rule may be inferred from a label.

### 4.2 Entities, physical bindings and row grain

**What:** an entity is an addressable semantic dataset. It can bind to a table, secured view or reviewed derived relation. Grain says what one row represents in business terms. Separate key declarations explain how to identify a physical row, the real-world/business thing, and, when applicable, a version of that thing.

**Why:** “one row per license record” is incomplete if the team has not defined what distinguishes two license records. A table can contain one row per loaded snapshot row, per license version, or per current license. Counts of source rows, business licenses, producers, license numbers and historical versions are different metrics. A primary key, especially a surrogate key, can make each physical row unique without proving which rows represent the same business license.

**Minimum contents:** ID, description, connection reference, qualified object binding, current/history semantics, a grain specification, physical row key, business identity candidate(s), version identifier(s) where present, null/normalization rules, uniqueness evidence, owner, provenance, freshness expectations and allowed access. Store credentials outside the catalog.

**Enforcement:** publication verifies referenced fields and key assertions. A cardinality-dependent operation MUST have valid evidence for its required uniqueness. A `source_row_count` can count physical rows. A `license_count` requires a business definition, a rule for current/history versions, and a key or approved row-selection rule that identifies one counted license. The compiler must not repair duplicate identities with an unexplained `DISTINCT`.

**Application:** the supplied column lists do not establish a license business key. `(Producer_Key, License_Id)` is only a candidate composite key, and `License_Id` may itself be a surrogate row ID. `License_Number` may repeat across states, producers, or versions; a combination such as `(Producer_Key, State, License_Number)` is also only a hypothesis until the business owner confirms its meaning and data constraints support it. The same rule applies to `(Producer_Key, Appointment_Id)`. Contract identities need source qualification if combined. Never infer the business key from column names or a primary-key constraint alone.

### 4.3 Fields and dimensions

**What:** field metadata binds semantic attributes to source columns or reviewed expressions. A dimension is a business attribute used to filter, group or describe records.

**Why:** physical types alone do not explain nulls, valid comparisons, business synonyms, sensitive content or aggregation behavior.

**Minimum contents:** entity ID, field ID, source binding, semantic type, physical type, null meaning, business label, definition, roles, permitted operators, optional value-domain ID, sensitivity, lineage and status. Roles may include identifier, dimension, measure input and temporal field.

**Enforcement:** typed validation rejects incompatible comparisons and unauthorized projections. Identifiers bind through an allowlist; they are never accepted as arbitrary SQL text. `NULL`, empty text, unknown codes and an absent business fact remain distinct unless a governed normalization rule says otherwise.

**Application:** the user confirmed that “term date” in the first query means `Producer_Licenses.Termination_Date`. Retrieve its description and aliases; let the agent propose an `is_null` filter on that semantic field; validate and compile it deterministically. It does not establish current activity without a business definition. `State` cannot be added to a contract join because the supplied contract tables have no State column.

### 4.4 Value domains, aliases and physical value bindings

**What:** a value domain owns canonical values and aliases. A binding maps a canonical value to one or more typed source literals for a particular entity/field and effective interval.

**Why:** “Pet” could be stored as `PET`, `P`, an integer, or several product codes. Agent and agency contract sources may encode it differently.

**Minimum contents:** domain ID, value ID, canonical label, aliases, description, binding scope, literal type/value, source of truth, validity interval, deprecation status, owner and revision. A canonical value may bind to a set of literals; the set must be complete for the requested scope.

**Enforcement:** exact code/name/curated alias matching first for literal resolution; lexical/vector retrieval and reranking supply candidates when needed. Hybrid search is a production platform capability, but an exact status-code lookup need not call embeddings. Only a resolver can issue a resolved value handle. An LLM-generated literal is insufficient. Missing binding coverage produces an error rather than silently searching only one contract source. High-cardinality values use authorized indexed providers with recorded freshness and source-specific bindings.

**Ambiguity:** no universal embedding-score threshold proves correctness. V1 should ask the user to choose among plausible fuzzy matches. Later auto-resolution requires evaluated, domain-specific acceptance rules. A deterministic algorithm is repeatable, but its inferred match can still be semantically wrong.

### 4.5 Named business predicates and temporal semantics

**What:** a named predicate is a reusable typed condition, such as `license.active`, `appointment.active`, `license.no_termination_date` or `contract.has_product_category`.

**Why:** a predicate often combines code mappings, dates and exception handling. Repeating it in prompts makes behavior inconsistent.

**Minimum contents:** ID, supported entity, typed expression tree, required value bindings, parameter definitions, null behavior, time basis, owner, explanation and tests. Declare whether a predicate is a mandatory security restriction, source technical restriction, business default or user-requested condition.

**Enforcement:** required restrictions are inserted by trusted code; defaults are disclosed and overridable only where allowed. User filters cannot remove mandatory restrictions. Time-dependent predicates use an explicit timestamp/timezone and boundary rule.

**Application:** enum mappings and reviewed example queries provide evidence for interpreting “active.” For a status-only definition, a predicate can simply reference the appropriate mapped status set. If a reviewed definition also imposes a date condition, promote that condition into the named predicate so all questions use it consistently. Do not equate “active” with “no term date.” Historical “active as of” queries usually need effective dates or snapshots; the supplied fields cannot establish all historical states.

### 4.6 Relationships and operation contracts

**What:** a relationship describes an approved correspondence between entity roles. Its operation contract specifies how that relationship may be used in a query: qualify by existence, exclude by absence, enrich without dropping the base population, or expand into child details.

**Why:** one equality does not determine the right query behavior. `LEFT JOIN`, `INNER JOIN`, `EXISTS` and a child collection express different population/grain intentions.

**Minimum contents:** stable ID, directed endpoints and roles, typed key pairs, required predicates, identity namespace, cardinality in both directions, null-key behavior, temporal scope, permitted operations, required SQL form for each operation, preservation policy, fanout behavior, output grain, allowed fields, required evidence, owner and version.

**Enforcement:** compile an operation selected by intent. For a mandatory-left enrichment contract, the compiler emits left-preserving logic and the validator rejects inner replacement. For a contract-existence condition, the compiler uses `EXISTS`, preventing child multiplicity from multiplying the base. Predicates that filter included child rows stay inside the child relation or join condition. Predicates that qualify the base population are modeled separately.

**Important limit:** preserving every eligible producer does not preserve one output row per producer when all licenses are expanded. A producer with three licenses yields three flat rows. Preservation and multiplicity are separate assertions.

**Application:** licenses and contracts joined only on Producer_Key can be many-to-many. They MUST NOT be declared many-to-one merely because Producer_Key has “key” in its name. “Has a Pet contract” is existence at producer scope; it does not prove the particular license is explicitly tied to that contract.

### 4.7 Populations and reusable cohorts

**What:** a population defines which base records qualify. A cohort can be a reusable membership predicate or a one-key-per-member relation.

**Why:** “all licenses held by producers with Pet contracts” separates a license population from contract evidence. Combining both in a raw detail join changes the count.

**Minimum contents:** base entity, qualifying conditions, applicable relationship IDs, time scope, authorization scope and key/grain guarantee.

**Enforcement:** materialized or derived cohort joins require verified uniqueness at the joined key. Otherwise compile as correlated existence. Unioned contract-source membership means “either source,” not “both sources.” The cohort must not imply an individual/agency relationship that is absent from the catalog.

### 4.8 Metrics and aggregation contracts

**What:** a metric defines what is measured, at which grain, over which population and with what aggregation. It may be parameterized by category or time.

**Why:** `COUNT(*)`, `COUNT(License_Id)` and `COUNT(DISTINCT Producer_Key)` answer different questions; a measure can be duplicated by a later join.

**Minimum contents:** metric ID, label, base entity, grain, aggregation operator, unit, required predicates, optional filters, allowed group dimensions, additivity, null behavior and output type. Define record count and producer count as different metrics.

**Enforcement:** apply membership conditions without multiplying base rows; aggregate at the declared grain. Multiple facts require independent aggregation to approved conformed dimensions before combination, or a reviewed allocation rule. The general plan model represents these operations from the start. Releases enable each capability only after its contracts and target-engine tests pass; unsupported raw fact-to-fact multiplication is rejected.

**Application:** license and appointment counts are independent. Do not join licenses to appointments to answer either sample count. Pet-contract eligibility must not add a contract-status condition unless the question or an explicitly governed default requires it.

### 4.9 Query intent and semantic intermediate representation

**What:** a typed query plan carries base entity, projection, metric, population filters, relationship operations, resolved value references, output grain, sorting and pagination.

**Why:** it creates a stable boundary between probabilistic interpretation and deterministic execution. It also makes explanations and regression tests inspectable.

**Minimum contents:** schema version, catalog revision, query kind, known IDs, typed filters, relationship references, scoped filter placement, ambiguity decisions and response shape. The trusted application binds identity, policy context and execution limits separately.

**Enforcement:** reject unknown fields, SQL snippets, undeclared identifiers, incompatible metrics, unresolved values, unapproved paths and unsupported operators. The server canonicalizes and validates the model's proposal; the proposal is never an execution entitlement.

### 4.10 Catalog retrieval, path resolution and verified examples

**What:** retrieval finds candidate entities, fields, predicates, values and examples. Path resolution enumerates permitted typed relationship paths. Verified examples connect questions to reviewed plans, fixtures and expected results.

**Why:** only relevant context needs to reach the model, while completeness-critical dependencies must still be loaded deterministically.

**Minimum contents:** business-domain routing, authorization-aware lexical/vector indexes, atomic semantic documents, versioned IDs, calibrated reranking, graph dependency closure, provenance and explicit ambiguity outcomes. Retrieval evaluation measures complete required entity/field/relationship coverage, including low-ranked bridge entities. Verified examples include counterexamples and rejection expectations.

**Enforcement:** search rank cannot override relationship policy. Graph adjacency does not authorize arbitrary transitive joins. A shortest path can have the wrong temporal or business meaning. Materially different valid paths require a semantic preference or clarification. Reviewed examples inform intent; their SQL is not an executable bypass.

### 4.11 Compiler, semantic validator and SQL validator

**What:** the compiler lowers approved semantic plans to relational operations and SQL. Semantic checks establish meaning within the supported algebra; SQL checks validate the generated artifact against its expected structure and access restrictions.

**Why:** prompts and schema-valid JSON do not guarantee correct joins, filters or permissions.

**Minimum contents:** typed operator implementation, parameter binding, dialect adapter, field lineage, relationship-use manifest, grain analysis, authorization checks, deterministic aliasing and structured error codes.

**Enforcement:** only compiler-created artifacts can reach execution. The SQL validator parses all statement scopes, including CTEs and subqueries. It checks allowed objects/functions, operation shape and manifest consistency. It must not claim to prove semantic equivalence of arbitrary SQL. Unsupported transformations fail closed.

**Limit:** the strongest remaining risks are incorrect approved metadata, mistaken intent and source-data drift. Compilation cannot prove the owner's definition of “active” is the correct business definition.

### 4.12 Security and execution policy

**What:** trusted identity, metadata authorization, source restrictions, result controls and bounded read-only execution.

**Why:** the agent must not grant itself access by naming a table, selecting a tenant or supplying a policy ID. Aggregate existence can itself reveal protected information.

**Minimum contents:** data classification, entitled roles, permitted fields/operations, server-side identity context, row restriction mechanism, time/scan/result limits, function allowlist and audit rules. Never invent a tenant field absent from the source schema.

**Enforcement:** database grants and applicable row policies or secured views back application policy. Runtime credentials must lack elevated bypass privileges. Apply visibility to every relation used, including contract existence checks. If business users may test contract eligibility without reading raw contracts, provide a separately authorized eligibility object with that deliberate policy.

### 4.13 Provenance, freshness and answer presentation

**What:** an answer envelope records interpretation, rules, query identity, execution timing, scope and completeness.

**Why:** users need to know what was counted, whether results were truncated, and which definition produced a surprising result.

**Minimum contents:** metric/base grain, filters, source scope, approved assumptions, catalog/mapping/policy/compiler versions, data snapshot or execution time, result completeness, executed-query ID and relevant warnings. Store sensitive values only where authorized.

**Enforcement:** present database results faithfully. Do not label a limited page “all records.” Do not compute a global count over a page. If the database lacks snapshot retention, record that repeating the same SQL later can return different data.

### 4.14 Ownership, publication, change control and evidence

**What:** an authoring and release process for the catalog, separate from query execution.

**Why:** semantic changes can alter answers without changing application code. An unchecked spreadsheet cell must not become executable policy.

**Minimum contents:** draft/reviewed/published/deprecated lifecycle, business and technical owners, source evidence, effective interval, content hash, schema version, compatibility notes and migration tests.

**Enforcement:** publication validates schema, references, physical bindings, definitions, key evidence, mapping coverage and regression cases. Publish an immutable snapshot atomically. Existing requests pin it; urgent policy revocation takes precedence and invalidates affected artifacts. Draft objects cannot execute in production.

Changing an active definition, a join population rule or a source scope is a semantic change even if the metadata field names stay the same. It requires answer-impact review. Display-name changes that preserve semantics need less review.

### 4.15 Enterprise discovery, coverage and stewardship

**What:** automated collection of physical metadata, descriptions, approved query examples, lineage and restricted profiling, followed by domain-owner review.

**Why:** thousands of tables cannot be onboarded solely through manual spreadsheets. Automatically discovered foreign keys and descriptions are useful evidence, but they do not establish business identity, preferred join paths or metric meaning.

**Minimum contents:** source connector, schema fingerprint, domain assignment, technical owner, business steward, discovered/inferred/approved status, confidence provenance, source evidence and coverage gaps. Approved operational query logs may suggest missing definitions after redaction; they must not silently become authoritative rules.

**Enforcement:** discovery writes staging records. Only reviewed definitions publish. Each domain declares which question families are supported and how unknown fields or unavailable source history are handled. Measure coverage independently from correctness so a system cannot appear accurate by refusing most useful questions.

### 4.16 Search and graph projections

**What:** rebuildable search documents, embeddings, adjacency indexes and lineage projections derived from one catalog release.

**Why:** different retrieval operations require different access patterns. Large-schema language matching benefits from lexical/vector search; joining and dependency validation need explicit typed relationships.

**Minimum contents:** source object IDs, content hashes, release ID, embedding model/dimensions, index configuration, graph projection version, access-policy references and build status. Separate execution relationship edges from descriptive or inferred associations.

**Enforcement:** every selected search hit is rehydrated from the pinned authoritative snapshot and reauthorized before model context. Missing bridge definitions trigger bounded graph expansion. No similarity score or graph-summary prose may authorize a join. Search and graph are projections, never independently edited authorities.

### 4.17 Durable workflows and workload control

**What:** an explicit production workflow with domain routing, retrieval, value resolution, interpretation, clarification, compilation, execution and answer assembly.

**Why:** retries, human clarification and long queries must survive process restarts without losing scope or resubmitting unbounded database work.

**Minimum contents:** checkpointed state, identity binding, deadlines, stage budgets, bounded repair loops, idempotency/execution ledger, cancellation, typed errors and retention policy. Separate interactive requests, exports and catalog ingestion into workload classes.

**Enforcement:** use LangGraph with a durable production checkpointer in the first production release. Deterministic nodes call the same domain services as other application clients. Credentials, authorization and query execution remain server-controlled. Resume rechecks live entitlement and revocations; checkpoint persistence is not a guarantee of exactly-once database execution.

### 4.18 Production quality and operations

**What:** enterprise evaluation, observability, release management, capacity planning and recovery.

**Why:** accurate SQL on four sample tables does not show correct retrieval over a large catalog, correct cross-domain joins or safe operation under load.

**Minimum contents:** domain-balanced evaluation sets, retrieval completeness, semantic result checks, target-engine tests, security negatives, latency/cost budgets, load/soak/failure tests, model/index versioning, incident ownership, recovery objectives and rollback artifacts.

**Enforcement:** publish only capabilities and domains that pass defined gates. Monitor incorrect accepted answers, unnecessary clarification, unsupported-request rate, database load, index lag and authorization freshness separately. Model, prompt, embedding or ranker changes require regression evaluation even when application code is unchanged.

## 5. Production technology commitments

| Responsibility | Recommended initial production choice | Reason and boundary |
|---|---|---|
| Authoritative catalog and release service | Shared PostgreSQL database, managed with production backup/HA configuration | Concurrent editing, transactions, revision history and release coordination; business data remains in Azure SQL |
| Worker catalog reads | Immutable SQLite snapshots keyed by release hash | Local, consistent lookup; workers never edit published snapshots |
| Hybrid retrieval | Azure AI Search lexical/vector indexes with evaluated reranking | Supports language matching across large domains; authoritative objects are reloaded before planning |
| Relationship planning | Typed directed multigraph, initially a dedicated planner service using NetworkX or equivalent | Explicit composite/temporal/role-aware graph from the first release; latency and memory validated before release |
| Workflow orchestration | LangGraph with PostgreSQL checkpointer | Durable clarification, branching and recovery from the first release |
| Operational queries | Azure SQL Database, controlled T-SQL executor | Source permissions, typed parameters, cost/time/result controls |
| Artifacts and recovery | Versioned object storage for releases, snapshots and permitted results | Rebuild indexes and graph projections; replay definition versions; controlled retention |

This is a recommended stack rather than a claim that installing these products guarantees quality. A vector-capable search service satisfies the vector-storage need; a separate standalone vector database is an implementation choice. A graph data structure is required from the outset. A dedicated graph database is selected before release if shared graph workloads, lineage exploration or measured planner capacity justify it; the choice must not be based on the four-table sample.

Keep three graphs distinct: the semantic relationship/dependency graph, a request's relational plan graph, and LangGraph's workflow graph. Storage and traversal technology can vary behind typed interfaces. Agent Skills can supply procedural packaging with on-demand resources. [Agent Skills specification](https://agentskills.io/specification)

The initial production architecture uses the orchestration facilities described by [LangGraph](https://docs.langchain.com/oss/python/langgraph/overview) and hybrid retrieval supported by [Azure AI Search](https://learn.microsoft.com/en-us/azure/search/hybrid-search-overview). Their placement and configuration are application design decisions.

## 6. Enterprise release requirements

| Requirement | Acceptance evidence |
|---|---|
| Catalog breadth and approved scope | Inventory of domains/tables, declared question families, coverage metrics and responsible stewards |
| Business identity and grain | Source-row key, business key, temporal/version rules, owner review and data evidence |
| Hybrid retrieval completeness | Held-out domain/cross-domain questions with complete required entity, field, metric and relationship sets |
| Relationship graph correctness | Approved role-aware paths, bridge cardinality, filter scope and fanout tests |
| Durable orchestration | Clarification survives restart; retries, deadlines, cancellation and execution uncertainty handled |
| Consistent release projections | Catalog/search/graph/model manifest pinning; no mixed-version results during publication |
| Access control | Pre-context authorization, live revocation, source restrictions, checkpoint/result/cache isolation |
| Query correctness | Target-engine results for supported operators, temporal cases, multiple facts and output grains |
| Operational readiness | Load/soak tests, proposed SLOs measured, dashboards, runbooks, backup and restore exercise |
| Safe expansion | Versioned operator/domain onboarding, regression suites, canary release and rollback |

The sample producer fixture is one required regression set among many. Its unresolved codes and keys are sample onboarding issues, not a definition of enterprise scope.

## 7. Phased maturity

Phase 0 establishes enterprise inventory, deployment requirements, representative evaluation sets and performance envelopes. Phase 1 delivers a production platform with hybrid retrieval, graph planning, LangGraph, a shared catalog, snapshots and execution controls over a selected set of real domains. Phase 2 broadens query operators and cross-domain coverage. Later phases increase organizational scale, temporal depth and workload coverage based on demand and measured limits.

The stable boundary is `question -> authorized context -> semantic query -> validated plan -> compiled artifact -> result`. Platform services and query semantics are designed for the target system now; rollout controls decide what is enabled. The plan anticipates normal schema migrations and operator additions while avoiding replacement of these central contracts.
