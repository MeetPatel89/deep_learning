"""Exercise the JSONL experiment CLI without sending traces or provider requests."""

from asyncio import CancelledError
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from subprocess import run
from sys import executable
from types import ModuleType
from typing import cast
from unittest.mock import AsyncMock, Mock

from pytest import CaptureFixture, MonkeyPatch, fixture, importorskip, mark, raises

importorskip("langfuse", reason="requires observe-eval-ai[langfuse]")

from langfuse import Langfuse  # noqa: E402
from langfuse.api import DatasetItem  # noqa: E402
from opentelemetry.sdk.trace.export.in_memory_span_exporter import (  # noqa: E402
    InMemorySpanExporter,
)

from observability_ai.evaluation import EvaluationResult, JudgeResponseError  # noqa: E402


@fixture
def example(
    sdk: tuple[Langfuse, InMemorySpanExporter], monkeypatch: MonkeyPatch
) -> ModuleType:
    """Load the CLI with fake credentials and intercept every SDK delivery path."""
    path = Path(__file__).resolve().parents[1] / "examples" / "experiment_example.py"
    spec = spec_from_file_location("experiment_example", path)
    assert spec is not None and spec.loader is not None
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    client, _ = sdk
    monkeypatch.setattr(client, "create_score", Mock())
    monkeypatch.setattr(client, "flush", Mock())
    monkeypatch.setattr(client, "shutdown", Mock(wraps=client.shutdown))
    monkeypatch.setattr(module, "build_langfuse_client", Mock(return_value=client))
    monkeypatch.setattr(module, "load_dotenv", Mock())
    monkeypatch.setenv("LANGFUSE_PUBLIC_KEY", "pk-example")
    monkeypatch.setenv("LANGFUSE_SECRET_KEY", "sk-example")
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    monkeypatch.delenv("ANTHROPIC_MODEL", raising=False)
    monkeypatch.setattr("sys.argv", ["experiment_example.py"])
    return module


@mark.parametrize("judge_enabled", [False, True])
def test_default_data_runs_real_sdk_with_optional_judge(
    example: ModuleType,
    sdk: tuple[Langfuse, InMemorySpanExporter],
    monkeypatch: MonkeyPatch,
    capsys: CaptureFixture[str],
    judge_enabled: bool,
) -> None:
    """Bundled JSONL passes deterministic gates and invokes only opted-in judges."""
    client, exporter = sdk
    judge = AsyncMock(return_value=EvaluationResult("normalization_quality", 1))
    monkeypatch.setattr(example, "_judge", judge)
    monkeypatch.setattr(example, "find_spec", lambda name: object())
    monkeypatch.setenv("ANTHROPIC_MODEL", "test-model")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "not-a-real-key")
    monkeypatch.setattr(
        "sys.argv",
        ["experiment_example.py", "--run-name", "candidate"]
        + (["--judge"] if judge_enabled else []),
    )
    experiment = Mock(wraps=client.run_experiment)
    monkeypatch.setattr(client, "run_experiment", experiment)
    example.main()
    assert experiment.call_args.kwargs["run_name"] == "candidate"
    assert experiment.call_args.kwargs["max_concurrency"] == 4
    assert len(experiment.call_args.kwargs["data"]) == 3
    assert judge.await_count == (3 if judge_enabled else 0)
    if judge_enabled:
        assert judge.await_args is not None
        assert judge.await_args.kwargs["model"] == "test-model"
        assert judge.await_args.kwargs["api_key"] == "not-a-real-key"
        assert judge.await_args.kwargs["metadata"]["case"] in {
            "spaces",
            "tabs-newlines",
            "unicode",
        }
    output = capsys.readouterr().out
    assert "3/3 completed; 0 failed; 0 evaluator failures" in output
    assert "exact_match: 1.000 (3 scores)" in output
    assert "length_within: 1.000 (3 scores)" in output
    assert "Regression gate passed" in output
    assert exporter.get_finished_spans()
    cast(Mock, client.shutdown).assert_called_once_with()


@mark.parametrize(
    "content,message",
    [
        ("", "at least one item"),
        ('{"input": 1, "expected_output": "1"}\n', "string input"),
        ('{"input": "one"}\n', "expected_output"),
        ("{bad json}\n", "line 1"),
    ],
)
def test_invalid_dataset_fails_before_client_creation(
    example: ModuleType,
    monkeypatch: MonkeyPatch,
    tmp_path: Path,
    capsys: CaptureFixture[str],
    content: str,
    message: str,
) -> None:
    """Bad local fixtures never create a client or start an experiment."""
    path = tmp_path / "data.jsonl"
    path.write_text(content, encoding="utf-8")
    monkeypatch.setattr("sys.argv", ["experiment_example.py", str(path)])
    with raises(SystemExit) as caught:
        example.main()
    assert caught.value.code == 2
    assert message in capsys.readouterr().err
    example.build_langfuse_client.assert_not_called()


def test_wrong_reference_fails_gate_and_shuts_down(
    example: ModuleType,
    sdk: tuple[Langfuse, InMemorySpanExporter],
    monkeypatch: MonkeyPatch,
    tmp_path: Path,
    capsys: CaptureFixture[str],
) -> None:
    """A task cannot copy its expected answer to manufacture a passing result."""
    path = tmp_path / "data.jsonl"
    path.write_text('{"input": " actual ", "expected_output": "wrong"}\n')
    monkeypatch.setattr("sys.argv", ["experiment_example.py", str(path)])
    with raises(SystemExit, match="Regression gate failed: exact_match"):
        example.main()
    assert "Regression gate passed" not in capsys.readouterr().out
    cast(Mock, sdk[0].shutdown).assert_called_once_with()


@mark.parametrize("failure", [False, True])
def test_judge_regression_or_exception_fails_gate(
    example: ModuleType,
    sdk: tuple[Langfuse, InMemorySpanExporter],
    monkeypatch: MonkeyPatch,
    failure: bool,
) -> None:
    """A low judge score and swallowed SDK evaluator errors both fail the CLI."""
    monkeypatch.setattr(example, "find_spec", lambda name: object())
    monkeypatch.setenv("ANTHROPIC_MODEL", "test-model")
    monkeypatch.setenv("ANTHROPIC_API_KEY", "not-a-real-key")
    monkeypatch.setattr("sys.argv", ["experiment_example.py", "--judge"])
    monkeypatch.setattr(
        example,
        "_judge",
        AsyncMock(
            return_value=EvaluationResult("normalization_quality", 0.5),
            side_effect=ValueError("bad judge response") if failure else None,
        ),
    )
    message = "evaluator.*failed" if failure else "normalization_quality"
    with raises(SystemExit, match=message):
        example.main()
    cast(Mock, sdk[0].shutdown).assert_called_once_with()


@mark.parametrize("missing", ["extra", "model", "key"])
def test_judge_requires_explicit_configuration(
    example: ModuleType, monkeypatch: MonkeyPatch, missing: str
) -> None:
    """Missing optional dependencies or credentials fail before any SDK writes."""
    monkeypatch.setattr(
        example, "find_spec", lambda name: None if missing == "extra" else object()
    )
    if missing != "model":
        monkeypatch.setenv("ANTHROPIC_MODEL", "test-model")
    if missing != "key":
        monkeypatch.setenv("ANTHROPIC_API_KEY", "not-a-real-key")
    monkeypatch.setattr("sys.argv", ["experiment_example.py", "--judge"])
    with raises(SystemExit) as caught:
        example.main()
    assert caught.value.code == 2
    example.build_langfuse_client.assert_not_called()


def test_sdk_failure_still_shuts_down(
    example: ModuleType,
    sdk: tuple[Langfuse, InMemorySpanExporter],
    monkeypatch: MonkeyPatch,
) -> None:
    """Client ownership is respected even when the SDK cannot run an experiment."""
    failure = RuntimeError("SDK unavailable")
    monkeypatch.setattr(sdk[0], "run_experiment", Mock(side_effect=failure))
    with raises(RuntimeError) as caught:
        example.main()
    assert caught.value is failure
    cast(Mock, sdk[0].shutdown).assert_called_once_with()


@mark.parametrize("response", ["valid", "invalid", "cancelled"])
async def test_live_judge_wiring_parses_response_and_closes_provider(
    example: ModuleType, monkeypatch: MonkeyPatch, response: str
) -> None:
    """The real judge uses the configured route and closes clients on all exits."""
    importorskip("model_runtime", reason="requires observe-eval-ai[model-runtime]")
    from model_runtime import Message, ModelResponse, ModelRuntime

    provider = AsyncMock()
    provider.__aenter__.return_value = provider
    factory = Mock(return_value=provider)
    monkeypatch.setattr("anthropic.AsyncAnthropic", factory)
    complete = AsyncMock(
        return_value=ModelResponse(
            message=Message.assistant(
                '{"score": 1, "reasoning": "Whitespace normalized."}'
                if response == "valid"
                else "not JSON"
            ),
        ),
        side_effect=CancelledError if response == "cancelled" else None,
    )
    monkeypatch.setattr(ModelRuntime, "complete", complete)
    arguments = {
        "model": "test-model",
        "api_key": "not-a-real-key",
        "input": " hello  world ",
        "output": "hello world",
        "expected_output": "hello world",
        "metadata": {"case": "spaces"},
    }
    if response == "valid":
        result = await example._judge(**arguments)
        assert result == EvaluationResult(
            "normalization_quality", 1, comment="Whitespace normalized."
        )
    else:
        with raises(CancelledError if response == "cancelled" else JudgeResponseError):
            await example._judge(**arguments)
    factory.assert_called_once_with(
        api_key="not-a-real-key", max_retries=0, timeout=30.0
    )
    provider.__aexit__.assert_awaited_once()
    assert complete.await_args is not None
    assert complete.await_args.args[0] == "judge"
    assert "hello world" in complete.await_args.args[1].messages[-1].text


def test_normalization_task_supports_hosted_items_and_rejects_nontext(
    example: ModuleType,
) -> None:
    """Normalization changes only whitespace and does not require SDK local data."""
    assert example.normalize(item={"input": " \t hello\nworld "}) == "hello world"
    assert example.normalize(item=Mock(spec=DatasetItem, input=" café ")) == "café"
    with raises(TypeError, match="must be a string"):
        example.normalize(item={"input": 5})


def test_example_import_does_not_load_model_runtime() -> None:
    """A fresh process can import the deterministic example without model extras."""
    path = Path(__file__).resolve().parents[1] / "examples" / "experiment_example.py"
    result = run(
        [
            executable,
            "-I",
            "-c",
            "\n".join(
                [
                    "from runpy import run_path",
                    "from sys import modules",
                    f"run_path({str(path)!r})",
                    "assert 'model_runtime' not in modules",
                ]
            ),
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr
