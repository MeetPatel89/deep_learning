"""Permission checks and path containment shared by all tools."""

from pathlib import Path, PurePosixPath
from typing import Any
from urllib.parse import unquote

PERMISSIONS = {
    "allow_write",
    "allow_delete",
    "allow_run",
    "allow_live_env",
    "allow_git_write",
    "allow_manage",
    "allow_sql_write",
    "allow_sas",
}


def require(config: Any, permission: str) -> None:
    if permission not in PERMISSIONS:
        raise ValueError(f"Unknown permission: {permission}")
    enabled = (
        config.get(permission, False)
        if isinstance(config, dict)
        else getattr(config, permission, False)
    )
    if enabled is not True:
        raise PermissionError(f"{permission} is disabled in configuration")


def planned_action(action: str, dry_run: bool, **details: Any) -> dict | None:
    if dry_run:
        from data_mcp_core.results import redact

        return {"dry_run": True, "action": action, **redact(details)}
    return None


def relative_path(path: str) -> str:
    if "\x00" in path or "://" in path:
        raise ValueError("Use a path relative to the configured store")
    decoded = path
    for _ in range(3):
        decoded = unquote(decoded)
    normalized = decoded.replace("\\", "/")
    if normalized.startswith("/") or (len(normalized) >= 2 and normalized[1] == ":"):
        raise ValueError("Use a path relative to the configured store")
    if ".." in normalized.split("/"):
        raise PermissionError("Parent traversal is forbidden")
    return str(PurePosixPath(path.replace("\\", "/"))) if path else ""


def local_path(root: str | Path, path: str, allowed_roots: list[str] | None = None) -> Path:
    relative = relative_path(path)
    base = Path(root).expanduser().resolve()
    resolved = (base / relative).resolve()
    if not resolved.is_relative_to(base):
        raise PermissionError("Path escapes the configured store root")
    if allowed_roots and not any(
        resolved.is_relative_to(Path(allowed).expanduser().resolve()) for allowed in allowed_roots
    ):
        raise PermissionError("Path is outside allowed local roots")
    return resolved
