import json
import random
from collections import Counter
from decimal import Decimal

import polars as pl
import pytest
from qa_mcp_server.models import CompareOptions, OutputOptions, ParquetSource
from qa_mcp_server.service import compare

from .conftest import read_dump


def test_keyed_statuses_and_column_flags(run_compare):
    result = run_compare(
        [
            {"id": 1, "name": "A", "v": 2},
            {"id": 2, "name": "B", "v": 4},
            {"id": 3, "name": "C", "v": 8},
        ],
        [
            {"id": 1, "name": "A", "v": 2},
            {"id": 2, "name": "b", "v": 5},
            {"id": 4, "name": "D", "v": 16},
        ],
        primary_keys=["id"],
    )
    assert result["counts"] == {
        "matched": 1,
        "mismatched": 1,
        "missing_in_actual": 1,
        "extra_in_actual": 1,
    }
    assert result["mismatches_per_column"] == {"name": 1, "v": 1}
    assert result["completeness_verified"]
    assert read_dump(result).height == 3


def test_duplicate_keys_pair_in_input_order(run_compare):
    result = run_compare(
        [{"id": 1, "v": "a"}, {"id": 1, "v": "b"}, {"id": 1, "v": "c"}],
        [{"id": 1, "v": "a"}, {"id": 1, "v": "x"}],
        primary_keys=["id"],
    )
    assert result["counts"] == {
        "matched": 1,
        "mismatched": 1,
        "missing_in_actual": 1,
        "extra_in_actual": 0,
    }
    assert result["duplicate_key_rows"] == {"expected": 3, "actual": 2}
    assert read_dump(result).filter(pl.col("status") == "duplicate_key").height == 5


def test_multiset_counts_occurrences(run_compare):
    result = run_compare(
        [{"v": "a"}, {"v": "a"}, {"v": "a"}, {"v": "b"}],
        [{"v": "a"}, {"v": "c"}, {"v": "c"}],
    )
    assert result["mode"] == "multiset"
    assert result["counts"] == {
        "matched": 1,
        "mismatched": 0,
        "missing_in_actual": 3,
        "extra_in_actual": 2,
    }
    dump = read_dump(result)
    assert dump.height == 3
    assert dump["occurrences"].sum() == 5
    assert result["duplicate_key_rows"] == {"expected": 0, "actual": 0}


def test_string_mapping_ignore_and_numeric_coercion(run_compare):
    result = run_compare(
        [{"id": 1, "name": "  ALICE ", "amount": Decimal("3.00"), "ignored": "a"}],
        [{"key": 1.0, "display_name": "alice", "amount": 3.005, "ignored": "b"}],
        primary_keys=["id"],
        column_mapping={"id": "key", "name": "display_name"},
        ignore_columns=["ignored"],
        trim_strings=True,
        case_insensitive=True,
        numeric_tolerance=0.01,
    )
    assert result["counts"]["matched"] == 1
    assert "ignored" not in result["comparison_schema"]
    assert result["comparison_schema"]["amount"] == "Float64"


@pytest.mark.parametrize("partitioned", [False, True])
def test_null_equality_in_keys_values_and_multiset(run_compare, partitioned):
    opts = {"memory_budget_mb": 0.00001} if partitioned else {}
    rows = [{"id": None, "v": "a"}, {"id": None, "v": "a"}, {"id": 1, "v": None}]
    equal = run_compare(rows, rows, primary_keys=["id"], **opts)
    assert equal["counts"]["matched"] == 3
    unequal = run_compare(rows, rows, primary_keys=["id"], treat_null_as_equal=False, **opts)
    assert unequal["counts"] == {
        "matched": 0,
        "mismatched": 1,
        "missing_in_actual": 2,
        "extra_in_actual": 2,
    }
    assert unequal["duplicate_key_rows"] == {"expected": 2, "actual": 2}
    multiset = run_compare(rows, rows, treat_null_as_equal=False, **opts)
    assert multiset["counts"] == {
        "matched": 0,
        "mismatched": 0,
        "missing_in_actual": 3,
        "extra_in_actual": 3,
    }


def test_schema_difference_is_not_hidden_by_nulls(run_compare):
    result = run_compare([{"id": 1, "v": None}], [{"id": 1}], primary_keys=["id"])
    assert result["counts"]["mismatched"] == 1
    assert result["schema_differences"] == ["v"]
    result = run_compare([{"id": 1, "v": None}], [{"id": 1}])
    assert result["counts"]["missing_in_actual"] == 1
    assert result["counts"]["extra_in_actual"] == 1


@pytest.mark.parametrize("rows", [[], [{"id": 1, "v": "x"}]])
def test_empty_sources(run_compare, rows):
    for expected, actual in (([], rows), (rows, [])):
        result = run_compare(expected, actual)
        assert result["counts"]["missing_in_actual"] == len(expected)
        assert result["counts"]["extra_in_actual"] == len(actual)
        assert result["completeness_verified"]
    if rows:
        result = run_compare([], rows, primary_keys=["id"], memory_budget_mb=0.00001)
        assert result["counts"]["extra_in_actual"] == 1


@pytest.mark.parametrize(
    "options",
    [
        {"primary_keys": ["missing"]},
        {"primary_keys": ["id"], "ignore_columns": ["id"]},
        {"column_mapping": {"id": "foo", "v": "foo"}},
        {"column_mapping": {"id": "v"}},
        {"ignore_columns": ["id", "v"]},
    ],
)
def test_invalid_column_configuration_fails(run_compare, options):
    with pytest.raises(ValueError):
        run_compare([{"id": 1, "v": "x"}], [{"id": 1, "v": "x"}], **options)


def dump_counter(result):
    return Counter(
        json.dumps(row, sort_keys=True, default=str) for row in read_dump(result).to_dicts()
    )


@pytest.mark.parametrize("keyed", [True, False])
@pytest.mark.parametrize("strategy", ["hash", "skew"])
def test_partitioned_results_equal_in_memory(run_compare, keyed, strategy):
    rng = random.Random(17)
    expected = [{"id": i % 19, "name": f"Name {i % 7}", "v": i % 5} for i in range(120)]
    actual = [dict(row) for row in expected[3:]] + [{"id": 30, "name": "extra", "v": 9}]
    rng.shuffle(actual)
    actual[15]["v"] = 999
    opts = {"primary_keys": ["id"]} if keyed else {}
    reference = run_compare(expected, actual, **opts)
    partition_opts = {"num_partitions": 7} if strategy == "hash" else {"memory_budget_mb": 0.0001}
    result = run_compare(expected, actual, **opts, **partition_opts)
    assert result["partitioned"]
    for key in ("counts", "mismatches_per_column", "duplicate_key_rows", "comparison_schema"):
        assert result[key] == reference[key]
    assert dump_counter(result) == dump_counter(reference)
    assert bool(result["disk_fallback_buckets"]) == (strategy == "skew")


def test_normalization_happens_before_hashing(run_compare):
    expected = [{"id": "  A  ", "value": 3}, {"id": "b", "value": 4}]
    actual = [{"id": "a", "value": "3"}, {"id": "B ", "value": "4"}]
    result = run_compare(
        expected,
        actual,
        primary_keys=["id"],
        num_partitions=7,
        trim_strings=True,
        case_insensitive=True,
    )
    assert result["counts"]["matched"] == 2
    assert result["comparison_schema"]["value"] == "String"


@pytest.mark.parametrize("memory_budget", [1024, 0.00001])
def test_nan_infinity_signed_zero_and_large_integer_tolerance(tmp_path, memory_budget):
    expected = pl.DataFrame({"id": [0.0, float("nan"), float("inf")], "v": [2**63 - 1, 0, 2]})
    actual = pl.DataFrame({"id": [-0.0, float("nan"), float("inf")], "v": [-(2**63) + 1, 1, 2]})
    epath, apath = tmp_path / "e.parquet", tmp_path / "a.parquet"
    expected.write_parquet(epath)
    actual.write_parquet(apath)
    result = compare(
        ParquetSource(path=epath),
        ParquetSource(path=apath),
        CompareOptions(primary_keys=["id"], numeric_tolerance=1, memory_budget_mb=memory_budget),
        OutputOptions(output_dir=tmp_path),
    )
    assert result["counts"]["matched"] == 2
    assert result["counts"]["mismatched"] == 1
    json.dumps(result, allow_nan=False)


def test_unsigned_tolerance(tmp_path):
    epath, apath = tmp_path / "e.parquet", tmp_path / "a.parquet"
    pl.DataFrame({"id": [1], "v": [0]}, schema={"id": pl.UInt64, "v": pl.UInt64}).write_parquet(
        epath
    )
    pl.DataFrame({"id": [1], "v": [1]}, schema={"id": pl.UInt64, "v": pl.UInt64}).write_parquet(
        apath
    )
    result = compare(
        ParquetSource(path=epath),
        ParquetSource(path=apath),
        CompareOptions(primary_keys=["id"], numeric_tolerance=1),
        OutputOptions(output_dir=tmp_path),
    )
    assert result["counts"]["matched"] == 1


def test_nested_inline_values(run_compare):
    rows = [{"id": 1, "meta": {"x": 1}, "tags": ["a", "b"]}]
    assert run_compare(rows, rows, primary_keys=["id"])["counts"]["matched"] == 1


def test_skewed_single_key_compares_every_occurrence(run_compare):
    expected = [{"id": 1, "v": i} for i in range(75)]
    result = run_compare(
        expected, expected[:-1], primary_keys=["id"], memory_budget_mb=0.00001, num_partitions=2
    )
    assert result["counts"]["matched"] == 74
    assert result["counts"]["missing_in_actual"] == 1
    assert result["disk_fallback_buckets"] == 1
