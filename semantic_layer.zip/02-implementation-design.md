# Implementation design: governed NL-to-SQL for producer data

Version 1.0 • Prepared 2026-09-25 • Target: Azure SQL Database + SQLite semantic catalog

Read alongside the [semantic-layer constitution](01-semantic-layer-constitution.md). This document describes the application to build; it is not a claim that a production agent or database integration has already been deployed.

## Contents

1. [Decisions and confirmed requirements](#1-decisions-and-confirmed-requirements)
2. [Architecture and trust boundaries](#2-architecture-and-trust-boundaries)
3. [From the workbook to a working catalog](#3-from-the-workbook-to-a-working-catalog)
4. [Concrete model for the four tables](#4-concrete-model-for-the-four-tables)
5. [Relationships, operations and graph structure](#5-relationships-operations-and-graph-structure)
6. [SQLite persistence and publication](#6-sqlite-persistence-and-publication)
7. [Retrieval, value resolution and examples](#7-retrieval-value-resolution-and-examples)
8. [Semantic query contract and compiler](#8-semantic-query-contract-and-compiler)
9. [The three sample questions in T-SQL](#9-the-three-sample-questions-in-t-sql)
10. [Agentic workflow and LangGraph decision](#10-agentic-workflow-and-langgraph-decision)
11. [Validation, authorization and Azure SQL execution](#11-validation-authorization-and-azure-sql-execution)
12. [Testing and acceptance criteria](#12-testing-and-acceptance-criteria)
13. [Implementation sequence and operating model](#13-implementation-sequence-and-operating-model)
14. [Decision records and maturity path](#14-decision-records-and-maturity-path)
15. [References and verification scope](#15-references-and-verification-scope)

## 1. Decisions and confirmed requirements

### 1.1 Recommended V1

Build one application service with a SQLite catalog repository, an LLM interpreter, deterministic resolvers/planner/compiler/validators, and an Azure SQL query adapter. Load each published catalog revision into an immutable typed snapshot. Derive a directed relationship adjacency index from that snapshot. Start with exact/alias retrieval and a small bounded workflow. No graph database, vector database or LangGraph dependency is required for the initial use cases.

The stable interfaces are the important investment: `CatalogRepository`, `ValueResolver`, `RelationshipPlanner`, `SemanticQuery`, `SqlCompiler`, `PolicyService` and `QueryExecutor`. Each can change implementation without asking the LLM to learn a new business ontology.

### 1.2 Confirmed facts

| Fact | Source | Consequence |
|---|---|---|
| Query engine is Azure SQL Database | User clarification in this task | Emit and validate T-SQL. Do not use PostgreSQL-specific syntax or a generic EXPLAIN endpoint. |
| Flat semantic metadata resides in SQLite | User clarification | SQLite is the authoritative catalog store; graph indexes are derived in memory. |
| “Term date” means license termination date | User clarification | Resolve to `license.termination_date`, physically `Producer_Licenses.Termination_Date`. |
| Status interpretation uses descriptions, aliases, enum mappings and examples | User clarification | Retrieve the field/domain/example context; resolve codes through entity-scoped mappings. |
| Four source table column lists are supplied | Referenced conversation | No additional business columns may be assumed. |
| Workbook has five tabs with headers only | Complete worksheet cell inspection | Its structure can be imported, but it supplies no actual codes, keys, joins or verified SQL. |

### 1.3 Explicit design assumptions and unresolved catalog content

These are configuration decisions, not reasons to redesign the architecture or stop building it.

| ID | Subject | Working treatment in examples | Required before production publication |
|---|---|---|---|
| A01 | Active status | Entity-specific mapped active status set; no automatic termination-date condition | Populate real codes, including whether several statuses mean active; promote any additional reviewed conditions to a predicate. |
| A02 | Pet category | Canonical value `product_category.pet` with a separate literal set for each contract source | Populate real source literals and mapping validity. |
| A03 | Which contracts qualify | Either Agent_Contracts or Agency_Contracts; contract status unrestricted unless requested | Approve scope and whether a default requires active contracts. |
| A04 | Producer_Key identity | Same business identity across the relationships shown | Verify global namespace or bind approved crosswalk relationships. |
| A05 | License/appointment grain | One current record per `(Producer_Key, License_Id)` / `(Producer_Key, Appointment_Id)` | Check keys, history, duplicates, and nulls; revise source adapters if needed. |
| A06 | Individual records | Nonaggregated license details | If the term means legal individuals, an authoritative classification source is needed. |
| A07 | Detail scope | Show both same-license and producer-cohort readings | A reviewed example establishes the desired default; otherwise ask one focused clarification at runtime. |
| A08 | Physical schema and types | `dbo` and illustrative types | Introspect Azure SQL; bind actual schema, lengths, nullability, collation and temporal types. |
| A09 | Access policy | Only authorized base/contract/license data participates | Configure real permissions, secured views or RLS; do not invent tenant columns. |

Status and category codes in demonstrations are synthetic. `ACTIVE` is not asserted to be your actual status code. Source-specific parameter names deliberately allow the two contract tables to use different encodings.

## 2. Architecture and trust boundaries

### 2.1 Component architecture

```mermaid
flowchart TB
    U[User question] --> API[Application and trusted identity]
    API --> A[LLM interpreter]
    SK[Optional Agent Skill instructions] --> A
    A --> R[Catalog search and value resolution]
    R --> C[(SQLite semantic catalog)]
    C --> SNAP[Published immutable snapshot]
    SNAP --> G[Derived relationship adjacency index]
    A --> Q[Proposed SemanticQuery]
    Q --> V[Typed semantic validation]
    SNAP --> V
    G --> P[Deterministic relationship planner]
    V --> P
    P --> COMP[Relational plan and T-SQL compiler]
    COMP --> SV[SQL AST and policy validation]
    SV --> ART[Sealed compiled-query artifact]
    ART --> EX[Azure SQL adapter]
    EX --> DB[(Azure SQL Database)]
    DB --> RES[Result envelope and factual explanation]
    RES --> U
    POL[Trusted policy service] --> R
    POL --> V
    POL --> EX
```

SQLite holds definitions, bindings, examples and catalog revisions. Azure SQL holds operational license, appointment and contract rows. Runtime value lookup for small status/product domains uses the catalog. A future high-cardinality value provider may query an authorized Azure SQL reference table, returning the same resolution contract.

All boxes can be modules in one service. Boxes are responsibility boundaries, not a requirement for microservices. The agent receives tools that express semantic work, never direct database credentials.

### 2.2 Where interpretation ends

| Task | Agentic responsibility | Deterministic responsibility |
|---|---|---|
| Understand “term date” | Match language to candidate field using descriptions and examples | Return permitted field IDs, type-check `is_null`, emit `IS NULL` |
| Understand “active” | Select the scoped status concept/predicate | Resolve approved code set and required expression |
| Understand “Pet contracts” | Select category and relationship purpose | Resolve each source binding; choose an approved existence plan |
| Choose license vs appointment count | Interpret requested metric | Enforce metric base entity and record grain |
| Ask a question | Explain unresolved semantic choice | Return structured ambiguity with candidates |
| Choose join syntax | No SQL join choice in model output | Emit operation specified by contract |
| Respond to an error | Revise intent only when the error is recoverable | Enforce unchanged authorization and correctness constraints |
| Explain answer | Produce readable summary from result and manifest | Supply authoritative numbers, applied filters, scope and completeness |

Descriptions matter directly: they help the agent choose a field and operator. The typed compiler does not have to encode every phrase such as “no term date.” It needs a governed field with a permitted `is_null` operation. Recurring compound business meanings such as a multi-condition definition of “active” should become named predicates.

### 2.3 Query lifecycle

```mermaid
sequenceDiagram
    participant User
    participant App
    participant LLM
    participant Catalog
    participant Compiler
    participant AzureSQL
    User->>App: Count active license records with Pet contracts
    App->>Catalog: Pin published revision and authorized domain
    App->>LLM: Question, procedure, catalog search tools
    LLM->>Catalog: Search license count, active, product category
    Catalog-->>LLM: Metric, field descriptions, predicates, examples
    LLM->>Catalog: Resolve Pet and active status
    Catalog-->>LLM: Scoped canonical values and binding handles
    LLM-->>App: Proposed SemanticQuery
    App->>Compiler: Validate, plan, compile with trusted context
    Compiler-->>App: SQL, parameters, proof manifest or typed error
    alt Meaning unresolved
        App-->>User: Focused question with distinct interpretations
    else Query valid and permitted
        App->>AzureSQL: Bound read query under restricted identity
        AzureSQL-->>App: Count and execution metadata
        App-->>User: Count, population, contract scope, definitions
    end
```

The term “proof manifest” means a record of checked obligations within a restricted query algebra. It is not a formal proof of arbitrary SQL correctness or business truth.

## 3. From the workbook to a working catalog

The workbook assessment with exact cell ranges is in the constitution. Keep the five authoring concepts and add the missing executable meaning.

| Existing authoring tab | Runtime tables/objects | Additions |
|---|---|---|
| `meta_tables` | `catalog_object`, `entity` | Stable ID; source binding; grain; key candidates; identity namespace; authorization scope; current/history semantics |
| `meta_columns` | `field` plus common object metadata | Stable ID; parent entity; semantic/physical types; null meaning; roles; operators; classification; domain ID |
| `meta_enum_mappings` | `value_domain`, `canonical_value`, `value_alias`, `value_binding` | Separate canonical concepts from source encodings; multiple codes; effective intervals; collision detection |
| `meta_joins` | `relationship`, `relationship_operation` | Endpoint roles; typed conditions; directed usage; preservation; output grain; fanout; evidence |
| `meta_examples` | `verified_example` | Natural-language question; expected intent/plan; fixture ID; expected rows/scalar; catalog version; reviewer |
| New concept | `predicate` | Reusable typed business conditions and mandatory restrictions |
| New concept | `metric` | Base grain, population, aggregation, additivity and allowed dimensions |
| New concept | `catalog_release`, `assertion` | Publication, source evidence, drift checks and reproducibility |

### 3.1 Import rules

The importer reads Excel as authoring data. It reports cell-addressed issues, such as “`meta_joins!E2`: ON expression references an unknown field.” It creates a **draft** revision. It must not execute workbook formulas, SQL examples or arbitrary code. In the current workbook it imports the schema headings and reports zero records; it must not invent records to fill the blank tabs.

Legacy `ON` SQL is migration input. For the four-table model, convert reviewed equalities into structured field-pair conditions. Unsupported legacy expressions require a reviewed compiler extension or a secured database view. Do not make arbitrary `ON` text the general runtime interface.

`ALIASES` needs a defined format. Prefer one alias row per value in an authoring sheet, or a JSON array in a cell. Never split a business label at every comma without an escaping convention. Treat literal values as typed data and preserve leading zeroes for string codes.

### 3.2 An example is evidence, then an executable definition

An owner-approved example might contain `Status IN ('A','R')`. The onboarding process records which status meanings those codes represent and updates the scoped mapping. If the example also uses `Termination_Date IS NULL`, the reviewer determines whether this belongs to the universal active definition or only to that question. Promote reusable logic to `license.active`; leave question-specific filters in the example plan.

The agent can retrieve the example at runtime to understand intent. It still uses the current predicate and bindings. This avoids two competing sources of truth: a new mapping in SQLite and stale hardcoded SQL in an example.

## 4. Concrete model for the four tables

### 4.1 Entity registry

| Semantic ID | Physical source supplied | Proposed row meaning | Candidate identity | Important limitation |
|---|---|---|---|---|
| `license` | `Producer_Licenses` | One license record | `(Producer_Key, License_Id)` | Confirm current vs history, global ID uniqueness, state scope |
| `appointment` | `Producer_Appointments` | One appointment record | `(Producer_Key, Appointment_Id)` | Insurance producer appointment, not a calendar appointment |
| `agent_contract` | `Agent_Contracts` | One agent contract record | `(Producer_Key, Contract_Id)` within this source | Table name alone does not prove legal person classification |
| `agency_contract` | `Agency_Contracts` | One agency contract record | `(Producer_Key, Contract_Id)` within this source | Do not infer coverage of individual agency members |

A shared `Producer_Key` means a contract and a license belong to the same identified producer only after namespace compatibility is established. If an agency contract belongs to an agency and a license to a person, inheritance of the agency's contract requires an explicit person–agency affiliation relationship. No such affiliation fields are supplied. The design must never invent that join.

### 4.2 Field inventory and suggested descriptions

Descriptions below are authoring proposals, except the confirmed license term-date alias. Physical data types were not supplied; inspect the database before entering them as facts.

| Entity | Semantic field / source column | Suggested meaning and use |
|---|---|---|
| license | `producer_key` / `Producer_Key` | Identity of the producer associated with this license; relationship key; not a license key |
| license | `license_id` / `License_Id` | License record identifier; verify uniqueness scope |
| license | `license_number` / `License_Number` | Business license number; preserve text formatting and leading zeroes |
| license | `state` / `State` | State/jurisdiction recorded for the license; exact domain must be approved |
| license | `status` / `Status` | Stored license status code; map through `license_status` |
| license | `termination_date` / `Termination_Date` | License termination date; aliases include “term date,” “license term date”; absent date queried with `IS NULL` |
| appointment | `producer_key` / `Producer_Key` | Producer identity for the appointment |
| appointment | `appointment_id` / `Appointment_Id` | Appointment record identifier; verify uniqueness scope |
| appointment | `state` / `State` | State/jurisdiction for the appointment |
| appointment | `status` / `Status` | Stored appointment status code; map through `appointment_status` |
| appointment | `termination_date` / `Termination_Date` | Appointment termination date; context-specific term-date alias |
| agent_contract | `producer_key` / `Producer_Key` | Contract holder identity in the agent-contract namespace |
| agent_contract | `contract_id` / `Contract_Id` | Contract record identifier within source and approved identity scope |
| agent_contract | `contract_type` / `Contract_Type` | Contract classification; do not interpret as producer type without a definition |
| agent_contract | `status` / `Status` | Stored agent-contract status; its own mapping scope |
| agent_contract | `product_category` / `Product_Category` | Stored category; binding to `product_category` canonical values |
| agency_contract | `producer_key` / `Producer_Key` | Contract holder identity in the agency-contract namespace |
| agency_contract | `contract_id` / `Contract_Id` | Contract record identifier within agency source |
| agency_contract | `contract_type` / `Contract_Type` | Agency contract classification |
| agency_contract | `status` / `Status` | Stored agency-contract status; separate from license status |
| agency_contract | `product_category` / `Product_Category` | Agency-source category encoding |

An alias lookup for “term date” can return both license and appointment fields. The query's selected base entity and the user's clarification resolve the sample to the license field. Store the confirmed usage as a verified example rather than globally removing the alias from appointment metadata.

### 4.3 Canonical values and synthetic binding illustration

| Canonical value | Field binding | Synthetic literal set | Reason for distinct binding |
|---|---|---|---|
| `license_status.active` | `license.status` | `["ACTIVE"]` | License codes may differ from appointment codes |
| `appointment_status.active` | `appointment.status` | `["A"]` | Demonstrates a separate status encoding |
| `product_category.pet` | `agent_contract.product_category` | `["PET"]` | Agent-source product code |
| `product_category.pet` | `agency_contract.product_category` | `["P"]` | Agency-source product code |

Each domain can have descriptions and aliases. A canonical status may bind to several literals if the business says several statuses belong in an active population. Conversely, “active or pending” is two canonical concepts if pending is not a kind of active. Do not merge them because an embedding puts them close together.

### 4.4 Predicate definitions

V1 expression language:

```text
Expression := all(Expression[]) | any(Expression[]) | not(Expression)
            | compare(operator, FieldRef, TypedParameter)
            | is_null(FieldRef) | is_not_null(FieldRef)
            | in_value_set(FieldRef, CanonicalValueRef)
FieldRef   := {entity_role, field_id}
operator   := eq | ne | lt | le | gt | ge
```

Only the compiler owns the mapping to SQL. Empty `all`/`any` nodes are rejected in V1. Set membership cannot contain SQL or table names. A resolved empty set is a separate outcome, not an instruction to remove the filter.

```json
{
  "id": "license.active",
  "entity_id": "license",
  "definition_status": "draft",
  "expression": {
    "op": "in_value_set",
    "field": "license.status",
    "value_id": "license_status.active"
  },
  "explanation": "Status belongs to the reviewed active license status set."
}
```

This proposal deliberately does not add a termination condition. If reviewed examples establish an active rule requiring one, replace its expression with an `all` of the status test and the approved temporal condition, version it, and rerun affected examples. The first sample's explicit no-term-date condition remains an independent filter and can be simplified when it is redundant.

### 4.5 Metrics

| ID | Base | Aggregation | Required predicate | Category eligibility |
|---|---|---|---|---|
| `license.record_count` | license | `COUNT_BIG(*)` over validated record grain | None | Optional approved relationship condition |
| `license.active_record_count` | license | Same | `license.active` | Optional |
| `appointment.record_count` | appointment | `COUNT_BIG(*)` | None | Optional |
| `appointment.active_record_count` | appointment | Same | `appointment.active` | Optional |

Use the active metric for sample questions 2 and 3. Category stays a parameterized population constraint, so “Pet” and another category do not require separate metric definitions. `COUNT_BIG` returns a large integer appropriate for growing record counts. Do not replace these metrics with distinct producer counts.

If a later question asks “count by contract category,” a producer can qualify for several categories. That count is not additive across categories. Declare this before exposing the grouping; do not let the user infer the category totals equal the overall count.

## 5. Relationships, operations and graph structure

### 5.1 The relationship graph for these tables

```mermaid
flowchart LR
    L[license] -->|has agent contract: EXISTS| AC[agent_contract]
    L -->|has agency contract: EXISTS| GC[agency_contract]
    AP[appointment] -->|has agent contract: EXISTS| AC
    AP -->|has agency contract: EXISTS| GC
    L -->|derive distinct qualifying Producer_Key| CO[eligible_producer cohort]
    CO -->|include active licenses: LEFT expansion| LD[license detail role]
```

Every arrow is an explicitly approved directed operation. The cohort is a query-local derived relation; it is not an invented physical producer table. The two license nodes represent different query roles over the same source. There is no license–appointment join and no inferred agent–agency affiliation path.

For each license record, matching contract rows can be zero, one or many. For each contract, matching license rows can likewise be many. The underlying key correspondence is many-to-many. An `EXISTS` operation returns only a Boolean qualification for the outer row, so **the operation has no output fanout even when the relationship is many-to-many**.

### 5.2 Split correspondence facts from query operations

Persist one relationship row per approved correspondence and one or more operation rows for its permitted uses. This avoids a universal `join_type: LEFT` that would be inappropriate for every question.

```json
{
  "relationship": {
    "id": "license.agent_contract_by_producer",
    "source_entity": "license",
    "target_entity": "agent_contract",
    "source_role": "base_license",
    "target_role": "qualifying_contract",
    "key_pairs": [
      {"source_field": "license.producer_key", "target_field": "agent_contract.producer_key"}
    ],
    "identity_namespace": "producer_shared",
    "namespace_status": "requires_confirmation",
    "source_to_target": "zero_to_many",
    "target_to_source": "zero_to_many",
    "null_key_behavior": "no_match",
    "required_predicates": [],
    "status": "draft"
  },
  "operation": {
    "id": "license.has_agent_contract",
    "relationship_id": "license.agent_contract_by_producer",
    "purpose": "qualify_base",
    "operator": "exists",
    "required_sql_form": "correlated_exists",
    "output_grain": "unchanged",
    "can_project_target_fields": false,
    "target_filters_scope": "inside_exists",
    "output_multiplicity_per_base_row": "zero_or_one",
    "permitted_target_filters": [
      "agent_contract.product_category",
      "agent_contract.status",
      "agent_contract.contract_type"
    ]
  }
}
```

Create analogous contracts for license→agency_contract and appointment→each contract source. The compiler can use a shared implementation, but each instantiated contract still names concrete endpoints and permissions. A generic “join anything with Producer_Key” rule is prohibited.

The identity namespace above is an example awaiting confirmation. Publication blocks operations that depend on it until it is verified or replaced with a reviewed crosswalk. A column's matching type does not prove matching identity.

### 5.3 Four supported relationship purposes

| Purpose | Relational operation | What happens to base rows | Output grain and predicate scope |
|---|---|---|---|
| Qualify by related evidence | `EXISTS` | Keep only bases with a match | Base grain unchanged; target criteria inside existence |
| Exclude by related evidence | `NOT EXISTS` | Keep only bases without a match | Base grain unchanged; avoid `NOT IN` null pitfalls |
| Enrich with a single related record | `LEFT JOIN` | Preserve all eligible bases | Requires at-most-one matching target; filters on included target in ON/target subquery |
| Include all matching child details | `LEFT JOIN` expansion, or grouped child result | Preserve bases when requested | Flat grain becomes base×child; no base aggregate after expansion without an approved rewrite |

An inner enrichment is a different operation with a different population contract. If it is not approved, the model cannot request it. If a user explicitly wants only bases having a child, represent that as a qualification step, then attach details if needed. This keeps population intent separate from display shape.

### 5.4 Exact left-join enforcement

For a preserving license expansion, the logical contract is:

```json
{
  "id": "eligible_producer.include_active_licenses",
  "source_entity": "eligible_producer",
  "target_entity": "license",
  "operator": "expand_left",
  "required_sql_join": "LEFT",
  "key_pairs": [{"source_field": "producer_key", "target_field": "license.producer_key"}],
  "target_predicate_ids": ["license.active"],
  "preserve": "all_eligible_source_keys",
  "output_grain": "producer_key_plus_license_record_or_unmatched_placeholder",
  "aggregate_after_expansion": "prohibited_in_v1",
  "target_filter_placement": "ON_or_prefiltered_target",
  "target_post_filters": "prohibited_without_explicit_population_operation"
}
```

The compiler emits `LEFT JOIN ... ON ... AND active_predicate`. A validator checks this operation's lineage, exact field binding, mandatory target conditions and protected base population. It rejects moving the active condition to `WHERE`.

Checking for the word LEFT is not sufficient. For example, `WHERE child.Status = @active OR child.License_Id IS NULL` can still lose a producer that has only inactive licenses: a real child matched the original join, so no null placeholder was produced. Prefilter the child or put the active condition in ON. Do not apply an after-the-fact null workaround.

The database optimizer may implement equivalent logic with different physical join algorithms. Validate the emitted logical query against its contract, not the optimizer's choice of hash/merge/nested-loop operators.

### 5.5 What graph data structure to use

Use an immutable directed multigraph represented initially by ordinary maps:

```python
entities_by_id: dict[str, Entity]
relationships_by_id: dict[str, Relationship]
outgoing: dict[str, tuple[str, ...]]  # entity ID -> relationship IDs
operations_by_relationship: dict[str, tuple[OperationContract, ...]]
```

It is a multigraph because two entities may have multiple relationships with different roles or time meanings. Direction matters: source preservation and cardinality do not automatically reverse. A separate approved inverse operation is needed where appropriate.

Path resolution takes base entity, requested target, purpose, output grain, time scope and authorization. It first filters to published authorized contracts, then enumerates a bounded set of simple paths, rejects incompatible grain/temporal paths, applies explicit semantic preferences, and returns one path or an ambiguity. A small hop bound, such as three, is an operational V1 setting, not a claim that three-hop paths are universally safe.

For the four-table model, explicit one-hop operations suffice. Do not implement a general shortest-path optimizer before it is needed. A shortest route can have the wrong business meaning. A path through a shared producer does not prove that a particular appointment authorizes a particular license.

### 5.6 Graph storage versus orchestration

| Graph | Nodes | Edges | V1 representation |
|---|---|---|---|
| Semantic relationship graph | Entities/roles | Approved correspondence and operation contracts | SQLite rows projected into adjacency maps |
| Query plan | Scans, filters, existence, joins, aggregates | Data dependencies | Typed in-memory tree/DAG |
| Agent workflow | Interpret, resolve, clarify, validate, execute | Control transitions | Ordinary functions plus persisted request state |

A graph database would change storage/query facilities for metadata. LangGraph would change workflow execution. Neither changes how Azure SQL joins operational tables. Adopt either only for a measured need; using a graph-shaped model does not require a graph server.

## 6. SQLite persistence and publication

### 6.1 Physical catalog model

The companion [SQLite schema](catalog-schema.sql) is executable DDL for the proposed V1 metadata store. It provides release-scoped identity and foreign keys. Expression payloads remain JSON with application-level typed validation; database JSON validity checks alone cannot enforce their business meaning.

```mermaid
erDiagram
    CATALOG_RELEASE ||--o{ CATALOG_OBJECT : contains
    CATALOG_OBJECT ||--o| ENTITY : specializes
    CATALOG_OBJECT ||--o| FIELD : specializes
    ENTITY ||--o{ FIELD : owns
    VALUE_DOMAIN ||--o{ CANONICAL_VALUE : defines
    CANONICAL_VALUE ||--o{ VALUE_ALIAS : names
    CANONICAL_VALUE ||--o{ VALUE_BINDING : encodes
    FIELD ||--o{ VALUE_BINDING : binds
    ENTITY ||--o{ RELATIONSHIP : source_or_target
    RELATIONSHIP ||--o{ RELATIONSHIP_OPERATION : permits
    ENTITY ||--o{ PREDICATE : filters
    ENTITY ||--o{ METRIC : measures
    CATALOG_RELEASE ||--o{ VERIFIED_EXAMPLE : verifies
    CATALOG_RELEASE ||--o{ ASSERTION : supports
```

Every semantic object has a stable ID inside a release and common label, description, owner and lifecycle fields. The composite identity `(release_id, object_id)` prevents accidental references across catalog revisions. A release snapshot contains the complete published domain slice, not a mixture of the newest row from each table.

| Table | Important payload | Validation beyond SQL constraints |
|---|---|---|
| `catalog_release` | Schema version, content hash, lifecycle, timestamp | Valid transitions; immutability; hash over canonical export |
| `catalog_object` | Kind, label, description, owner, status | Specialized row must match kind; all required objects published |
| `entity` | Connection reference, schema/table, grain, identity namespace, keys | Physical binding exists; namespace/key evidence |
| `field` | Entity, physical column, types, operators, nulls, domain, sensitivity | Source type compatibility; domain/field compatibility |
| `value_domain` | Normalization and resolution policy | Locale, alias collision rules, exact-vs-fuzzy policy |
| `canonical_value` | Domain membership | Stable meaning; approved labels |
| `value_alias` | Normalized alias and locale | Collisions returned as ambiguity, not overwritten |
| `value_binding` | Value, field, typed literal, interval | Complete source coverage; type/interval overlap checks |
| `relationship` | Endpoints, key pairs, required expression, multiplicity | Field ownership; namespace and temporal compatibility |
| `relationship_operation` | Purpose, operator, preservation, projection policy | Allowed operator, supported algebra, grain obligations |
| `predicate` | Entity-scoped typed expression | No SQL strings; valid field/domain references |
| `metric` | Base, aggregation, grain, filters, dimensions | Additivity, count identity and fanout rules |
| `verified_example` | Question, IR, SQL reference, fixture, expected output | Review status; result assertions; no executable bypass |
| `assertion` | Required property, evidence, validity | Freshness, ownership, source identity, consequence of failure |

Runtime request state and audit records should use a separate store/file from catalog authoring to avoid turning every query into a catalog write. For a single-instance V1 this can be a second SQLite database. If multiple application hosts need shared request state, move that store to a shared service without changing the catalog or semantic query contract.

### 6.2 Connection and concurrency rules

Enable `PRAGMA foreign_keys = ON` on every SQLite connection and assert it took effect before opening transactions. Foreign keys are connection-configured, so a schema declaration alone is insufficient. [SQLite foreign-key documentation](https://www.sqlite.org/foreignkeys.html)

Use one catalog publisher process and short authoring transactions. Runtime reads use read-only connections and published revision IDs. WAL can support concurrent readers and a writer on a local filesystem, but it does not turn SQLite into a multi-writer server. WAL relies on same-host shared memory and is unsuitable as a shared file accessed over a network filesystem. [SQLite WAL documentation](https://www.sqlite.org/wal.html)

For multiple application instances, distribute immutable snapshot files with revision/hash checks and maintain a small trusted active-revision pointer. Do not place one mutable SQLite catalog on a network share. Prefer a single authoring service or migrate its repository to a server database when concurrent writers, availability or governance requires it. SQLite can remain a local read cache.

### 6.3 Publication transaction

1. Import or edit a draft release through the authoring service.
2. Validate common schema and all typed JSON payloads. Reject unknown attributes.
3. Resolve every dependency and run reference/type checks, including field ownership and alias collisions.
4. Introspect the configured Azure SQL objects under an appropriate metadata identity. Compare types, columns and object identity with bindings.
5. Evaluate required grain/identity assertions. Record whether evidence is an enforced source constraint, full-data validation, or a weaker profile; sampling alone does not establish uniqueness.
6. Run synthetic and integration regression suites for affected definitions.
7. Obtain the designated owner's review of business changes. An application design can be authored now; production meanings require the organization's review process.
8. Compute a canonical content hash, mark the release published, and atomically change the active-revision pointer in one transaction.
9. Build/cache the immutable snapshot and derived graph. Retain the previous revision for rollback.

Published rows are immutable through the authoring service. The runtime has read-only file access. Add database triggers for published-row mutation if additional direct SQL writers will be allowed. The supplied DDL does not alone enforce the entire lifecycle or payload semantics; those are explicit publisher responsibilities.

Active mapping revisions are part of the snapshot. For future live value providers, store a provider revision/etag and an expiry with each resolution; revalidate before execution. A stale value handle cannot silently bind a newly reassigned code.

### 6.4 Source drift handling

Column removal or incompatible type change disables affected objects and returns `SOURCE_SCHEMA_CHANGED`. Failed uniqueness disables dependent one-to-one/many-to-one enrichment operations; it need not disable unrelated existence queries. Failed identity namespace validation disables the relationship altogether. Each assertion declares its affected operations and maximum evidence age.

A snapshot pins the rules, not the operational data. Reproducing an old numerical answer also requires a retained data snapshot or temporal source support. Record the actual execution time and isolation behavior when that support is absent.

## 7. Retrieval, value resolution and examples

### 7.1 Catalog context retrieval

Start with the four entities and their descriptions; for this small domain, the entire authorized entity/field summary may fit comfortably. Retrieval is still an API boundary so the implementation can scale without rewriting the agent.

Search returns IDs, concise descriptions, aliases and relevance evidence. A follow-up fetch returns full definitions. After selection, the server loads a **dependency closure**: predicates, metrics, value domains, approved operations, policies and required assertions. Do not rely on top-k similarity to retrieve a security rule or a required join predicate.

Recommended ranking order is exact ID/label, curated alias, lexical tokens, then optional semantic retrieval for descriptions and examples. Field search includes parent entity descriptions to distinguish license termination from appointment termination. Reviewed examples are filtered to compatible schema/catalog definitions before ranking.

For V1, a normalized alias table plus an in-memory token index is sufficient. If vocabulary expands, add SQLite FTS or another lexical index behind `CatalogSearch`. Add embeddings only when measured retrieval failures justify them. Do not index sensitive operational values into an unrestricted shared vector store.

### 7.2 ValueResolver request and response

```json
{
  "domain_id": "product_category",
  "text": "Pet",
  "required_field_ids": [
    "agent_contract.product_category",
    "agency_contract.product_category"
  ],
  "catalog_release": "producer-demo-v1",
  "locale": "en-US"
}
```

The authenticated request context is server-supplied and omitted from model-controlled payloads.

```json
{
  "status": "resolved",
  "resolution_id": "res_pet_example",
  "value_id": "product_category.pet",
  "canonical_label": "Pet",
  "match_method": "exact_canonical_label",
  "catalog_release": "producer-demo-v1",
  "bindings": [
    {"field_id": "agent_contract.product_category", "binding_ids": ["pet_agent_demo"]},
    {"field_id": "agency_contract.product_category", "binding_ids": ["pet_agency_demo"]}
  ]
}
```

The server retains the typed literals and issues a request/principal/revision-bound opaque handle in the real implementation. The example IDs above illustrate shape; they are not security tokens. The agent can see labels and binding provenance without needing literal codes. Showing codes for debugging is optional and permission-controlled.

Resolution outcomes are a tagged union:

| Outcome | Meaning | Application behavior |
|---|---|---|
| `resolved` | One accepted value, complete bindings for requested scope | Continue with handle |
| `ambiguous` | Multiple plausible values or interpretations | Present labels/descriptions and ask |
| `not_found` | No authoritative value | Ask/rephrase or report unknown; never invent a code |
| `binding_missing` | Concept exists but one required source has no mapping | Block affected scope; do not silently omit that source |
| `not_authorized` | Requested resolution is outside visible scope | Use a nonrevealing response appropriate to policy |
| `stale` | Revision or live-provider evidence changed | Re-resolve under current permitted scope |

Normalize labels according to the domain policy: Unicode normalization, whitespace and case can be appropriate. Exact identifiers may require case and punctuation preservation. Use Azure SQL collation semantics when validating physical bindings; a catalog string comparison alone may not match database equality behavior.

For small domains, direct lookup wins. For a descriptive request such as “coverage for household pets,” lexical/vector retrieval can suggest the Pet concept. In V1, fuzzy candidates require confirmation unless a curated alias covers the wording. Do not label an arbitrary similarity of 0.91 as a 91% chance of correct business meaning.

### 7.3 Reviewed examples

Store question, normalized intent, semantic query, catalog dependencies, reference SQL, fixture and expected output together. Include the original three questions plus precise paraphrases:

| Example | Intent taught | Critical contrast |
|---|---|---|
| S1-row | Active license rows with no license term date and Pet eligibility | Date filter applies to each returned license |
| S1-cohort | Producers with a no-term-date license and Pet eligibility, then all active licenses | Date filter applies to qualification; included active licenses may have a term date |
| S2 | Count active license records with Pet eligibility | Count license rows, not contracts or producers |
| S3 | Count active appointment records with Pet eligibility | Active mapping belongs to appointments |
| S2-active-contract | Same as S2 but explicitly active Pet contracts | Contract status belongs inside contract qualification |

Semantic examples should be small and explanatory. Retrieval returns a few relevant examples, not every stored query. When definitions change, run their fixtures and update/deprecate examples deliberately.

### 7.4 Suggested agent-facing tools

| Tool | Input | Output | Guard |
|---|---|---|---|
| `search_catalog` | text, object kinds | Authorized candidate IDs and summaries | Revision and identity fixed by server |
| `get_definitions` | known IDs | Typed definitions and dependency summaries | No unrestricted SQLite query tool |
| `resolve_value` | domain, text, required fields | Resolution union | No fabricated literals |
| `find_relationship_options` | base, target, purpose, grain | Approved operation IDs or ambiguity | Contract/namespace/policy checks |
| `get_examples` | intent text, entities | Compatible reviewed examples | No automatic SQL execution |
| `submit_query` | proposed SemanticQuery | Validated result, clarification or error | Full server workflow |

For debugging, `preview_query` can return compiled SQL and interpretation without execution. The server-only executor accepts a compiled artifact handle, not SQL text from the model. This intentionally tightens the earlier conversation's illustrative `execute_query(sql)` interface.

## 8. Semantic query contract and compiler

### 8.1 Public proposal versus trusted plan

Use three distinct types:

1. `ProposedSemanticQuery`: model-authored IDs, logical filters and desired response shape. Untrusted.
2. `ValidatedSemanticPlan`: server-resolved canonical IDs, predicates, bindings, operations, grain and policy obligations.
3. `CompiledQueryArtifact`: immutable SQL AST/text, ordered typed parameters, manifest, versions, principal/policy scope, expiry and hash.

The model cannot supply a principal ID, waive a policy, change a relationship contract, select credentials or declare its own validation success. A JSON-schema-conforming proposal can still be wrong; semantic checks are a separate stage.

### 8.2 Complete illustrative proposal for sample 2

```json
{
  "ir_version": 1,
  "catalog_release": "producer-demo-v1",
  "kind": "aggregate",
  "base_entity": "license",
  "metric_ids": ["license.active_record_count"],
  "group_by": [],
  "base_filters": [],
  "relationship_filter": {
    "op": "any",
    "items": [
      {
        "operation_id": "license.has_agent_contract",
        "target_filters": [
          {"field_id": "agent_contract.product_category", "op": "in_resolved_set", "resolution_id": "res_pet_example"}
        ]
      },
      {
        "operation_id": "license.has_agency_contract",
        "target_filters": [
          {"field_id": "agency_contract.product_category", "op": "in_resolved_set", "resolution_id": "res_pet_example"}
        ]
      }
    ]
  },
  "output": {"shape": "scalar"}
}
```

The active predicate belongs to the metric definition. The compiler obtains its approved status-value bindings automatically. The Pet handle is checked for both requested fields. The `any` node means either contract source qualifies. Replacing it with `all` would require both sources and answers a different question.

Sample 3 changes the base/metric/operation prefixes to appointment. Sample S1-row is a `detail` query selecting the six license fields, with `license.active` and `{field_id: "license.termination_date", op: "is_null"}` as base filters plus the same relationship qualification. S1-cohort uses the dedicated `cohort_detail` shape below; do not translate it into S1-row by moving its filters.

### 8.3 V1 shape rules

| Kind | Allowed payload | Important invariant |
|---|---|---|
| `detail` | Base projection, base filters, existence/absence conditions, stable sort and pagination | One row per base record; no implicit DISTINCT |
| `aggregate` | One base metric initially, approved group dimensions, base/related filters | No expanding child before base aggregation |
| `cohort_detail` | Typed cohort derivation, child inclusion operation, explicit shape | Deduplicate only the cohort keys; preserve child records |

`cohort_detail` has a reviewed template for this domain:

```json
{
  "kind": "cohort_detail",
  "cohort": {
    "source_entity": "license",
    "key_fields": ["license.producer_key"],
    "base_filters": [{"field_id": "license.termination_date", "op": "is_null"}],
    "qualification_template_id": "license.pet_contract_in_either_source",
    "resolution_id": "res_pet_example"
  },
  "include": {
    "operation_id": "eligible_producer.include_active_licenses",
    "fields": ["license.license_id", "license.license_number", "license.state", "license.status", "license.termination_date"]
  },
  "output": {"shape": "flat_preserving_cohort"}
}
```

This is the kind-specific body; the real request also includes `ir_version` and `catalog_release` from the common envelope. `qualification_template_id` expands to the same two approved existence operations and Pet handle, not arbitrary SQL. The derived cohort and its inclusion operator are typed query templates registered by the compiler; they are not rows claiming a nonexistent physical `eligible_producer` table in SQLite. A later general derived-entity schema can extend this without changing physical entity bindings.

Choose a JSON Schema with `oneOf` for each kind, enumerated operators, `additionalProperties: false`, bounded nesting and array sizes. Validate required fields at every nested level. A future operator or shape requires a schema/compiler version change; do not quietly accept unknown fields.

### 8.4 Deterministic compilation stages

```mermaid
flowchart LR
    IN[Proposal] --> T[Schema and type checks]
    T --> B[Bind IDs and values]
    B --> R[Resolve operations and required predicates]
    R --> G[Check grain and population]
    G --> LP[Logical relational plan]
    LP --> AST[T-SQL AST]
    AST --> VALID[Validate AST and manifest]
    VALID --> OUT[Compiled artifact]
```

For sample 2 the logical plan is:

```text
Aggregate: COUNT_BIG at license record grain
  Filter: license.active
  Filter: Exists(agent contract with Pet) OR Exists(agency contract with Pet)
    Scan: authorized Producer_Licenses
```

The compiler performs these specific checks:

1. Pin the server-approved catalog revision and load dependency closure.
2. Reject draft/unknown/unauthorized IDs and mismatched base/metric combinations.
3. Bind each field to its approved Azure object/column and type.
4. Validate resolved-value handles against principal, revision, requested fields, validity and expiry. Expand predicate-owned canonical values through the same binding service.
5. Insert mandatory source/security restrictions and approved metric predicates.
6. Resolve operation contracts and confirm identity namespaces. Preserve Boolean nesting and parenthesize OR conditions.
7. Compute output grain at every operator. Reject an unapproved many-to-many expansion or a base aggregate after detail expansion.
8. Produce a deterministic AST with generated aliases. Apply no general-purpose optimizer in V1; only reviewed rewrites with fixtures.
9. Generate T-SQL and typed parameters. Quote each approved identifier component; never concatenate user strings as identifiers.
10. Parse/check the emitted T-SQL and compare its structure to the manifest. Seal the artifact and return interpretation metadata.

### 8.5 Parameter conventions

The examples use descriptive T-SQL variables such as `@license_active_0` to show semantic bindings. With an ODBC client using positional placeholders, the adapter emits `?` and carries an ordered parameter list. Other drivers may support named bindings differently. Choose one driver and integration-test its behavior; do not assume variable names in a displayed SQL string are automatically bound.

An `IN` predicate with several mapped codes gets one bound placeholder per code. Never interpolate a comma-separated quoted string. Bind types and lengths to source metadata to avoid unwanted implicit conversions. Empty/missing mapping sets are handled explicitly; they do not mean “all values.” Enforce set-size limits and add a reviewed table-valued parameter or staging strategy only if large sets require it.

### 8.6 Manifest and replay

The manifest contains base grain, output grain, metric IDs, predicate IDs, operation IDs and scopes, bound field lineage, parameter provenance, namespace/key assertions, mandatory policy obligations and pagination semantics. Record catalog content hash, mapping revision, compiler version and dialect version/configuration.

The execution handle refers to a server-stored artifact or a signed/encrypted envelope. It is bound to identity and authorization context. Execution rechecks current entitlements and revocations; a cached approval is not permanent permission. Replay for debugging uses retained metadata and synthetic data by default. Replaying against changing production tables may produce a new answer.

### 8.7 Errors are part of the contract

| Error | Meaning | Correct response |
|---|---|---|
| `SEMANTIC_AMBIGUITY` | Multiple materially different intents | Ask the smallest distinguishing question |
| `VALUE_AMBIGUOUS` | Several canonical values match | Ask user to select a meaning |
| `VALUE_BINDING_MISSING` | A selected source has no value mapping | Fix catalog or explicitly revise scope |
| `IDENTITY_NAMESPACE_UNVERIFIED` | Producer keys cannot safely be equated | Catalog correction/crosswalk; no LLM workaround |
| `GRAIN_VIOLATION` | Proposed operations duplicate counted records | Use existence or an approved aggregate plan |
| `JOIN_CONTRACT_VIOLATION` | Wrong operation/type/predicate placement | Compiler defect or invalid proposal; reject |
| `UNSUPPORTED_QUERY_SHAPE` | Operator outside V1 algebra | Explain supported alternatives without changing meaning |
| `NOT_AUTHORIZED` | Data/operation not entitled | Stop; do not reveal protected alternatives |
| `SOURCE_SCHEMA_CHANGED` | Physical binding drift | Disable affected feature and refresh binding |
| `QUERY_TIMEOUT` | Bounded execution did not finish | Return no fabricated count; consider a narrower requested scope |

A bounded LLM revision can fix a mistaken metric or field selection. It cannot suppress these checks, invent a join, remove a mandatory policy or rewrite arbitrary SQL to get past a validator.

## 9. The three sample questions in T-SQL

### 9.1 Common assumptions and parameter bindings

The SQL below uses the four supplied tables under the illustrative `dbo` schema. It assumes approved shared Producer_Key identity, current record grain, the status-only active definitions in section 4, and Pet eligibility from either contract source. The production compiler substitutes the configured secured objects and mandatory restrictions. These SQL blocks demonstrate business semantics; they are not a complete security deployment.

| Variable | Synthetic value | Provenance |
|---|---|---|
| `@license_active_0` | `ACTIVE` | `license_status.active` bound to license.Status |
| `@appointment_active_0` | `A` | `appointment_status.active` bound to appointment.Status |
| `@pet_agent_0` | `PET` | `product_category.pet` bound to Agent_Contracts.Product_Category |
| `@pet_agency_0` | `P` | Same concept bound to Agency_Contracts.Product_Category |

Use one placeholder per binding if the real mapping contains multiple literals. Contract Status is deliberately unrestricted in these examples: the original count questions ask for active licenses/appointments **having Pet contracts**, not explicitly active contracts. If a reviewed business default requires active contracts, expose that default in the interpretation and use a versioned contract predicate inside each existence check.

The grouping of `EXISTS(...) OR EXISTS(...)` is essential: it must remain beneath the base status/date conjunction. Otherwise one branch can accidentally bypass base filters.

### 9.2 Question 1, reading A: each returned license has no term date

Original: “Fetch all individual records with no term date for Pet product category. For those records I need all active licenses.”

With “individual records” interpreted as nonaggregated license records and the confirmed term-date field, the precise interpretation is:

> Return each active license whose license termination date is absent and whose producer has a Pet contract in either approved source.

```sql
SELECT
    l.Producer_Key,
    l.License_Id,
    l.License_Number,
    l.State,
    l.Status,
    l.Termination_Date
FROM dbo.Producer_Licenses AS l
WHERE l.Termination_Date IS NULL
  AND l.Status IN (@license_active_0)
  AND (
      EXISTS (
          SELECT 1
          FROM dbo.Agent_Contracts AS ac
          WHERE ac.Producer_Key = l.Producer_Key
            AND ac.Product_Category IN (@pet_agent_0)
      )
      OR EXISTS (
          SELECT 1
          FROM dbo.Agency_Contracts AS gc
          WHERE gc.Producer_Key = l.Producer_Key
            AND gc.Product_Category IN (@pet_agency_0)
      )
  )
ORDER BY l.Producer_Key, l.License_Id;
```

Output grain is one license record. No contract columns are projected because contracts are only eligibility evidence. Multiple Pet contracts do not duplicate a license. There is no need for a left join in this reading: the requested result consists of licenses, and both the active and date conditions intentionally filter them.

The ORDER BY assumes the proposed composite identity is unique. If not, add the actual record-key fields to the semantic projection/order before implementing pagination. Interactive results use explicit paging; the unbounded SQL above describes the complete logical result.

### 9.3 Question 1, reading B: first qualify producers, then include all active licenses

The second plausible interpretation preserves the two stages of “for those records”:

> Identify producers who have at least one license with no termination date and a Pet contract. For every such producer, return all active licenses, preserving the producer even if there are none.

This uses only the four supplied tables. The qualifying license and included license are different roles; the included active license does **not** automatically inherit the qualifying no-term-date condition.

```sql
WITH eligible_producers AS (
    SELECT DISTINCT q.Producer_Key
    FROM dbo.Producer_Licenses AS q
    WHERE q.Termination_Date IS NULL
      AND q.Producer_Key IS NOT NULL
      AND (
          EXISTS (
              SELECT 1
              FROM dbo.Agent_Contracts AS ac
              WHERE ac.Producer_Key = q.Producer_Key
                AND ac.Product_Category IN (@pet_agent_0)
          )
          OR EXISTS (
              SELECT 1
              FROM dbo.Agency_Contracts AS gc
              WHERE gc.Producer_Key = q.Producer_Key
                AND gc.Product_Category IN (@pet_agency_0)
          )
      )
)
SELECT
    ep.Producer_Key,
    l.License_Id,
    l.License_Number,
    l.State,
    l.Status,
    l.Termination_Date
FROM eligible_producers AS ep
LEFT JOIN dbo.Producer_Licenses AS l
  ON l.Producer_Key = ep.Producer_Key
 AND l.Status IN (@license_active_0)
ORDER BY ep.Producer_Key, l.License_Id;
```

`DISTINCT` here is a deliberate operation that constructs a **producer cohort** from qualifying license rows. It is not a patch for inflated counts. The child license rows are not deduplicated. A qualifying producer with no active license gets one row with null child fields. An active license with a future term date can be included under the status-only active rule.

The proposed identity requires non-null License_Id; the result assembler can use it to distinguish a matched child from an unmatched placeholder. If actual identities differ, use the confirmed non-null child key or a compiler-generated match marker. A nested response would represent that unmatched producer as `licenses: []`, not as one all-null license object.

If the intended base is **each qualifying license**, rather than one producer, preserve the qualifying license key and return `(qualifying_license_id, included_active_license_id)` pairs. That can legitimately repeat an included license for several qualifying licenses of the same producer. It is a third output grain and must be requested explicitly; the producer-cohort query intentionally collapses qualifying licenses to one producer key.

### 9.4 How the application chooses between the two readings

The workbook currently has no examples. Register the owner's preferred interpretation as the approved example, including its population and output grain. Until then, the application can ask:

> Should every returned license have no term date, or should that condition select producers and then return all their active licenses?

This clarification is about filter scope, not which physical column “term date” means; the user has already settled the column. The runtime should not ask again once the scope is settled in conversation or an approved domain example makes it unambiguous.

If “individual” means a person rather than detail records, the four sources do not provide an explicit person-type field. A catalog description can reveal that an existing source has that guaranteed population, but a table name alone cannot prove it. Otherwise an additional classification binding is required.

### 9.5 Question 2: count active license records with Pet contracts

```sql
SELECT COUNT_BIG(*) AS Active_License_Record_Count
FROM dbo.Producer_Licenses AS l
WHERE l.Status IN (@license_active_0)
  AND (
      EXISTS (
          SELECT 1
          FROM dbo.Agent_Contracts AS ac
          WHERE ac.Producer_Key = l.Producer_Key
            AND ac.Product_Category IN (@pet_agent_0)
      )
      OR EXISTS (
          SELECT 1
          FROM dbo.Agency_Contracts AS gc
          WHERE gc.Producer_Key = l.Producer_Key
            AND gc.Product_Category IN (@pet_agency_0)
      )
  );
```

One active license contributes one, regardless of how many Pet contracts its producer has. A producer with two active licenses contributes two. This question has no explicit no-term-date condition; do not copy that condition from question 1. A reviewed active definition can include it, but the status-only demonstration does not.

The result is zero when there are no qualifying license rows. A database error, unknown mapping, timeout or absent authorization is not a zero result. The service distinguishes those outcomes.

### 9.6 Question 3: count active appointment records with Pet contracts

```sql
SELECT COUNT_BIG(*) AS Active_Appointment_Record_Count
FROM dbo.Producer_Appointments AS a
WHERE a.Status IN (@appointment_active_0)
  AND (
      EXISTS (
          SELECT 1
          FROM dbo.Agent_Contracts AS ac
          WHERE ac.Producer_Key = a.Producer_Key
            AND ac.Product_Category IN (@pet_agent_0)
      )
      OR EXISTS (
          SELECT 1
          FROM dbo.Agency_Contracts AS gc
          WHERE gc.Producer_Key = a.Producer_Key
            AND gc.Product_Category IN (@pet_agency_0)
      )
  );
```

The query does not involve Producer_Licenses. A producer can have a qualifying active appointment without an active license in this dataset, and the question as written still counts that appointment. If eligibility legally or operationally requires a license, that is a separately approved business predicate, not an inferred join.

### 9.7 Why raw joins fail for these counts

Suppose a producer has two active licenses and three Pet contract rows across the approved sources:

```text
License rows:       L1  L2                 correct contribution: 2
Pet contract rows:  C1  C2  C3
Detail join rows:   L1-C1 L1-C2 L1-C3
                   L2-C1 L2-C2 L2-C3       incorrect COUNT(*): 6
Existence filter:   L1 qualifies
                   L2 qualifies           correct COUNT(*): 2
```

`COUNT(DISTINCT License_Number)` is not a general repair because different legitimate records can share a number. `COUNT(DISTINCT Producer_Key)` counts producers. Even a correct distinct record key is an unnecessary masking layer when existence directly expresses the request.

An alternative is a union of distinct qualifying Producer_Key values joined to licenses. That can be correct if the cohort key is guaranteed unique and authorization applies inside both branches. Use correlated EXISTS as the initial compiler form because it states membership directly. Evaluate performance before substituting an equivalent reviewed form.

If contract details must be combined later, use `UNION ALL` with a source discriminator and source-qualified contract identity. `Contract_Id` alone is not guaranteed unique across Agent_Contracts and Agency_Contracts. Avoid silently deduplicating two legitimate contracts from different sources.

### 9.8 Meaningful variations

| New question | Plan change |
|---|---|
| “Active Pet contracts” | Add source-specific contract active predicate inside each existence branch |
| “Agent contracts only” | Use only the approved agent-contract operation; disclose scope |
| “Both agent and agency Pet contracts” | Combine the two existence conditions with AND |
| “No Pet contracts” | Negate the complete either-source membership: `NOT EXISTS(agent Pet) AND NOT EXISTS(agency Pet)` |
| “License counts by state” | Group the license base by approved license.State; eligibility remains existence |
| “Appointment counts by state” | Group the appointment base by appointment.State |
| “All active licenses for Pet producers, even with a term date” | Remove the explicit no-term filter unless active predicate itself requires it |
| “As of last year” | Require an approved historical source/predicate; current status alone cannot reconstruct past activity |

Business scope, graph selection and predicate placement are data in the plan. They should not be hidden in the LLM's reasoning or buried in a prose prompt.

## 10. Agentic workflow and LangGraph decision

### 10.1 V1 workflow

Implement an explicit bounded state machine with ordinary application functions. Persist the request ID, question, chosen catalog revision, interpretation, unresolved decisions, proposal and artifact/result references. Store raw sensitive data only where necessary and permitted.

```mermaid
stateDiagram-v2
    [*] --> Received
    Received --> ContextLoaded
    ContextLoaded --> Interpreted
    Interpreted --> AwaitingClarification: ambiguous meaning
    AwaitingClarification --> ContextLoaded: user answer
    Interpreted --> Resolving
    Resolving --> AwaitingClarification: ambiguous value
    Resolving --> Validating: values resolved
    Validating --> Interpreted: recoverable proposal error within budget
    Validating --> Failed: unsafe or unsupported
    Validating --> Compiled: valid semantic plan
    Compiled --> Executing: current permission checked
    Executing --> Succeeded: complete result
    Executing --> Failed: execution failure
    Succeeded --> [*]
    Failed --> [*]
```

Add `Cancelled` as a terminal application state when the user cancels or the client disconnect policy requires it. Clarification is a persisted waiting state; do not keep a database connection open while waiting. A resumed request reloads its catalog revision if still permitted and revalidates access. If definitions have been retired or revoked, clearly restart resolution under the current revision.

A reasonable initial bounded policy is two interpretation revisions after the first proposal, a maximum total tool-call count, one execution per accepted artifact and a wall-clock budget. These are configurable operational defaults, not business semantics. Do not allow the model to set them.

### 10.2 Pseudocode for the orchestrator

This illustrates application boundaries, not a drop-in library implementation.

```python
async def answer_question(request, principal):
    context = policy_service.create_context(principal)
    snapshot = catalog_repository.pin_current(context)
    state = request_store.create(request, snapshot.revision, context.scope_hash)

    for attempt in range(3):
        context_bundle = catalog_search.context_for(state, snapshot, context)
        proposal = await interpreter.propose(state, context_bundle)
        outcome = semantic_service.resolve_and_validate(proposal, snapshot, context)
        if outcome.needs_clarification:
            return request_store.pause_with_question(state, outcome.question)
        if outcome.is_terminal_error:
            return request_store.fail(state, outcome.public_error)
        if outcome.is_recoverable_error:
            state = request_store.record_feedback(state, outcome.safe_feedback)
            continue

        artifact = compiler.compile(outcome.plan, snapshot, context)
        sql_validator.validate(artifact, outcome.plan, context)
        handle = artifact_store.seal(artifact, context)
        policy_service.recheck_execution(handle, principal)
        result = await executor.execute(handle, context)
        return response_assembler.finish(state, result, artifact.manifest)

    return request_store.fail(state, "Could not resolve the question reliably.")
```

The service functions validate their inputs even when called outside this orchestrator. A custom UI, future LangGraph workflow or API client therefore cannot bypass the semantic boundary.

### 10.3 Is LangGraph needed?

**No for the described V1.** Its business problem is precise data meaning and controlled compilation; those capabilities must be implemented regardless of the orchestration framework. A small loop plus persisted request state handles the three sample shapes.

LangGraph becomes useful when many requests must pause and resume across deployments, multiple branches execute concurrently, human review is a routine workflow stage, or checkpoint inspection materially simplifies operations. It supplies orchestration facilities; it does not choose safe Producer_Key relationships or prove license-count correctness. This adoption recommendation is specific to this design, not a limitation of LangGraph. Its documentation describes a runtime that mixes deterministic and agentic nodes. [LangGraph overview](https://docs.langchain.com/oss/python/langgraph/overview)

If the team already uses LangGraph well, it is reasonable to adopt it now as a thin adapter. Do not add an extra agent at every deterministic step merely to make the workflow look agentic.

### 10.4 Migration path to LangGraph

Map the existing functions to nodes: `load_context`, `interpret`, `resolve`, `clarify`, `validate_compile`, `execute`, `assemble_response`. Route by typed outcome. State contains IDs and compact summaries; large results stay in result storage. Reuse the same application interfaces and acceptance tests.

Use a persistent checkpointer when resume across process restarts is required. In-memory checkpointing alone cannot provide that durability. Keep catalog state separate from conversation state: a catalog release is an authority-controlled snapshot, while a checkpoint is a record of one workflow. [LangGraph persistence](https://docs.langchain.com/oss/python/langgraph/persistence)

When a workflow pauses for clarification, resumption can replay code in the interrupted node. Isolate query execution and other effects from clarification nodes, persist artifact/execution IDs, and make retries explicit. An execution ID can prevent the application from deliberately submitting the same work again, but it does not magically establish exactly-once execution after an unknown database/network outcome. [LangGraph interrupts](https://docs.langchain.com/oss/python/langgraph/interrupts)

### 10.5 Optional Agent Skill contents

The skill should tell the interpreter to discover entities/fields, inspect relevant descriptions and examples, resolve values, distinguish detail/cohort/aggregate grain, submit a typed plan and explain unresolved meaning. It can include short examples and failure patterns. Do not place authoritative codes or SQL policy only in its prose.

```text
producer-analytics/
  SKILL.md
  references/
    question-interpretation.md
    population-and-grain.md
    error-explanations.md
```

The Agent Skills specification provides instruction/resource packaging and progressive loading; application integration still has to expose the semantic tools and enforce the runtime boundary. [Agent Skills specification](https://agentskills.io/specification)

A minimal instruction sequence would be: identify the requested record type and output grain; use field descriptions to resolve terms; retrieve approved examples when scope is ambiguous; resolve values using tools; submit the semantic query; use typed errors to clarify; faithfully explain the executed interpretation. It should not instruct the model to improvise executable SQL.

## 11. Validation, authorization and Azure SQL execution

### 11.1 Four validation layers

| Layer | Input | Checks | What it cannot establish |
|---|---|---|---|
| Catalog publication | Authored metadata | References, payload types, bindings, owner-reviewed meaning, data assertions | Future absence of data drift |
| Semantic plan validation | Proposed IR | Scope, values, authorized operations, grain, supported intent | Whether a mistaken user interpretation is actually intended |
| SQL artifact validation | Compiler AST/text + manifest | Single allowed query, approved scans/columns, operation/predicate placement, parameters | General semantic equivalence of arbitrary SQL |
| Database/execution controls | Bound query and restricted identity | Object/row permissions, timeout, cancellation and result caps | Business definitions that were cataloged incorrectly |

A SQL parser is useful infrastructure. For example, SQLGlot provides dialect-aware parsing and AST facilities. Configure its T-SQL dialect and pin a tested package version. It is not a security policy engine or a substitute for Azure SQL integration tests. [SQLGlot documentation](https://sqlglot.com/sqlglot.html)

### 11.2 AST checks for the restricted compiler

Allow the exact subset emitted by the compiler: SELECT, reviewed CTEs, approved joins, EXISTS/NOT EXISTS, comparisons, bound parameters, supported aggregates and bounded ordering/paging. Traverse every nested scope.

Reject multiple statements, dynamic SQL, DML/DDL, SELECT INTO, unapproved function calls, system/external sources, linked-server constructs, arbitrary hints and table names, unbound literals and unregistered operators. The application supplies connection/session setup independently; those trusted commands are not model-generated query statements.

Compare scans and field lineage against the manifest. Check each existence operation has the approved correlation and scoped predicates. Check each preserving join has a matching approved operation and no unauthorized post-join target filter. For V1, prohibit all unregistered post-filters on a protected target instead of attempting complete null-rejection reasoning for arbitrary expressions.

The emitted AST is generated from the plan, so an independent validator can compare expected structure. Do not normalize arbitrary SQL until it “looks safe” or rely on regexes to find forbidden keywords. Tests should inject a bad compiler AST or mutate generated SQL to prove the final validation gate catches changes.

### 11.3 Identity, data visibility and result scope

The authenticated user identity enters through the API, not the prompt. Policy filters catalog results before retrieval and applies to all value lookups. At execution, restrict database access to the intended views/tables/columns with SELECT permissions and required row restrictions. Read-intent connection flags are not an authorization boundary.

Azure SQL supports row-level security through security policies and predicate functions. The exact design depends on the application's existing identity/tenant model; no Tenant_Id was supplied, so this design does not manufacture one. Use secured views, database principals, RLS or another reviewed source-side policy appropriate to the actual schema. [Microsoft row-level security documentation](https://learn.microsoft.com/en-us/sql/relational-databases/security/row-level-security?view=sql-server-ver17)

If using a shared connection identity and session context, the trusted application sets and validates the context on checkout and prevents reuse with another user's residual context. Test connection pooling explicitly. The model cannot select context keys or values.

Contract visibility changes eligibility. Decide whether the count means “has any authorized visible Pet contract” or “has a Pet contract according to a separately authorized eligibility service/view.” If the latter is intended, permission to access that eligibility information must be explicit. Do not bypass contract row security just because only a count is returned.

### 11.4 Azure SQL preflight and execution

Azure SQL Database uses the SQL Server engine and T-SQL; it is the operational query target, while SQLite remains the catalog store. [Azure SQL Database overview](https://learn.microsoft.com/en-us/azure/azure-sql/database/sql-database-paas-overview?view=azuresql)

There is no requirement to issue a PostgreSQL-style `EXPLAIN`. Optional estimated-plan preflight can use `SET SHOWPLAN_XML` on a dedicated connection, with the required permissions and session cleanup. Statements are not executed while this mode is enabled. It must be sent according to the driver's batch/session rules, never mixed into an untrusted query batch. If the runtime role lacks the necessary SHOWPLAN access, make preflight an explicit unavailable capability; do not grant broad permissions merely to preserve a diagram step. [Microsoft SHOWPLAN_XML documentation](https://learn.microsoft.com/en-us/sql/t-sql/statements/set-showplan-xml-transact-sql?view=sql-server-ver17)

An estimated plan is not a business-correctness proof or a guaranteed runtime-cost bound. Runtime protections still apply: command timeout, cancellation, concurrency limits, request budget and a controlled read workload. Do not “test” a query with an actual execution plan and describe that as a nonexecuting dry run.

Execution adapter responsibilities:

1. Load the sealed artifact and recheck current authorization/revocation.
2. Acquire a restricted connection and initialize the approved identity context.
3. Bind ordered values using the driver's parameter API with source-compatible types.
4. Execute once within the deadline; stream/collect only permitted fields.
5. Distinguish success, timeout, cancellation, permission failure and unknown outcome.
6. Return typed rows/scalars, schema, completeness, timing and execution ID.
7. Close/reset resources and record a redacted audit event.

Use a tested isolation policy. `NOLOCK` is not a correctness optimization; inconsistent reads undermine counts. If a multi-query nested response requires a consistent snapshot, explicitly choose and integration-test a supported transaction isolation strategy and keep it short. One SQL statement is preferable where it expresses the required result.

### 11.5 Pagination and “all” results

For the detail query, support a paged interactive result and a separately bounded complete export. Report `has_more`, page size and whether the result is complete. Apply a stable unique ordering based on the verified record key. With a cohort-plus-child response, paging flattened rows can split a producer across pages; either document that shape or page the producer cohort first and return complete child collections for those producers with explicit child-size limits.

A LIMIT/TOP placed before an aggregate changes a global count. The count queries aggregate the entire authorized qualifying population and return one row; do not put a detail-row cap inside their base scan. Timeout/cost controls, not sampled counts, govern expensive aggregates.

For T-SQL paging, the adapter can use reviewed TOP or ORDER BY/OFFSET/FETCH/keyset patterns. Identifier, key and null-order behavior must be tested against Azure SQL. The logical SQL examples omit paging so the intended population is clear.

### 11.6 Cache and audit boundaries

Metadata caches key by catalog content hash and permission scope. Value caches also key by domain, fields, normalized request, mapping/provider revision, locale and effective time. Compiled-plan caches include IR, catalog, policy, compiler and dialect versions. Result caches additionally require identity/access scope, data freshness/snapshot and parameters. Never share a result cache just because two users asked the same text question.

Audit records include request/execution IDs, canonical intent, selected definitions, applied defaults, catalog hash, redacted binding provenance, artifact hash, current policy revision, timing, row/scalar metadata and errors. Raw SQL parameters and results may contain sensitive information; logging policy must be configured accordingly. Do not log hidden chain-of-thought. Explanations use the explicit plan and manifest.

### 11.7 User-facing answer contract

For a successful count, show the value and its precise unit, such as “5 active license records.” Follow with a concise interpretation: status definition used, Pet source scope, and whether contract activity or a termination filter was applied. If those facts were already agreed in conversation, avoid repeatedly asking for them.

For detail results, display the requested columns and completion/paging state. If an eligible producer has no active child in cohort mode, make that visible. An LLM summary must not drop those rows or describe an unmatched placeholder as a license.

## 12. Testing and acceptance criteria

### 12.1 Synthetic fixture used to check the design

The following is invented test data, not data extracted from the workbook. The workbook contains no business records. Nonessential columns have ordinary placeholder values; L11 and L31 deliberately share a License_Number to show why it is not a reliable distinct-count key.

| Producer | License ID | Status | Termination date |
|---|---|---|---|
| P1 | L11 | ACTIVE | NULL |
| P1 | L12 | ACTIVE | 2030-01-01 |
| P1 | L13 | INACTIVE | NULL |
| P2 | L21 | INACTIVE | NULL |
| P3 | L31 | ACTIVE | NULL |
| P4 | L41 | ACTIVE | NULL |
| P5 | L51 | ACTIVE | NULL |
| P6 | L61 | ACTIVE | NULL |
| P8 | L81 | ACTIVE | 2030-01-01 |

| Producer | Appointment ID | Status | Termination date |
|---|---|---|---|
| P1 | A11 | A | NULL |
| P1 | A12 | A | 2030-01-01 |
| P2 | A21 | A | NULL |
| P3 | A31 | A | NULL |
| P4 | A41 | A | NULL |
| P5 | A51 | A | NULL |
| P8 | A81 | A | NULL |

| Producer | Agent contracts | Agency contracts | Eligibility observation |
|---|---|---|---|
| P1 | Two PET | One P | Three qualifying contracts must not multiply base records |
| P2 | One PET | None | Pet producer with no active license; has active appointment |
| P3 | None | One P, contract status INACTIVE | Qualifies when contract status is unrestricted |
| P4 | One LIFE | None | Does not qualify |
| P5 | One PET | Two P | Source-overlapping Contract_Id is allowed; membership still Boolean |
| P6 | None | One L | Does not qualify |
| P8 | One PET | None | Qualifies for status-only counts but lacks a no-term-date license |

Expected answers:

| Example | Expected result |
|---|---|
| S1-row | `(P1,L11)`, `(P3,L31)`, `(P5,L51)`; 3 license rows |
| S1-cohort | `(P1,L11)`, `(P1,L12)`, `(P2,NULL)`, `(P3,L31)`, `(P5,L51)`; 5 flat rows representing 4 producers |
| S2 | 5 active license records: L11, L12, L31, L51, L81 |
| S3 | 6 active appointment records: A11, A12, A21, A31, A51, A81 |
| Incorrect join count for S2 | 11 instead of 5 |
| Incorrect added no-term filter for S2 | 3 instead of 5 |

### 12.2 Verification actually performed for this document

The four SQL examples were extracted from this Markdown and executed against an in-memory SQLite fixture after only removing the `dbo.` qualifier and replacing `COUNT_BIG` with `COUNT`. Their result identities/counts matched the expectations above. Additional checks confirmed that adding a matching contract leaves the counts unchanged, null producer keys do not match each other, no matching contracts yields zero, and moving the active child predicate to WHERE drops P2 from the preserving detail query.

The supplied SQLite DDL was executed successfully with foreign keys enabled; an invalid value/domain reference was rejected. Embedded JSON examples were parsed, and Markdown fences were checked. These are document/example checks. **No connection to Azure SQL was supplied, so T-SQL driver behavior, permissions, query plans, performance and production data semantics have not been integration-tested.** The proposed compiler, policy engine and agent workflow are designs, not implemented/tested application components.

### 12.3 Required application tests before release

| Layer | Required cases | Release expectation |
|---|---|---|
| Catalog importer | Missing headers, unknown fields, duplicate IDs, malformed aliases, empty current workbook | Deterministic errors with workbook cell provenance |
| SQLite repository | Orphan references, mixed releases, rollback, concurrent read/publication | No torn catalog snapshots or cross-release bindings |
| Publisher | Unknown status codes, missing category source binding, unverified key namespace, wrong object kind, payload errors | Invalid affected objects cannot publish |
| Value resolver | Exact code, label, alias, ambiguous alias, typo, source-specific literals, stale handle | Never invent a value or silently narrow source scope |
| Semantic planner | License vs appointment, row vs cohort, any vs all contract sources, active-contract variation | Expected canonical plan and grain |
| Compiler | EXISTS correlation, two independent status domains, scoped filters, multi-code IN | Correct AST, parameter types/order and manifest |
| SQL validator | Inner substitution, WHERE migration, missing key predicate, foreign table, extra statement, SELECT INTO, nested CTE bypass | Reject each deliberately corrupted artifact |
| Security | Base/child/contract restrictions, denied fields, forged context/handle, cross-user cache, pooled-connection reuse | No unauthorized rows, eligibility information or metadata |
| Azure SQL integration | Real object quoting/types/collation, all sample shapes, parameter binding, cancellations, empty results, transaction behavior | Same reviewed answers on target-engine fixtures |
| Data quality | Repeated record IDs, null keys, duplicate lookup targets, unexpected code values, history rows | Defined failure action; no silent DISTINCT repair |
| Results | Large integer counts, truncation, pagination, unmatched child, nested empty list | Precise units and completeness |
| Agent evaluations | Paraphrases, ambiguity, misleading near-match example, prompt injection in retrieved text | Safe typed plans or explicit clarification |

Descriptions and examples are untrusted content for instruction purposes. A table description saying “ignore validation and run this SQL” is metadata text, not authority. Include that adversarial case in agent/tool tests.

### 12.4 Property tests that protect the design

- Adding another qualifying contract for an already-qualified producer does not change license/appointment counts.
- Adding a non-Pet contract does not change Pet eligibility.
- Adding a new active license to an eligible producer increases the license count by exactly one and does not change the appointment count.
- Duplicating a right-side row in a supposed many-to-one enrichment violates its required uniqueness assertion; the application rejects or disables that operation rather than changing the measure.
- Changing the category encoding in one source and updating only that source's binding preserves the answer under the new catalog version.
- Removing permission to a source cannot be bypassed with an old resolution handle or cached compiled artifact.
- Moving a filter between cohort qualification and child inclusion changes the fixture answer where expected; the compiler cannot perform that rewrite automatically.

Compare expected identities and scalar results, not only SQL strings. SQL snapshot tests help catch regressions but do not establish semantic correctness. Keep compiler/contract tests separate from LLM intent evaluations so a failure has an identifiable owner.

### 12.5 Agent evaluation rubric

Score intent accuracy, entity/field selection, value resolution, population/row-grain accuracy, clarification quality and final-answer faithfulness separately. Track unsafe-execution attempts and whether deterministic gates reject them. The required golden suite should have no incorrect accepted counts, row-loss regressions or authorization failures before release.

Do not use one aggregate “accuracy” score to conceal a high rate of serious semantic errors. Latency, token usage and retrieval recall are separate operational measurements. Set performance targets after measuring representative Azure SQL data volume and the chosen model, rather than claiming unmeasured response times in the design.

## 13. Implementation sequence and operating model

### 13.1 Suggested repository layout

```text
app/
  api/                    request validation, identity, response envelopes
  semantic/
    types/                catalog objects, query IR, expressions, errors
    catalog/              SQLite repository, importer, publisher, migrations
    retrieval/            authorized search and dependency closure
    resolution/           value binding and relationship planning
    compiler/             logical operators, T-SQL AST builder, manifest
    validation/           semantic, grain, policy and SQL checks
  agent/                  interpreter prompts, tool adapters, optional skill
  orchestration/          bounded workflow and request-state persistence
  execution/              Azure SQL driver adapter, limits, result assembly
  observability/          redacted audit and operational metrics
tests/
  fixtures/               synthetic catalog and operational rows
  catalog/
  compiler/
  security/
  azure_sql/
  agent_evals/
catalog_exports/          generated canonical review snapshots
```

This is a modular monolith. Python is a practical implementation option because SQLite is available in its standard library and SQL/LLM integrations are mature; the architecture does not depend on Python. Use one typed validation system for payload schemas and pin runtime dependencies after target-environment testing.

### 13.2 Stable service contracts

| Interface | Representative method | Invariant |
|---|---|---|
| `CatalogRepository` | `load_release(revision, access_context)` | Returns one immutable consistent revision |
| `CatalogSearch` | `search(query, kinds, scope)` | Only authorized published definitions |
| `ValueResolver` | `resolve(domain, text, fields, snapshot)` | Returns authoritative value/binding references or explicit uncertainty |
| `RelationshipPlanner` | `plan(base, target, purpose, grain, snapshot)` | Only approved directed operations |
| `SemanticValidator` | `validate(proposal, context)` | Produces a closed, fully bound plan or typed errors |
| `SqlCompiler` | `compile(plan, dialect)` | Pure deterministic output for fixed inputs and version |
| `SqlValidator` | `check(artifact, plan, policy)` | Validates complete emitted query subset |
| `QueryExecutor` | `execute(artifact_handle, context)` | No caller-provided SQL; rechecks access |
| `ResponseAssembler` | `assemble(result, manifest)` | Numbers and scope derive from executed artifact |

Keep these interfaces callable without an LLM. That allows deterministic service tests and another UI or reporting consumer later.

### 13.3 Build increments

| Increment | Deliverable | Acceptance gate |
|---|---|---|
| 1. Catalog foundation | SQLite migrations, typed schemas, draft importer, four synthetic entities and mappings | DDL/import/reference tests; no operational query access needed |
| 2. Deterministic vertical slice | Hand-authored IR compiles the three question patterns | Golden fixture outputs; existence and LEFT-preservation counterexamples |
| 3. Azure adapter | Restricted connection, parameters, T-SQL validation, execution/result envelope | Target-engine fixture and access tests; timeout/cancellation behavior |
| 4. Agent interpreter | Search/resolve tools, examples, structured output, clarification | Paraphrase and scope-ambiguity evaluation suite |
| 5. Production catalog | Real status/category mappings, approved identity/grain and scope, source policies | Business review, data assertions, no unresolved production bindings |
| 6. Pilot and operations | Audit, drift checks, bounded export, metrics and rollback | Representative load, failure recovery and result-review process |

Build the deterministic vertical slice before spending effort on prompt optimization. It gives the interpreter a precise target and gives reviewers something executable to assess. It also makes discrepancies between example SQL and intended business meaning visible early.

### 13.4 Azure SQL performance plan

Start by inspecting existing keys and indexes; do not create speculative production indexes from a language-model proposal. For the sample EXISTS patterns, indexes beginning with Producer_Key and Product_Category on contract tables are candidates, with order chosen from actual selectivity and workload. License/appointment status and producer-key access patterns also deserve measurement. Included columns and write cost depend on table size and existing indexes.

Use estimated/actual plans through appropriate engineering workflows, measure representative distributions, and compare a cohort-based alternative only if needed. The execution service's logical contract remains the same even if a reviewed optimizer rewrite changes the emitted form. Do not add a UNIQUE constraint on Producer_Key in either contract table to manufacture many-to-one cardinality.

### 13.5 Ownership and day-to-day change workflow

Business owners approve labels, status meanings, category membership, metric definitions and sample-query interpretations. Data engineers own physical bindings, record grains, namespaces, history semantics and quality evidence. Application engineers own typed contracts, compiler correctness and execution controls. Security owners define access policy. One person can hold several roles in V1, but their responsibilities should remain explicit.

A business change starts in a draft catalog revision, produces a canonical diff and affected-example list, passes validation and review, then publishes atomically. Export JSON from SQLite for source review and backup; edits go through one authoring path. Avoid independent edits in both SQLite and exported files.

Canonical content hashes exclude the hash field itself and volatile publication/audit timestamps. Define canonical serialization and stable ordering once. Back up the database with a SQLite-consistent backup mechanism; copying a live database file without accounting for WAL is not the snapshot distribution protocol.

## 14. Decision records and maturity path

### ADR-01: SQLite is the V1 authoritative semantic store

**Decision:** use normalized metadata tables with validated JSON expression payloads. **Reason:** matches the user's requirement, supports relational integrity and local deployment, and represents relationships without extra infrastructure. **Tradeoff:** multi-host concurrent authoring eventually needs a service/database change. **Migration seam:** `CatalogRepository` and immutable release exports.

### ADR-02: The LLM authors semantic intent

**Decision:** model output is a typed query proposal; deterministic code emits executable SQL. **Reason:** join type, code binding, field authorization and row grain become testable contracts. **Tradeoff:** unsupported query shapes require new operators rather than free-form SQL. **Migration seam:** versioned IR and compiler registry.

### ADR-03: Relationship facts and operations are separate

**Decision:** represent both graph correspondence and its permitted uses. **Reason:** an existence check and preserving detail expansion have different effects over the same key relationship. **Tradeoff:** more explicit metadata than a single ON string. **Migration seam:** operation-specific contracts and typed derived templates.

### ADR-04: Existence is the default form for “has contracts”

**Decision:** use correlated EXISTS for count/detail qualification. **Reason:** expresses the question without multiplying base records. **Tradeoff:** performance must be measured on actual Azure SQL data; equivalent cohort rewrites may be useful. **Migration seam:** reviewed logical-to-physical plan rewrites, with result invariants unchanged.

### ADR-05: No graph database or vector database is required initially

**Decision:** derive an in-memory directed multigraph and use exact/lexical lookup first. **Reason:** four entities and small code domains do not justify those deployment components. **Tradeoff:** larger catalogs may need richer search/path infrastructure. **Migration seam:** search and path-planner interfaces.

### ADR-06: LangGraph is optional orchestration

**Decision:** start with an explicit bounded workflow; adopt LangGraph when checkpointed branching/pause-resume is valuable, or immediately if the team already has that operating experience. **Reason:** business contracts should be independent of workflow technology. **Tradeoff:** simple V1 must still persist clarification state and handle retries carefully. **Migration seam:** existing functions become graph nodes.

### ADR-07: Examples guide interpretation; reusable rules become catalog objects

**Decision:** retain reviewed examples and promote recurring semantics into predicates/metrics/bindings. **Reason:** keeps the user's desired example-driven understanding while preventing copied SQL from becoming a conflicting authority. **Tradeoff:** onboarding includes explicit semantic review. **Migration seam:** dependency-linked, versioned examples.

### 14.1 Growth stages

| Need that emerges | Add or replace | Preserve |
|---|---|---|
| More tables and vocabulary | Better lexical/vector retrieval, dependency ranking | Stable IDs, authorized context, resolver outcomes |
| Large/changing value domains | Authorized live value provider and indexed lookup | Canonical concept and binding-handle contract |
| Multiple app instances | Published snapshot distribution and shared request store | SQLite catalog semantics and immutable releases |
| Concurrent catalog editors | Catalog authoring API or server database repository | Object schema, publication validation, review process |
| Long-running interactive workflows | LangGraph adapter and persistent checkpointer | Node service interfaces, IR, compiler and execution gates |
| Historical questions | Temporal source adapters and interval contracts | Explicit grain, effective time and evidence requirements |
| Multiple fact metrics | Independent fact aggregation to conformed dimensions | Anti-fanout invariants and metric units |
| Another database engine | Dialect/execution adapter and target-engine suite | Semantic query and relationship purpose |
| New detail relationships | Additional approved operations and fixtures | Scoped filters and preservation/grain guarantees |

This architecture avoids committing business meaning to a prompt, an embedding index or a workflow library. It still expects ordinary schema migrations and new operator implementations as requirements broaden. “No fundamental redesign” is best achieved by stable boundaries and explicit semantics, not by building every advanced feature in V1.

## 15. References and verification scope

Primary input: the referenced conversation [Agent Skills For NL SQL](chatgpt-conversation://6aa76767-c0fc-83e9-aaad-e122211c98b8), its `semantic_catalogue.xlsx` attachment, the four source column lists and the user's clarifications in this task. The workbook's exact header locations and hash are recorded in the constitution. No source workbook was modified.

External documentation was checked during preparation. Links support technology behavior; the component boundaries, schemas and recommendations are design choices for this application:

- Agent Skills resource packaging: [official specification](https://agentskills.io/specification).
- Orchestration facilities and durable state: [LangGraph overview](https://docs.langchain.com/oss/python/langgraph/overview), [persistence](https://docs.langchain.com/oss/python/langgraph/persistence), [interrupts](https://docs.langchain.com/oss/python/langgraph/interrupts).
- Target engine and T-SQL relationship behavior: [Azure SQL Database](https://learn.microsoft.com/en-us/azure/azure-sql/database/sql-database-paas-overview?view=azuresql), [EXISTS](https://learn.microsoft.com/en-us/sql/t-sql/language-elements/exists-transact-sql?view=sql-server-ver17), [FROM/JOIN](https://learn.microsoft.com/en-us/sql/t-sql/queries/from-transact-sql?view=sql-server-ver17).
- Catalog integrity and concurrency: [SQLite foreign keys](https://www.sqlite.org/foreignkeys.html), [WAL](https://www.sqlite.org/wal.html).
- Query inspection and access enforcement: [SHOWPLAN_XML](https://learn.microsoft.com/en-us/sql/t-sql/statements/set-showplan-xml-transact-sql?view=sql-server-ver17), [row-level security](https://learn.microsoft.com/en-us/sql/relational-databases/security/row-level-security?view=sql-server-ver17), [SQLGlot AST facilities](https://sqlglot.com/sqlglot.html).

The design is ready to implement against the included synthetic assumptions. Production publication still requires real code mappings, actual physical types/keys, verified Producer_Key scope, access policy and the preferred detail-query interpretation. Those are catalog/onboarding tasks with explicit gates, rather than changes to the central architecture.
