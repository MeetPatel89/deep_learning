-- Configure the persistent SQLite authority before application transactions.
-- Run on each authority connection; journal_mode persists on the database,
-- while foreign_keys, synchronous and busy_timeout require connection setup.
-- Check the returned journal_mode is 'wal'; do not silently ignore setup errors.
-- Storage must provide correct local locking and durable writes on one host.
-- Snapshot builders and RAM readers have separate configuration.
PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;
PRAGMA synchronous = FULL;
PRAGMA busy_timeout = 5000;

-- 5000 ms is an initial bounded lock-wait budget, to be tuned from measurements.
-- CatalogService additionally serializes writes and applies revision checks.
-- This file does not configure backup scheduling, encryption, or access control.
