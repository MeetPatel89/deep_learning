---
doc_id: SVC-CAT-API-001
title: Internal API Gateway Service Catalog Entry
doc_type: service_catalog
service_id: svc_internal_api_gateway
owner_group: Platform Engineering
visibility: internal
status: active
created_at: "2026-05-01T09:00:00"
updated_at: "2026-06-19T10:00:00"
related_records:
  - KI-307
  - RUNBOOK-API-005
source_facts:
  - svc_internal_api_gateway
difficulty_tags:
  - ownership-routing
  - dependency-awareness
servicenow:
  table: cmdb_ci_service
  number: SVC0001003
  sys_class_name: cmdb_ci_service
  name: Internal API Gateway
  service_tier: 1
  operational_status: Operational
  business_criticality: "1 - most critical"
  owned_by_group: Platform Engineering
  support_group: Platform Engineering
  visibility: internal
  contains_customer_safe_wording: false
---

# Internal API Gateway Service Catalog Entry

## Record details

| Field | Value |
| --- | --- |
| Table | cmdb_ci_service |
| Number | SVC0001003 |
| Class name | cmdb_ci_service |
| Name | Internal API Gateway |
| Service tier | 1 |
| Operational status | Operational |
| Business criticality | 1 - most critical |
| Owned by group | Platform Engineering |
| Support group | Platform Engineering |
| Visibility | internal |
| Contains customer-safe wording | false |

## Service summary

Internal API Gateway routes internal API traffic and enforces rate limits. It is a Tier 1 platform service because API routing and throttling behavior can affect multiple internal systems and client integrations.

The gateway is the ownership point for issues where clients receive unexpected 429 Too Many Requests responses, where traffic policy behavior changes after a release, or where the applied rate-limit policy does not match the client entitlement.

## Business purpose

The service gives Nautilus Financial Systems a standard internal API routing layer with rate-limit enforcement. This keeps client traffic within expected limits and protects platform stability during bursts. It also creates a single escalation path for rate-limit policy questions that would otherwise be split across application teams.

Support requests may use different wording for the same pattern: client throttled, burst rejected, unexpected 429, Business-tier client blocked, or API traffic policy applied incorrectly. Those should be reviewed against this service before being routed elsewhere.

## Owning team

Platform Engineering owns Internal API Gateway. Service Desk L1 performs initial intake and collects client ID, affected endpoint, timestamp, and customer tier when a user reports 429 errors. Rate-limit policy mismatches should be escalated to Platform Engineering.

Platform Engineering owns policy validation, gateway configuration review, and corrective adjustment when the applied policy does not match entitlement.

## Key dependencies

Dependencies include Kong, Vault, and Splunk.

| Dependency | Support relevance |
| --- | --- |
| Kong | Gateway runtime where rate-limit policies are applied. |
| Vault | Dependency for gateway-managed secret retrieval and runtime configuration access. |
| Splunk | Operational logging source used to inspect 429 volume and affected clients. |

## Supported users and systems

The service supports internal API clients and teams consuming internal APIs through the gateway. Business-tier and Enterprise-tier clients may have different traffic entitlements, so support must collect the customer tier before concluding that 429 responses are expected.

For triage, do not assume every 429 is an incident. Some 429 responses are valid when a client exceeds entitlement. The incident path begins when the reported rate limit appears inconsistent with the known customer tier or begins immediately after a policy release.

## Common incident patterns

Common patterns include:

- API clients receive 429 Too Many Requests.
- Business-tier clients are affected more often than Enterprise clients.
- Errors start after a rate-limit policy deployment.
- 429 volume increases in Splunk for specific client groups.
- Applied rate-limit policy appears stricter than entitlement.

Known issue KI-307 covers unexpected 429 responses after rate-limit policy update. RUNBOOK-API-005 contains the current investigation path.

## Initial triage guidance

Service Desk L1 should capture:

- Client ID.
- Affected endpoint.
- Approximate timestamp.
- Customer tier.
- Whether the client recently changed traffic volume.
- Whether the symptoms started after CHG-2420 or another API Gateway policy change.

If the client is Business-tier and symptoms began after the rate-limit policy deployment, link the ticket to KI-307 for review.

## Escalation guidance

Escalate to Platform Engineering when:

- The applied rate-limit policy does not match entitlement.
- 429 errors affect multiple clients.
- Business-tier clients are seeing unexpected burst rejection after a policy release.
- Splunk shows elevated 429 volume for a client group.
- The customer-safe response needs confirmation before external use.

For customer-safe wording, use the KI-307 summary: We are reviewing the applied API traffic policy for the affected client.

## Related records

- KI-307: API clients receive unexpected 429 responses after rate-limit policy update.
- RUNBOOK-API-005: API Gateway 429 Investigation Runbook.

