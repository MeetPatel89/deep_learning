"""Synapse Git repositories. No Azure discovery, checkout switching or live fallback."""

import base64
import copy
import difflib
import hashlib
import json
import os
import re
import subprocess
import tempfile
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from urllib.parse import quote

import httpx
from data_mcp_core.guards import require
from data_mcp_core.results import redact

from synapse_mcp_server.config import WorkspaceConfig
from synapse_mcp_server.locking import file_lock

LAYOUT = {
    "pipeline": "pipeline",
    "dataset": "dataset",
    "linked_service": "linkedService",
    "notebook": "notebook",
    "data_flow": "dataflow",
    "spark_job_definition": "sparkJobDefinition",
    "sql_script": "sqlscript",
    "trigger": "trigger",
    "integration_runtime": "integrationRuntime",
    "credential": "credential",
}
MAX_BYTES = 50 * 1024 * 1024


class RevisionConflict(ValueError):
    """The repository changed since the caller inspected it."""


def branch_name(value: str) -> str:
    if (
        not value
        or value.startswith(("-", "/", "refs/"))
        or value.endswith(("/", "."))
        or any(c in value for c in ("..", "@{", "//", "\\"))
        or re.search(r"[\x00-\x20\x7f~^:?*\[]", value)
        or any(p.startswith(".") or p.endswith(".lock") for p in value.split("/"))
        or value in {"HEAD", "@"}
    ):
        raise ValueError("Use a literal branch name, not a Git revision expression")
    return value


def artifact_path(kind: str, name: str, root: str = "") -> str:
    if kind not in LAYOUT:
        raise ValueError(f"Artifact type {kind!r} is unsupported by the Git backend")
    if (
        not name
        or name in {".", ".."}
        or name.startswith(".")
        or re.search(r"[\x00-\x1f/\\:%]", name)
    ):
        raise ValueError("Artifact names must be plain filenames without path separators")
    return str(PurePosixPath(root, LAYOUT[kind], name + ".json"))


def artifact_key(path: str, root: str = "") -> tuple[str, str] | None:
    parts = PurePosixPath(path).parts
    prefix = PurePosixPath(root).parts
    if parts[: len(prefix)] != prefix:
        return None
    parts = parts[len(prefix) :]
    if len(parts) != 2 or not parts[1].endswith(".json"):
        return None
    kind = next((k for k, v in LAYOUT.items() if v == parts[0]), None)
    if kind is None:
        return None
    name = parts[1][:-5]
    if artifact_path(kind, name, root) != path:
        raise ValueError("Noncanonical artifact path")
    return kind, name


def fingerprint(files: dict[str, bytes]) -> str:
    digest = hashlib.sha256()
    for path, body in sorted(files.items()):
        digest.update(path.encode() + b"\0" + hashlib.sha256(body).digest())
    return digest.hexdigest()


def encode_artifact(value: dict) -> bytes:
    if not isinstance(value, dict) or not isinstance(value.get("properties"), dict):
        raise ValueError("Synapse artifact JSON requires a properties object")
    return (json.dumps(value, ensure_ascii=False, indent=4, allow_nan=False) + "\n").encode()


def safe_lines(data: bytes | None) -> list[str]:
    return (
        json.dumps(redact(json.loads(data)), indent=2, sort_keys=True).splitlines() if data else []
    )


@dataclass(frozen=True)
class Snapshot:
    branch: str
    commit: str
    backend: str
    root: str
    files: dict[str, bytes]
    dirty: bool = False

    @property
    def fingerprint(self):
        return fingerprint(self.files)

    def metadata(self):
        return {
            "branch": self.branch,
            "commit": self.commit,
            "repository_backend": self.backend,
            "content_fingerprint": self.fingerprint,
            "uncommitted": self.dirty,
        }

    def get(self, kind: str, name: str) -> dict:
        path = artifact_path(kind, name, self.root)
        if path not in self.files:
            raise FileNotFoundError(f"Git artifact not found: {kind}/{name}; no live fallback")
        value = json.loads(self.files[path])
        if not isinstance(value, dict) or not isinstance(value.get("properties"), dict):
            raise ValueError(f"Invalid Synapse artifact JSON: {path}")
        if "name" in value and value["name"] != name:
            raise ValueError(f"Artifact name does not match its file: {path}")
        return copy.deepcopy(value)

    def list(self, kind: str) -> list[dict]:
        artifact_path(kind, "validate", self.root)
        return [
            self.get(kind, key[1])
            for path in sorted(self.files)
            if (key := artifact_key(path, self.root)) and key[0] == kind
        ]


class Repository:
    backend: str

    def __init__(self, settings: WorkspaceConfig):
        self.settings = settings
        self.config = settings.repository
        if self.config is None:
            raise ValueError("Repository configuration is required")

    def writable(self, branch):
        require(self.settings, "allow_git_write")
        branch_name(branch)
        if branch in {
            self.config.collaboration_branch,
            self.config.publish_branch,
            "workspace_publish",
        }:
            raise PermissionError(f"Protected collaboration/publish branch: {branch}")

    def check_revision(self, branch, expected):
        if not expected or self.resolve(branch) != expected:
            raise RevisionConflict("Branch revision changed; inspect the branch and retry")

    def changes(self, values):
        result = {}
        for path, value in values.items():
            if not artifact_key(path, self.config.artifact_root):
                raise ValueError("Only configured Synapse artifact JSON paths can be committed")
            if value is not None:
                key = artifact_key(path, self.config.artifact_root)
                if value.get("name", key[1]) != key[1]:
                    raise ValueError("Artifact name must match its file")
            result[path] = None if value is None else encode_artifact(value)
        return result

    def diff(self, branch, base=None):
        before = self.snapshot(base or self.config.collaboration_branch, include_working=False)
        after = self.snapshot(branch)
        changes = []
        for path in sorted(before.files.keys() | after.files.keys()):
            if before.files.get(path) == after.files.get(path):
                continue
            changes.append(
                {
                    "path": path,
                    "diff": "\n".join(
                        difflib.unified_diff(
                            safe_lines(before.files.get(path)),
                            safe_lines(after.files.get(path)),
                            fromfile="base/" + path,
                            tofile="branch/" + path,
                        )
                    ),
                }
            )
        return {"base_commit": before.commit, **after.metadata(), "changes": changes}

    def close(self):
        pass


class LocalRepository(Repository):
    backend = "local"

    def __init__(self, settings):
        super().__init__(settings)
        if not self.config.local_path:
            raise ValueError("Configure repository.local_path")
        self.path = Path(self.config.local_path).expanduser().resolve()
        top = Path(self.git("rev-parse", "--show-toplevel").strip()).resolve()
        if top != self.path:
            raise ValueError("local_path must be the Git checkout root; use artifact_root below it")
        self.common = Path(
            self.git("rev-parse", "--path-format=absolute", "--git-common-dir").strip()
        )

    def git(self, *args, cwd=None, data=None, env=None, check=True, binary=False):
        process = subprocess.run(
            ["git", "-c", "core.hooksPath=" + os.devnull, *args],
            cwd=cwd or self.path,
            input=data,
            capture_output=True,
            timeout=60,
            env={**os.environ, "GIT_TERMINAL_PROMPT": "0", **(env or {})},
        )
        if check and process.returncode:
            raise ValueError("Git operation failed: " + process.stderr.decode(errors="replace"))
        return process.stdout if binary else process.stdout.decode().strip()

    @contextmanager
    def lock(self):
        with file_lock(self.common / "synapse-mcp.lock"):
            yield

    @contextmanager
    def _lock_checkout(self, checkout, branch, expected):
        index = Path(
            self.git("rev-parse", "--path-format=absolute", "--git-path", "index", cwd=checkout)
        )
        path = Path(str(index) + ".lock")
        descriptor = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        os.close(descriptor)
        try:
            self.check_revision(branch, expected)
            if self.git("symbolic-ref", "--short", "HEAD", cwd=checkout) != branch:
                raise RevisionConflict("Checkout branch changed; artifact edit refused")
            yield
        finally:
            path.unlink(missing_ok=True)

    def remote_branches(self):
        return [
            {"name": line.split()[1].removeprefix("refs/heads/"), "revision": line.split()[0]}
            for line in self.git("ls-remote", "--heads", self.config.remote).splitlines()
        ]

    def resolve(self, branch):
        return self.git("rev-parse", "--verify", "refs/heads/" + branch_name(branch))

    def branches(self):
        return [
            {"name": line.split("\t")[0], "revision": line.split("\t")[1]}
            for line in self.git(
                "for-each-ref", "--format=%(refname:short)\t%(objectname)", "refs/heads/"
            ).splitlines()
        ]

    def create_branch(self, branch, base, expected):
        self.writable(branch)
        with self.lock():
            self.check_revision(base, expected)
            self.git("update-ref", "refs/heads/" + branch, expected, "0" * len(expected))
        return {"branch": branch, "revision": expected}

    def _checkout(self, branch, create=False):
        branch_name(branch)
        if self.git("symbolic-ref", "--quiet", "--short", "HEAD", check=False) == branch:
            return self.path
        path = self.common / "synapse-mcp-worktrees" / hashlib.sha256(branch.encode()).hexdigest()
        if path.is_dir():
            if self.git("symbolic-ref", "--short", "HEAD", cwd=path) != branch:
                raise RevisionConflict("Managed worktree branch changed")
            return path
        if not create:
            return None
        path.parent.mkdir(parents=True, exist_ok=True)
        self.git("worktree", "add", str(path), branch)
        return path

    def _contained(self, checkout, path):
        candidate = checkout / path
        if not candidate.resolve().is_relative_to(checkout.resolve()):
            raise PermissionError("Artifact path escapes the checkout")
        for parent in (candidate, *candidate.parents):
            if parent == checkout:
                break
            if parent.is_symlink():
                raise PermissionError("Symlink artifacts and directories are unsupported")
        return candidate

    def _working_files(self, checkout):
        names = self.git(
            "ls-files",
            "--cached",
            "--others",
            "--exclude-standard",
            "-z",
            cwd=checkout,
            binary=True,
        ).split(b"\0")
        result = {}
        size = 0
        for raw in sorted(set(names)):
            if not raw:
                continue
            path = raw.decode()
            if not artifact_key(path, self.config.artifact_root):
                continue
            file = self._contained(checkout, path)
            if file.is_file():
                size += file.stat().st_size
                if size > MAX_BYTES:
                    raise ValueError("Repository snapshot exceeds 50 MiB")
                result[path] = file.read_bytes()
        return result

    def _committed_files(self, revision):
        result, size = {}, 0
        for entry in self.git("ls-tree", "-rz", revision, binary=True).split(b"\0"):
            if not entry:
                continue
            header, path = entry.split(b"\t", 1)
            path = path.decode()
            if not artifact_key(path, self.config.artifact_root):
                continue
            mode, kind, sha = header.decode().split()
            if kind != "blob" or mode not in {"100644", "100755"}:
                raise PermissionError("Symlink and submodule artifacts are unsupported")
            size += int(self.git("cat-file", "-s", sha))
            if size > MAX_BYTES:
                raise ValueError("Repository snapshot exceeds 50 MiB")
            result[path] = self.git("cat-file", "blob", sha, binary=True)
        return result

    def snapshot(self, branch, include_working=True):
        with self.lock():
            revision = self.resolve(branch)
            committed = self._committed_files(revision)
            checkout = self._checkout(branch) if include_working else None
            files = self._working_files(checkout) if checkout else committed
            if checkout and files != self._working_files(checkout):
                raise RevisionConflict("Artifact files changed while capturing the snapshot")
            self.check_revision(branch, revision)
            return Snapshot(
                branch, revision, self.backend, self.config.artifact_root, files, files != committed
            )

    def edit(self, branch, kind, name, value, expected):
        self.writable(branch)
        path = artifact_path(kind, name, self.config.artifact_root)
        data = self.changes({path: value})[path]
        with self.lock():
            self.check_revision(branch, expected)
            checkout = self._checkout(branch, create=True)
            with self._lock_checkout(checkout, branch, expected):
                destination = self._contained(checkout, path)
                if data is None:
                    destination.unlink()
                else:
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    with tempfile.NamedTemporaryFile(
                        dir=destination.parent, delete=False
                    ) as handle:
                        temp = Path(handle.name)
                        handle.write(data)
                    try:
                        self.check_revision(branch, expected)
                        os.replace(temp, destination)
                    finally:
                        temp.unlink(missing_ok=True)
        return {"branch": branch, "revision": expected, "path": path, "uncommitted": True}

    def commit(self, branch, expected, message, changes=None, paths=None):
        self.writable(branch)
        if not message.strip():
            raise ValueError("A commit message is required")
        if changes:
            raise ValueError("Local commits use current artifact files; edit artifacts first")
        with self.lock():
            self.check_revision(branch, expected)
            checkout = self._checkout(branch, create=True)
            before = self._committed_files(expected)
            files = self._working_files(checkout)
            changed = {p for p in before.keys() | files.keys() if before.get(p) != files.get(p)}
            if paths is not None:
                if not paths or any(not artifact_key(p, self.config.artifact_root) for p in paths):
                    raise ValueError("Commit paths must be configured Synapse artifact JSON paths")
                changed &= set(paths)
            if not changed:
                raise ValueError("No uncommitted artifact changes")
            # A private index excludes all unrelated staged changes. Lock the real index
            # while updating only committed paths, preserving its other entries.
            index = Path(
                self.git("rev-parse", "--path-format=absolute", "--git-path", "index", cwd=checkout)
            )
            lockfile = Path(str(index) + ".lock")
            fd = os.open(lockfile, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            os.close(fd)
            try:
                if self.git("symbolic-ref", "--short", "HEAD", cwd=checkout) != branch:
                    raise RevisionConflict("Checkout branch changed; commit refused")
                with tempfile.TemporaryDirectory(prefix="synapse-index-") as directory:
                    private = str(Path(directory) / "commit-index")
                    updated = str(Path(directory) / "updated-index")
                    env = {"GIT_INDEX_FILE": private}
                    self.git("read-tree", expected, cwd=checkout, env=env)
                    updates = []
                    for path in sorted(changed):
                        if path in files:
                            sha = self.git("hash-object", "-w", "--stdin", data=files[path])
                            updates.append(f"100644 {sha}\t{path}\0")
                        else:
                            updates.append(f"0 {'0' * len(expected)}\t{path}\0")
                    payload = "".join(updates).encode()
                    self.git(
                        "update-index", "-z", "--index-info", data=payload, env=env, cwd=checkout
                    )
                    tree = self.git("write-tree", env=env, cwd=checkout)
                    new = self.git(
                        "commit-tree", tree, "-p", expected, data=message.encode(), cwd=checkout
                    )
                    if index.exists():
                        Path(updated).write_bytes(index.read_bytes())
                    else:
                        self.git(
                            "read-tree", expected, env={"GIT_INDEX_FILE": updated}, cwd=checkout
                        )
                    self.git(
                        "update-index",
                        "-z",
                        "--index-info",
                        data=payload,
                        env={"GIT_INDEX_FILE": updated},
                        cwd=checkout,
                    )
                    if self._working_files(checkout) != files:
                        raise RevisionConflict("Artifact contents changed during commit")
                    lockfile.write_bytes(Path(updated).read_bytes())
                    self.git("update-ref", "refs/heads/" + branch, new, expected)
                    os.replace(lockfile, index)
            finally:
                lockfile.unlink(missing_ok=True)
        return {"branch": branch, "revision": new, "paths": sorted(changed)}

    def push(self, branch, expected, expected_remote):
        self.writable(branch)
        with self.lock():
            self.check_revision(branch, expected)
            ref = "refs/heads/" + branch
            remote = self.config.remote
            line = self.git("ls-remote", "--heads", remote, ref)
            current = line.split()[0] if line else ""
            if current != expected_remote:
                raise RevisionConflict("Remote branch changed; inspect and retry")
            if expected_remote:
                self.git("merge-base", "--is-ancestor", expected_remote, expected)
            # Lease provides compare-and-swap; the ancestry check forbids overwrites.
            self.git(
                "push",
                "--porcelain",
                f"--force-with-lease={ref}:{expected_remote}",
                remote,
                f"{expected}:{ref}",
            )
        return {"branch": branch, "revision": expected, "pushed": True}


class GitHubRepository(Repository):
    backend = "github"

    def __init__(self, settings, client=None):
        super().__init__(settings)
        if not self.config.github_repository or not self.config.github_token:
            raise ValueError("Configure github_repository and github_token for authenticated APIs")
        self.client = client or httpx.Client(
            base_url="https://api.github.com",
            timeout=30,
            follow_redirects=False,
            headers={
                "Authorization": "Bearer " + self.config.github_token.get_secret_value(),
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
            },
        )
        self.prefix = "/repos/" + self.config.github_repository

    def request(self, method, path, **kwargs):
        response = self.client.request(method, self.prefix + path, **kwargs)
        if response.status_code in {409, 422}:
            raise RevisionConflict("GitHub rejected a concurrent or invalid branch update")
        response.raise_for_status()
        return response.json()

    def resolve(self, branch):
        return self.request("GET", "/git/ref/heads/" + quote(branch_name(branch), safe=""))[
            "object"
        ]["sha"]

    def branches(self):
        result = []
        for page in range(1, 101):
            values = self.request("GET", "/branches", params={"per_page": 100, "page": page})
            result.extend({"name": v["name"], "revision": v["commit"]["sha"]} for v in values)
            if len(values) < 100:
                return result
        raise ValueError("Branch listing exceeded pagination limit")

    def create_branch(self, branch, base, expected):
        self.writable(branch)
        self.check_revision(base, expected)
        self.request("POST", "/git/refs", json={"ref": "refs/heads/" + branch, "sha": expected})
        return {"branch": branch, "revision": expected}

    def snapshot(self, branch, include_working=True):
        revision = self.resolve(branch)
        tree = self.request("GET", "/git/trees/" + revision, params={"recursive": "1"})
        if tree.get("truncated"):
            raise ValueError("GitHub returned a truncated tree; snapshot would be incomplete")
        files, size = {}, 0
        for entry in tree["tree"]:
            path = entry["path"]
            if not artifact_key(path, self.config.artifact_root):
                continue
            if entry["type"] != "blob" or entry["mode"] not in {"100644", "100755"}:
                raise PermissionError("Symlink and submodule artifacts are unsupported")
            size += entry.get("size", 0)
            if size > MAX_BYTES:
                raise ValueError("Repository snapshot exceeds 50 MiB")
            blob = self.request("GET", "/git/blobs/" + entry["sha"])
            if blob.get("encoding") != "base64":
                raise ValueError("Unsupported GitHub blob encoding")
            files[path] = base64.b64decode(blob["content"])
            if sum(map(len, files.values())) > MAX_BYTES:
                raise ValueError("Repository snapshot exceeds 50 MiB")
        return Snapshot(branch, revision, self.backend, self.config.artifact_root, files)

    def commit(self, branch, expected, message, changes=None, paths=None):
        self.writable(branch)
        if not changes or not message.strip():
            raise ValueError("GitHub commits require artifact changes and a message")
        if paths is not None and set(paths) != set(changes):
            raise ValueError("GitHub commit paths must match the changes map")
        files = self.changes(changes)
        self.check_revision(branch, expected)
        # REST ref updates lack an expected-head field. This GraphQL mutation supplies
        # a server-side compare-and-swap, including when another actor resets the ref.
        query = """mutation($input: CreateCommitOnBranchInput!) {
          createCommitOnBranch(input: $input) { commit { oid url } }
        }"""
        response = self.client.post(
            "/graphql",
            json={
                "query": query,
                "variables": {
                    "input": {
                        "branch": {
                            "repositoryNameWithOwner": self.config.github_repository,
                            "branchName": branch,
                        },
                        "expectedHeadOid": expected,
                        "message": {"headline": message},
                        "fileChanges": {
                            "additions": [
                                {"path": p, "contents": base64.b64encode(v).decode()}
                                for p, v in files.items()
                                if v is not None
                            ],
                            "deletions": [{"path": p} for p, v in files.items() if v is None],
                        },
                    }
                },
            },
        )
        response.raise_for_status()
        data = response.json()
        if data.get("errors"):
            raise RevisionConflict("GitHub commit rejected; refresh expected_revision and retry")
        commit = data["data"]["createCommitOnBranch"]["commit"]
        return {
            "branch": branch,
            "revision": commit["oid"],
            "url": commit["url"],
            "paths": sorted(files),
        }

    def edit(self, branch, kind, name, value, expected):
        return self.commit(
            branch,
            expected,
            f"Update {kind}/{name}",
            {artifact_path(kind, name, self.config.artifact_root): value},
        )

    def push(self, branch, expected, expected_remote):
        self.writable(branch)
        self.check_revision(branch, expected)
        if expected_remote != expected:
            raise RevisionConflict("GitHub edits already commit remotely; refresh the revision")
        return {"branch": branch, "revision": expected, "already_remote": True}

    def create_pr(self, branch, expected, title, body):
        self.writable(branch)
        self.check_revision(branch, expected)
        return self.request(
            "POST",
            "/pulls",
            json={
                "title": title,
                "body": body,
                "head": branch,
                "base": self.config.collaboration_branch,
                "draft": True,
            },
        )

    def close(self):
        self.client.close()
