from synapse_mcp_server.server import main

main()
