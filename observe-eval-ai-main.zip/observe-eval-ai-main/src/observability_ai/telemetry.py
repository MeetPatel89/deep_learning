"""An application-owned tracing facade using standard OpenTelemetry context."""

from collections.abc import (
    AsyncGenerator,
    AsyncIterable,
    Awaitable,
    Callable,
    Generator,
    Iterable,
    Iterator,
)
from contextlib import AbstractContextManager, contextmanager
from functools import wraps
from inspect import isasyncgenfunction, iscoroutinefunction, isgeneratorfunction
from time import time_ns
from types import TracebackType
from typing import Self, cast, get_args, overload

from opentelemetry.sdk.trace import SpanProcessor
from opentelemetry.trace import Tracer, set_tracer_provider, use_span

from ._context import _merged_attributes, _propagate
from ._stream import _async_stream, _stream
from .attributes import ObservationType, TraceAttributes
from .config import LangfuseSettings, _validate_text
from .content import ContentCapturePolicy
from .export import build_tracer_provider
from .genai import model_attributes, tool_attributes
from .observation import Generation, Observation

_OBSERVATION_TYPES = frozenset(get_args(ObservationType.__value__))


class Telemetry:
    """Own a Langfuse tracer provider and its export lifecycle.

    Use one instance per application and close it after all work has finished.
    ``set_global=True`` opts into OpenTelemetry's one-time global registration.
    Injecting ``span_processor`` replaces network export and transfers lifecycle
    ownership of that processor to this instance.
    """

    def __init__(
        self,
        settings: LangfuseSettings,
        *,
        service_name: str,
        service_version: str,
        span_processor: SpanProcessor | None = None,
        set_global: bool = False,
        content_capture: ContentCapturePolicy | None = None,
    ) -> None:
        """Build a local provider, optionally registering it process-wide."""
        if content_capture is not None and not isinstance(
            content_capture, ContentCapturePolicy
        ):
            raise TypeError("content_capture must be a ContentCapturePolicy or None")
        self._content_capture = (
            ContentCapturePolicy() if content_capture is None else content_capture
        )
        self._provider = build_tracer_provider(
            settings,
            service_name=service_name,
            service_version=service_version,
            span_processor=span_processor,
        )
        if set_global:
            set_tracer_provider(self._provider)

    @property
    def content_capture(self) -> ContentCapturePolicy:
        """The frozen policy used for this facade's explicit payloads."""
        return self._content_capture

    def tracer(self, name: str) -> Tracer:
        """Return a standard OTel tracer for the supplied instrumentation name."""
        return self._provider.get_tracer(name)

    def propagate(self, attributes: TraceAttributes) -> AbstractContextManager[None]:
        """Merge task-local trace dimensions for observations created in this scope.

        Nested scopes restore previous values on exit, including after errors.
        Nonempty explicit fields override inherited fields; metadata merges by
        key. Empty collections and None mean unspecified, not removal.
        Raw tracers and third-party adapters do not consume these dimensions.
        """
        return _propagate(attributes)

    def _start_observation(
        self,
        name: str,
        *,
        type: ObservationType,
        attributes: TraceAttributes | None,
        input: object,
        output: object,
        start_time: int | None = None,
    ) -> Observation:
        if type not in _OBSERVATION_TYPES:
            raise ValueError("type must be a supported Langfuse observation type")
        otel_attributes = _merged_attributes(attributes).as_otel_attributes()
        otel_attributes["langfuse.observation.type"] = type
        span = self.tracer("observability_ai").start_span(
            name, attributes=otel_attributes, start_time=start_time
        )
        handle_type = Generation if type == "generation" else Observation
        observation = handle_type(span, self._content_capture)
        try:
            observation.set_input(input)
            observation.set_output(output)
        except BaseException:
            span.end()
            raise
        return observation

    @contextmanager
    def observe(
        self,
        name: str,
        *,
        type: ObservationType = "span",
        attributes: TraceAttributes | None = None,
        input: object = None,
        output: object = None,
    ) -> Iterator[Observation]:
        """Start a current observation and yield a handle with raw access via .span.

        Nesting and asyncio task propagation follow OTel context. Trace
        dimensions merge propagated attributes with explicit values winning.
        Application exceptions are recorded and re-raised.
        Use a regular ``with`` block in both synchronous and asynchronous code.
        Input/output are snapshotted at entry only for recording spans when the
        content policy enables capture; ``None`` omits the corresponding value.
        """
        observation = self._start_observation(
            name, type=type, attributes=attributes, input=input, output=output
        )
        with use_span(observation.span, end_on_exit=True):
            yield observation

    def agent(
        self,
        name: str,
        *,
        attributes: TraceAttributes | None = None,
        input: object = None,
        output: object = None,
    ) -> AbstractContextManager[Observation]:
        """Observe an agent using the same context and capture policy as observe."""
        return self.observe(
            name, type="agent", attributes=attributes, input=input, output=output
        )

    @contextmanager
    def tool(
        self,
        name: str,
        *,
        attributes: TraceAttributes | None = None,
        input: object = None,
        output: object = None,
        call_id: str | None = None,
        description: str | None = None,
    ) -> Iterator[Observation]:
        """Observe a tool using the same context and capture policy as observe."""
        tool = tool_attributes(name=name, call_id=call_id, description=description)
        with self.observe(
            name, type="tool", attributes=attributes, input=input, output=output
        ) as observation:
            observation.set_attributes(tool)
            yield observation

    def chain(
        self,
        name: str,
        *,
        attributes: TraceAttributes | None = None,
        input: object = None,
        output: object = None,
    ) -> AbstractContextManager[Observation]:
        """Observe a chain using the same context and capture policy as observe."""
        return self.observe(
            name, type="chain", attributes=attributes, input=input, output=output
        )

    @contextmanager
    def generation(
        self,
        name: str,
        *,
        model: str,
        provider_name: str,
        operation_name: str = "chat",
        attributes: TraceAttributes | None = None,
        input: object = None,
        output: object = None,
    ) -> Iterator[Generation]:
        """Observe a model call and expose generation-specific updates."""
        model_identity = model_attributes(
            provider_name=provider_name,
            request_model=model,
            operation_name=operation_name,
        )
        with self.observe(
            name, type="generation", attributes=attributes, input=input, output=output
        ) as observation:
            observation.set_attributes(model_identity)
            yield cast(Generation, observation)

    def retriever(
        self,
        name: str,
        *,
        attributes: TraceAttributes | None = None,
        input: object = None,
        output: object = None,
    ) -> AbstractContextManager[Observation]:
        """Observe retrieval using the facade's context and capture policy."""
        return self.observe(
            name, type="retriever", attributes=attributes, input=input, output=output
        )

    def embedding(
        self,
        name: str,
        *,
        attributes: TraceAttributes | None = None,
        input: object = None,
        output: object = None,
    ) -> AbstractContextManager[Observation]:
        """Observe embedding using the facade's context and capture policy."""
        return self.observe(
            name, type="embedding", attributes=attributes, input=input, output=output
        )

    def guardrail(
        self,
        name: str,
        *,
        attributes: TraceAttributes | None = None,
        input: object = None,
        output: object = None,
    ) -> AbstractContextManager[Observation]:
        """Observe a guardrail using the facade's context and capture policy."""
        return self.observe(
            name, type="guardrail", attributes=attributes, input=input, output=output
        )

    def evaluator(
        self,
        name: str,
        *,
        attributes: TraceAttributes | None = None,
        input: object = None,
        output: object = None,
    ) -> AbstractContextManager[Observation]:
        """Observe evaluation using the facade's context and capture policy."""
        return self.observe(
            name, type="evaluator", attributes=attributes, input=input, output=output
        )

    def event(
        self,
        name: str,
        *,
        attributes: TraceAttributes | None = None,
        input: object = None,
        output: object = None,
    ) -> Observation:
        """Record a zero-duration event and return its already-ended handle."""
        timestamp = time_ns()
        observation = self._start_observation(
            name,
            type="event",
            attributes=attributes,
            input=input,
            output=output,
            start_time=timestamp,
        )
        observation.span.end(end_time=timestamp)
        return observation

    @overload
    def stream[T, S](
        self,
        name: str,
        source: AsyncGenerator[T, S],
        *,
        type: ObservationType = "generation",
        attributes: TraceAttributes | None = None,
        input: object = None,
        output: object = None,
    ) -> AsyncGenerator[T, S]: ...

    @overload
    def stream[T](
        self,
        name: str,
        source: AsyncIterable[T],
        *,
        type: ObservationType = "generation",
        attributes: TraceAttributes | None = None,
        input: object = None,
        output: object = None,
    ) -> AsyncGenerator[T, None]: ...

    @overload
    def stream[T, S, R](
        self,
        name: str,
        source: Generator[T, S, R],
        *,
        type: ObservationType = "generation",
        attributes: TraceAttributes | None = None,
        input: object = None,
        output: object = None,
    ) -> Generator[T, S, R]: ...

    @overload
    def stream[T](
        self,
        name: str,
        source: Iterable[T],
        *,
        type: ObservationType = "generation",
        attributes: TraceAttributes | None = None,
        input: object = None,
        output: object = None,
    ) -> Generator[T, None, object]: ...

    def stream[T, S, R](
        self,
        name: str,
        source: Iterable[T] | AsyncIterable[T],
        *,
        type: ObservationType = "generation",
        attributes: TraceAttributes | None = None,
        input: object = None,
        output: object = None,
    ) -> Generator[T, S, R] | AsyncGenerator[T, S]:
        """Trace producer execution from first iteration until exhaustion or close.

        Yields are unchanged and never captured. Producer context is restored
        between steps without leaking into the consumer. First-item UTC time and
        stream_item_count metadata are recorded, including partial streams.
        Close partially consumed streams using closing/aclosing or close/aclose.
        """
        if type not in _OBSERVATION_TYPES:
            raise ValueError("type must be a supported Langfuse observation type")

        def start() -> Observation:
            return self._start_observation(
                name, type=type, attributes=attributes, input=input, output=output
            )

        if isinstance(source, AsyncIterable):
            return _async_stream(source, start)
        return _stream(source, start)

    def traced[**P, R](
        self, name: str | None = None, *, type: ObservationType = "span"
    ) -> Callable[[Callable[P, R]], Callable[P, R]]:
        """Decorate a sync or async callable with one observation per invocation.

        The default name is the callable's qualified name, or its class name
        for a callable instance. Signatures, metadata, results, and exceptions
        are preserved. Arguments and results are never captured automatically.
        Generator and async-generator lifetimes are covered during iteration.
        """
        if name is not None:
            _validate_text("name", name)
        if type not in _OBSERVATION_TYPES:
            raise ValueError("type must be a supported Langfuse observation type")

        def decorate(function: Callable[P, R]) -> Callable[P, R]:
            call = getattr(function, "__call__", None)
            observation_name = (
                name
                if name is not None
                else getattr(function, "__qualname__", function.__class__.__qualname__)
            )
            if any(
                isgeneratorfunction(target) or isasyncgenfunction(target)
                for target in (function, call)
            ):
                generator_function = cast(
                    Callable[P, Iterable[object] | AsyncIterable[object]], function
                )

                @wraps(function)
                def stream_wrapped(*args: P.args, **kwargs: P.kwargs) -> object:
                    return self.stream(
                        observation_name, generator_function(*args, **kwargs), type=type
                    )

                return cast(Callable[P, R], stream_wrapped)
            if iscoroutinefunction(function) or iscoroutinefunction(call):
                async_function = cast(Callable[P, Awaitable[object]], function)

                @wraps(function)
                async def async_wrapped(*args: P.args, **kwargs: P.kwargs) -> object:
                    with self.observe(observation_name, type=type):
                        return await async_function(*args, **kwargs)

                # Preserve the original callable's coroutine return annotation.
                return cast(Callable[P, R], async_wrapped)

            @wraps(function)
            def wrapped(*args: P.args, **kwargs: P.kwargs) -> R:
                with self.observe(observation_name, type=type):
                    return function(*args, **kwargs)

            return wrapped

        return decorate

    def force_flush(self, timeout_millis: int = 30_000) -> bool:
        """Wait for queued spans; return False on failure or after shutdown."""
        return self._provider.force_flush(timeout_millis)

    def shutdown(self) -> None:
        """Drain queued spans and close the processor once, logging failures."""
        self._provider.shutdown()

    def __enter__(self) -> Self:
        """Return this instance for application-scoped lifecycle management."""
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_value: BaseException | None,
        traceback: TracebackType | None,
    ) -> None:
        """Close the provider without suppressing application exceptions."""
        self.shutdown()
