"""Azure Synapse MCP server."""
