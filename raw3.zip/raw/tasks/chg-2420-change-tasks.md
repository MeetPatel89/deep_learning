---
doc_id: TASK-CHG-2420
title: CHG-2420 Change Tasks
doc_type: change_task
service_id: svc_internal_api_gateway
owner_group: Platform Engineering
visibility: internal
status: closed
created_at: "2026-06-17T09:00:00"
updated_at: "2026-06-19T11:00:00"
related_records:
  - CHG-2420
  - INC-1302
  - POL-CAB-001
source_facts:
  - CHG-2420
  - svc_internal_api_gateway
difficulty_tags:
  - change-context
  - action-sequencing
servicenow:
  table: change_task
  parent: CHG002420
  task_numbers:
    - CTASK0003001
    - CTASK0003002
    - CTASK0003003
    - CTASK0003004
  visibility: internal
  contains_customer_safe_wording: false
---

# CHG-2420 Change Tasks

## Record details

| Field | Value |
| --- | --- |
| Table | change_task |
| Parent | CHG002420 |
| Task numbers | CTASK0003001, CTASK0003002, CTASK0003003, CTASK0003004 |
| Visibility | internal |
| Contains customer-safe wording | false |

## CTASK0003001 — Pre-change validation of current rate-limit policy state

| Field | Value |
| --- | --- |
| Number | CTASK0003001 |
| Short description | Pre-change validation of current rate-limit policy state |
| Assignment group | Platform Engineering |
| State | Closed Complete |
| Opened at | 2026-06-17T09:00:00 |
| Closed at | 2026-06-18T18:00:00 |

Before the change window, Platform Engineering captured the current rate-limit policy state on Internal API Gateway, confirmed the gateway configuration was healthy, and verified that a restore path to the prior policy existed for rollback. The change was CAB-approved per POL-CAB-001 with the CAB held on 2026-06-17.

## CTASK0003002 — Deploy new rate-limit policy to API Gateway

| Field | Value |
| --- | --- |
| Number | CTASK0003002 |
| Short description | Deploy new rate-limit policy to API Gateway |
| Assignment group | Platform Engineering |
| State | Closed Complete |
| Opened at | 2026-06-18T20:00:00 |
| Closed at | 2026-06-18T20:30:00 |

Platform Engineering deployed the new rate-limit policy to Internal API Gateway within the approved change window. The gateway accepted the new policy and continued routing API traffic during the deployment. No rollback was required during the window.

## CTASK0003003 — Post-change validation of policy application

| Field | Value |
| --- | --- |
| Number | CTASK0003003 |
| Short description | Post-change validation of policy application |
| Assignment group | Platform Engineering |
| State | Closed Complete |
| Opened at | 2026-06-18T20:30:00 |
| Closed at | 2026-06-18T20:45:00 |

Post-change validation confirmed the gateway accepted the new policy, API routing remained available, and initial gateway behavior appeared normal. The change record was updated as completed at 2026-06-18T20:50:00.

## CTASK0003004 — Post-implementation review after INC-1302

| Field | Value |
| --- | --- |
| Number | CTASK0003004 |
| Short description | Post-implementation review after INC-1302 |
| Assignment group | Platform Engineering |
| State | Closed Complete |
| Opened at | 2026-06-19T09:00:00 |
| Closed at | 2026-06-19T11:00:00 |

The post-implementation review was opened after INC-1302, in which Business-tier clients received unexpected 429 responses following the deployment. The review found that the post-change validation in CTASK0003003 did not compare the applied burst limits against tier entitlements, so the entitlement mismatch was not caught before client impact.

The gap is documented in KI-307, and the permanent fix — adding tier-entitlement validation to the policy deployment pipeline — is tracked under PRB-411.
