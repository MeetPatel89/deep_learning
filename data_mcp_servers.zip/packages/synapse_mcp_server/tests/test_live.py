import asyncio
import os

import pytest
from data_mcp_core.results import json_safe
from synapse_mcp_server.branch_package import build_package, digest
from synapse_mcp_server.config import get_config
from synapse_mcp_server.server import SynapseService


@pytest.mark.live
def test_live_pipeline_listing():
    workspace = os.environ.get("SYNAPSE_MCP_LIVE_WORKSPACE")
    if not workspace or not os.environ.get("SYNAPSE_MCP_CONFIG"):
        pytest.skip("Set SYNAPSE_MCP_CONFIG and SYNAPSE_MCP_LIVE_WORKSPACE explicitly")
    service = SynapseService(get_config())
    try:
        assert "items" in service.list_artifacts(workspace, "pipeline", limit=5, source="live")
    finally:
        service.close()


@pytest.mark.live
@pytest.mark.parametrize("backend", ["studio_http", "sdk_staging"])
def test_live_branch_pipeline_and_preservation(backend):
    if os.environ.get("SYNAPSE_MCP_LIVE_BRANCH_TESTS") != "1":
        pytest.skip("Set SYNAPSE_MCP_LIVE_BRANCH_TESTS=1 to execute real branch activities")
    workspace = os.environ.get("SYNAPSE_MCP_LIVE_WORKSPACE")
    branch = os.environ.get("SYNAPSE_MCP_LIVE_BRANCH")
    pipeline = os.environ.get("SYNAPSE_MCP_LIVE_PIPELINE")
    if not all((workspace, branch, pipeline, os.environ.get("SYNAPSE_MCP_CONFIG"))):
        pytest.fail("Integration requires explicit config, workspace, feature branch and pipeline")
    service = SynapseService(get_config())
    settings = service.config.workspaces[workspace]
    settings.branch_execution_backend = backend
    profile = os.environ.get("SYNAPSE_MCP_LIVE_TEST_PROFILE") or settings.default_test_profile
    assert profile in settings.test_profiles, "Configure the integration test profile"
    assert settings.allow_live_env, "Live access is needed to verify published definitions"
    repository = service.repository(workspace)
    protected = {repository.config.collaboration_branch, repository.config.publish_branch}
    heads = {name: repository.resolve(name) for name in protected}
    package = build_package(
        repository.snapshot(branch), pipeline, profile, settings.test_profiles[profile]
    )
    assert len([key for key in package.order if key.startswith("pipeline/")]) >= 2
    assert {"notebook", "data_flow"} <= {key.split("/", 1)[0] for key in package.order}

    def published():
        result = {}
        for kind in ("pipeline", "dataset", "linked_service", "notebook", "data_flow", "trigger"):
            operations, mapping = service._artifact_ops(workspace, kind)
            result[kind] = sorted(
                (json_safe(value) for value in getattr(operations, mapping[1])()),
                key=lambda value: value["name"],
            )
        return digest(result)

    before = published()
    execution_id = None
    try:
        result = service.run_branch_pipeline(
            workspace, pipeline, branch, test_profile=profile, dry_run=False
        )
        execution_id = result["execution_id"]
        completed = asyncio.run(
            service.wait_for_branch_pipeline_run(workspace, execution_id, timeout_seconds=600)
        )
        assert not completed["timed_out"]
        execution = completed["execution"]
        assert execution["state"] == "finished" and execution["status"] == "Succeeded"
        assert execution["child_run_ids"]
        assert execution["cleanup"] in {"complete", "not_needed"}
        assert service.get_branch_activity_results(workspace, execution_id)["items"]
        assert heads == {name: repository.resolve(name) for name in protected}
        assert published() == before
    finally:
        if execution_id:
            record = service.execution_store.get(workspace, execution_id)
            if record["native_run_id"] and record["state"] != "finished":
                service.cancel_branch_pipeline_run(workspace, execution_id, dry_run=False)
                asyncio.run(service.wait_for_branch_pipeline_run(workspace, execution_id))
        service.close()
