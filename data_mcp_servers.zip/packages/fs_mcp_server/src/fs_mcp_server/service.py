"""Filesystem discovery, content, datasets and guarded file operations."""

import fnmatch
import json
import posixpath
import re
import shutil
from collections import Counter, deque
from contextlib import ExitStack
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

import polars as pl
import sqlglot
from data_mcp_core import formats
from data_mcp_core.guards import planned_action, relative_path, require
from data_mcp_core.results import (
    MAX_CHARS,
    MAX_ROWS,
    bounded_result,
    cap_rows,
    paginate,
    redact,
    truncate_text,
)
from data_mcp_core.sql import ensure_read_only
from data_mcp_core.stores import ResolvedPath, resolve_store
from sqlglot import exp

from fs_mcp_server.config import FSConfig


class FileService:
    def __init__(self, config: FSConfig):
        self.config = config

    def resolve(self, store: str, path: str = "") -> ResolvedPath:
        if store not in self.config.stores:
            raise ValueError(f"Unknown store: {store}")
        return resolve_store(
            self.config.stores[store],
            path,
            auth_profiles=self.config.auth_profiles,
            allowed_local_roots=self.config.allowed_local_roots,
        )

    def entries(self, resolved: ResolvedPath, recursive: bool, glob: str | None = None):
        if glob:
            relative_path(glob)
            items = resolved.fs.glob(resolved.child(glob).fs_path, detail=True)
        elif recursive:
            items = resolved.fs.find(resolved.fs_path, detail=True, withdirs=True)
        else:
            items = {item["name"]: item for item in resolved.fs.ls(resolved.fs_path, detail=True)}
        result = []
        for name, info in sorted(items.items()):
            try:
                relative = resolved.relative_name(name)
            except PermissionError:
                # Symlinks to locations outside the store are omitted from discovery.
                continue
            result.append({**info, "name": relative})
        return result

    def list_stores(self) -> dict[str, Any]:
        """List configured store locations and explicit permission flags."""
        return redact(
            {
                "stores": {
                    name: value.model_dump(exclude={"auth", "options"})
                    for name, value in self.config.stores.items()
                }
            }
        )

    def list_paths(
        self,
        store: str,
        path: str = "",
        recursive: bool = False,
        glob: str | None = None,
        limit: int = 100,
        continuation: str | None = None,
    ) -> dict[str, Any]:
        """List paths relative to a named store, with resumable pagination."""
        entries = self.entries(self.resolve(store, path), recursive, glob)
        return paginate(entries, limit, continuation, f"list:{store}:{path}:{recursive}:{glob}")

    def get_path_info(self, store: str, path: str) -> dict[str, Any]:
        """Get file size, type and backend timestamps."""
        resolved = self.resolve(store, path)
        return redact({**resolved.fs.info(resolved.fs_path), "name": resolved.relative})

    def find_files(
        self,
        store: str,
        path: str = "",
        glob: str = "*",
        modified_after: str | None = None,
        modified_before: str | None = None,
        min_size: int = 0,
        max_size: int | None = None,
        limit: int = 100,
        continuation: str | None = None,
    ) -> dict[str, Any]:
        """Find files recursively by glob, UTC modification window and size."""
        relative_path(glob)
        if min_size < 0 or (max_size is not None and max_size < min_size):
            raise ValueError("Invalid file size range")

        def timestamp(value):
            if isinstance(value, (float, int)):
                return datetime.fromtimestamp(value, UTC)
            if isinstance(value, str):
                value = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return value.replace(tzinfo=UTC) if value and value.tzinfo is None else value

        after, before = timestamp(modified_after), timestamp(modified_before)
        selected = []
        for item in self.entries(self.resolve(store, path), True):
            if item.get("type") != "file" or not fnmatch.fnmatch(item["name"], glob):
                continue
            size = item.get("size", 0) or 0
            modified = timestamp(
                item.get("mtime", item.get("last_modified", item.get("LastModified")))
            )
            if size < min_size or (max_size is not None and size > max_size):
                continue
            if (after and (not modified or modified < after)) or (
                before and (not modified or modified > before)
            ):
                continue
            selected.append(item)
        context = json.dumps(
            [store, path, glob, modified_after, modified_before, min_size, max_size]
        )
        return paginate(selected, limit, continuation, context)

    def summarize_directory(self, store: str, path: str = "") -> dict[str, Any]:
        """Count files and bytes by extension and discover hive partition fields."""
        counts, sizes, partitions = Counter(), Counter(), set()
        for item in self.entries(self.resolve(store, path), True):
            if item.get("type") != "file":
                continue
            extension = Path(item["name"]).suffix.lower() or "<none>"
            counts[extension] += 1
            sizes[extension] += item.get("size", 0) or 0
            partitions.update(
                part.split("=", 1)[0] for part in item["name"].split("/")[:-1] if "=" in part
            )
        return {
            "file_count": sum(counts.values()),
            "total_bytes": sum(sizes.values()),
            "extensions": {
                key: {"count": value, "bytes": sizes[key]} for key, value in counts.items()
            },
            "hive_partition_columns": sorted(partitions),
        }

    def read_text(
        self,
        store: str,
        path: str,
        encoding: str = "utf-8",
        byte_start: int | None = None,
        byte_end: int | None = None,
        line_start: int | None = None,
        line_end: int | None = None,
        head: int | None = None,
        tail: int | None = None,
        max_chars: int = MAX_CHARS,
    ) -> dict[str, Any]:
        """Read bounded text; byte/line ranges are zero based and end exclusive."""
        if not 1 <= max_chars <= MAX_CHARS:
            raise ValueError("Invalid character cap")
        for value in (byte_start, byte_end, line_start, line_end, head, tail):
            if value is not None and value < 0:
                raise ValueError("Ranges and head/tail must be nonnegative")
        by_bytes = byte_start is not None or byte_end is not None
        if (
            sum(
                [
                    by_bytes,
                    line_start is not None or line_end is not None,
                    head is not None,
                    tail is not None,
                ]
            )
            > 1
        ):
            raise ValueError("Choose one of byte range, line range, head or tail")
        resolved = self.resolve(store, path)
        with resolved.fs.open(resolved.fs_path, "rb") as handle:
            if by_bytes:
                start = byte_start or 0
                if byte_end is not None and byte_end < start:
                    raise ValueError("byte_end must be >= byte_start")
                handle.seek(start)
                length = min(
                    (byte_end - start) if byte_end is not None else max_chars * 4 + 4,
                    max_chars * 4 + 4,
                )
                text = handle.read(length).decode(encoding, errors="replace")
            else:
                import io

                reader = io.TextIOWrapper(handle, encoding=encoding, errors="replace")
                if tail is not None:
                    if tail > MAX_ROWS:
                        raise ValueError("tail exceeds the line cap")
                    # Bound each retained line, even for pathological logs.
                    lines = deque((line[: max_chars + 1] for line in reader), maxlen=tail)
                    text = "".join(lines)
                else:
                    start, end = line_start or 0, line_end if line_end is not None else head
                    if end is not None and end < start:
                        raise ValueError("line_end must be >= line_start")
                    lines, size = [], 0
                    for index, line in enumerate(reader):
                        if index < start:
                            continue
                        if end is not None and index >= end:
                            break
                        lines.append(line[: max_chars + 1])
                        size += len(line)
                        if size > max_chars:
                            break
                    text = "".join(lines)
        return truncate_text(redact(text), max_chars)

    def search_text(
        self,
        store: str,
        pattern: str,
        path: str = "",
        glob: str = "*",
        encoding: str = "utf-8",
        limit: int = 100,
        max_files: int = 100,
        max_bytes_per_file: int = 1_000_000,
    ) -> dict[str, Any]:
        """Search a bounded number of files using a regex and return matching lines."""
        if (
            not 1 <= limit <= MAX_ROWS
            or not 1 <= max_files <= MAX_ROWS
            or not 1 <= max_bytes_per_file <= 10_000_000
        ):
            raise ValueError("Invalid search caps")
        relative_path(glob)
        regex = re.compile(pattern)
        matches, searched, truncated = [], 0, False
        for item in self.entries(self.resolve(store, path), True):
            if item.get("type") != "file" or not fnmatch.fnmatch(item["name"], glob):
                continue
            if searched >= max_files:
                truncated = True
                break
            resolved = self.resolve(store, item["name"])
            with resolved.fs.open(resolved.fs_path, "rb") as handle:
                data = handle.read(max_bytes_per_file + 1)
            truncated |= len(data) > max_bytes_per_file
            searched += 1
            for number, line in enumerate(
                data[:max_bytes_per_file].decode(encoding, errors="replace").splitlines(), 1
            ):
                if regex.search(line):
                    matches.append({"path": item["name"], "line": number, "text": line[:2000]})
                    if len(matches) >= limit:
                        return bounded_result(
                            {"matches": matches, "files_searched": searched, "truncated": True}
                        )
        return bounded_result(
            {"matches": matches, "files_searched": searched, "truncated": truncated}
        )

    def detect_format(
        self, store: str, path: str, options: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Detect format, compression, text encoding and delimiter."""
        return formats.detect_format(self.resolve(store, path), options)

    def inspect_dataset(
        self,
        store: str,
        path: str,
        format: str | None = None,
        options: dict[str, Any] | None = None,
        sample_size: int = 5,
    ) -> dict[str, Any]:
        """Return full dataset row count, schema, hive fields and a small sample."""
        if not 0 <= sample_size <= 100:
            raise ValueError("sample_size must be between 0 and 100")
        resolved = self.resolve(store, path)
        with formats.scan_dataset(resolved, format, options) as scan:
            result = {
                "schema": {name: str(dtype) for name, dtype in scan.collect_schema().items()},
                "row_count": scan.select(pl.len()).collect(engine="streaming").item(),
                "sample": scan.head(sample_size).collect(engine="streaming").to_dicts(),
            }
        if resolved.fs.isdir(resolved.fs_path):
            result["partitions"] = self.summarize_directory(store, path)["hive_partition_columns"]
        return bounded_result(result)

    def preview_dataset(
        self,
        store: str,
        path: str,
        format: str | None = None,
        options: dict[str, Any] | None = None,
        columns: list[str] | None = None,
        filter_expression: str | None = None,
        mode: Literal["head", "tail", "random"] = "head",
        limit: int = 20,
        seed: int = 0,
    ) -> dict[str, Any]:
        """Preview selected columns with a SQL filter expression, head, tail or random sampling."""
        if not 1 <= limit <= MAX_ROWS:
            raise ValueError("Invalid preview row cap")
        with formats.scan_dataset(self.resolve(store, path), format, options) as scan:
            if filter_expression:
                scan = scan.filter(pl.sql_expr(filter_expression))
            if columns is not None:
                scan = scan.select(columns)
            if mode == "random":
                frame = scan.collect(engine="streaming")
                frame = frame.sample(n=min(limit, frame.height), seed=seed)
            else:
                frame = (scan.tail(limit) if mode == "tail" else scan.head(limit)).collect(
                    engine="streaming"
                )
            return cap_rows(frame.to_dicts(), limit)

    def profile_dataset(
        self,
        store: str,
        path: str,
        format: str | None = None,
        options: dict[str, Any] | None = None,
        columns: list[str] | None = None,
        top_n: int = 5,
    ) -> dict[str, Any]:
        """Profile nulls, distinct values, min/max, numeric quantiles and frequent values."""
        if not 0 <= top_n <= 20:
            raise ValueError("top_n must be between 0 and 20")
        profiles = {}
        with formats.scan_dataset(self.resolve(store, path), format, options) as scan:
            schema = scan.collect_schema()
            selected = columns if columns is not None else list(schema)
            if len(selected) > 100:
                raise ValueError("Profile at most 100 columns per request")
            for name in selected:
                column = pl.col(name)
                expressions = [
                    column.null_count().alias("null_count"),
                    column.n_unique().alias("distinct_count"),
                ]
                dtype = schema[name]
                if dtype.is_numeric() or dtype.is_temporal() or dtype in {pl.String, pl.Boolean}:
                    expressions += [column.min().alias("min"), column.max().alias("max")]
                if dtype.is_numeric():
                    expressions += [
                        column.quantile(q).alias(f"q{int(q * 100)}") for q in (0.25, 0.5, 0.75)
                    ]
                profile = scan.select(expressions).collect(engine="streaming").to_dicts()[0]
                if top_n:
                    profile["top_values"] = (
                        scan.group_by(name)
                        .len()
                        .sort("len", descending=True)
                        .head(top_n)
                        .collect(engine="streaming")
                        .to_dicts()
                    )
                profiles[name] = profile
        return bounded_result({"columns": profiles})

    def query_datasets(
        self,
        datasets: dict[str, dict[str, Any]],
        query: str,
        limit: int = 100,
        output_store: str | None = None,
        output_path: str | None = None,
        output_format: str = "parquet",
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Query aliased {store,path,format,options} datasets with Polars SQL; optionally export."""
        ensure_read_only(query)
        if not 1 <= limit <= MAX_ROWS or not 1 <= len(datasets) <= 20:
            raise ValueError("Invalid query caps")
        parsed = sqlglot.parse_one(query, read="tsql")
        ctes = {cte.alias for cte in parsed.find_all(exp.CTE)}
        for table in parsed.find_all(exp.Table):
            if (
                not isinstance(table.this, exp.Identifier)
                or table.db
                or table.catalog
                or table.name not in (set(datasets) | ctes)
            ):
                raise PermissionError("SQL tables must reference supplied dataset aliases")
        output = None
        if output_store is not None or output_path is not None:
            if not output_store or not output_path:
                raise ValueError("Export requires output_store and output_path")
            output = self.resolve(output_store, output_path)
            require(output.store, "allow_write")
            plan = planned_action(
                "query_datasets",
                dry_run,
                output_store=output_store,
                output_path=output_path,
                format=output_format,
            )
            if plan:
                return plan
        with ExitStack() as stack:
            tables = {
                alias: stack.enter_context(
                    formats.scan_dataset(
                        self.resolve(reference["store"], reference["path"]),
                        reference.get("format"),
                        reference.get("options"),
                    )
                )
                for alias, reference in datasets.items()
            }
            context = pl.SQLContext(tables)
            result = context.execute(query, eager=False)
            if output:
                return formats.write_dataset(
                    result.collect(engine="streaming"), output, output_format
                )
            frame = result.head(limit + 1).collect(engine="streaming")
            return cap_rows(frame.to_dicts(), limit)

    def validate_dataset(
        self,
        store: str,
        path: str,
        rules: list[dict[str, Any]],
        format: str | None = None,
        options: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Validate not_null, unique, regex, range and allowed_values rules without truncating
        counts.
        """
        if len(rules) > 100:
            raise ValueError("At most 100 validation rules are allowed")
        results = []
        with formats.scan_dataset(self.resolve(store, path), format, options) as scan:
            total = scan.select(pl.len()).collect(engine="streaming").item()
            for rule in rules:
                column, kind = pl.col(rule["column"]), rule["type"]
                if kind == "not_null":
                    invalid = column.is_null()
                elif kind == "unique":
                    invalid = column.is_duplicated()
                elif kind == "regex":
                    invalid = ~column.cast(pl.String).str.contains(rule["pattern"])
                elif kind == "range":
                    invalid = ~column.is_between(rule["min"], rule["max"])
                elif kind == "allowed_values":
                    invalid = ~column.is_in(rule["values"])
                else:
                    raise ValueError(f"Unknown validation rule: {kind}")
                count = (
                    scan.select(invalid.fill_null(True).sum()).collect(engine="streaming").item()
                )
                results.append({"rule": rule, "invalid_rows": count, "passed": count == 0})
        return bounded_result(
            {
                "valid": all(result["passed"] for result in results),
                "row_count": total,
                "rules": results,
            }
        )

    def convert_dataset(
        self,
        store: str,
        path: str,
        output_store: str,
        output_path: str,
        output_format: str,
        format: str | None = None,
        options: dict[str, Any] | None = None,
        write_options: dict[str, Any] | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Convert a dataset into another supported format (requires destination allow_write)."""
        source, destination = self.resolve(store, path), self.resolve(output_store, output_path)
        require(destination.store, "allow_write")
        plan = planned_action(
            "convert_dataset",
            dry_run,
            source=source.relative,
            destination=destination.relative,
            format=output_format,
        )
        return plan or formats.write_dataset(
            formats.read_dataset(source, format, options), destination, output_format, write_options
        )

    def write_text(
        self,
        store: str,
        path: str,
        text: str,
        encoding: str = "utf-8",
        append: bool = False,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Write or append text (requires allow_write)."""
        resolved = self.resolve(store, path)
        require(resolved.store, "allow_write")
        plan = planned_action(
            "write_text",
            dry_run,
            store=store,
            path=path,
            append=append,
            bytes=len(text.encode(encoding)),
        )
        if plan:
            return plan
        parent = posixpath.dirname(resolved.fs_path)
        resolved.fs.makedirs(parent, exist_ok=True)
        with resolved.fs.open(resolved.fs_path, "ab" if append else "wb") as handle:
            handle.write(text.encode(encoding))
        return {"written": True, "path": path}

    def write_dataset(
        self,
        store: str,
        path: str,
        rows: list[dict[str, Any]],
        format: str | None = None,
        options: dict[str, Any] | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Write inline rows as CSV, Parquet, NDJSON, IPC, Excel or Delta (requires allow_write)."""
        resolved = self.resolve(store, path)
        require(resolved.store, "allow_write")
        plan = planned_action(
            "write_dataset", dry_run, store=store, path=path, format=format, row_count=len(rows)
        )
        return plan or formats.write_dataset(
            pl.DataFrame(rows, infer_schema_length=None), resolved, format, options
        )

    def make_directory(self, store: str, path: str, dry_run: bool = False) -> dict[str, Any]:
        """Create a directory (requires allow_write)."""
        resolved = self.resolve(store, path)
        require(resolved.store, "allow_write")
        plan = planned_action("make_directory", dry_run, store=store, path=path)
        if plan:
            return plan
        resolved.fs.makedirs(resolved.fs_path, exist_ok=True)
        return {"created": True, "path": path}

    def _transfer(
        self, source: ResolvedPath, destination: ResolvedPath, recursive: bool, overwrite: bool
    ):
        if destination.exists() and not overwrite:
            raise FileExistsError("Destination exists; specify overwrite=true")
        is_directory = source.fs.isdir(source.fs_path)
        if is_directory:
            if not recursive:
                raise ValueError("Directory transfers require recursive=true")
            if source.store == destination.store and (
                destination.fs_path == source.fs_path
                or destination.fs_path.startswith(source.fs_path.rstrip("/") + "/")
            ):
                raise ValueError("Cannot transfer a directory into itself")
            destination.fs.makedirs(destination.fs_path, exist_ok=True)
            for item in self.entries(source, True):
                if item.get("type") != "file":
                    continue
                suffix = posixpath.relpath(item["name"], source.relative or ".")
                source_file = resolve_store(
                    source.store,
                    item["name"],
                    profile=source.auth,
                    allowed_local_roots=source.allowed_local_roots,
                )
                target_file = destination.child(suffix)
                self._transfer(source_file, target_file, False, overwrite)
        else:
            if source.uri == destination.uri:
                raise ValueError("Source and destination must differ")
            destination.fs.makedirs(posixpath.dirname(destination.fs_path), exist_ok=True)
            with (
                source.fs.open(source.fs_path, "rb") as src,
                destination.fs.open(destination.fs_path, "wb") as dst,
            ):
                shutil.copyfileobj(src, dst)

    def transfer(
        self,
        source_store: str,
        source_path: str,
        destination_store: str,
        destination_path: str,
        recursive: bool = False,
        overwrite: bool = False,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Copy a file or directory between stores (requires destination allow_write)."""
        source, destination = (
            self.resolve(source_store, source_path),
            self.resolve(destination_store, destination_path),
        )
        require(destination.store, "allow_write")
        plan = planned_action(
            "transfer",
            dry_run,
            source_store=source_store,
            source_path=source_path,
            destination_store=destination_store,
            destination_path=destination_path,
            recursive=recursive,
            overwrite=overwrite,
        )
        if plan:
            return plan
        self._transfer(source, destination, recursive, overwrite)
        return {"copied": True, "path": destination_path}

    def copy_path(
        self,
        store: str,
        source_path: str,
        destination_path: str,
        recursive: bool = False,
        overwrite: bool = False,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Copy within a store (requires allow_write)."""
        return self.transfer(
            store, source_path, store, destination_path, recursive, overwrite, dry_run
        )

    def move_path(
        self,
        store: str,
        source_path: str,
        destination_path: str,
        recursive: bool = False,
        overwrite: bool = False,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Move within a store; ADLS uses atomic HNS rename (requires allow_write and
        allow_delete).
        """
        source, destination = (
            self.resolve(store, source_path),
            self.resolve(store, destination_path),
        )
        require(source.store, "allow_write")
        require(source.store, "allow_delete")
        if source.uri == destination.uri:
            raise ValueError("Source and destination must differ")
        plan = planned_action(
            "move_path",
            dry_run,
            store=store,
            source_path=source_path,
            destination_path=destination_path,
            recursive=recursive,
            overwrite=overwrite,
        )
        if plan:
            return plan
        if destination.exists() and not overwrite:
            raise FileExistsError("Destination exists; specify overwrite=true")
        is_directory = source.fs.isdir(source.fs_path)
        if is_directory and not recursive:
            raise ValueError("Moving directories requires recursive=true")
        if is_directory and destination.fs_path.startswith(source.fs_path.rstrip("/") + "/"):
            raise ValueError("Cannot move a directory into itself")
        if source.store.protocol == "abfss":
            from fs_mcp_server.adls import path_client

            client = path_client(source, directory=is_directory)
            with client:
                rename = client.rename_directory if is_directory else client.rename_file
                rename(destination.fs_path)
        elif source.store.protocol == "file":
            # Validate every descendant before an OS-level directory rename.
            if is_directory:
                self.entries(source, True)
            destination.fs.makedirs(posixpath.dirname(destination.fs_path), exist_ok=True)
            source.fs.mv(source.fs_path, destination.fs_path, recursive=recursive)
        else:
            self._transfer(source, destination, recursive, overwrite)
            source.fs.rm(source.fs_path, recursive=recursive)
        return {"moved": True, "path": destination_path}

    def delete_path(
        self, store: str, path: str, recursive: bool = False, dry_run: bool = True
    ) -> dict[str, Any]:
        """Delete a path; defaults to a plan (requires allow_delete even in dry-run)."""
        resolved = self.resolve(store, path)
        require(resolved.store, "allow_delete")
        if resolved.relative in {"", "."}:
            raise PermissionError("Deleting a store root is forbidden")
        plan = planned_action("delete_path", dry_run, store=store, path=path, recursive=recursive)
        if plan:
            return plan
        resolved.fs.rm(resolved.fs_path, recursive=recursive)
        return {"deleted": True, "path": path}
