"""Preserve fieldguide-ai's document relevance and original rank semantics."""

from collections.abc import Callable
from typing import Any

from pytest import approx, mark, raises

from observability_ai.evaluation import HitAtK, PrecisionAtK, RecallAtK, ReciprocalRank


@mark.parametrize(
    ("retrieved", "expected", "k", "scores"),
    [
        (["x", "a", "a", "b"], ["a", "b", "b"], 3, (1, 0.5, 1 / 3, 0.5)),
        (["a"], ["a", "b"], 4, (1, 0.5, 0.25, 1)),
        ([], ["a"], 3, (0, 0, 0, 0)),
        (["x", "x", "a"], ["a"], 2, (0, 0, 0, 0)),
        (["x", "x", "a"], ["a"], 3, (1, 1, 1 / 3, 1 / 3)),
        (["a", "b", "x"], ["a", "b"], 3, (1, 1, 2 / 3, 1)),
    ],
)
def test_document_metrics(
    retrieved: list[str], expected: list[str], k: int, scores: tuple[float, ...]
) -> None:
    """Duplicates consume ranks; precision includes missing slots in its denominator."""
    evaluators = (HitAtK(k), RecallAtK(k), PrecisionAtK(k), ReciprocalRank(k))
    results = [e(output=retrieved, expected_output=expected) for e in evaluators]
    assert [r.value for r in results] == approx(scores)
    assert all(r.data_type == "NUMERIC" for r in results)
    assert [r.name for r in results] == [
        f"hit_at_{k}",
        f"recall_at_{k}",
        f"precision_at_{k}",
        f"reciprocal_rank_at_{k}",
    ]


def test_full_reciprocal_rank_and_custom_names() -> None:
    """An omitted cutoff includes the complete list without deduplicating ranks."""
    result = ReciprocalRank()(output=["x", "x", "a"], expected_output=["a"])
    assert result.name == "reciprocal_rank"
    assert result.value == approx(1 / 3)
    assert HitAtK(2, name="hit")(output=["a"], expected_output=["a"]).name == "hit"


@mark.parametrize("factory", [HitAtK, RecallAtK, PrecisionAtK, ReciprocalRank])
@mark.parametrize("k", [0, -1, True, 1.5, "3"])
def test_invalid_cutoff(factory: Callable[..., object], k: object) -> None:
    """Every cutoff requires a positive nonboolean integer."""
    with raises((TypeError, ValueError)):
        factory(k)


@mark.parametrize("factory", [HitAtK, RecallAtK, PrecisionAtK, ReciprocalRank])
@mark.parametrize(
    ("output", "expected"),
    [
        ("a", ["a"]),
        (["a"], "a"),
        ({"a"}, ["a"]),
        (["a"], []),
        ([" "], ["a"]),
        ([1], ["a"]),
        (["a"], [None]),
    ],
)
def test_invalid_document_lists(
    factory: Callable[..., Any], output: object, expected: object
) -> None:
    """Require ordered sequences and nonempty relevance labels."""
    with raises((TypeError, ValueError)):
        factory(3)(output=output, expected_output=expected)
