# Semantic-layer constitution for the producer NL-to-SQL application

Version: 1.0 design proposal • Prepared 2026-09-25

Companion: [Implementation design](02-implementation-design.md)

## 1. Purpose and status

The semantic layer is the governed interface between business questions and database queries. It defines what data means, which populations and records an answer represents, how concepts map to stored values, which relationships may be traversed, and which query operations are valid. Its executable contracts are consumed by deterministic application code.

**Recommended architecture:** an LLM proposes a typed semantic query; a catalog resolves its meaning; a deterministic planner and compiler produce parameterized SQL; validation and database controls govern execution. Agent Skills can package the agent's procedure. A relationship graph helps find permitted paths. Neither the skill nor the graph replaces enforcement.

This constitution specifies the target rules. It does not assert that the supplied database already meets them. `MUST` denotes a release or execution requirement; `SHOULD` denotes a recommended practice with a documented exception; `MAY` denotes an optional extension.

The reviewed workbook is a **header-only catalog template**, not a populated semantic model. Confirmed follow-up requirements are Azure SQL Database for operational queries, SQLite for semantic metadata, “term date” meaning license termination date, and status interpretation driven by enum descriptions/aliases and reviewed examples. Other concrete business definitions below are either facts from the supplied column lists or explicitly proposed definitions awaiting confirmation. The companion document contains the decision register and SQL examples using synthetic values.

## 2. Evidence and workbook assessment

Inspected the attachment named `semantic_catalogue.xlsx` retrieved from the referenced conversation, rather than assuming the earlier `/mnt/data` path existed in this Windows workspace. Workbook SHA-256: `51133d92a8967e4ae60c1f915d555ab246adf537ef772086ed193698cffca8f1`. All worksheet cell contents were inspected. There are five sheets and no populated definition rows, formulas, or query examples in their cells.

| Workbook location | Existing fields | Assessment |
|---|---|---|
| `meta_tables!A1:B1` | `TABLE_NAME`, `BUSINESS_DESCRIPTION` | Good entity inventory start; needs stable identity, source, grain, keys, owner, lifecycle and security. |
| `meta_columns!A1:F1` | `TABLE_NAME`, `COLUMN_NAME`, `DATA_TYPE`, `BUSINESS_COLUMN_NAME`, `ENUM_MAPPING`, `BUSINESS_DESCRIPTION` | Good field inventory start; needs null semantics, roles, permitted operations, sensitivity, and typed binding. |
| `meta_enum_mappings!A1:E1` | `ENUM_MAPPING`, `LITERAL_VALUE`, `CANONICAL_NAME`, `ALIASES`, `BUSINESS_DESCRIPTION` | Correct separation of stored value and business label; needs concept IDs, source-specific bindings, validity and ambiguity rules. |
| `meta_joins!A1:F1` | `JOIN_NAME`, `LEFT_TABLE_NAME`, `RIGHT_TABLE_NAME`, `TYPE`, `ON`, `CARDINALITY` | Already recognizes join type and cardinality as separate facts; needs scoped operations, preservation, filter placement, grain and evidence. |
| `meta_examples!A1:C1` | `EXAMPLE_NAME`, `EXAMPLE_DESCRIPTION`, `EXAMPLE_SQL` | Useful starting point; needs expected intent, versioned plans, fixtures and expected answers. |

Preserve these concepts. Extend them through a versioned importer and validated catalog schema. Excel may remain a business-authoring interface. The runtime MUST consume a published immutable catalog snapshot, not arbitrary edits to a live workbook.

## 3. Foundational commitments

| Rule | What it requires | Why it exists |
|---|---|---|
| C01 Meaning precedes SQL | Identify population, output grain, predicates and metric before compilation. | Syntactically valid SQL can answer the wrong question. |
| C02 IDs precede names | Reference stable semantic IDs; bind physical names separately. | Renames and source migrations should not rewrite prompts and saved queries. |
| C03 Facts precede similarity | Resolve labels to authoritative records and bindings. | Search similarity is not proof that a stored code is correct. |
| C04 Contracts precede join syntax | Select an approved relationship operation; compiler owns SQL form. | A plausible join can lose rows or multiply measures. |
| C05 Unknown stays unknown | Missing rules produce clarification or unsupported errors. | Invention creates confident, untraceable answers. |
| C06 Authorization covers every stage | Scope metadata, value resolution, source access, results and caches. | A protected value can leak without ever appearing in a final result row. |
| C07 Versions travel together | Pin catalog, mapping, policy and compiler versions to each compiled artifact. | An answer must be attributable to the rules actually used. |
| C08 Tests prove specific guarantees | Test populations, grain, nulls, duplicates and policy boundaries. | Successful parsing and a few happy-path examples are insufficient. |
| C09 One implementation of a business rule | Predicates and metrics are referenced by ID. | Repeated status/date logic drifts across queries. |
| C10 Bounded expressiveness | V1 supports a deliberately limited query algebra. | An arbitrary SQL escape hatch defeats semantic enforcement. |

## 4. Components: what, why, required contents and enforcement

### 4.1 Domain and business glossary

**What:** named concepts such as producer, individual, agency, license, appointment, contract, active and Pet product category. A glossary describes business intent and distinguishes homonyms.

**Why:** the same word can refer to different fields or entities. “Active” may have separate definitions for licenses, appointments and contracts. “Individual” may describe a legal person type, a contract type, or simply a request for detail rows.

**Minimum contents:** stable concept ID, label, definition, aliases, scope, owner, related entity/field/predicate IDs, provenance, status and version. An alias MUST NOT silently merge different concepts. Ambiguous aliases return alternatives.

**Enforcement:** catalog publication detects alias collisions within a scope. Interpretation records which concept was chosen and why. No universal `active = Status = 'A'` rule may be inferred from a label.

### 4.2 Entities, physical bindings and row grain

**What:** an entity is an addressable semantic dataset. It can bind to a table, secured view or reviewed derived relation. Grain states exactly what one row represents. Record identity is separately declared as a key.

**Why:** `Producer_Licenses` is not necessarily one row per producer. Counts of licenses, producers, license numbers and historical versions are different metrics.

**Minimum contents:** ID, description, connection reference, qualified object binding, current/history semantics, grain description, candidate and verified keys, nullable-key policy, owner, provenance, freshness expectations and allowed access. Store credentials outside the catalog.

**Enforcement:** publication verifies referenced fields and key assertions. A cardinality-dependent operation MUST have valid evidence for its required uniqueness. If a dataset contains duplicate physical records, a `physical_row_count` can still count rows if explicitly defined. A `license_record_count` requires a defined record grain; the compiler must not repair duplicate identities with an unexplained `DISTINCT`.

**Application:** `(Producer_Key, License_Id)` and `(Producer_Key, Appointment_Id)` are candidate identities, not facts established by column names. `License_Number` can repeat across states or historical records. Contract identities need source qualification if combined.

### 4.3 Fields and dimensions

**What:** field metadata binds semantic attributes to source columns or reviewed expressions. A dimension is a business attribute used to filter, group or describe records.

**Why:** physical types alone do not explain nulls, valid comparisons, business synonyms, sensitive content or aggregation behavior.

**Minimum contents:** entity ID, field ID, source binding, semantic type, physical type, null meaning, business label, definition, roles, permitted operators, optional value-domain ID, sensitivity, lineage and status. Roles may include identifier, dimension, measure input and temporal field.

**Enforcement:** typed validation rejects incompatible comparisons and unauthorized projections. Identifiers bind through an allowlist; they are never accepted as arbitrary SQL text. `NULL`, empty text, unknown codes and an absent business fact remain distinct unless a governed normalization rule says otherwise.

**Application:** the user confirmed that “term date” in the first query means `Producer_Licenses.Termination_Date`. Retrieve its description and aliases; let the agent propose an `is_null` filter on that semantic field; validate and compile it deterministically. It does not establish current activity without a business definition. `State` cannot be added to a contract join because the supplied contract tables have no State column.

### 4.4 Value domains, aliases and physical value bindings

**What:** a value domain owns canonical values and aliases. A binding maps a canonical value to one or more typed source literals for a particular entity/field and effective interval.

**Why:** “Pet” could be stored as `PET`, `P`, an integer, or several product codes. Agent and agency contract sources may encode it differently.

**Minimum contents:** domain ID, value ID, canonical label, aliases, description, binding scope, literal type/value, source of truth, validity interval, deprecation status, owner and revision. A canonical value may bind to a set of literals; the set must be complete for the requested scope.

**Enforcement:** exact code/name/curated alias matching first; lexical and optional vector retrieval supply candidates afterward. Only a resolver can issue a resolved value handle. An LLM-generated literal is insufficient. Missing binding coverage produces an error rather than silently searching only one contract source.

**Ambiguity:** no universal embedding-score threshold proves correctness. V1 should ask the user to choose among plausible fuzzy matches. Later auto-resolution requires evaluated, domain-specific acceptance rules. A deterministic algorithm is repeatable, but its inferred match can still be semantically wrong.

### 4.5 Named business predicates and temporal semantics

**What:** a named predicate is a reusable typed condition, such as `license.active`, `appointment.active`, `license.no_termination_date` or `contract.has_product_category`.

**Why:** a predicate often combines code mappings, dates and exception handling. Repeating it in prompts makes behavior inconsistent.

**Minimum contents:** ID, supported entity, typed expression tree, required value bindings, parameter definitions, null behavior, time basis, owner, explanation and tests. Declare whether a predicate is a mandatory security restriction, source technical restriction, business default or user-requested condition.

**Enforcement:** required restrictions are inserted by trusted code; defaults are disclosed and overridable only where allowed. User filters cannot remove mandatory restrictions. Time-dependent predicates use an explicit timestamp/timezone and boundary rule.

**Application:** enum mappings and reviewed example queries provide evidence for interpreting “active.” For a status-only definition, a predicate can simply reference the appropriate mapped status set. If a reviewed definition also imposes a date condition, promote that condition into the named predicate so all questions use it consistently. Do not equate “active” with “no term date.” Historical “active as of” queries usually need effective dates or snapshots; the supplied fields cannot establish all historical states.

### 4.6 Relationships and operation contracts

**What:** a relationship describes an approved correspondence between entity roles. Its operation contract specifies how that relationship may be used in a query: qualify by existence, exclude by absence, enrich without dropping the base population, or expand into child details.

**Why:** one equality does not determine the right query behavior. `LEFT JOIN`, `INNER JOIN`, `EXISTS` and a child collection express different population/grain intentions.

**Minimum contents:** stable ID, directed endpoints and roles, typed key pairs, required predicates, identity namespace, cardinality in both directions, null-key behavior, temporal scope, permitted operations, required SQL form for each operation, preservation policy, fanout behavior, output grain, allowed fields, required evidence, owner and version.

**Enforcement:** compile an operation selected by intent. For a mandatory-left enrichment contract, the compiler emits left-preserving logic and the validator rejects inner replacement. For a contract-existence condition, the compiler uses `EXISTS`, preventing child multiplicity from multiplying the base. Predicates that filter included child rows stay inside the child relation or join condition. Predicates that qualify the base population are modeled separately.

**Important limit:** preserving every eligible producer does not preserve one output row per producer when all licenses are expanded. A producer with three licenses yields three flat rows. Preservation and multiplicity are separate assertions.

**Application:** licenses and contracts joined only on Producer_Key can be many-to-many. They MUST NOT be declared many-to-one merely because Producer_Key has “key” in its name. “Has a Pet contract” is existence at producer scope; it does not prove the particular license is explicitly tied to that contract.

### 4.7 Populations and reusable cohorts

**What:** a population defines which base records qualify. A cohort can be a reusable membership predicate or a one-key-per-member relation.

**Why:** “all licenses held by producers with Pet contracts” separates a license population from contract evidence. Combining both in a raw detail join changes the count.

**Minimum contents:** base entity, qualifying conditions, applicable relationship IDs, time scope, authorization scope and key/grain guarantee.

**Enforcement:** materialized or derived cohort joins require verified uniqueness at the joined key. Otherwise compile as correlated existence. Unioned contract-source membership means “either source,” not “both sources.” The cohort must not imply an individual/agency relationship that is absent from the catalog.

### 4.8 Metrics and aggregation contracts

**What:** a metric defines what is measured, at which grain, over which population and with what aggregation. It may be parameterized by category or time.

**Why:** `COUNT(*)`, `COUNT(License_Id)` and `COUNT(DISTINCT Producer_Key)` answer different questions; a measure can be duplicated by a later join.

**Minimum contents:** metric ID, label, base entity, grain, aggregation operator, unit, required predicates, optional filters, allowed group dimensions, additivity, null behavior and output type. Define record count and producer count as different metrics.

**Enforcement:** apply membership conditions without multiplying base rows; aggregate at the declared grain. V1 rejects multiple expanding children or unrelated facts in one aggregate. Later implementations may aggregate each fact separately to conformed dimensions and combine those results using a reviewed plan.

**Application:** license and appointment counts are independent. Do not join licenses to appointments to answer either sample count. Pet-contract eligibility must not add a contract-status condition unless the question or an explicitly governed default requires it.

### 4.9 Query intent and semantic intermediate representation

**What:** a typed query plan carries base entity, projection, metric, population filters, relationship operations, resolved value references, output grain, sorting and pagination.

**Why:** it creates a stable boundary between probabilistic interpretation and deterministic execution. It also makes explanations and regression tests inspectable.

**Minimum contents:** schema version, catalog revision, query kind, known IDs, typed filters, relationship references, scoped filter placement, ambiguity decisions and response shape. The trusted application binds identity, policy context and execution limits separately.

**Enforcement:** reject unknown fields, SQL snippets, undeclared identifiers, incompatible metrics, unresolved values, unapproved paths and unsupported operators. The server canonicalizes and validates the model's proposal; the proposal is never an execution entitlement.

### 4.10 Catalog retrieval, path resolution and verified examples

**What:** retrieval finds candidate entities, fields, predicates, values and examples. Path resolution enumerates permitted typed relationship paths. Verified examples connect questions to reviewed plans, fixtures and expected results.

**Why:** only relevant context needs to reach the model, while completeness-critical dependencies must still be loaded deterministically.

**Minimum contents:** authorization-aware indexes, versioned IDs, provenance, search explanation, dependency closure and explicit ambiguity outcomes. Verified examples include counterexamples and rejection expectations.

**Enforcement:** search rank cannot override relationship policy. Graph adjacency does not authorize arbitrary transitive joins. A shortest path can have the wrong temporal or business meaning. Materially different valid paths require a semantic preference or clarification. Reviewed examples inform intent; their SQL is not an executable bypass.

### 4.11 Compiler, semantic validator and SQL validator

**What:** the compiler lowers approved semantic plans to relational operations and SQL. Semantic checks establish meaning within the supported algebra; SQL checks validate the generated artifact against its expected structure and access restrictions.

**Why:** prompts and schema-valid JSON do not guarantee correct joins, filters or permissions.

**Minimum contents:** typed operator implementation, parameter binding, dialect adapter, field lineage, relationship-use manifest, grain analysis, authorization checks, deterministic aliasing and structured error codes.

**Enforcement:** only compiler-created artifacts can reach execution. The SQL validator parses all statement scopes, including CTEs and subqueries. It checks allowed objects/functions, operation shape and manifest consistency. It must not claim to prove semantic equivalence of arbitrary SQL. Unsupported transformations fail closed.

**Limit:** the strongest remaining risks are incorrect approved metadata, mistaken intent and source-data drift. Compilation cannot prove the owner's definition of “active” is the correct business definition.

### 4.12 Security and execution policy

**What:** trusted identity, metadata authorization, source restrictions, result controls and bounded read-only execution.

**Why:** the agent must not grant itself access by naming a table, selecting a tenant or supplying a policy ID. Aggregate existence can itself reveal protected information.

**Minimum contents:** data classification, entitled roles, permitted fields/operations, server-side identity context, row restriction mechanism, time/scan/result limits, function allowlist and audit rules. Never invent a tenant field absent from the source schema.

**Enforcement:** database grants and applicable row policies or secured views back application policy. Runtime credentials must lack elevated bypass privileges. Apply visibility to every relation used, including contract existence checks. If business users may test contract eligibility without reading raw contracts, provide a separately authorized eligibility object with that deliberate policy.

### 4.13 Provenance, freshness and answer presentation

**What:** an answer envelope records interpretation, rules, query identity, execution timing, scope and completeness.

**Why:** users need to know what was counted, whether results were truncated, and which definition produced a surprising result.

**Minimum contents:** metric/base grain, filters, source scope, approved assumptions, catalog/mapping/policy/compiler versions, data snapshot or execution time, result completeness, executed-query ID and relevant warnings. Store sensitive values only where authorized.

**Enforcement:** present database results faithfully. Do not label a limited page “all records.” Do not compute a global count over a page. If the database lacks snapshot retention, record that repeating the same SQL later can return different data.

### 4.14 Ownership, publication, change control and evidence

**What:** an authoring and release process for the catalog, separate from query execution.

**Why:** semantic changes can alter answers without changing application code. An unchecked spreadsheet cell must not become executable policy.

**Minimum contents:** draft/reviewed/published/deprecated lifecycle, business and technical owners, source evidence, effective interval, content hash, schema version, compatibility notes and migration tests.

**Enforcement:** publication validates schema, references, physical bindings, definitions, key evidence, mapping coverage and regression cases. Publish an immutable snapshot atomically. Existing requests pin it; urgent policy revocation takes precedence and invalidates affected artifacts. Draft objects cannot execute in production.

Changing an active definition, a join population rule or a source scope is a semantic change even if the metadata field names stay the same. It requires answer-impact review. Display-name changes that preserve semantics need less review.

## 5. Storage, graph and orchestration constitution

Persist structured metadata in **SQLite**, as requested, using normalized entity, field, value, relationship and metric tables plus validated JSON expression payloads. Publish immutable catalog revisions and create an in-memory directed adjacency index at load time. Versioned JSON exports support code review and backup; they are not a second editable source of truth. Operational queries execute against **Azure SQL Database** using T-SQL. A graph database is optional infrastructure, not a prerequisite for graph-shaped metadata.

Keep three graphs distinct:

1. The **relationship graph** connects business entities through approved contracts.
2. The **query plan graph** represents scans, filters, existence checks, joins and aggregates for one request.
3. The **workflow graph** represents interpretation, clarification, validation and execution stages. LangGraph concerns this third graph.

For V1, ordinary application functions and persisted request state are sufficient for a bounded interpret–resolve–compile–execute workflow. Adopt LangGraph when durable pause/resume, richer branching and checkpointed workflows justify its operational cost. Node functions must call the same domain interfaces; business rules must not move into orchestration edges.

Agent Skills supplies procedural packaging and progressive context loading. Its specification supports instructions and on-demand resources; the chosen separation of runtime semantics and enforcement is an application design recommendation. [Agent Skills specification](https://agentskills.io/specification)

LangGraph describes itself as an orchestration runtime for stateful workflows and supports mixing deterministic and agentic steps. Its presence does not supply SQL business semantics. [LangGraph overview](https://docs.langchain.com/oss/python/langgraph/overview)

## 6. Minimum release requirements for the supplied domain

| Requirement | Acceptance evidence |
|---|---|
| Producer identity is defined | Shared-key assurance or explicit namespace/crosswalk mappings across each permitted relationship. |
| Record grain is defined | Verified license/appointment identities or an explicit physical-row metric. |
| Active means one approved thing per entity | Predicate definitions plus null, inactive and future-termination fixtures. |
| Pet is resolved for every included source | Source-specific value bindings with typed literals and ambiguity handling. |
| Contract scope is explicit | Agent-only, agency-only or either-source scope with ownership semantics. |
| Detail-query scope is explicit | License termination date is confirmed; the reviewed example distinguishes license-row filtering from selecting a producer cohort and expanding all its active licenses. “Individual” is treated as detail-row wording unless legal person classification is explicitly requested. |
| Membership preserves counts | Multiple matching contracts do not increase either base-record count. |
| Enrichment preserves eligible producers | A producer with no active license remains present when preservation is requested. |
| Source permissions apply consistently | Positive and negative access tests for base, child and existence relations. |
| Answers are reproducible at the rule level | Pinned versions, canonical plan, bindings and query manifest. |

The four supplied tables can express all three question patterns under the license-detail interpretation; no additional producer master is required. Real status/product values, record keys, relationship identity and contract scope still need catalog definitions before production execution. Build the catalog, resolver, compiler and tests against synthetic fixtures, then publish the validated production bindings. If “individual” is later defined as a legal person category, add an authoritative classification source instead of inferring it from a table name.

## 7. Evolution without changing the central contract

V1 supports detail rows, base-record counts, simple dimensions, typed filters, existence/absence and a single governed child expansion. Later releases can add historical entities, new value providers, vector retrieval, additional dialects, distributed execution and broader measures through versioned operators and contracts.

The stable boundary is `question -> semantic query -> validated plan -> compiled artifact -> result`. Storage, search technology and orchestration can change behind that boundary. This reduces the likelihood of fundamental redesign; it does not eliminate future migrations when business requirements or source semantics change.
