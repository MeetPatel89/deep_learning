-- Enterprise v2 SQLite PUBLISHED SNAPSHOT bootstrap schema.
-- Shared authoring authority uses catalog-postgresql.sql.
-- This file never runs against operational Azure SQL.
-- Enable foreign keys on EACH connection before beginning a transaction.
-- Requires SQLite JSON functions. Publisher validates all payload schemas,
-- specialized object kinds, lifecycle, field ownership and business rules.
PRAGMA foreign_keys = ON;

CREATE TABLE catalog_release (
    release_id TEXT PRIMARY KEY,
    schema_version INTEGER NOT NULL CHECK (schema_version > 0),
    status TEXT NOT NULL CHECK (status IN ('draft','reviewed','published','retired')),
    content_sha256 TEXT,
    created_at TEXT NOT NULL,
    published_at TEXT,
    CHECK (status <> 'published' OR
           (content_sha256 IS NOT NULL AND published_at IS NOT NULL))
);
CREATE TABLE catalog_object (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    object_id TEXT NOT NULL,
    object_kind TEXT NOT NULL CHECK (object_kind IN
      ('entity','field','value_domain','canonical_value','relationship',
       'predicate','metric','business_domain','concept','query_template')),
    label TEXT NOT NULL,
    description TEXT NOT NULL,
    owner TEXT NOT NULL,
    access_policy_ref TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('draft','reviewed','published','deprecated')),
    provenance_json TEXT NOT NULL CHECK (json_valid(provenance_json)),
    PRIMARY KEY (release_id, object_id)
);
CREATE TABLE data_source (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    source_id TEXT NOT NULL,
    provider_kind TEXT NOT NULL,
    dialect TEXT NOT NULL,
    connection_config_ref TEXT NOT NULL,
    schema_fingerprint TEXT NOT NULL,
    auth_policy_ref TEXT NOT NULL,
    freshness_json TEXT NOT NULL CHECK (json_valid(freshness_json)),
    PRIMARY KEY (release_id, source_id)
);
CREATE TABLE entity (
    release_id TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    binding_kind TEXT NOT NULL CHECK (binding_kind IN ('physical','derived')),
    connection_ref TEXT,
    physical_schema TEXT,
    physical_object TEXT,
    derived_plan_json TEXT CHECK (derived_plan_json IS NULL OR json_valid(derived_plan_json)),
    row_semantics_json TEXT NOT NULL CHECK (json_valid(row_semantics_json)),
    physical_row_key_json TEXT NOT NULL CHECK (json_valid(physical_row_key_json)),
    business_identity_json TEXT NOT NULL CHECK (json_valid(business_identity_json)),
    versioning_json TEXT NOT NULL CHECK (json_valid(versioning_json)),
    uniqueness_evidence_json TEXT NOT NULL CHECK (json_valid(uniqueness_evidence_json)),
    identity_namespace TEXT NOT NULL,
    temporal_json TEXT NOT NULL CHECK (json_valid(temporal_json)),
    access_policy_ref TEXT NOT NULL,
    PRIMARY KEY (release_id, entity_id),
    FOREIGN KEY (release_id, entity_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, connection_ref)
      REFERENCES data_source(release_id, source_id),
    CHECK ((binding_kind = 'physical' AND connection_ref IS NOT NULL
            AND physical_schema IS NOT NULL AND physical_object IS NOT NULL
            AND derived_plan_json IS NULL)
        OR (binding_kind = 'derived' AND derived_plan_json IS NOT NULL
            AND connection_ref IS NULL AND physical_schema IS NULL
            AND physical_object IS NULL))
);
CREATE TABLE value_domain (
    release_id TEXT NOT NULL,
    domain_id TEXT NOT NULL,
    normalization_json TEXT NOT NULL CHECK (json_valid(normalization_json)),
    resolution_policy_json TEXT NOT NULL CHECK (json_valid(resolution_policy_json)),
    PRIMARY KEY (release_id, domain_id),
    FOREIGN KEY (release_id, domain_id)
      REFERENCES catalog_object(release_id, object_id)
);
CREATE TABLE field (
    release_id TEXT NOT NULL,
    field_id TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    physical_column TEXT,
    expression_json TEXT CHECK (expression_json IS NULL OR json_valid(expression_json)),
    physical_type TEXT NOT NULL,
    semantic_type TEXT NOT NULL,
    nullable INTEGER NOT NULL CHECK (nullable IN (0,1)),
    null_meaning TEXT NOT NULL,
    roles_json TEXT NOT NULL CHECK (json_valid(roles_json)),
    operators_json TEXT NOT NULL CHECK (json_valid(operators_json)),
    aliases_json TEXT NOT NULL CHECK (json_valid(aliases_json)),
    sensitivity TEXT NOT NULL,
    domain_id TEXT,
    PRIMARY KEY (release_id, field_id),
    FOREIGN KEY (release_id, field_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, entity_id) REFERENCES entity(release_id, entity_id),
    FOREIGN KEY (release_id, domain_id) REFERENCES value_domain(release_id, domain_id),
    UNIQUE (release_id, entity_id, physical_column),
    CHECK ((physical_column IS NOT NULL AND expression_json IS NULL)
        OR (physical_column IS NULL AND expression_json IS NOT NULL))
);
CREATE TABLE canonical_value (
    release_id TEXT NOT NULL,
    value_id TEXT NOT NULL,
    domain_id TEXT NOT NULL,
    PRIMARY KEY (release_id, value_id),
    FOREIGN KEY (release_id, value_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, domain_id) REFERENCES value_domain(release_id, domain_id)
);
CREATE TABLE value_alias (
    release_id TEXT NOT NULL,
    value_id TEXT NOT NULL,
    locale TEXT NOT NULL,
    normalized_alias TEXT NOT NULL,
    PRIMARY KEY (release_id, value_id, locale, normalized_alias),
    FOREIGN KEY (release_id, value_id)
      REFERENCES canonical_value(release_id, value_id)
    -- Intentionally permits the same alias for different values.
    -- Resolver reports ambiguity; publisher prevents silent last-write wins.
);
CREATE INDEX value_alias_lookup
  ON value_alias(release_id, locale, normalized_alias);
CREATE TABLE value_binding (
    release_id TEXT NOT NULL,
    binding_id TEXT NOT NULL,
    value_id TEXT NOT NULL,
    field_id TEXT NOT NULL,
    literal_type TEXT NOT NULL CHECK (literal_type IN
      ('string','integer','decimal','boolean','date','timestamp')),
    literal_json TEXT NOT NULL CHECK (json_valid(literal_json)),
    valid_from TEXT NOT NULL,
    valid_to TEXT,
    PRIMARY KEY (release_id, binding_id),
    FOREIGN KEY (release_id, value_id)
      REFERENCES canonical_value(release_id, value_id),
    FOREIGN KEY (release_id, field_id) REFERENCES field(release_id, field_id),
    CHECK (valid_to IS NULL OR valid_from < valid_to)
);
CREATE INDEX value_binding_lookup
  ON value_binding(release_id, value_id, field_id, valid_from);
CREATE TABLE relationship (
    release_id TEXT NOT NULL,
    relationship_id TEXT NOT NULL,
    source_entity_id TEXT NOT NULL,
    target_entity_id TEXT NOT NULL,
    source_role TEXT NOT NULL,
    target_role TEXT NOT NULL,
    key_pairs_json TEXT NOT NULL CHECK (json_valid(key_pairs_json)),
    cardinality_json TEXT NOT NULL CHECK (json_valid(cardinality_json)),
    required_predicates_json TEXT NOT NULL CHECK (json_valid(required_predicates_json)),
    identity_json TEXT NOT NULL CHECK (json_valid(identity_json)),
    temporal_json TEXT NOT NULL CHECK (json_valid(temporal_json)),
    PRIMARY KEY (release_id, relationship_id),
    FOREIGN KEY (release_id, relationship_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, source_entity_id) REFERENCES entity(release_id, entity_id),
    FOREIGN KEY (release_id, target_entity_id) REFERENCES entity(release_id, entity_id)
);
CREATE INDEX relationship_outgoing
  ON relationship(release_id, source_entity_id);
CREATE TABLE relationship_operation (
    release_id TEXT NOT NULL,
    operation_id TEXT NOT NULL,
    relationship_id TEXT NOT NULL,
    operator TEXT NOT NULL CHECK (operator IN
      ('exists','not_exists','enrich_left','expand_left','enrich_inner',
       'expand_inner','temporal_lookup','bridge_membership','bridge_allocate')),
    contract_json TEXT NOT NULL CHECK (json_valid(contract_json)),
    PRIMARY KEY (release_id, operation_id),
    FOREIGN KEY (release_id, relationship_id)
      REFERENCES relationship(release_id, relationship_id)
);
CREATE TABLE predicate (
    release_id TEXT NOT NULL,
    predicate_id TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    expression_json TEXT NOT NULL CHECK (json_valid(expression_json)),
    purpose TEXT NOT NULL CHECK (purpose IN
      ('business','source_restriction','security_restriction')),
    PRIMARY KEY (release_id, predicate_id),
    FOREIGN KEY (release_id, predicate_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, entity_id) REFERENCES entity(release_id, entity_id)
);
CREATE TABLE metric (
    release_id TEXT NOT NULL,
    metric_id TEXT NOT NULL,
    base_entity_id TEXT NOT NULL,
    definition_json TEXT NOT NULL CHECK (json_valid(definition_json)),
    PRIMARY KEY (release_id, metric_id),
    FOREIGN KEY (release_id, metric_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, base_entity_id) REFERENCES entity(release_id, entity_id)
);
CREATE TABLE verified_example (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    example_id TEXT NOT NULL,
    question TEXT NOT NULL,
    semantic_query_json TEXT NOT NULL CHECK (json_valid(semantic_query_json)),
    reference_sql TEXT,
    fixture_id TEXT NOT NULL,
    expected_json TEXT NOT NULL CHECK (json_valid(expected_json)),
    review_status TEXT NOT NULL CHECK (review_status IN ('draft','approved','rejected')),
    reviewer TEXT,
    PRIMARY KEY (release_id, example_id)
);
CREATE TABLE assertion (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    assertion_id TEXT NOT NULL,
    subject_id TEXT NOT NULL,
    requirement_json TEXT NOT NULL CHECK (json_valid(requirement_json)),
    evidence_json TEXT NOT NULL CHECK (json_valid(evidence_json)),
    valid_until TEXT,
    failure_action_json TEXT NOT NULL CHECK (json_valid(failure_action_json)),
    PRIMARY KEY (release_id, assertion_id)
    -- subject may be an object, an operation, or a source identity namespace;
    -- publisher resolves the typed subject in requirement_json.
);

-- Domain and context model. Dataset membership may span several domains.
CREATE TABLE business_domain (
    release_id TEXT NOT NULL,
    domain_id TEXT NOT NULL,
    routing_summary TEXT NOT NULL,
    vocabulary_json TEXT NOT NULL CHECK (json_valid(vocabulary_json)),
    coverage_json TEXT NOT NULL CHECK (json_valid(coverage_json)),
    steward TEXT NOT NULL,
    PRIMARY KEY (release_id, domain_id),
    FOREIGN KEY (release_id, domain_id)
      REFERENCES catalog_object(release_id, object_id)
);
CREATE TABLE domain_membership (
    release_id TEXT NOT NULL,
    domain_id TEXT NOT NULL,
    object_id TEXT NOT NULL,
    membership_role TEXT NOT NULL,
    PRIMARY KEY (release_id, domain_id, object_id),
    FOREIGN KEY (release_id, domain_id) REFERENCES business_domain(release_id, domain_id),
    FOREIGN KEY (release_id, object_id) REFERENCES catalog_object(release_id, object_id)
);
CREATE TABLE semantic_concept (
    release_id TEXT NOT NULL,
    concept_id TEXT NOT NULL,
    definition_json TEXT NOT NULL CHECK (json_valid(definition_json)),
    PRIMARY KEY (release_id, concept_id),
    FOREIGN KEY (release_id, concept_id) REFERENCES catalog_object(release_id, object_id)
);
CREATE TABLE semantic_edge (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    edge_id TEXT NOT NULL,
    from_object_id TEXT NOT NULL,
    to_object_id TEXT NOT NULL,
    edge_kind TEXT NOT NULL CHECK (edge_kind IN
      ('depends_on','lineage','concept_association','equivalence','taxonomy')),
    review_status TEXT NOT NULL CHECK (review_status IN ('proposed','approved')),
    properties_json TEXT NOT NULL CHECK (json_valid(properties_json)),
    PRIMARY KEY (release_id, edge_id),
    FOREIGN KEY (release_id, from_object_id) REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, to_object_id) REFERENCES catalog_object(release_id, object_id)
    -- These edges never authorize an executable SQL relationship by themselves.
);
CREATE INDEX semantic_edge_outgoing ON semantic_edge(release_id, from_object_id, edge_kind);
CREATE INDEX semantic_edge_incoming ON semantic_edge(release_id, to_object_id, edge_kind);
CREATE TABLE query_template (
    release_id TEXT NOT NULL,
    template_id TEXT NOT NULL,
    parameter_schema_json TEXT NOT NULL CHECK (json_valid(parameter_schema_json)),
    plan_json TEXT NOT NULL CHECK (json_valid(plan_json)),
    capability_requirements_json TEXT NOT NULL CHECK (json_valid(capability_requirements_json)),
    PRIMARY KEY (release_id, template_id),
    FOREIGN KEY (release_id, template_id) REFERENCES catalog_object(release_id, object_id)
);
CREATE TABLE capability (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    capability_id TEXT NOT NULL,
    operator_name TEXT NOT NULL,
    operator_version INTEGER NOT NULL CHECK (operator_version > 0),
    dialect TEXT NOT NULL,
    schema_json TEXT NOT NULL CHECK (json_valid(schema_json)),
    requirements_json TEXT NOT NULL CHECK (json_valid(requirements_json)),
    PRIMARY KEY (release_id, capability_id)
);
CREATE TABLE domain_capability (
    release_id TEXT NOT NULL,
    domain_id TEXT NOT NULL,
    capability_id TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('disabled','evaluation','enabled')),
    evidence_json TEXT NOT NULL CHECK (json_valid(evidence_json)),
    PRIMARY KEY (release_id, domain_id, capability_id),
    FOREIGN KEY (release_id, domain_id) REFERENCES business_domain(release_id, domain_id),
    FOREIGN KEY (release_id, capability_id) REFERENCES capability(release_id, capability_id)
);

-- Authority control tables. Their schemas are retained for representation parity,
-- but their rows are NOT copied into the immutable SQLite semantic snapshot.
-- The snapshot checksum/manifest lives in the authority and external manifest.
-- This avoids embedding a file's own checksum inside the checksummed file.
CREATE TABLE projection_artifact (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    projection_id TEXT NOT NULL,
    projection_kind TEXT NOT NULL CHECK (projection_kind IN
      ('sqlite','search','graph','examples','evaluation')),
    state TEXT NOT NULL CHECK (state IN ('building','ready','failed','retired')),
    locator TEXT NOT NULL,
    content_hash TEXT,
    configuration_json TEXT NOT NULL CHECK (json_valid(configuration_json)),
    PRIMARY KEY (release_id, projection_id),
    CHECK (state <> 'ready' OR content_hash IS NOT NULL)
);
CREATE TABLE release_manifest (
    manifest_id TEXT PRIMARY KEY,
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    manifest_version INTEGER NOT NULL CHECK (manifest_version > 0),
    snapshot_projection_id TEXT NOT NULL,
    search_projection_id TEXT NOT NULL,
    graph_projection_id TEXT NOT NULL,
    application_config_json TEXT NOT NULL CHECK (json_valid(application_config_json)),
    manifest_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE (release_id, manifest_id),
    FOREIGN KEY (release_id, snapshot_projection_id)
      REFERENCES projection_artifact(release_id, projection_id),
    FOREIGN KEY (release_id, search_projection_id)
      REFERENCES projection_artifact(release_id, projection_id),
    FOREIGN KEY (release_id, graph_projection_id)
      REFERENCES projection_artifact(release_id, projection_id)
    -- Publisher checks kind, readiness, content and application compatibility.
);
CREATE TABLE active_manifest (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    manifest_id TEXT NOT NULL REFERENCES release_manifest(manifest_id)
    -- Runtime uses the authority's active pointer, then pins a local snapshot.
);
