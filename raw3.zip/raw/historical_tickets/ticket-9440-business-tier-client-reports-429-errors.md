---
doc_id: TICKET-9440
title: Business-Tier Client Reports 429 Errors
doc_type: historical_ticket
service_id: svc_internal_api_gateway
owner_group: Service Desk L1
visibility: internal
status: closed
created_at: "2026-06-19T08:30:00"
updated_at: "2026-06-19T12:15:00"
related_records:
  - INC-1302
  - KI-307
  - RUNBOOK-API-005
source_facts:
  - KI-307
  - svc_internal_api_gateway
difficulty_tags:
  - historical-resolution
  - entitlement-check
servicenow:
  table: incident
  number: INC009440
  parent_incident: INC001302
  state: Closed
  impact: 2
  urgency: 2
  priority: 3
  priority_label: "3 - Moderate"
  category: Network
  subcategory: API Gateway
  business_service: Client API Access
  cmdb_ci: Internal API Gateway
  assignment_group: Platform Engineering
  opened_by_group: Service Desk L1
  contact_type: Email
  related_known_issue: KI00307
  visibility: internal
  contains_customer_safe_wording: false
---

# Business-Tier Client Reports 429 Errors

## Record details

| Field | Value |
| --- | --- |
| Table | incident |
| Number | INC009440 |
| Parent incident | INC001302 |
| State | Closed |
| Impact | 2 |
| Urgency | 2 |
| Priority | 3 - Moderate |
| Category | Network |
| Subcategory | API Gateway |
| Business service | Client API Access |
| Configuration item | Internal API Gateway |
| Assignment group | Platform Engineering |
| Opened by group | Service Desk L1 |
| Contact type | Email |
| Related known issue | KI00307 |
| Visibility | internal |
| Contains customer-safe wording | false |

## Ticket summary

TICKET-9440 was opened for a Business-tier client reporting 429 errors after the rate-limit policy deployment. The symptoms matched KI-307 and were linked to INC-1302.

The ticket is useful for future retrieval because it describes the known issue using ticket language: Business-tier client throttled, unexpected 429, and policy review needed.

## User report

The client reported that API calls to an affected endpoint returned HTTP 429 Too Many Requests after the rate-limit policy deployment. The client stated that the traffic burst should have been within their expected tier allowance.

Business-tier client reported 429 errors after the rate-limit policy deployment.

## Triage notes

Service Desk L1 collected client ID, endpoint, timestamp, and tier. No secrets, tokens, or credentials were placed in the ticket.

Service Desk L1 checked the recent change calendar and found CHG-2420. Because the issue occurred after the rate-limit policy deployment and the client was Business-tier, the ticket was linked to KI-307 and escalated to Platform Engineering through RUNBOOK-API-005.

## Related incident or known issue

Related records:

- INC-1302: Business-Tier API Clients Receive 429 Errors After Rate-Limit Policy Deployment.
- KI-307: API Clients Receive Unexpected 429 Responses After Rate-Limit Policy Update.
- RUNBOOK-API-005: API Gateway 429 Investigation Runbook.

The incident notes indicated that Business-tier clients were affected more often than Enterprise clients after CHG-2420.

## Resolution

Platform Engineering found an applied policy mismatch. The applied rate-limit policy was adjusted after Platform Engineering compared the gateway policy against customer entitlement.

After adjustment, the client no longer saw the unexpected 429 pattern for the reported endpoint during the follow-up check.

## Customer-facing update

Customer-facing update used the approved customer-safe summary from KI-307.

The approved wording was:

"We are reviewing the applied API traffic policy for the affected client."

The closure update did not state that an internal policy mistake occurred.

## Closure notes

Closed at 2026-06-19T12:15:00. Closure reason: known issue matched, Platform Engineering adjusted the applied policy, and follow-up checks showed the unexpected 429 pattern had stopped.

The ticket remains linked to KI-307 for future retrieval when Business-tier clients report unexpected 429 responses after an API Gateway policy deployment.

## Related records

- INC-1302: Business-Tier API Clients Receive 429 Errors After Rate-Limit Policy Deployment.
- KI-307: API Clients Receive Unexpected 429 Responses After Rate-Limit Policy Update.
- RUNBOOK-API-005: API Gateway 429 Investigation Runbook.
