# Dataset Comparison MCP Server

A Python stdio MCP server that compares every row of two datasets and produces
colored Excel reports. It supports Azure SQL with interactive MFA, CSV, Parquet,
Excel, and inline JSON. Large comparisons spill to hash partitions on disk.

## Install and run

Install [uv](https://docs.astral.sh/uv/getting-started/installation/) and Python 3.12 or newer.
From this directory:

```sh
uv sync
uv run qa-mcp-server
```

The process waits for an MCP client on stdin; stdout carries only MCP messages.
`uv run python -m qa_mcp_server` and `uv run python main.py` also work.

For SQL, install **Microsoft ODBC Driver 18 for SQL Server** on the Windows machine
running the server. `ActiveDirectoryInteractive` opens the Microsoft Entra login/MFA
dialog there. Supply `username` as a UPN hint if needed. File and inline sources do
not require an installed ODBC runtime.

See [Microsoft's ODBC authentication documentation](https://learn.microsoft.com/en-us/sql/connect/odbc/using-azure-active-directory?view=sql-server-ver17)
and [driver downloads](https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server).

## MCP configuration on Windows

Use the following `mcpServers` configuration in Cursor's `.cursor/mcp.json` or Claude
Desktop's `claude_desktop_config.json`. Replace the paths with your checkout and uv
installation; `uv.exe` can be used directly if it is on the client's PATH.

```json
{
  "mcpServers": {
    "dataset-comparison": {
      "command": "C:\\Users\\you\\.local\\bin\\uv.exe",
      "args": [
        "--directory", "C:\\projects\\qa_mcp_server",
        "run", "qa-mcp-server"
      ]
    }
  }
}
```

All source and output paths refer to the server's filesystem. Absolute paths are
recommended. Relative paths resolve against the project directory in this config.

## Tools

| Tool | Inputs | Result |
| --- | --- | --- |
| `compare_datasets` | `expected`, `actual`, optional `primary_keys`, `compare_options`, `output_options` | Counts, per-column mismatches, duplicate counts, completeness check, report paths, up to ten difference samples |
| `inspect_dataset` | `source`, optional `sample_size` (0–100, default 5) | Full row count, schema and sample; SQL may trigger MFA |
| `test_sql_connection` | `server`, `database`, optional `username`, `driver`, `timeout` | Runs `SELECT 1` and caches the authenticated connection |

Connections are cached for the server process by server, database, username and
driver. Queries sharing a connection are serialized, and cursors close after each
query. Restart the server to clear a stale connection or authenticate again.
Login and query timeout defaults to 30 seconds; queries execute with autocommit.

### Source shapes

```json
{"type": "sql", "server": "example.database.windows.net", "database": "QA", "username": "you@example.com", "query": "SELECT id, amount FROM dbo.Expected"}
{"type": "sql", "server": "example.database.windows.net", "database": "QA", "query_file": "C:/queries/expected.sql", "timeout": 120}
{"type": "csv", "path": "C:/data/expected.csv", "delimiter": ",", "encoding": "utf-8", "has_header": true}
{"type": "parquet", "path": "C:/data/actual.parquet"}
{"type": "excel", "path": "C:/data/actual.xlsx", "sheet": "Data"}
{"type": "inline", "rows": [{"id": 1, "amount": 12.50}]}
```

SQL requires exactly one of `query` and `query_file`. Scripts must return one tabular
result set and must not contain client-only `GO` batch separators. UTF-8 BOMs are
supported in query files. Excel sheet indices are 1-based; omitting `sheet` selects
the first sheet. CSV `null_values` accepts a string, list, or per-column mapping.
CSV types are inferred across the file; non-UTF-8 CSVs are transcoded to a temporary
UTF-8 file before streaming.

### Comparison example

```json
{
  "expected": {"type": "csv", "path": "C:/data/expected.csv"},
  "actual": {"type": "parquet", "path": "C:/data/actual.parquet"},
  "primary_keys": ["id"],
  "compare_options": {
    "column_mapping": {"name": "customer_name"},
    "ignore_columns": ["loaded_at"],
    "numeric_tolerance": 0.01,
    "trim_strings": true,
    "case_insensitive": true,
    "treat_null_as_equal": true,
    "memory_budget_mb": 1024
  },
  "output_options": {
    "output_dir": "C:/reports",
    "max_rows_per_file": 100000,
    "include_matched_rows": false,
    "max_total_report_rows": 500000
  }
}
```

`column_mapping` maps expected names to actual names. Keys use expected names.
Keys may also be supplied through `compare_options.primary_keys`; contradictory
values are rejected. Ignored keys, missing keys, ambiguous mappings, and unknown
options are rejected. Input column names beginning with `__qa_` are reserved.

Numeric columns use a common numeric type; Decimal mixed with float becomes Float64.
Mixed scalar types become strings, so numeric tolerance applies only to numeric
columns. Nested values become canonical JSON strings. Times, durations and
nanosecond timestamps use exact string representations to preserve precision through
Python row iteration. String normalization applies
to values and keys, while reports retain original string values. Key matching is
exact after normalization; numeric tolerance applies to compared non-key values.

Repeated keys pair by occurrence in source order. All occurrences of repeated keys
also appear in `Duplicate_Keys`; these diagnostic entries do not add to status counts.
Order duplicate keys explicitly in SQL if deterministic pairing is required.
With null equality disabled, null keys never pair and paired null values mismatch.
Columns absent from one schema are reported as schema differences and cannot hide
behind equal nulls. Empty inline datasets inherit the other side's schema.

Omitting keys (or supplying `[]`) selects **multiset** mode. Every normalized column
is part of the identity, and repeated identical rows have occurrence counts. This
mode reports missing and extra occurrences, with zero value mismatches. Numeric
tolerance does not merge nearby rows in multiset mode.

## Completeness and memory

CSV, Parquet, and SQL are loaded in batches. Once measured input size crosses a
quarter of the memory budget, resident batches and all later batches spill to
temporary Parquet. This leaves space for normalization and joins. Both sides use
the same harmonized schema and normalized key hash before bucket assignment.
`num_partitions` forces disk partitioning (including `1`); otherwise the planner
chooses a count from measured size. Oversized or skewed buckets use SQLite sorting
and occurrence joins on disk, including a single key repeated across many rows.

The budget is a planning target, not a hard process-memory limit: a source batch,
Polars runtime allocations, and buffered report records still require memory.
Excel's reader materializes the selected sheet, and inline rows arrive in memory.
Spill files require local free disk space and are deleted after success or failure.
Partition row totals are verified, followed by these independent accounting checks:

```text
matched + mismatched + missing_in_actual = expected_row_count
matched + mismatched + extra_in_actual   = actual_row_count
```

A failed check raises an error and removes that run's incomplete output directory.

## Reports

Each run creates its own `comparison_*` directory under `output_dir`, so existing
reports are preserved. It contains:

- `report_001.xlsx`, followed by additional numbered workbooks as needed. The first
  contains `Summary` with options, counts and all artifact paths.
- `Mismatches`, `Missing_in_Actual`, `Extra_in_Actual`, and `Duplicate_Keys` sheets
  when their rows are present. `Matched` is optional. Paired value columns are
  adjacent; matching values are green, and different values are bold red.
- `mismatches.parquet/part_*.parquet`: a complete typed difference dataset, including
  duplicate diagnostics, regardless of Excel caps. Expected and actual fields use
  `expected.` and `actual.` prefixes. Identical inputs produce an empty typed shard.
- `summary.json`: the same JSON summary returned by the tool.

`max_rows_per_file` counts data rows across all sheets in a workbook, excludes
headers and Summary, and defaults to 100,000 (maximum 1,048,575). Each split repeats
its sheet headers. `max_total_report_rows` caps Excel data rows across all workbooks;
zero creates a Summary-only workbook. Counts and Parquet always remain complete.
Multiset report rows include `occurrences`, so one report row can represent many
input rows. Excel's cell-size and numeric-precision limits apply; large integers
and decimals are written as text, and Parquet retains their typed values.

To load the full dump with Polars:

```python
import polars as pl

differences = pl.scan_parquet("C:/reports/comparison_abc/mismatches.parquet/*.parquet")
```

## Development

```sh
uv sync --group dev
uv run pytest -q
uv run ruff check .
uv run ruff format --check .
```

Tests use generated datasets and mocked SQL connections. They cover every source,
duplicate and multiset accounting, normalization, coercion, nulls, partition parity,
skewed buckets, Excel splitting and colors, complete capped dumps, and an MCP stdio
client/server round trip. Live Azure MFA requires a Windows machine and credentials.
