"""Explicit Git mutations and reviewable PR preparation with test provenance."""

from typing import Any

from data_mcp_core.guards import require
from data_mcp_core.results import bounded_result, redact

from synapse_mcp_server.branch_execution import repository_identity
from synapse_mcp_server.branch_package import digest
from synapse_mcp_server.config import RepositoryBackend
from synapse_mcp_server.repository import RevisionConflict


class GitTools:
    def list_git_branches(
        self,
        workspace: str,
        repository_backend: RepositoryBackend | None = None,
        include_remote: bool = False,
    ) -> dict[str, Any]:
        """Discover repository branches without live workspace discovery."""
        self.workspace(workspace, "git")
        repository = self.repository(workspace, repository_backend)
        return bounded_result(
            {
                "branches": repository.branches(),
                "collaboration_branch": repository.config.collaboration_branch,
                "publish_branch": repository.config.publish_branch,
                "remote_branches": (
                    repository.remote_branches()
                    if repository.backend == "local"
                    else repository.branches()
                )
                if include_remote
                else [],
            }
        )

    def create_git_branch(
        self,
        workspace: str,
        branch: str,
        expected_revision: str,
        base_branch: str | None = None,
        repository_backend: RepositoryBackend | None = None,
        dry_run: bool = True,
    ) -> dict[str, Any]:
        """Create a feature branch from an expected base revision; requires allow_git_write."""
        require(self.workspace(workspace, "git"), "allow_git_write")
        repository = self.repository(workspace, repository_backend)
        repository.writable(branch)
        base = base_branch or repository.config.collaboration_branch
        repository.check_revision(base, expected_revision)
        if dry_run:
            return {"dry_run": True, "branch": branch, "base": base, "revision": expected_revision}
        return repository.create_branch(branch, base, expected_revision)

    def diff_git_branch(
        self,
        workspace: str,
        branch: str,
        base_branch: str | None = None,
        repository_backend: RepositoryBackend | None = None,
    ) -> dict[str, Any]:
        """Compare Synapse artifact JSON with a base branch, including local uncommitted edits."""
        self.workspace(workspace, "git")
        return bounded_result(
            self.repository(workspace, repository_backend).diff(branch, base_branch)
        )

    def commit_git_branch(
        self,
        workspace: str,
        branch: str,
        expected_revision: str,
        message: str,
        changes: dict[str, Any] | None = None,
        repository_backend: RepositoryBackend | None = None,
        dry_run: bool = True,
        paths: list[str] | None = None,
    ) -> dict[str, Any]:
        """Commit artifact edits; optional paths preserve other staged artifacts. GitHub requires
        a changes map of artifact paths to JSON objects (null deletes). Rejects stale heads.
        """
        require(self.workspace(workspace, "git"), "allow_git_write")
        repository = self.repository(workspace, repository_backend)
        repository.writable(branch)
        repository.check_revision(branch, expected_revision)
        if changes:
            repository.changes(changes)
        if dry_run:
            return bounded_result(
                {
                    "dry_run": True,
                    "branch": branch,
                    "revision": expected_revision,
                    "message": message,
                    "changes": changes,
                    "paths": paths,
                    "diff": repository.diff(branch),
                }
            )
        return bounded_result(repository.commit(branch, expected_revision, message, changes, paths))

    def push_git_branch(
        self,
        workspace: str,
        branch: str,
        expected_revision: str,
        expected_remote_revision: str,
        repository_backend: RepositoryBackend | None = None,
        dry_run: bool = True,
    ) -> dict[str, Any]:
        """Push a feature branch with expected local and remote heads (empty remote revision for
        a new branch). Rejects overwrites. GitHub API commits already reside on the remote.
        """
        require(self.workspace(workspace, "git"), "allow_git_write")
        repository = self.repository(workspace, repository_backend)
        repository.writable(branch)
        repository.check_revision(branch, expected_revision)
        if dry_run:
            return {
                "dry_run": True,
                "branch": branch,
                "revision": expected_revision,
                "expected_remote_revision": expected_remote_revision,
            }
        return repository.push(branch, expected_revision, expected_remote_revision)

    def prepare_git_pr(
        self,
        workspace: str,
        branch: str,
        title: str,
        summary: str = "",
        repository_backend: RepositoryBackend | None = None,
    ) -> dict[str, Any]:
        """Prepare a PR into the collaboration branch, recording matching and stale test results.
        Creates no PR. A passed-test claim requires unchanged artifact contents and test profile.
        """
        settings = self.workspace(workspace, "git")
        repository = self.repository(workspace, repository_backend)
        if branch in {
            repository.config.collaboration_branch,
            repository.config.publish_branch,
            "workspace_publish",
        }:
            raise PermissionError("PR source must be a feature branch")
        snapshot = repository.snapshot(branch)
        diff = repository.diff(branch)
        if diff["content_fingerprint"] != snapshot.fingerprint or diff["commit"] != snapshot.commit:
            raise RevisionConflict("Branch changed while preparing the PR")
        tests = []
        for record in self.execution_store.list(workspace):
            provenance = record["provenance"]
            if provenance["branch"] != branch:
                continue
            profile = settings.test_profiles.get(provenance["test_profile"])
            matches = (
                provenance["content_fingerprint"] == snapshot.fingerprint
                and record["endpoint"] == settings.endpoint
                and record["repository_identity"] == repository_identity(settings)
                and profile is not None
                and provenance["profile_fingerprint"] == digest(profile.model_dump())
            )
            tests.append(
                {
                    "execution_id": record["execution_id"],
                    "status": record["status"],
                    "backend": record["backend"],
                    "test_profile": provenance["test_profile"],
                    "pipeline": provenance["pipeline"],
                    "tested_commit": provenance["commit"],
                    "matches_current_contents": matches,
                    "passed_current_contents": matches
                    and record["state"] == "finished"
                    and record["tree_complete"]
                    and record["status"] == "Succeeded",
                }
            )
        matching = [test for test in tests if test["passed_current_contents"]]
        body = [summary.strip() or title, "", "Artifact changes:"]
        body.extend("- " + item["path"] for item in diff["changes"])
        body.extend(
            [
                "",
                f"Proposed revision: `{snapshot.commit}`.",
                f"Artifact content fingerprint: `{snapshot.fingerprint}`.",
                "",
                "Recorded tests:",
            ]
        )
        if not tests:
            body.append("- No recorded branch tests.")
        for test in tests:
            claim = (
                "passed these artifact contents"
                if test["passed_current_contents"]
                else "does not establish a pass for these contents"
            )
            body.append(
                f"- {test['execution_id']}: {test['pipeline']} / {test['test_profile']} / "
                f"{test['backend']}: {test['status']}; {claim}. "
                f"Tested base commit: {test['tested_commit']}."
            )
        if snapshot.dirty:
            body.extend(
                [
                    "",
                    "Uncommitted artifacts are included. Commit and push before creating a PR.",
                ]
            )
        return bounded_result(
            {
                "title": title,
                "body": redact("\n".join(body)),
                "branch": branch,
                "base": repository.config.collaboration_branch,
                **snapshot.metadata(),
                "tests": tests,
                "has_matching_successful_test": bool(matching),
            }
        )

    def create_draft_pr(
        self,
        workspace: str,
        branch: str,
        expected_revision: str,
        title: str,
        summary: str = "",
        repository_backend: RepositoryBackend | None = None,
    ) -> dict[str, Any]:
        """Explicitly create a GitHub draft PR into the configured collaboration branch.
        Requires allow_git_write, committed/pushed contents and an unchanged expected revision.
        Rechecks test provenance; never merges or publishes.
        """
        require(self.workspace(workspace, "git"), "allow_git_write")
        repository = self.repository(workspace, repository_backend)
        repository.writable(branch)
        repository.check_revision(branch, expected_revision)
        prepared = self.prepare_git_pr(workspace, branch, title, summary, repository_backend)
        if prepared.get("truncated"):
            raise ValueError("PR preparation exceeds the tool output cap; narrow the change set")
        if prepared["uncommitted"]:
            raise ValueError("Commit and push local artifacts before PR creation")
        github = self.repository(workspace, "github")
        remote = github.snapshot(branch)
        if (
            remote.commit != expected_revision
            or remote.fingerprint != prepared["content_fingerprint"]
        ):
            raise RevisionConflict(
                "GitHub branch does not match the prepared revision; push and retry"
            )
        result = github.create_pr(branch, expected_revision, title, prepared["body"])
        return bounded_result(
            {
                "url": result["html_url"],
                "number": result["number"],
                "draft": True,
                "proposed_revision": expected_revision,
                "has_matching_successful_test": prepared["has_matching_successful_test"],
            }
        )
