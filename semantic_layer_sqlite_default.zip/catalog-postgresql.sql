-- Enterprise v2.1 OPTIONAL PostgreSQL catalog adapter bootstrap.
-- Default persistent authority and RAM reader backend: SQLite.
-- Catalog schema version 3. Adopt PostgreSQL when measured requirements justify it.
-- Do not run against operational Azure SQL Database.
-- JSONB validates JSON syntax; typed payload/business/lifecycle rules belong to
-- the publisher. Add least-privilege roles, migrations and audit in deployment.
-- SQLite snapshots export semantic rows; authority control rows stay here.
CREATE TABLE catalog_release (
    release_id TEXT PRIMARY KEY,
    schema_version INTEGER NOT NULL CHECK (schema_version > 0),
    status TEXT NOT NULL CHECK (status IN ('draft','reviewed','published','retired')),
    content_sha256 TEXT,
    created_at TIMESTAMPTZ NOT NULL,
    published_at TIMESTAMPTZ,
    edit_revision INTEGER NOT NULL DEFAULT 0 CHECK (edit_revision >= 0),
    CHECK (status <> 'published' OR
           (content_sha256 IS NOT NULL AND published_at IS NOT NULL))
);
CREATE TABLE catalog_object (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    object_id TEXT NOT NULL,
    object_kind TEXT NOT NULL CHECK (object_kind IN
      ('entity','field','value_domain','canonical_value','relationship',
       'predicate','metric','business_domain','concept','query_template')),
    label TEXT NOT NULL,
    description TEXT NOT NULL,
    owner TEXT NOT NULL,
    access_policy_ref TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('draft','reviewed','published','deprecated')),
    provenance_json JSONB NOT NULL,
    PRIMARY KEY (release_id, object_id)
);
CREATE TABLE data_source (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    source_id TEXT NOT NULL,
    provider_kind TEXT NOT NULL,
    dialect TEXT NOT NULL,
    connection_config_ref TEXT NOT NULL,
    schema_fingerprint TEXT NOT NULL,
    auth_policy_ref TEXT NOT NULL,
    freshness_json JSONB NOT NULL,
    PRIMARY KEY (release_id, source_id)
);
CREATE TABLE entity (
    release_id TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    binding_kind TEXT NOT NULL CHECK (binding_kind IN ('physical','derived')),
    connection_ref TEXT,
    physical_schema TEXT,
    physical_object TEXT,
    derived_plan_json JSONB,
    row_semantics_json JSONB NOT NULL,
    physical_row_key_json JSONB NOT NULL,
    business_identity_json JSONB NOT NULL,
    versioning_json JSONB NOT NULL,
    uniqueness_evidence_json JSONB NOT NULL,
    identity_namespace TEXT NOT NULL,
    temporal_json JSONB NOT NULL,
    access_policy_ref TEXT NOT NULL,
    PRIMARY KEY (release_id, entity_id),
    FOREIGN KEY (release_id, entity_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, connection_ref)
      REFERENCES data_source(release_id, source_id),
    CHECK ((binding_kind = 'physical' AND connection_ref IS NOT NULL
            AND physical_schema IS NOT NULL AND physical_object IS NOT NULL
            AND derived_plan_json IS NULL)
        OR (binding_kind = 'derived' AND derived_plan_json IS NOT NULL
            AND connection_ref IS NULL AND physical_schema IS NULL
            AND physical_object IS NULL))
);
CREATE TABLE value_domain (
    release_id TEXT NOT NULL,
    domain_id TEXT NOT NULL,
    normalization_json JSONB NOT NULL,
    resolution_policy_json JSONB NOT NULL,
    PRIMARY KEY (release_id, domain_id),
    FOREIGN KEY (release_id, domain_id)
      REFERENCES catalog_object(release_id, object_id)
);
CREATE TABLE field (
    release_id TEXT NOT NULL,
    field_id TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    physical_column TEXT,
    expression_json JSONB,
    physical_type TEXT NOT NULL,
    semantic_type TEXT NOT NULL,
    nullable INTEGER NOT NULL CHECK (nullable IN (0,1)),
    null_meaning TEXT NOT NULL,
    roles_json JSONB NOT NULL,
    operators_json JSONB NOT NULL,
    aliases_json JSONB NOT NULL,
    sensitivity TEXT NOT NULL,
    domain_id TEXT,
    PRIMARY KEY (release_id, field_id),
    FOREIGN KEY (release_id, field_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, entity_id) REFERENCES entity(release_id, entity_id),
    FOREIGN KEY (release_id, domain_id) REFERENCES value_domain(release_id, domain_id),
    UNIQUE (release_id, entity_id, physical_column),
    CHECK ((physical_column IS NOT NULL AND expression_json IS NULL)
        OR (physical_column IS NULL AND expression_json IS NOT NULL))
);
CREATE TABLE canonical_value (
    release_id TEXT NOT NULL,
    value_id TEXT NOT NULL,
    domain_id TEXT NOT NULL,
    PRIMARY KEY (release_id, value_id),
    FOREIGN KEY (release_id, value_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, domain_id) REFERENCES value_domain(release_id, domain_id)
);
CREATE TABLE value_alias (
    release_id TEXT NOT NULL,
    value_id TEXT NOT NULL,
    locale TEXT NOT NULL,
    normalized_alias TEXT NOT NULL,
    PRIMARY KEY (release_id, value_id, locale, normalized_alias),
    FOREIGN KEY (release_id, value_id)
      REFERENCES canonical_value(release_id, value_id)
    -- Intentionally permits the same alias for different values.
    -- Resolver reports ambiguity; publisher prevents silent last-write wins.
);
CREATE INDEX value_alias_lookup
  ON value_alias(release_id, locale, normalized_alias);
CREATE TABLE value_binding (
    release_id TEXT NOT NULL,
    binding_id TEXT NOT NULL,
    value_id TEXT NOT NULL,
    field_id TEXT NOT NULL,
    literal_type TEXT NOT NULL CHECK (literal_type IN
      ('string','integer','decimal','boolean','date','timestamp')),
    literal_json JSONB NOT NULL,
    valid_from TIMESTAMPTZ NOT NULL,
    valid_to TIMESTAMPTZ,
    PRIMARY KEY (release_id, binding_id),
    FOREIGN KEY (release_id, value_id)
      REFERENCES canonical_value(release_id, value_id),
    FOREIGN KEY (release_id, field_id) REFERENCES field(release_id, field_id),
    CHECK (valid_to IS NULL OR valid_from < valid_to)
);
CREATE INDEX value_binding_lookup
  ON value_binding(release_id, value_id, field_id, valid_from);
CREATE TABLE relationship (
    release_id TEXT NOT NULL,
    relationship_id TEXT NOT NULL,
    source_entity_id TEXT NOT NULL,
    target_entity_id TEXT NOT NULL,
    source_role TEXT NOT NULL,
    target_role TEXT NOT NULL,
    key_pairs_json JSONB NOT NULL,
    cardinality_json JSONB NOT NULL,
    required_predicates_json JSONB NOT NULL,
    identity_json JSONB NOT NULL,
    temporal_json JSONB NOT NULL,
    PRIMARY KEY (release_id, relationship_id),
    FOREIGN KEY (release_id, relationship_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, source_entity_id) REFERENCES entity(release_id, entity_id),
    FOREIGN KEY (release_id, target_entity_id) REFERENCES entity(release_id, entity_id)
);
CREATE INDEX relationship_outgoing
  ON relationship(release_id, source_entity_id);
CREATE TABLE relationship_operation (
    release_id TEXT NOT NULL,
    operation_id TEXT NOT NULL,
    relationship_id TEXT NOT NULL,
    operator TEXT NOT NULL CHECK (operator IN
      ('exists','not_exists','enrich_left','expand_left','enrich_inner',
       'expand_inner','temporal_lookup','bridge_membership','bridge_allocate')),
    contract_json JSONB NOT NULL,
    PRIMARY KEY (release_id, operation_id),
    FOREIGN KEY (release_id, relationship_id)
      REFERENCES relationship(release_id, relationship_id)
);
CREATE TABLE predicate (
    release_id TEXT NOT NULL,
    predicate_id TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    expression_json JSONB NOT NULL,
    purpose TEXT NOT NULL CHECK (purpose IN
      ('business','source_restriction','security_restriction')),
    PRIMARY KEY (release_id, predicate_id),
    FOREIGN KEY (release_id, predicate_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, entity_id) REFERENCES entity(release_id, entity_id)
);
CREATE TABLE metric (
    release_id TEXT NOT NULL,
    metric_id TEXT NOT NULL,
    base_entity_id TEXT NOT NULL,
    definition_json JSONB NOT NULL,
    PRIMARY KEY (release_id, metric_id),
    FOREIGN KEY (release_id, metric_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, base_entity_id) REFERENCES entity(release_id, entity_id)
);
CREATE TABLE verified_example (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    example_id TEXT NOT NULL,
    question TEXT NOT NULL,
    semantic_query_json JSONB NOT NULL,
    reference_sql TEXT,
    fixture_id TEXT NOT NULL,
    expected_json JSONB NOT NULL,
    review_status TEXT NOT NULL CHECK (review_status IN ('draft','approved','rejected')),
    reviewer TEXT,
    PRIMARY KEY (release_id, example_id)
);
CREATE TABLE assertion (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    assertion_id TEXT NOT NULL,
    subject_id TEXT NOT NULL,
    requirement_json JSONB NOT NULL,
    evidence_json JSONB NOT NULL,
    valid_until TIMESTAMPTZ,
    failure_action_json JSONB NOT NULL,
    PRIMARY KEY (release_id, assertion_id)
    -- subject may be an object, an operation, or a source identity namespace;
    -- publisher resolves the typed subject in requirement_json.
);

-- Domain and context model. Dataset membership may span several domains.
CREATE TABLE business_domain (
    release_id TEXT NOT NULL,
    domain_id TEXT NOT NULL,
    routing_summary TEXT NOT NULL,
    vocabulary_json JSONB NOT NULL,
    coverage_json JSONB NOT NULL,
    steward TEXT NOT NULL,
    PRIMARY KEY (release_id, domain_id),
    FOREIGN KEY (release_id, domain_id)
      REFERENCES catalog_object(release_id, object_id)
);
CREATE TABLE domain_membership (
    release_id TEXT NOT NULL,
    domain_id TEXT NOT NULL,
    object_id TEXT NOT NULL,
    membership_role TEXT NOT NULL,
    PRIMARY KEY (release_id, domain_id, object_id),
    FOREIGN KEY (release_id, domain_id) REFERENCES business_domain(release_id, domain_id),
    FOREIGN KEY (release_id, object_id) REFERENCES catalog_object(release_id, object_id)
);
CREATE TABLE semantic_concept (
    release_id TEXT NOT NULL,
    concept_id TEXT NOT NULL,
    definition_json JSONB NOT NULL,
    PRIMARY KEY (release_id, concept_id),
    FOREIGN KEY (release_id, concept_id) REFERENCES catalog_object(release_id, object_id)
);
CREATE TABLE semantic_edge (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    edge_id TEXT NOT NULL,
    from_object_id TEXT NOT NULL,
    to_object_id TEXT NOT NULL,
    edge_kind TEXT NOT NULL CHECK (edge_kind IN
      ('depends_on','lineage','concept_association','equivalence','taxonomy')),
    review_status TEXT NOT NULL CHECK (review_status IN ('proposed','approved')),
    properties_json JSONB NOT NULL,
    PRIMARY KEY (release_id, edge_id),
    FOREIGN KEY (release_id, from_object_id) REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, to_object_id) REFERENCES catalog_object(release_id, object_id)
    -- These edges never authorize an executable SQL relationship by themselves.
);
CREATE INDEX semantic_edge_outgoing ON semantic_edge(release_id, from_object_id, edge_kind);
CREATE INDEX semantic_edge_incoming ON semantic_edge(release_id, to_object_id, edge_kind);
CREATE TABLE query_template (
    release_id TEXT NOT NULL,
    template_id TEXT NOT NULL,
    parameter_schema_json JSONB NOT NULL,
    plan_json JSONB NOT NULL,
    capability_requirements_json JSONB NOT NULL,
    PRIMARY KEY (release_id, template_id),
    FOREIGN KEY (release_id, template_id) REFERENCES catalog_object(release_id, object_id)
);
CREATE TABLE capability (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    capability_id TEXT NOT NULL,
    operator_name TEXT NOT NULL,
    operator_version INTEGER NOT NULL CHECK (operator_version > 0),
    dialect TEXT NOT NULL,
    schema_json JSONB NOT NULL,
    requirements_json JSONB NOT NULL,
    PRIMARY KEY (release_id, capability_id)
);
CREATE TABLE domain_capability (
    release_id TEXT NOT NULL,
    domain_id TEXT NOT NULL,
    capability_id TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('disabled','evaluation','enabled')),
    evidence_json JSONB NOT NULL,
    PRIMARY KEY (release_id, domain_id, capability_id),
    FOREIGN KEY (release_id, domain_id) REFERENCES business_domain(release_id, domain_id),
    FOREIGN KEY (release_id, capability_id) REFERENCES capability(release_id, capability_id)
);

-- Authority control tables: populated in the durable SQLite authority by default.
-- Their rows are NOT copied into the immutable semantic snapshot/RAM reader.
-- Snapshot checksums/manifests live in the authority and external manifest.
-- This avoids embedding a file's own checksum inside the checksummed file.
CREATE TABLE projection_artifact (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    projection_id TEXT NOT NULL,
    projection_kind TEXT NOT NULL CHECK (projection_kind IN
      ('sqlite','search','graph','examples','evaluation')),
    state TEXT NOT NULL CHECK (state IN ('building','ready','failed','retired')),
    locator TEXT NOT NULL,
    content_hash TEXT,
    configuration_json JSONB NOT NULL,
    PRIMARY KEY (release_id, projection_id),
    CHECK (state <> 'ready' OR content_hash IS NOT NULL)
);
CREATE TABLE release_manifest (
    manifest_id TEXT PRIMARY KEY,
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    manifest_version INTEGER NOT NULL CHECK (manifest_version > 0),
    snapshot_projection_id TEXT NOT NULL,
    search_projection_id TEXT NOT NULL,
    graph_projection_id TEXT NOT NULL,
    application_config_json JSONB NOT NULL,
    manifest_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL,
    UNIQUE (release_id, manifest_id),
    FOREIGN KEY (release_id, snapshot_projection_id)
      REFERENCES projection_artifact(release_id, projection_id),
    FOREIGN KEY (release_id, search_projection_id)
      REFERENCES projection_artifact(release_id, projection_id),
    FOREIGN KEY (release_id, graph_projection_id)
      REFERENCES projection_artifact(release_id, projection_id)
    -- Publisher checks kind, readiness, content and application compatibility.
);
CREATE TABLE active_manifest (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    manifest_id TEXT NOT NULL REFERENCES release_manifest(manifest_id)
    -- Runtime uses the authority's active pointer, then pins a local snapshot.
);

-- Authority-only transactional outbox. Insert a publication event in the same
-- transaction as its release state transition. Consumers must be idempotent.
-- Rows stay in the authority; they are excluded from snapshots and RAM readers.
CREATE TABLE publication_outbox (
    event_id TEXT PRIMARY KEY,
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    topic TEXT NOT NULL,
    idempotency_key TEXT NOT NULL UNIQUE,
    payload_json JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL,
    delivered_at TIMESTAMPTZ,
    attempt_count INTEGER NOT NULL DEFAULT 0 CHECK (attempt_count >= 0)
);
CREATE INDEX publication_outbox_pending ON publication_outbox(created_at)
  WHERE delivered_at IS NULL;
