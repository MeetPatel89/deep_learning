"""Document-label metrics over ordered result positions, including duplicates."""

from collections.abc import Mapping, Sequence
from dataclasses import dataclass

from ..config import _validate_text
from .results import EvaluationResult


def _validate_k(k: int) -> None:
    if isinstance(k, bool) or not isinstance(k, int):
        raise TypeError("k must be an integer")
    if k <= 0:
        raise ValueError("k must be positive")


def _doc_ids(value: object, name: str) -> tuple[str, ...]:
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise TypeError(f"{name} must be an ordered sequence of document IDs")
    result: list[str] = []
    for item in value:
        _validate_text("document ID", item)
        result.append(item)
    return tuple(result)


def _documents(
    output: object, expected_output: object, k: int | None
) -> tuple[tuple[str, ...], set[str]]:
    retrieved = _doc_ids(output, "output")
    expected = set(_doc_ids(expected_output, "expected_output"))
    if not expected:
        raise ValueError("expected_output must contain at least one document ID")
    return retrieved[:k], expected


@dataclass(frozen=True, slots=True)
class HitAtK:
    """Score 1 when any of the first k result positions has an expected ID."""

    k: int
    name: str | None = None

    def __post_init__(self) -> None:
        """Require a positive cutoff and an optional nonblank custom name."""
        _validate_k(self.k)
        if self.name is not None:
            _validate_text("name", self.name)

    def __call__(
        self,
        *,
        input: object = None,
        output: object,
        expected_output: object = None,
        metadata: Mapping[str, object] | None = None,
    ) -> EvaluationResult:
        """Count an empty retrieval as a miss."""
        retrieved, expected = _documents(output, expected_output, self.k)
        return EvaluationResult(
            self.name or f"hit_at_{self.k}", float(bool(set(retrieved) & expected))
        )


@dataclass(frozen=True, slots=True)
class RecallAtK:
    """Divide distinct relevant IDs in the first k positions by distinct labels."""

    k: int
    name: str | None = None

    def __post_init__(self) -> None:
        """Require a positive cutoff and an optional nonblank custom name."""
        _validate_k(self.k)
        if self.name is not None:
            _validate_text("name", self.name)

    def __call__(
        self,
        *,
        input: object = None,
        output: object,
        expected_output: object = None,
        metadata: Mapping[str, object] | None = None,
    ) -> EvaluationResult:
        """Measure coverage of supplied labels, not unlabeled corpus relevance."""
        retrieved, expected = _documents(output, expected_output, self.k)
        return EvaluationResult(
            self.name or f"recall_at_{self.k}",
            len(set(retrieved) & expected) / len(expected),
        )


@dataclass(frozen=True, slots=True)
class PrecisionAtK:
    """Divide distinct relevant IDs in the first k positions by k, even if short."""

    k: int
    name: str | None = None

    def __post_init__(self) -> None:
        """Require a positive cutoff and an optional nonblank custom name."""
        _validate_k(self.k)
        if self.name is not None:
            _validate_text("name", self.name)

    def __call__(
        self,
        *,
        input: object = None,
        output: object,
        expected_output: object = None,
        metadata: Mapping[str, object] | None = None,
    ) -> EvaluationResult:
        """Let duplicates consume positions without earning additional credit."""
        retrieved, expected = _documents(output, expected_output, self.k)
        return EvaluationResult(
            self.name or f"precision_at_{self.k}",
            len(set(retrieved) & expected) / self.k,
        )


@dataclass(frozen=True, slots=True)
class ReciprocalRank:
    """Score the reciprocal of the first relevant position, optionally cut off at k."""

    k: int | None = None
    name: str | None = None

    def __post_init__(self) -> None:
        """Require a positive cutoff when provided and a nonblank custom name."""
        if self.k is not None:
            _validate_k(self.k)
        if self.name is not None:
            _validate_text("name", self.name)

    def __call__(
        self,
        *,
        input: object = None,
        output: object,
        expected_output: object = None,
        metadata: Mapping[str, object] | None = None,
    ) -> EvaluationResult:
        """Use original 1-based positions; a miss scores zero."""
        retrieved, expected = _documents(output, expected_output, self.k)
        rank = next(
            (position for position, doc in enumerate(retrieved, 1) if doc in expected),
            None,
        )
        default_name = (
            "reciprocal_rank" if self.k is None else f"reciprocal_rank_at_{self.k}"
        )
        return EvaluationResult(self.name or default_name, 1.0 / rank if rank else 0.0)
