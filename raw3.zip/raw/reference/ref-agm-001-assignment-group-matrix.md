---
doc_id: REF-AGM-001
title: Assignment Group Matrix
doc_type: reference
service_id: null
owner_group: Service Desk L1
visibility: internal
status: active
created_at: "2026-05-12T09:00:00"
updated_at: "2026-06-20T09:00:00"
related_records:
  - POL-ESC-001
  - SVC-CAT-IDENTITY-001
  - SVC-CAT-PAYMENTS-001
  - SVC-CAT-API-001
source_facts:
  - support_groups
difficulty_tags:
  - ownership-routing
  - reference-data
servicenow:
  table: kb_knowledge
  number: KB0000905
  kb_category: Reference
  workflow_state: Published
  assignment_group: Service Desk L1
  visibility: internal
  contains_customer_safe_wording: false
---

# Assignment Group Matrix

## Record details

| Field | Value |
| --- | --- |
| Table | kb_knowledge |
| Number | KB0000905 |
| KB category | Reference |
| Workflow state | Published |
| Assignment group | Service Desk L1 |
| Visibility | internal |
| Contains customer-safe wording | false |

## Purpose

REF-AGM-001 maps business services, configuration items, and incident categories to the correct assignment group. Service Desk L1 uses this matrix at intake to route incidents, and again at escalation when a documented workaround fails or scope grows.

## Group responsibilities

| Assignment group | Role |
| --- | --- |
| Service Desk L1 | Intake, initial triage, known issue matching, customer-safe communication, routing per this matrix. |
| IAM Platform | Owns Identity Gateway. Final remediation for SSO, SAML, identity metadata, and certificate issues. |
| Data Applications | Owns Payments Reporting Service. Final remediation for reporting freshness, refresh pipelines, and export mismatches. |
| Platform Engineering | Owns Internal API Gateway. Final remediation for routing, rate limiting, and policy entitlement issues. |
| Release Management | Change coordination, CAB administration, release notes, and change-related incident notification. Not a technical remediation group. |

## Routing matrix

| Business service | Configuration item (cmdb_ci) | Category / symptom keywords | Assignment group |
| --- | --- | --- | --- |
| Employee Portal | Identity Gateway | Software / Authentication: login failure, invalid SAML response, SSO, sign-in after identity maintenance | IAM Platform |
| Payments Reporting Service | Payments Reporting Pipeline | Data / Reporting: stale dashboard, export mismatch, data freshness, refresh delay | Data Applications |
| Client API Access | Internal API Gateway | Network / API Gateway: 429 Too Many Requests, rate limit, throttling, policy entitlement | Platform Engineering |
| Any | Any | Symptom appears within 24 hours of a completed change | Owning group above, with Release Management notified |

## Routing rules

- Route by failing layer, not by where the symptom was noticed. An Employee Portal login failure that occurs before an authenticated session is established belongs to IAM Platform, not to a portal application team.
- Distinguish source data from reporting. When source transaction records are present but dashboards lag, route to Data Applications rather than treating it as data loss.
- Release Management is notified, never assigned remediation, when an incident correlates with a recent completed change such as CHG002407, CHG002411, or CHG002420.
- If no row matches, keep the incident with Service Desk L1, gather symptom evidence, and consult the service catalog entries before assigning to a technical group.

## Related records

- POL-ESC-001: Incident Severity and Escalation Policy.
- SVC-CAT-IDENTITY-001, SVC-CAT-PAYMENTS-001, SVC-CAT-API-001: Service catalog entries with detailed escalation guidance.
