"""Filesystem server configuration (no implicit writable stores)."""

from typing import Literal

from data_mcp_core.config import DataConfig, load_config
from pydantic import Field

Toolset = Literal["discovery", "content", "datasets", "delta", "files", "adls"]


class FSConfig(DataConfig):
    enabled_toolsets: list[Toolset] = Field(
        default_factory=lambda: ["discovery", "content", "datasets", "delta", "files", "adls"]
    )


def get_config() -> FSConfig:
    return load_config("FS_MCP_CONFIG", FSConfig)
