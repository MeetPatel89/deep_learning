"""Verify managed prompt selection and preserve native compilation behavior."""

from typing import Any
from unittest.mock import Mock

from pytest import importorskip, mark, raises

importorskip("langfuse", reason="requires observe-eval-ai[langfuse]")

from langfuse import Langfuse  # noqa: E402
from langfuse.api import ChatMessage, Prompt_Chat, Prompt_Text  # noqa: E402
from langfuse.model import ChatPromptClient, TextPromptClient  # noqa: E402

from observability_ai.langfuse import PromptRepository  # noqa: E402


@mark.parametrize(("label", "version"), [(None, None), ("staging", None), (None, 2)])
def test_get_returns_original_text_prompt(
    label: str | None, version: int | None
) -> None:
    """Keep SDK prompt identity, version, and compilation separate from content."""
    prompt = TextPromptClient(
        Prompt_Text(
            name="answer",
            version=2,
            prompt="Hello {{name}}",
            labels=["staging"],
            tags=[],
            config={},
        )
    )
    client = Mock(spec=Langfuse)
    client.get_prompt.return_value = prompt
    result = PromptRepository(client).get("answer", label=label, version=version)
    assert result is prompt
    assert result.compile(name="reader") == "Hello reader"
    assert result.compile(name="another reader") == "Hello another reader"
    assert result.prompt == "Hello {{name}}"
    assert result.version == 2
    client.get_prompt.assert_called_once_with(
        "answer", label=label, version=version, type="text"
    )
    client.shutdown.assert_not_called()


def test_get_returns_native_chat_prompt() -> None:
    """Chat prompts retain SDK message compilation and generation attribution."""
    prompt = ChatPromptClient(
        Prompt_Chat(
            name="chat",
            version=1,
            prompt=[ChatMessage(role="user", content="{{question}}")],
            labels=["production"],
            tags=[],
            config={},
        )
    )
    client = Mock(spec=Langfuse)
    client.get_prompt.return_value = prompt
    result = PromptRepository(client).get("chat", type="chat")
    assert result is prompt
    assert result.compile(question="What is tracing?") == [
        {"role": "user", "content": "What is tracing?"}
    ]
    client.get_prompt.assert_called_once_with(
        "chat", label=None, version=None, type="chat"
    )


@mark.parametrize(
    ("kwargs", "error"),
    [
        ({"name": " "}, ValueError),
        ({"name": 1}, TypeError),
        ({"label": ""}, ValueError),
        ({"label": 1}, TypeError),
        ({"version": 0}, ValueError),
        ({"version": -1}, ValueError),
        ({"version": True}, TypeError),
        ({"version": 1.5}, TypeError),
        ({"version": "1"}, TypeError),
        ({"label": "production", "version": 1}, ValueError),
        ({"type": "invalid"}, ValueError),
    ],
)
def test_invalid_prompt_selectors_do_not_fetch(
    kwargs: dict[str, object],
    error: type[Exception],
) -> None:
    """Validate selectors before a cache access or network request can occur."""
    client = Mock(spec=Langfuse)
    # Deliberately bypass static signatures to exercise runtime validation.
    arguments: dict[str, Any] = {"name": "answer"} | kwargs
    with raises(error):
        PromptRepository(client).get(**arguments)
    client.get_prompt.assert_not_called()


def test_prompt_fetch_errors_keep_sdk_context() -> None:
    """Do not invent fallback content when the SDK cannot resolve a prompt."""
    client = Mock(spec=Langfuse)
    failure = RuntimeError("prompt unavailable")
    client.get_prompt.side_effect = failure
    with raises(RuntimeError) as caught:
        PromptRepository(client).get("answer")
    assert caught.value is failure
