"""Exercise app provisioning through the CLI with isolated Docker and HTTP calls."""

from base64 import b64encode
from email.message import Message
from io import StringIO
from json import dumps, loads
from pathlib import Path
from subprocess import CalledProcessError, CompletedProcess
from unittest.mock import MagicMock, Mock
from urllib.error import HTTPError, URLError

from pytest import CaptureFixture, MonkeyPatch, fixture, mark, raises

from observability_ai.cli import main, verify_project, wait_for_health
from observability_ai.provisioning import ProvisioningError, read_env_file


@fixture(autouse=True)
def cli_errors(monkeypatch: MonkeyPatch) -> StringIO:
    """Capture the CLI's explicitly imported error stream without global IO."""
    errors = StringIO()
    monkeypatch.setattr("observability_ai.cli.stderr", errors)
    return errors


def _response(payload: object) -> MagicMock:
    """Provide a context-managed HTTP response containing a JSON document."""
    response = MagicMock()
    response.status = 200
    response.read.return_value = dumps(payload).encode()
    response.__enter__.return_value = response
    response.__exit__.return_value = False
    return response


@fixture
def stack(tmp_path: Path, monkeypatch: MonkeyPatch) -> Path:
    """Create stack configuration without requiring a real Docker daemon."""
    path = tmp_path / "central-stack"
    path.mkdir()
    (path / "compose.yaml").write_text("services:\n  langfuse-web:\n    image: test\n")
    (path / ".env").write_text(
        "LANGFUSE_BASE_URL=http://localhost:3333\n"
        "LANGFUSE_INIT_USER_EMAIL=stale@example.com\n"
        "LANGFUSE_INIT_USER_PASSWORD=stale-secret\n"
    )
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("OBSERVABILITY_AI_STACK_DIR", raising=False)
    return path


@fixture
def docker(monkeypatch: MonkeyPatch) -> Mock:
    """Capture successful Docker commands without running subprocesses."""

    def execute(command: list[str], **kwargs: object) -> CompletedProcess[str]:
        if command[1:3] == ["compose", "version"]:
            output = "2.39.1\n"
        elif "--services" in command:
            output = "langfuse-worker\npostgres\nclickhouse\nredis\nminio\n"
        else:
            output = ""
        return CompletedProcess(command, 0, stdout=output, stderr="")

    runner = Mock(side_effect=execute)
    monkeypatch.setattr("observability_ai.cli.run", runner)
    return runner


@fixture
def http(monkeypatch: MonkeyPatch) -> Mock:
    """Return a healthy instance and a project matching the requested test app."""
    opener = Mock(
        side_effect=lambda request, **kwargs: _response(
            {
                "data": [
                    {
                        "id": "fieldguide",
                        "name": "Fieldguide",
                        "organization": {"id": "observability-ai"},
                    }
                ]
            }
        )
    )
    monkeypatch.setattr("observability_ai.cli.urlopen", opener)
    return opener


def _provision_args(stack: Path, *extra: str) -> list[str]:
    """Build a noninteractive invocation with an explicit stack location."""
    return [
        "provision",
        "--app",
        "fieldguide",
        "--app-env",
        ".env",
        "--stack-dir",
        str(stack),
        "--yes",
        *extra,
    ]


def test_provision_recreates_only_web_with_process_init_values(
    stack: Path,
    docker: Mock,
    http: Mock,
    monkeypatch: MonkeyPatch,
    capfd: CaptureFixture[str],
    cli_errors: StringIO,
) -> None:
    """Provisioning passes secrets via the process and preserves stack config."""
    stack_before = (stack / ".env").read_bytes()
    monkeypatch.setenv("LANGFUSE_INIT_USER_PASSWORD", "ambient-secret")
    monkeypatch.setenv("LANGFUSE_INIT_PROJECT_ID", "old-project")

    assert main(_provision_args(stack)) == 0

    compose_calls = [
        call for call in docker.call_args_list if "--force-recreate" in call.args[0]
    ]
    assert len(compose_calls) == 1
    command = compose_calls[0].args[0]
    assert command[:2] == ["docker", "compose"]
    assert command[-5:] == ["up", "-d", "--no-deps", "--force-recreate", "langfuse-web"]
    assert command[command.index("-f") + 1] == str(stack / "compose.yaml")
    assert command[command.index("--env-file") + 1] == str(stack / ".env")
    environment = compose_calls[0].kwargs["env"]
    app_values = read_env_file(Path(".env"))
    assert environment["LANGFUSE_INIT_PROJECT_ID"] == "fieldguide"
    assert (
        environment["LANGFUSE_INIT_PROJECT_PUBLIC_KEY"]
        == app_values["LANGFUSE_PUBLIC_KEY"]
    )
    assert (
        environment["LANGFUSE_INIT_PROJECT_SECRET_KEY"]
        == app_values["LANGFUSE_SECRET_KEY"]
    )
    assert environment["LANGFUSE_INIT_USER_PASSWORD"] == ""
    assert environment["LANGFUSE_INIT_USER_EMAIL"] == ""
    assert app_values["LANGFUSE_BASE_URL"] == "http://localhost:3333"
    assert (stack / ".env").read_bytes() == stack_before
    assert http.call_count >= 2
    output = capfd.readouterr()
    assert app_values["LANGFUSE_SECRET_KEY"] not in (
        output.out + output.err + cli_errors.getvalue()
    )
    registry = (stack / "provisioned.json").read_text()
    assert app_values["LANGFUSE_SECRET_KEY"] not in registry
    assert "ambient-secret" not in registry


def test_reprovision_reuses_keys_and_rotation_replaces_them(
    stack: Path,
    docker: Mock,
    http: Mock,
    capfd: CaptureFixture[str],
    cli_errors: StringIO,
) -> None:
    """An existing app retains its pair until explicit rotation is requested."""
    assert main(_provision_args(stack)) == 0
    original = read_env_file(Path(".env"))
    original_registry = loads((stack / "provisioned.json").read_text())

    assert main(_provision_args(stack)) == 0
    assert read_env_file(Path(".env")) == original
    assert loads((stack / "provisioned.json").read_text()) == original_registry

    assert main(_provision_args(stack, "--rotate-keys")) == 0
    rotated = read_env_file(Path(".env"))
    assert rotated["LANGFUSE_PUBLIC_KEY"] != original["LANGFUSE_PUBLIC_KEY"]
    assert rotated["LANGFUSE_SECRET_KEY"] != original["LANGFUSE_SECRET_KEY"]
    registry = (stack / "provisioned.json").read_text()
    assert rotated["LANGFUSE_PUBLIC_KEY"] in registry
    assert rotated["LANGFUSE_SECRET_KEY"] not in registry
    assert "rotated_at" in registry
    output = capfd.readouterr()
    assert "old" in (output.out + output.err + cli_errors.getvalue()).lower()


def test_dry_run_redacts_values_and_has_no_side_effects(
    stack: Path,
    docker: Mock,
    http: Mock,
    capfd: CaptureFixture[str],
) -> None:
    """Planning a restart neither writes credentials nor contacts Docker or HTTP."""
    before = (stack / ".env").read_bytes()
    assert (
        main(_provision_args(stack, "--dry-run", "--user-email", "owner@example.com"))
        == 0
    )
    output = capfd.readouterr().out
    assert "LANGFUSE_INIT_PROJECT_SECRET_KEY" in output
    assert "--force-recreate" in output
    assert "sk-lf-" not in output
    assert "pk-lf-" not in output
    assert "owner@example.com" not in output
    assert not Path(".env").exists()
    assert not (stack / "provisioned.json").exists()
    assert (stack / ".env").read_bytes() == before
    docker.assert_not_called()
    http.assert_not_called()


def test_generated_owner_password_is_printed_once_without_persistence(
    stack: Path,
    docker: Mock,
    http: Mock,
    capfd: CaptureFixture[str],
    cli_errors: StringIO,
) -> None:
    """A new owner's password is disclosed once and excluded from local files."""
    assert (
        main(
            _provision_args(
                stack, "--user-email", "owner@example.com", "--user-name", "Owner"
            )
        )
        == 0
    )
    restart = next(
        call for call in docker.call_args_list if "--force-recreate" in call.args[0]
    )
    environment = restart.kwargs["env"]
    password = environment["LANGFUSE_INIT_USER_PASSWORD"]
    assert environment["LANGFUSE_INIT_USER_EMAIL"] == "owner@example.com"
    assert environment["LANGFUSE_INIT_USER_NAME"] == "Owner"
    assert len(password) >= 32
    output = capfd.readouterr().out
    assert output.count(password) == 1
    assert password not in cli_errors.getvalue()
    assert password not in Path(".env").read_text()
    assert password not in (stack / "provisioned.json").read_text()
    assert "Existing users keep their password" in cli_errors.getvalue()


def test_missing_saved_credentials_require_explicit_rotation(
    stack: Path, docker: Mock, http: Mock, cli_errors: StringIO
) -> None:
    """A registry entry cannot cause unrelated or incomplete app keys to be reused."""
    assert main(_provision_args(stack)) == 0
    app_env = Path(".env")
    original = read_env_file(app_env)
    app_env.write_text(f"LANGFUSE_PUBLIC_KEY={original['LANGFUSE_PUBLIC_KEY']}\n")
    registry_before = (stack / "provisioned.json").read_bytes()
    docker.reset_mock()
    http.reset_mock()
    assert main(_provision_args(stack)) != 0
    assert (stack / "provisioned.json").read_bytes() == registry_before
    assert "--rotate-keys" in cli_errors.getvalue()
    docker.assert_not_called()
    http.assert_not_called()


def test_health_failure_preserves_app_and_registry(
    stack: Path, docker: Mock, http: Mock, monkeypatch: MonkeyPatch
) -> None:
    """A restart whose database never becomes ready cannot replace app credentials."""
    assert main(_provision_args(stack)) == 0
    app_before = Path(".env").read_bytes()
    registry_before = (stack / "provisioned.json").read_bytes()
    monkeypatch.setattr(
        "observability_ai.cli.wait_for_health",
        Mock(side_effect=ProvisioningError("Langfuse health check timed out")),
    )
    http.reset_mock()
    assert main(_provision_args(stack, "--rotate-keys")) != 0
    assert Path(".env").read_bytes() == app_before
    assert (stack / "provisioned.json").read_bytes() == registry_before
    assert not (stack / ".provision.lock").exists()
    http.assert_not_called()


def test_declined_restart_leaves_stack_and_app_untouched(
    stack: Path, docker: Mock, http: Mock, monkeypatch: MonkeyPatch
) -> None:
    """Without confirmation the CLI cancels before creating any local state."""
    monkeypatch.setattr("builtins.input", Mock(return_value="n"))
    arguments = _provision_args(stack)
    arguments.remove("--yes")
    assert main(arguments) != 0
    assert not Path(".env").exists()
    assert not (stack / "provisioned.json").exists()
    assert not (stack / ".provision.lock").exists()
    docker.assert_not_called()
    http.assert_not_called()


def test_app_env_cannot_be_stack_env(stack: Path, docker: Mock, http: Mock) -> None:
    """The stack configuration cannot be selected as the credential destination."""
    before = (stack / ".env").read_bytes()
    assert main(_provision_args(stack, "--app-env", str(stack / ".env"))) != 0
    assert (stack / ".env").read_bytes() == before
    docker.assert_not_called()
    http.assert_not_called()


def test_failed_project_verification_preserves_app_and_registry(
    stack: Path,
    docker: Mock,
    http: Mock,
    capfd: CaptureFixture[str],
    cli_errors: StringIO,
) -> None:
    """A mismatched response cannot overwrite previously verified credentials."""
    assert main(_provision_args(stack)) == 0
    app_before = Path(".env").read_bytes()
    registry_before = (stack / "provisioned.json").read_bytes()
    http.side_effect = lambda request, **kwargs: _response(
        {"data": [{"id": "another-app", "name": "fieldguide"}]}
    )

    assert main(_provision_args(stack, "--rotate-keys")) != 0
    assert Path(".env").read_bytes() == app_before
    assert (stack / "provisioned.json").read_bytes() == registry_before
    output = capfd.readouterr()
    assert "logs" in output.err + output.out + cli_errors.getvalue()
    assert "langfuse-web" in output.err + output.out + cli_errors.getvalue()


def test_docker_failure_preserves_credentials_and_redacts_stderr(
    stack: Path,
    docker: Mock,
    http: Mock,
    capfd: CaptureFixture[str],
    cli_errors: StringIO,
) -> None:
    """A failed restart cannot leak generated secrets or commit local state."""
    Path(".env").write_text("UNRELATED=keep\n")
    docker.side_effect = CalledProcessError(
        1, ["docker", "info"], stderr="daemon unavailable; secret diagnostic"
    )
    assert main(_provision_args(stack)) != 0
    assert Path(".env").read_text() == "UNRELATED=keep\n"
    assert not (stack / "provisioned.json").exists()
    http.assert_not_called()
    output = capfd.readouterr()
    assert "Docker" in output.out + output.err + cli_errors.getvalue()
    assert "secret diagnostic" not in output.out + output.err + cli_errors.getvalue()


def test_where_and_apps_list_do_not_restart_or_contact_server(
    stack: Path, docker: Mock, http: Mock, capfd: CaptureFixture[str]
) -> None:
    """Local inspection uses the app's stack setting and public registry only."""
    assert main(_provision_args(stack)) == 0
    docker.reset_mock()
    http.reset_mock()
    app_env = Path(".env")
    app_env.write_text(app_env.read_text() + f"OBSERVABILITY_AI_STACK_DIR={stack}\n")
    capfd.readouterr()
    assert main(["where", "--app-env", str(app_env)]) == 0
    where = capfd.readouterr().out
    assert str(stack) in where
    assert stack.name in where
    assert "http://localhost:3333" in where
    assert main(["apps", "list", "--app-env", str(app_env)]) == 0
    output = capfd.readouterr().out
    assert "fieldguide" in output
    assert read_env_file(app_env)["LANGFUSE_SECRET_KEY"] not in output
    docker.assert_not_called()
    http.assert_not_called()


def test_verify_command_reads_app_credentials_without_docker(
    stack: Path, docker: Mock, http: Mock, capfd: CaptureFixture[str]
) -> None:
    """Verification checks the configured app against the expected project ID."""
    assert main(_provision_args(stack)) == 0
    docker.reset_mock()
    capfd.readouterr()
    assert main(["verify", "--app-env", ".env", "--app", "fieldguide"]) == 0
    assert "fieldguide" in capfd.readouterr().out
    docker.assert_not_called()


def test_verify_http_authentication_and_exact_project_identity(
    monkeypatch: MonkeyPatch,
) -> None:
    """Basic auth must identify the expected project by ID rather than its name."""
    opener = Mock(
        return_value=_response({"data": [{"id": "fieldguide", "name": "Fieldguide"}]})
    )
    monkeypatch.setattr("observability_ai.cli.urlopen", opener)
    assert (
        verify_project(
            "http://localhost:3333/", "pk-example", "sk-example", "fieldguide"
        )
        == "fieldguide"
    )
    request = opener.call_args.args[0]
    assert request.full_url == "http://localhost:3333/api/public/projects"
    assert request.get_header("Authorization") == (
        "Basic " + b64encode(b"pk-example:sk-example").decode()
    )
    opener.return_value = _response({"data": [{"id": "other", "name": "fieldguide"}]})
    with raises(ProvisioningError):
        verify_project(
            "http://localhost:3333", "pk-example", "sk-example", "fieldguide"
        )


def test_verify_rejects_authentication_failure_without_secret_in_error(
    monkeypatch: MonkeyPatch,
) -> None:
    """An authentication failure reports a domain error without credentials."""
    monkeypatch.setattr(
        "observability_ai.cli.urlopen",
        Mock(
            side_effect=HTTPError(
                "http://localhost", 401, "Unauthorized", Message(), None
            )
        ),
    )
    with raises(ProvisioningError) as caught:
        verify_project("http://localhost:3333", "pk-example", "sk-example")
    assert "sk-example" not in str(caught.value)


@mark.parametrize(
    "payload",
    [
        None,
        [],
        {},
        {"data": []},
        {"data": [{"id": "first"}, {"id": "second"}]},
        {"data": [{"name": "fieldguide"}]},
        {"data": [{"id": ""}]},
    ],
)
def test_verification_rejects_ambiguous_or_malformed_responses(
    monkeypatch: MonkeyPatch, payload: object
) -> None:
    """Only a single project with a nonempty identifier is accepted as verified."""
    monkeypatch.setattr(
        "observability_ai.cli.urlopen", Mock(return_value=_response(payload))
    )
    with raises(ProvisioningError):
        verify_project("http://localhost:3333", "pk-example", "sk-example")


def test_verification_requires_matching_organization(monkeypatch: MonkeyPatch) -> None:
    """Matching project IDs alone cannot claim projects owned by another org."""
    monkeypatch.setattr(
        "observability_ai.cli.urlopen",
        Mock(
            return_value=_response(
                {"data": [{"id": "fieldguide", "organization": {"id": "other-org"}}]}
            )
        ),
    )
    with raises(ProvisioningError, match="organization"):
        verify_project(
            "http://localhost:3333",
            "pk-example",
            "sk-example",
            "fieldguide",
            "observability-ai",
        )


@mark.parametrize(
    "base_url",
    [
        "file:///tmp/credentials",
        "https://user:secret@example.com",
        "http://localhost:3000?secret=hidden",
        "http://localhost:3000#fragment",
        "https://",
    ],
)
def test_invalid_base_url_fails_without_network_or_secret_output(
    monkeypatch: MonkeyPatch,
    http: Mock,
    base_url: str,
    cli_errors: StringIO,
) -> None:
    """Credential-bearing or unsupported URLs are rejected before making requests."""
    monkeypatch.setenv("LANGFUSE_BASE_URL", base_url)
    monkeypatch.setenv("LANGFUSE_PUBLIC_KEY", "pk-lf-example")
    monkeypatch.setenv("LANGFUSE_SECRET_KEY", "sk-lf-example")
    assert main(["verify"]) != 0
    assert "user:secret" not in cli_errors.getvalue()
    assert "hidden" not in cli_errors.getvalue()
    http.assert_not_called()


def test_health_retries_until_healthy(monkeypatch: MonkeyPatch) -> None:
    """Transient startup failures are retried with database health requested."""
    opener = Mock(side_effect=[URLError("starting"), _response({"status": "OK"})])
    monkeypatch.setattr("observability_ai.cli.urlopen", opener)
    monkeypatch.setattr("observability_ai.cli.sleep", Mock())
    wait_for_health("http://localhost:3333", timeout=1)
    assert opener.call_count == 2
    request = opener.call_args.args[0]
    url = request if isinstance(request, str) else request.full_url
    assert url == (
        "http://localhost:3333/api/public/health?failIfDatabaseUnavailable=true"
    )


def test_health_timeout_is_actionable(monkeypatch: MonkeyPatch) -> None:
    """An unavailable instance eventually raises an explicit timeout error."""
    monkeypatch.setattr(
        "observability_ai.cli.urlopen", Mock(side_effect=URLError("still starting"))
    )
    monkeypatch.setattr("observability_ai.cli.sleep", Mock())
    with raises(ProvisioningError, match="(?i)(health|timed out|timeout)"):
        wait_for_health("http://localhost:3333", timeout=0.01)
