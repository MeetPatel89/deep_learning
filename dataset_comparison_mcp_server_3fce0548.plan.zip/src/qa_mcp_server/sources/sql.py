"""Azure SQL interactive MFA connections, serialized per cached connection."""

import atexit
from collections.abc import Iterator
from dataclasses import dataclass, field
from datetime import date, datetime, time
from decimal import Decimal
from threading import RLock
from typing import Any

import polars as pl

from qa_mcp_server.models import SQLConnection, SQLSource


@dataclass
class CachedConnection:
    connection: Any
    lock: RLock = field(default_factory=RLock)


_connections: dict[tuple[str, str, str | None, str], CachedConnection] = {}
_cache_lock = RLock()


def _open_connection(source: SQLConnection):
    try:
        import pyodbc
    except ImportError as error:
        raise RuntimeError(
            "SQL requires the ODBC runtime and Microsoft ODBC Driver 18 for SQL Server"
        ) from error
    return pyodbc.connect(connection_string(source), timeout=source.timeout, autocommit=True)


def _escape(value: str) -> str:
    return "{" + value.replace("}", "}}") + "}"


def connection_string(source: SQLConnection) -> str:
    server = source.server
    if not server.lower().startswith("tcp:"):
        server = "tcp:" + server
    if "," not in server:
        server += ",1433"
    fields = [
        f"Driver={_escape(source.driver)}",
        f"Server={_escape(server)}",
        f"Database={_escape(source.database)}",
        "Authentication=ActiveDirectoryInteractive",
        "Encrypt=yes",
        "TrustServerCertificate=no",
    ]
    if source.username:
        fields.append(f"UID={_escape(source.username)}")
    return ";".join(fields) + ";"


def get_connection(source: SQLConnection) -> CachedConnection:
    key = (source.server, source.database, source.username, source.driver)
    with _cache_lock:
        if key not in _connections:
            connection = _open_connection(source)
            _connections[key] = CachedConnection(connection)
        return _connections[key]


def test_connection(source: SQLConnection) -> dict[str, Any]:
    cached = get_connection(source)
    with cached.lock:
        cached.connection.timeout = source.timeout
        cursor = cached.connection.cursor()
        try:
            result = cursor.execute("SELECT 1").fetchone()
            if result is None or result[0] != 1:
                raise RuntimeError("SQL connection did not return 1 for SELECT 1")
        finally:
            cursor.close()
    return {"connected": True, "server": source.server, "database": source.database}


def iter_sql_batches(source: SQLSource, batch_size: int) -> Iterator[pl.DataFrame]:
    query = source.query
    if source.query_file is not None:
        query = source.query_file.read_text(encoding="utf-8-sig")
    if not query or not query.strip():
        raise ValueError("SQL query is empty")
    cached = get_connection(source)
    with cached.lock:
        cached.connection.timeout = source.timeout
        # Own the cursor so it is closed on completion or generator cancellation.
        cursor = cached.connection.cursor()
        try:
            emitted = False
            for frame in pl.read_database(
                query, cursor, iter_batches=True, batch_size=batch_size, infer_schema_length=None
            ):
                emitted = True
                yield frame
            if not emitted:
                if cursor.description is None:
                    raise ValueError("SQL query must return a tabular result set")
                dtype_map = {
                    bool: pl.Boolean,
                    int: pl.Int64,
                    float: pl.Float64,
                    str: pl.String,
                    bytes: pl.Binary,
                    date: pl.Date,
                    datetime: pl.Datetime("us"),
                    time: pl.Time,
                }
                schema = {}
                for description in cursor.description:
                    name, code = description[:2]
                    schema[name] = (
                        pl.Decimal(description[4] or 38, description[5] or 0)
                        if code is Decimal
                        else dtype_map.get(code, pl.Null)
                    )
                yield pl.DataFrame(schema=schema)
        finally:
            cursor.close()


def close_connections() -> None:
    with _cache_lock:
        for cached in _connections.values():
            with cached.lock:
                cached.connection.close()
        _connections.clear()


atexit.register(close_connections)
