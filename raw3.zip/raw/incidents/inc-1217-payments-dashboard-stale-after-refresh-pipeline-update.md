---
doc_id: INC-1217
title: Payments Dashboard Stale After Refresh Pipeline Update
doc_type: incident
service_id: svc_payments_reporting
owner_group: Data Applications
visibility: internal
status: resolved
created_at: "2026-06-15T23:05:00"
updated_at: "2026-06-16T04:15:00"
related_records:
  - CHG-2411
  - KI-221
  - PRB-304
  - RUNBOOK-PAY-007
  - KB-204
  - POL-COMMS-001
  - WN-INC-1217
  - COMM-INC-1217
  - TASK-INC-1217
  - POL-SLA-001
source_facts:
  - CHG-2411
  - KI-221
  - svc_payments_reporting
difficulty_tags:
  - multi-hop
  - source-vs-reporting-layer
  - temporal-reasoning
servicenow:
  table: incident
  number: INC001217
  state: Resolved
  impact: 2
  urgency: 1
  priority: 2
  priority_label: "2 - High"
  category: Data
  subcategory: Reporting
  business_service: Payments Reporting Service
  cmdb_ci: Payments Reporting Pipeline
  assignment_group: Data Applications
  opened_by_group: Service Desk L1
  contact_type: Self-service
  related_change: CHG002411
  related_known_issue: KI00221
  related_problem: PRB000304
  sla_policy: POL-SLA-001
  sla_target_response: "30 minutes"
  sla_target_resolution: "8 hours"
  sla_breached: false
  visibility: internal
  contains_customer_safe_wording: false
---

# Payments Dashboard Stale After Refresh Pipeline Update

## Record details

| Field | Value |
| --- | --- |
| Table | incident |
| Number | INC001217 |
| State | Resolved |
| Impact | 2 |
| Urgency | 1 |
| Priority | 2 - High |
| Category | Data |
| Subcategory | Reporting |
| Business service | Payments Reporting Service |
| Configuration item | Payments Reporting Pipeline |
| Assignment group | Data Applications |
| Opened by group | Service Desk L1 |
| Contact type | Self-service |
| Related change | CHG002411 |
| Related known issue | KI00221 |
| Related problem | PRB000304 |
| SLA policy | POL-SLA-001 |
| SLA target response | 30 minutes |
| SLA target resolution | 8 hours |
| SLA breached | false |
| Visibility | internal |
| Contains customer-safe wording | false |

## Incident summary

INC-1217 was opened for stale Payments Reporting Service dashboards after CHG-2411. CHG-2411 completed at 2026-06-15T22:30:00, and the incident was opened at 2026-06-15T23:05:00. Incident began after CHG-2411 completed.

Business users reported stale dashboards and payment export mismatches. Data Applications owned remediation.

## Impact

Payment operations users could view dashboards and exports, but the data freshness was wrong. Exported payment totals did not match the operational transaction view, creating reconciliation risk for business users.

Source payment transactions were not lost. The impact was isolated to reporting freshness and export consistency.

## Timeline

| Time | Event |
| --- | --- |
| 2026-06-15T21:00:00 | CHG-2411 change window opened. |
| 2026-06-15T22:30:00 | CHG-2411 planned window ended. |
| 2026-06-15T22:35:00 | Change record updated as completed. |
| 2026-06-15T23:05:00 | INC-1217 opened for stale dashboard reports. |
| 2026-06-15T23:24:00 | Service Desk L1 confirmed multiple users saw stale dashboard data. |
| 2026-06-15T23:50:00 | Data Applications confirmed Databricks transformation showed successful completion. |
| 2026-06-16T00:20:00 | Azure SQL Database staging tables confirmed current transaction records. |
| 2026-06-16T00:55:00 | Synapse/Fabric reporting layer still showed the previous refresh watermark. |
| 2026-06-16T02:10:00 | Reporting refresh rerun started. |
| 2026-06-16T03:05:00 | Backfill from last successful payment partition completed. |
| 2026-06-16T04:15:00 | Incident resolved after dashboard and export totals were confirmed refreshed. |

## Observed symptoms

The incident matched KI-221:

- Payments dashboards were stale.
- Payment export totals did not match dashboard or operational expectations.
- Databricks transformation showed successful completion.
- Azure SQL Database staging tables contained current transaction records.
- Synapse/Fabric reporting layer still showed the previous refresh watermark.

Support notes used several descriptions for the same condition, including stale reporting view, dashboard freshness delay, and source transactions present but reporting layer behind.

## Investigation notes

Service Desk L1 confirmed the affected dashboard and export timing, then escalated to Data Applications because the issue affected multiple business users and followed a high-risk reporting pipeline change.

Data Applications compared the source and reporting layers. The source side looked current: Azure SQL Database staging tables contained current transaction records and the Databricks transformation job had succeeded. The downstream Synapse/Fabric reporting refresh did not advance to the expected watermark.

The incident was linked to KI-221 and PRB-304 because the latest partition was not reflected in the reporting layer after transformation completion.

## Resolution

Rerunning reporting refresh and backfilling from the last successful partition resolved the issue. Data Applications verified the latest Databricks output partition and reran the Synapse/Fabric reporting refresh.

After backfill, the dashboard and export totals were confirmed against the expected reporting period. Service Desk L1 then closed the user-facing reports.

## Customer communication

Customer-facing updates used the KI-221 safe wording:

"Reporting data is delayed, but source payment transactions are not lost."

Support did not include internal control-table or watermark mechanics in customer-facing text.

## Follow-up actions

- Link future stale payment dashboard reports to KI-221 when symptoms match.
- Keep RUNBOOK-PAY-007 current with the watermark, partition, rerun, and backfill sequence.
- Track PRB-304 for the known error condition.
- Notify Release Management because the incident followed CHG-2411.

## Related records

- CHG-2411: Update Databricks Runtime and Synapse/Fabric Refresh Pipeline for Payments Reporting Service.
- KI-221: Payments Dashboard Data Freshness Delay After Synapse/Fabric Refresh Failure.
- PRB-304: Payments Reporting Watermark Not Advanced After Successful Databricks Transformation.
- RUNBOOK-PAY-007: Payments Reporting Data Freshness Runbook.
- KB-204: Payments Dashboard Data Delay.
- POL-COMMS-001: Customer-Safe Communication Policy.
- WN-INC-1217: Internal work notes recorded during the INC-1217 investigation.
- COMM-INC-1217: Customer communications sent for INC-1217.
- TASK-INC-1217: Incident tasks created and completed under INC-1217.
- POL-SLA-001: SLA policy governing INC-1217 response and resolution targets.

