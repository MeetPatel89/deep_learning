"""Smoke-test an installed observe-eval-ai distribution."""

from __future__ import annotations

from asyncio import run
from collections.abc import AsyncGenerator
from contextlib import aclosing
from functools import partial
from importlib import import_module
from importlib.metadata import entry_points, metadata, version
from importlib.resources import files
from importlib.util import find_spec
from pathlib import Path
from sys import argv
from typing import TYPE_CHECKING, cast

from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

from observability_ai import (
    ContentCapturePolicy,
    Generation,
    LangfuseSettings,
    Observation,
    Telemetry,
    TraceAttributes,
    __version__,
    current_observation_id,
    current_trace_id,
)
from observability_ai.adapters import model_runtime_observer, retrieval_observer
from observability_ai.evaluation import (
    Contains,
    EvaluationResult,
    ExactMatch,
    HitAtK,
    JsonParsable,
    JudgeRubric,
    LengthWithin,
    LiveEvaluation,
    ModelRuntimeJudge,
    NumericTolerance,
    PrecisionAtK,
    RecallAtK,
    ReciprocalRank,
    RegexMatch,
)
from observability_ai.genai import (
    langfuse_usage_details,
    model_attributes,
    prompt_attributes,
    usage_attributes,
)
from observability_ai.provisioning import AppProvision, init_environment

if TYPE_CHECKING:
    from model_runtime import ModelRuntime


def main() -> None:
    """Verify installed metadata, the public version, and packaged type information."""
    if len(argv) != 2:
        raise SystemExit("usage: package_smoke.py EXPECTED_VERSION")

    expected_version = argv[1]
    installed_version = version("observe-eval-ai")
    if installed_version != expected_version:
        raise RuntimeError(
            f"installed version {installed_version!r} does not match "
            f"expected version {expected_version!r}"
        )
    if __version__ != installed_version:
        raise RuntimeError("public version does not match installed package metadata")
    provision = AppProvision(app="package-smoke")
    if init_environment(provision)["LANGFUSE_INIT_PROJECT_ID"] != "package-smoke":
        raise RuntimeError("installed provisioning module could not prepare a project")
    scripts = tuple(entry_points(group="console_scripts", name="observability-ai"))
    if len(scripts) != 1 or not callable(scripts[0].load()):
        raise RuntimeError("installed provisioning console script is missing")
    if set(metadata("observe-eval-ai").get_all("Provides-Extra") or ()) != {
        "langfuse",
        "model-runtime",
        "vectorstore",
    }:
        raise RuntimeError("installed package is missing its optional extras")
    for optional in ("model_runtime", "vectorstore", "langfuse"):
        if find_spec(optional) is not None:
            raise RuntimeError(f"core distribution unexpectedly installed {optional}")
    try:
        ModelRuntimeJudge(
            cast("ModelRuntime", object()),
            "judge",
            JudgeRubric("quality", "Check output"),
        )
    except ImportError as exc:
        if "observe-eval-ai[model-runtime]" not in str(exc):
            raise RuntimeError("missing judge install hint") from exc
    else:
        raise RuntimeError("judge unexpectedly constructed without its extra")
    if PrecisionAtK(3)(output=["a", "a"], expected_output=["a"]).value != 1 / 3:
        raise RuntimeError("installed retrieval metric counted duplicate credit")
    for result in (
        Contains()(output="a useful answer", expected_output="answer"),
        RegexMatch(r"^answer$")(output="answer"),
        NumericTolerance(abs_tolerance=0.01)(output=1.001, expected_output=1),
        JsonParsable()(output='{"answer": 42}'),
        LengthWithin(min_length=1, max_length=1)(output=["answer"]),
        HitAtK(1)(output=["a"], expected_output=["a"]),
        RecallAtK(2)(output=["a", "b"], expected_output=["a", "b"]),
        ReciprocalRank()(output=["a"], expected_output=["a"]),
    ):
        if result.value != 1.0:
            raise RuntimeError(f"installed {result.name} evaluator failed")
    delivered: list[tuple[EvaluationResult, str, str | None]] = []

    def sink(
        result: EvaluationResult, trace_id: str, observation_id: str | None
    ) -> None:
        delivered.append((result, trace_id, observation_id))

    results = run(
        LiveEvaluation([ExactMatch()], sink=sink).evaluate(
            output="answer", expected_output="answer", trace_id="smoke-trace"
        )
    )
    if delivered != [
        (EvaluationResult("exact_match", True, "BOOLEAN"), "smoke-trace", None)
    ] or results != (delivered[0][0],):
        raise RuntimeError("installed live evaluation failed")
    try:
        import_module("observability_ai.langfuse")
    except ImportError as exc:
        if "observe-eval-ai[langfuse]" not in str(exc):
            raise RuntimeError("missing SDK install hint") from exc
    else:
        raise RuntimeError("SDK integration unexpectedly imported without its extra")

    package = files("observability_ai")
    if not package.joinpath("py.typed").is_file():
        raise RuntimeError("installed package is missing its py.typed marker")
    for module in ("datasets.py", "experiments.py", "batch.py", "_evaluation.py"):
        if not package.joinpath("langfuse", module).is_file():
            raise RuntimeError(f"installed package is missing langfuse/{module}")
    source_directory = Path(__file__).resolve().parents[1] / "src"
    if source_directory in Path(str(package)).resolve().parents:
        raise RuntimeError("smoke test imported repository source instead of a build")

    exporter = InMemorySpanExporter()
    with Telemetry(
        LangfuseSettings("pk-smoke", "sk-smoke"),
        service_name="package-smoke",
        service_version=installed_version,
        span_processor=SimpleSpanProcessor(exporter),
        content_capture=ContentCapturePolicy(enabled=False),
    ) as telemetry:
        for factory, extra in (
            (
                partial(model_runtime_observer, telemetry, provider_name="test"),
                "model-runtime",
            ),
            (partial(retrieval_observer, telemetry), "vectorstore"),
        ):
            try:
                factory()
            except ImportError as exc:
                if f"observe-eval-ai[{extra}]" not in str(exc):
                    raise RuntimeError("missing adapter install hint") from exc
            else:
                raise RuntimeError("adapter unexpectedly constructed without its extra")

        trace = TraceAttributes(session_id="package-smoke")

        @telemetry.traced("work", type="chain")
        def record_generation() -> None:
            with telemetry.generation(
                "child",
                model="test-model",
                provider_name="test",
                input="omitted prompt",
            ) as span:
                if not isinstance(span, Generation):
                    raise RuntimeError("installed generation did not return a handle")
                span.set_attributes(
                    model_attributes(provider_name="test", request_model="test-model")
                )
                span.set_attributes(
                    usage_attributes(input_tokens=7, output_tokens=3, cached_tokens=2)
                )
                span.link_prompt("smoke-prompt", 1)
                span.set_cost(total_cost=0)

        with telemetry.propagate(trace):
            with telemetry.agent("parent", input="omitted input") as handle:
                if not isinstance(handle, Observation):
                    raise RuntimeError("installed facade did not return a handle")
                if (
                    current_trace_id() != handle.trace_id
                    or current_observation_id() != handle.observation_id
                ):
                    raise RuntimeError("installed active IDs do not match the handle")
                record_generation()
                run(
                    LiveEvaluation([ExactMatch()], sink=sink).evaluate(
                        output="answer", expected_output="answer"
                    )
                )
                if delivered[-1][1:] != (handle.trace_id, handle.observation_id):
                    raise RuntimeError("installed live sink resolved the wrong IDs")
        if not telemetry.force_flush():
            raise RuntimeError("installed telemetry could not flush")
        child, chain, parent = exporter.get_finished_spans()
        if child.parent != chain.context or chain.parent != parent.context:
            raise RuntimeError("installed telemetry did not preserve parent context")
        for observation, expected_type in (
            (child, "generation"),
            (chain, "chain"),
            (parent, "agent"),
        ):
            if (
                observation.attributes is None
                or observation.attributes.get("langfuse.observation.type")
                != expected_type
                or "langfuse.observation.input" in observation.attributes
            ):
                raise RuntimeError(
                    "installed observation types or capture policy failed"
                )
        if ContentCapturePolicy(enabled=True).as_otel_attributes(output=False) != {
            "langfuse.observation.output": "false"
        }:
            raise RuntimeError("installed policy could not serialize explicit content")
        if (
            child.attributes is None
            or child.attributes.get("langfuse.session.id") != "package-smoke"
        ):
            raise RuntimeError("installed telemetry did not preserve trace dimensions")
        if child.attributes.get("gen_ai.usage.input_tokens") != 7:
            raise RuntimeError(
                "installed helper did not preserve inclusive token usage"
            )
        if langfuse_usage_details(input_tokens=7, output_tokens=3, cached_tokens=2) != {
            "input": 5,
            "output": 3,
            "cache_read_input_tokens": 2,
        }:
            raise RuntimeError("installed helper did not split exclusive token usage")

        if any(
            child.attributes.get(key) != value
            for key, value in prompt_attributes(name="smoke-prompt", version=1).items()
        ):
            raise RuntimeError("installed prompt attribution failed")
        if list(telemetry.stream("stream", [1, 2])) != [1, 2]:
            raise RuntimeError("installed stream changed yielded values")
        streamed = exporter.get_finished_spans()[-1]
        if (
            streamed.attributes is None
            or streamed.attributes.get(
                "langfuse.observation.metadata.stream_item_count"
            )
            != 2
            or "langfuse.observation.completion_start_time" not in streamed.attributes
        ):
            raise RuntimeError("installed stream did not record timing and count")
        if current_trace_id() is not None or current_observation_id() is not None:
            raise RuntimeError("installed tracing leaked active context")

        @telemetry.traced("partial async stream", type="chain")
        async def items() -> AsyncGenerator[int, None]:
            yield 1
            yield 2

        async def consume_one() -> None:
            async with aclosing(items()) as source:
                if await anext(source) != 1:
                    raise RuntimeError("installed async stream changed its first item")

        run(consume_one())
        partial_stream = exporter.get_finished_spans()[-1]
        if (
            partial_stream.name != "partial async stream"
            or partial_stream.attributes is None
            or partial_stream.attributes.get(
                "langfuse.observation.metadata.stream_item_count"
            )
            != 1
            or partial_stream.attributes.get("langfuse.observation.type") != "chain"
        ):
            raise RuntimeError(
                "installed async decorator did not close a partial stream"
            )
        redacted = ContentCapturePolicy(
            enabled=True, redactor=lambda value: "safe", max_characters=3
        ).as_otel_attributes(input=object())
        if redacted != {"langfuse.observation.input": '"sa...[truncated]'}:
            raise RuntimeError("installed redaction/truncation failed")

    telemetry.shutdown()
    print(f"observe-eval-ai {installed_version} distribution smoke test passed")


if __name__ == "__main__":
    main()
