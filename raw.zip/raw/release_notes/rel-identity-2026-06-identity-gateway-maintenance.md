---
doc_id: REL-IDENTITY-2026-06
title: June 2026 Identity Gateway Maintenance Release Notes
doc_type: release_note
service_id: svc_identity_gateway
owner_group: Release Management
visibility: internal
status: published
created_at: "2026-06-12T18:00:00"
updated_at: "2026-06-13T09:00:00"
related_records:
  - CHG-2407
  - KI-104
source_facts:
  - CHG-2407
  - svc_identity_gateway
difficulty_tags:
  - change-context
  - temporal-reasoning
---

# June 2026 Identity Gateway Maintenance Release Notes

## Release summary

June maintenance included Okta signing certificate rotation for Identity Gateway. The maintenance was managed through CHG-2407 and owned by IAM Platform, with Release Management publishing the release note for internal awareness.

Maintenance was expected to be transparent to users. No broad sign-in interruption was expected after the change window.

## Services affected

Primary service:

- Identity Gateway, service ID svc_identity_gateway.

Relevant dependencies:

- Okta.
- Employee Portal.
- Internal API Gateway.

Support teams should use this release note as change context when evaluating Employee Portal sign-in reports around 2026-06-12T22:00:00 through 2026-06-13.

## Changes included

The release included:

- Rotation of the Okta signing certificate used by Identity Gateway.
- Post-change verification of the active sign-in path.
- Confirmation that the maintenance activity completed inside the planned CHG-2407 window.

CHG-2407 planned start was 2026-06-12T22:00:00 and planned end was 2026-06-12T23:00:00. The change record was updated at 2026-06-12T23:05:00 after implementation notes were entered.

## Expected behavior

Expected behavior after the release:

- Users should continue to access Employee Portal through enterprise SSO.
- No user action should be required for the certificate rotation.
- Service Desk L1 should continue standard login troubleshooting unless multiple users report sign-in failures.

If multiple users report invalid SAML response errors after the window, route to Identity Gateway support and reference CHG-2407.

## Post-release observations

INC-1104 was opened at 2026-06-12T23:18:00, shortly after CHG-2407 completed. Users reported invalid SAML response errors, and some users could log in while others could not.

IAM Platform later associated the incident with KI-104, where some Identity Gateway nodes may continue using stale IdP metadata after certificate rotation.

## Known issues added after release

Known post-change issue KI-104 was added after the release window. The current customer-safe summary for that issue is:

"We are validating the enterprise sign-in configuration after scheduled identity maintenance."

Support should use RUNBOOK-SSO-003 for internal handling and avoid exposing internal diagnostic detail in customer-facing communication.

## Related records

- CHG-2407: Rotate Okta Signing Certificate for Identity Gateway.
- KI-104: SSO Metadata Cache Delay After Certificate Rotation.

