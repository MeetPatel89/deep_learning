---
doc_id: TASK-PRB-304
title: PRB-304 Problem Tasks
doc_type: problem_task
service_id: svc_payments_reporting
owner_group: Data Applications
visibility: internal
status: in_progress
created_at: "2026-06-16T09:30:00"
updated_at: "2026-06-18T10:00:00"
related_records:
  - PRB-304
  - KI-221
  - RUNBOOK-PAY-007
source_facts:
  - KI-221
  - svc_payments_reporting
difficulty_tags:
  - root-cause
  - task-decomposition
servicenow:
  table: problem_task
  parent: PRB000304
  task_numbers:
    - PTASK0002001
    - PTASK0002002
    - PTASK0002003
  visibility: internal
  contains_customer_safe_wording: false
---

# PRB-304 Problem Tasks

## Record details

| Field | Value |
| --- | --- |
| Table | problem_task |
| Parent | PRB000304 |
| Task numbers | PTASK0002001, PTASK0002002, PTASK0002003 |
| Visibility | internal |
| Contains customer-safe wording | false |

Three problem tasks were created under PRB000304 to confirm the root cause, document the known error, and deliver a permanent fix. PRB-304 remains in Known Error state because the permanent fix task is still in progress; matching incidents should continue to be treated as KI-221 candidates and handled with RUNBOOK-PAY-007.

## PTASK0002001 — Confirm watermark non-advancement root cause

| Field | Value |
| --- | --- |
| Number | PTASK0002001 |
| Short description | Confirm watermark non-advancement root cause |
| Assignment group | Data Applications |
| State | Closed Complete |
| Opened at | 2026-06-16T09:30:00 |
| Closed at | 2026-06-16T16:00:00 |

Data Applications reproduced the failure evidence from INC-1217: the Databricks transformation completed successfully and produced the latest output partition, but the Azure SQL Database control-table watermark did not advance. Because the watermark stayed on the previous value, the downstream Synapse/Fabric reporting refresh skipped the latest partition.

The root cause was confirmed as watermark advancement not being coupled to transformation success in the refresh pipeline deployed by CHG-2411. Source payment transactions were confirmed unaffected in all reproduced scenarios.

## PTASK0002002 — Document known error KI-221 and update RUNBOOK-PAY-007

| Field | Value |
| --- | --- |
| Number | PTASK0002002 |
| Short description | Document known error KI-221 and update RUNBOOK-PAY-007 |
| Assignment group | Data Applications |
| State | Closed Complete |
| Opened at | 2026-06-16T10:00:00 |
| Closed at | 2026-06-16T12:30:00 |

The known error condition and its symptom pattern were documented in KI-221, including the customer-safe summary for use in external communications. RUNBOOK-PAY-007 was updated with the approved workaround sequence: validate the Azure SQL control-table watermark, confirm the latest Databricks output partition, rerun the Synapse/Fabric reporting refresh, and backfill from the last successful payment partition if needed.

Service Desk L1 was pointed to KB-204 for customer-safe handling so that internal watermark and control-table detail stays out of customer-facing text.

## PTASK0002003 — Add watermark advancement validation to refresh pipeline

| Field | Value |
| --- | --- |
| Number | PTASK0002003 |
| Short description | Add watermark advancement validation to refresh pipeline |
| Assignment group | Data Applications |
| State | Open / In Progress |
| Opened at | 2026-06-16T14:00:00 |
| Closed at | — |

This task tracks the permanent fix: adding an explicit watermark advancement validation step to the reporting refresh pipeline so that a successful Databricks transformation with a non-advanced control-table watermark is detected and alerted before the Synapse/Fabric refresh runs.

The task remains in progress as of 2026-06-18T10:00:00, matching the Known Error status of PRB-304. Until it closes, stale dashboard reports that match the KI-221 pattern should be worked through RUNBOOK-PAY-007.
