"""Exercise decorator call semantics, span lifetime, and concurrent context."""

from asyncio import CancelledError, TaskGroup, sleep
from collections.abc import AsyncIterator, Iterator
from functools import partial
from inspect import iscoroutinefunction, signature
from typing import assert_type, cast

from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.trace import StatusCode, get_current_span
from pytest import mark, raises

from observability_ai import (
    ContentCapturePolicy,
    LangfuseSettings,
    ObservationType,
    Telemetry,
)


def test_sync_decorator_preserves_signature_results_and_metadata(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Each call gets a fresh observation without capturing arguments or results."""
    telemetry, exporter = otel

    def add(value: int, /, *, increment: int = 1) -> int:
        """Add an increment."""
        assert get_current_span().is_recording()
        return value + increment

    decorated = telemetry.traced()(add)
    assert getattr(decorated, "__name__") == add.__name__
    assert getattr(decorated, "__qualname__") == add.__qualname__
    assert decorated.__doc__ == add.__doc__
    assert signature(decorated) == signature(add)
    assert not iscoroutinefunction(decorated)
    assert assert_type(decorated(2, increment=3), int) == 5
    assert decorated(7) == 8
    spans = exporter.get_finished_spans()
    assert len(spans) == 2
    assert spans[0].context != spans[1].context
    for span in spans:
        assert span.name == add.__qualname__
        assert span.parent is None
        assert span.attributes == {"langfuse.observation.type": "span"}


def test_decorated_bound_methods_keep_binding_and_nested_types(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Decorators work as descriptors and explicit names select Langfuse types."""
    telemetry, exporter = otel

    class Worker:
        """Exercise instance and static method binding."""

        @telemetry.traced("worker", type="agent")
        def answer(self, value: str) -> str:
            """Call a nested tool."""
            return self.normalize(value)

        @staticmethod
        @telemetry.traced("normalize", type="tool")
        def normalize(value: str) -> str:
            """Return normalized text."""
            return value.upper()

    assert Worker().answer("text") == "TEXT"
    tool, agent = exporter.get_finished_spans()
    assert tool.parent == agent.context
    assert tool.attributes == {"langfuse.observation.type": "tool"}
    assert agent.attributes == {"langfuse.observation.type": "agent"}


async def test_enabled_capture_does_not_implicitly_capture_decorated_values(
    settings: LangfuseSettings,
) -> None:
    """An enabled policy still requires explicit input/output from the application."""
    exporter = InMemorySpanExporter()
    with Telemetry(
        settings,
        service_name="decorator-capture",
        service_version="1",
        span_processor=SimpleSpanProcessor(exporter),
        content_capture=ContentCapturePolicy(enabled=True),
    ) as telemetry:

        @telemetry.traced()
        def echo(value: object) -> object:
            return value

        @telemetry.traced()
        async def outer(value: object) -> object:
            await sleep(0)
            return echo(value)

        payload = object()
        assert await outer(payload) is payload
    spans = exporter.get_finished_spans()
    assert len(spans) == 2
    assert all(
        span.attributes == {"langfuse.observation.type": "span"} for span in spans
    )


async def test_async_decorator_covers_awaits_and_preserves_signature(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """A coroutine creates a span when awaited and keeps it current across awaits."""
    telemetry, exporter = otel
    previous = get_current_span()

    async def answer(value: int, *, increment: int = 1) -> int:
        """Compute after yielding control."""
        active = get_current_span()
        assert active.is_recording()
        await sleep(0)
        assert get_current_span() is active
        with telemetry.tool("nested"):
            await sleep(0)
        assert get_current_span() is active
        return value + increment

    decorated = telemetry.traced(type="chain")(answer)
    assert iscoroutinefunction(decorated)
    assert signature(decorated) == signature(answer)
    assert decorated.__doc__ == answer.__doc__
    coroutine = decorated(2, increment=3)
    assert not exporter.get_finished_spans()
    assert get_current_span() is previous
    assert assert_type(await coroutine, int) == 5
    assert get_current_span() is previous
    child, parent = exporter.get_finished_spans()
    assert child.parent == parent.context
    assert parent.name == answer.__qualname__
    assert parent.attributes == {"langfuse.observation.type": "chain"}


async def test_async_callable_instances_and_partials(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Async callables without function metadata still retain their awaited lifetime."""
    telemetry, exporter = otel

    class Worker:
        """Provide an async callable instance."""

        async def __call__(self, value: int) -> int:
            await sleep(0)
            assert get_current_span().is_recording()
            return value

    worker = Worker()
    assert await telemetry.traced()(worker)(3) == 3
    assert await telemetry.traced("partial")(partial(worker.__call__, 4))() == 4
    assert [span.name for span in exporter.get_finished_spans()] == [
        Worker.__qualname__,
        "partial",
    ]


async def test_decorators_preserve_application_exceptions(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Sync and async wrappers record the original error and restore context."""
    telemetry, exporter = otel
    previous = get_current_span()
    error = RuntimeError("application failed")

    @telemetry.traced("sync")
    def fail() -> None:
        raise error

    @telemetry.traced("async")
    async def outer() -> None:
        await sleep(0)
        fail()

    with raises(RuntimeError) as caught:
        await outer()
    assert caught.value is error
    assert get_current_span() is previous
    child, parent = exporter.get_finished_spans()
    assert child.parent == parent.context
    for span in (child, parent):
        assert span.status.status_code is StatusCode.ERROR
        assert [event.name for event in span.events] == ["exception"]


async def test_async_cancellation_ends_span_and_restores_context(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Cancellation is preserved without leaving a recording span current."""
    telemetry, exporter = otel
    previous = get_current_span()
    cancellation = CancelledError()

    @telemetry.traced()
    async def cancel() -> None:
        await sleep(0)
        raise cancellation

    with raises(CancelledError) as caught:
        await cancel()
    assert caught.value is cancellation
    assert get_current_span() is previous
    (span,) = exporter.get_finished_spans()
    assert span.end_time is not None


async def test_concurrent_decorated_calls_keep_distinct_parents(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Reusing decorators across TaskGroups never shares a span or request context."""
    telemetry, exporter = otel
    previous = get_current_span()

    @telemetry.traced("tool", type="tool")
    async def tool(request: str) -> str:
        active = get_current_span()
        active.set_attribute("request", request)
        await sleep(0)
        assert get_current_span() is active
        return request

    @telemetry.traced("agent", type="agent")
    async def agent(request: str) -> None:
        active = get_current_span()
        active.set_attribute("request", request)
        async with TaskGroup() as tasks:
            children = [tasks.create_task(tool(request)) for _ in range(2)]
        assert [child.result() for child in children] == [request, request]
        assert get_current_span() is active

    async with TaskGroup() as tasks:
        for request in ("one", "two"):
            tasks.create_task(agent(request))
    assert get_current_span() is previous
    spans = exporter.get_finished_spans()
    assert len(spans) == 6
    roots = [span for span in spans if span.name == "agent"]
    assert len({span.context.trace_id for span in roots if span.context}) == 2
    for root in roots:
        assert root.parent is None and root.context is not None
        children = [span for span in spans if span.parent == root.context]
        assert len(children) == 2
        for child in children:
            assert child.context is not None
            assert child.context.trace_id == root.context.trace_id
            assert child.attributes is not None and root.attributes is not None
            assert child.attributes["request"] == root.attributes["request"]


@mark.parametrize("name", ["", " ", 1])
def test_decorator_rejects_invalid_names(
    otel: tuple[Telemetry, InMemorySpanExporter], name: object
) -> None:
    """Invalid decorator configuration fails before a callable runs."""
    telemetry, exporter = otel
    with raises((TypeError, ValueError), match="name"):
        telemetry.traced(cast(str, name))
    with raises(ValueError, match="observation type"):
        telemetry.traced(type=cast(ObservationType, "invalid"))
    assert not exporter.get_finished_spans()


async def test_generators_are_traced_during_iteration(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Generator decoration traces execution lazily for sync and async sources."""
    telemetry, exporter = otel

    def generate() -> Iterator[int]:
        assert get_current_span().is_recording()
        yield 1

    async def async_generate() -> AsyncIterator[int]:
        assert get_current_span().is_recording()
        yield 1

    sync = telemetry.traced()(generate)()
    asynchronous = telemetry.traced()(async_generate)()
    assert not exporter.get_finished_spans()
    assert list(sync) == [1]
    assert [item async for item in asynchronous] == [1]
    assert len(exporter.get_finished_spans()) == 2
