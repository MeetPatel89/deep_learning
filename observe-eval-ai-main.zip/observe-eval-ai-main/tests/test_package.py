"""Verify public package metadata."""

from importlib.metadata import version
from pathlib import Path
from tomllib import loads

from observability_ai import __version__


def test_public_version_matches_project_and_distribution() -> None:
    """Keep the public version consistent with project and installed metadata."""
    project = loads(
        (Path(__file__).resolve().parents[1] / "pyproject.toml").read_text()
    )["project"]
    assert __version__ == project["version"] == version("observe-eval-ai")
