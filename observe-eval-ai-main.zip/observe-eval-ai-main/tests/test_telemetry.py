"""Verify observation context, lifecycle, and interoperability with raw OTel."""

from asyncio import TaskGroup, sleep
from collections.abc import Sequence
from subprocess import run
from sys import executable
from typing import cast, get_args, override
from unittest.mock import patch

from opentelemetry.sdk.trace import ReadableSpan, SpanProcessor
from opentelemetry.sdk.trace.export import (
    SimpleSpanProcessor,
    SpanExporter,
    SpanExportResult,
)
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.trace import StatusCode, get_current_span, get_tracer_provider
from pytest import LogCaptureFixture, mark, raises

from observability_ai import (
    LangfuseSettings,
    ObservationType,
    Telemetry,
    TraceAttributes,
)


def test_nested_observations_and_raw_tracers(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Facade and raw spans share context and keep explicitly supplied dimensions."""
    telemetry, exporter = otel
    previous = get_current_span()
    global_provider = get_tracer_provider()
    trace = TraceAttributes(
        session_id="session-1",
        user_id="user-1",
        tags=("tests",),
        metadata={"tenant": "test"},
    )
    with telemetry.observe("parent", attributes=trace) as parent:
        assert get_current_span() is parent.span
        with telemetry.observe("child", type="generation", attributes=trace) as child:
            assert get_current_span() is child.span
            child.set_attribute("gen_ai.request.model", "test-model")
            with telemetry.tracer("external.library").start_as_current_span(
                "raw", attributes=trace.as_otel_attributes()
            ):
                pass
        assert get_current_span() is parent.span
    assert get_current_span() is previous
    assert get_tracer_provider() is global_provider
    spans = {span.name: span for span in exporter.get_finished_spans()}
    assert set(spans) == {"parent", "child", "raw"}
    assert spans["parent"].parent is None
    assert spans["child"].parent == spans["parent"].context
    assert spans["raw"].parent == spans["child"].context
    for span in spans.values():
        assert span.context is not None
        assert span.context.trace_id == parent.span.get_span_context().trace_id
        assert span.attributes is not None
        for key, value in trace.as_otel_attributes().items():
            assert span.attributes[key] == value
    assert spans["child"].attributes is not None
    assert spans["child"].attributes["langfuse.observation.type"] == "generation"
    assert spans["child"].attributes["gen_ai.request.model"] == "test-model"
    assert spans["raw"].instrumentation_scope is not None
    assert spans["raw"].instrumentation_scope.name == "external.library"


@mark.parametrize("observation_type", get_args(ObservationType.__value__))
def test_observation_types(
    otel: tuple[Telemetry, InMemorySpanExporter], observation_type: ObservationType
) -> None:
    """Each supported type is stamped on the finished observation."""
    telemetry, exporter = otel
    with telemetry.observe("typed", type=observation_type):
        pass
    (span,) = exporter.get_finished_spans()
    assert span.attributes == {"langfuse.observation.type": observation_type}


def test_default_and_invalid_observation_types(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """The default is a span; invalid types fail without leaving active context."""
    telemetry, exporter = otel
    previous = get_current_span()
    with raises(ValueError, match="observation type"):
        with telemetry.observe("invalid", type=cast(ObservationType, "invalid")):
            raise AssertionError("the invalid observation body must not run")
    assert get_current_span() is previous
    with telemetry.observe("default"):
        pass
    (span,) = exporter.get_finished_spans()
    assert span.attributes == {"langfuse.observation.type": "span"}


async def test_task_group_parentage_and_isolation(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Concurrent requests and children restore context correctly across awaits."""
    telemetry, exporter = otel
    previous = get_current_span()

    async def child(request_id: str, index: int, trace: TraceAttributes) -> None:
        with telemetry.observe(
            f"{request_id}/child-{index}", type="tool", attributes=trace
        ) as active:
            await sleep(0)
            assert get_current_span() is active.span
            with telemetry.observe(f"{request_id}/leaf-{index}", attributes=trace):
                await sleep(0)
            assert get_current_span() is active.span

    async def request(request_id: str) -> None:
        trace = TraceAttributes(session_id=request_id)
        with telemetry.observe(request_id, attributes=trace) as parent:
            async with TaskGroup() as tasks:
                for index in range(2):
                    tasks.create_task(child(request_id, index, trace))
            assert get_current_span() is parent.span

    async with TaskGroup() as tasks:
        for request_id in ("one", "two"):
            tasks.create_task(request(request_id))
    assert get_current_span() is previous
    spans = {span.name: span for span in exporter.get_finished_spans()}
    assert len(spans) == 10
    first = spans["one"].context
    second = spans["two"].context
    assert first is not None and second is not None
    assert first.trace_id != second.trace_id
    for request_id in ("one", "two"):
        root = spans[request_id]
        assert root.parent is None and root.context is not None
        for index in range(2):
            branch = spans[f"{request_id}/child-{index}"]
            leaf = spans[f"{request_id}/leaf-{index}"]
            assert branch.parent == root.context
            assert leaf.parent == branch.context
            for span in (branch, leaf):
                assert span.context is not None
                assert span.context.trace_id == root.context.trace_id
                assert span.attributes is not None
                assert span.attributes["langfuse.session.id"] == request_id


def test_application_errors_are_recorded_and_preserved(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Application errors end spans, record exceptions, and restore parent context."""
    telemetry, exporter = otel
    previous = get_current_span()
    error = RuntimeError("application failure")
    with raises(RuntimeError) as caught:
        with telemetry.observe("parent"):
            with telemetry.observe("child"):
                raise error
    assert caught.value is error
    assert get_current_span() is previous
    assert len(exporter.get_finished_spans()) == 2
    for span in exporter.get_finished_spans():
        assert span.status.status_code is StatusCode.ERROR
        assert [event.name for event in span.events] == ["exception"]


def test_lifecycle_delegates_to_owned_processor(settings: LangfuseSettings) -> None:
    """Flush results and timeouts are exposed; context exit shuts the processor down."""
    with patch.object(SpanProcessor, "force_flush", return_value=False) as flush:
        with patch.object(SpanProcessor, "shutdown") as shutdown:
            with Telemetry(
                settings,
                service_name="lifecycle-test",
                service_version="1",
                span_processor=SpanProcessor(),
            ) as telemetry:
                assert not telemetry.force_flush(timeout_millis=1234)
            shutdown.assert_called_once_with()
        flush.assert_called_once()
        assert 0 < flush.call_args.args[0] <= 1234


class _FailingExporter(SpanExporter):
    """Simulate a transport failure without networking."""

    @override
    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        raise RuntimeError("transport unavailable")


@mark.parametrize("batched", [False, True])
def test_export_failure_does_not_interrupt_application(
    settings: LangfuseSettings, caplog: LogCaptureFixture, batched: bool
) -> None:
    """OTel processors log exporter failures and let application work complete."""
    with patch(
        "observability_ai.export.langfuse_span_exporter",
        return_value=_FailingExporter(),
    ):
        with Telemetry(
            settings,
            service_name="failure-test",
            service_version="1",
            span_processor=None if batched else SimpleSpanProcessor(_FailingExporter()),
        ) as telemetry:
            with telemetry.observe("failed export"):
                result = "application completed"
            telemetry.force_flush()
    assert result == "application completed"
    assert "transport unavailable" in caplog.text


def test_global_registration_requires_explicit_opt_in() -> None:
    """Exercise real one-time global registration in an isolated Python process."""
    result = run(
        [
            executable,
            "-c",
            """
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.trace import get_tracer, get_tracer_provider

before = get_tracer_provider()
from observability_ai import LangfuseSettings, Telemetry
assert get_tracer_provider() is before

settings = LangfuseSettings('pk-test', 'sk-test')
with Telemetry(settings, service_name='local', service_version='1',
               span_processor=SimpleSpanProcessor(InMemorySpanExporter())):
    assert get_tracer_provider() is before

exporter = InMemorySpanExporter()
with Telemetry(settings, service_name='global', service_version='1',
               span_processor=SimpleSpanProcessor(exporter), set_global=True):
    assert get_tracer_provider() is not before
    with get_tracer('third.party').start_as_current_span('global-span'):
        pass
    assert [span.name for span in exporter.get_finished_spans()] == ['global-span']
""",
        ],
        capture_output=True,
        text=True,
        check=False,
        timeout=20,
    )
    assert result.returncode == 0, result.stderr
