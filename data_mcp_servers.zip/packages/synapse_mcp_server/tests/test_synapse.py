import asyncio
import json
from unittest.mock import Mock

import polars as pl
import pytest
from azure.core.exceptions import ResourceNotFoundError
from azure.synapse.artifacts import models
from data_mcp_core import sql
from synapse_mcp_server.debugging import classify_failure
from synapse_mcp_server.server import TOOLSETS, create_server


class Poller:
    def __init__(self, result):
        self.value = result

    def result(self, timeout=None):
        return self.value


def test_run_tree_leaf_diagnosis_and_compare(synapse):
    service, _, _, _ = synapse
    tree = service.get_run_tree("dev", "parent")
    assert tree["children"][0]["run_id"] == "child"
    assert tree["duration_ms"] == 60000
    diagnosis = service.diagnose_pipeline_run("dev", "parent")
    failures = diagnosis["failed_leaf_activities"]
    assert len(failures) == 1 and failures[0]["activity"] == "CopySales"
    assert failures[0]["copy"]["rows_written"] == 4
    assert failures[0]["causes"][0]["cause"] == "missing_path"
    assert "never-echo-this" not in json.dumps(diagnosis)
    comparison = service.compare_pipeline_runs("dev", "child", "success")
    assert comparison["activities"][0]["expected"]["rows_written"] == 4
    assert comparison["activities"][0]["actual"]["rows_written"] == 10
    assert comparison["parameter_differences"]["date"]["actual"] == "2026-10-08"
    assert service.get_activity_run("dev", "child", "copy")["error"]["errorCode"] == "PathNotFound"


def test_query_pagination_never_loses_sdk_rows(synapse):
    service, artifacts, _, _ = synapse
    records = [
        {"runId": str(index), "status": "Succeeded", "parameters": {"p": 1}} for index in range(5)
    ]

    def page(parameters):
        if parameters.continuation_token is None:
            return {"value": records[:3], "continuationToken": "second-page"}
        assert parameters.continuation_token == "second-page"
        return {"value": records[3:], "continuationToken": None}

    artifacts.pipeline_run.query_pipeline_runs_by_workspace.side_effect = page
    token, identifiers = None, []
    while True:
        result = service.query_pipeline_runs(
            "dev", pipeline="Load", statuses=["Succeeded"], limit=1, continuation=token
        )
        identifiers.extend(item["runId"] for item in result["items"])
        token = result["continuation"]
        if token is None:
            break
    assert identifiers == ["0", "1", "2", "3", "4"]
    parameters = artifacts.pipeline_run.query_pipeline_runs_by_workspace.call_args.args[0]
    assert parameters.filters[0].operand == "PipelineName"
    assert parameters.filters[1].values == ["Succeeded"]
    first = service.query_pipeline_runs("dev", limit=1)
    with pytest.raises(ValueError, match="continuation"):
        service.query_pipeline_runs("dev", pipeline="different", continuation=first["continuation"])


def test_stats_cover_all_pages_and_parameter_filter(synapse):
    service, artifacts, _, _ = synapse
    rows = [
        {
            "runId": str(i),
            "status": status,
            "runDurationInMs": duration,
            "parameters": {"p": i % 2},
            "message": "failure" if status == "Failed" else "",
        }
        for i, (status, duration) in enumerate(
            [("Succeeded", 1000), ("Failed", 2000), ("Succeeded", 3000), ("Succeeded", 4000)]
        )
    ]
    artifacts.pipeline_run.query_pipeline_runs_by_workspace.return_value = {
        "value": rows,
        "continuationToken": None,
    }
    stats = service.pipeline_run_stats("dev")
    assert stats["run_count"] == 4 and stats["success_rate"] == 0.75
    assert stats["duration_ms"]["p50"] == 2500
    filtered = service.query_pipeline_runs("dev", parameters={"p": 1})
    assert [item["runId"] for item in filtered["items"]] == ["1", "3"]
    assert service.pipeline_run_stats("dev", max_runs=2)["truncated"]


def test_artifact_analysis_and_redaction(synapse):
    service, artifacts, _, _ = synapse
    parent = {
        "name": "Orchestrate",
        "properties": {
            "parameters": {"date": {"type": "string"}},
            "activities": [
                {
                    "name": "Copy",
                    "type": "Copy",
                    "inputs": [{"type": "DatasetReference", "referenceName": "Sales"}],
                },
                {
                    "name": "Child",
                    "type": "ExecutePipeline",
                    "dependsOn": [{"activity": "Copy", "dependencyConditions": ["Succeeded"]}],
                    "typeProperties": {
                        "pipeline": {"type": "PipelineReference", "referenceName": "Load"}
                    },
                },
            ],
        },
    }
    child = {"name": "Load", "properties": {"activities": []}}
    artifacts.pipeline.get_pipeline.side_effect = lambda name: (
        parent if name == "Orchestrate" else child
    )
    artifacts.dataset.get_dataset.return_value = {
        "properties": {
            "linkedServiceName": {"type": "LinkedServiceReference", "referenceName": "Lake"}
        }
    }
    analyzed = service.analyze_pipeline("dev", "Orchestrate", source="live")
    assert analyzed["edges"][0]["from"] == "Copy"
    assert analyzed["references"]["linked_services"] == ["Lake"]
    assert analyzed["child_pipelines"][0]["name"] == "Load"
    artifacts.linked_service.get_linked_service.return_value = {
        "properties": {
            "typeProperties": {
                "password": {"type": "SecureString", "value": "secret"},
                "connectionString": "secret",
            }
        }
    }
    assert "secret" not in json.dumps(
        service.get_artifact("dev", "linked_service", "Lake", source="live")
    )
    artifacts.pipeline.get_pipelines_by_workspace.return_value = [parent, child]
    assert (
        service.search_artifacts("dev", "Sales", artifact_types=["pipeline"], source="live")[
            "matches"
        ][0]["name"]
        == "Orchestrate"
    )


def test_artifact_dryrun_and_sdk_model_deserialization(synapse):
    service, artifacts, _, _ = synapse
    service.config.workspaces["dev"].allow_manage = True
    artifacts.pipeline.get_pipeline.side_effect = ResourceNotFoundError("missing")
    definition = {
        "properties": {
            "activities": [
                {"name": "Wait", "type": "Wait", "typeProperties": {"waitTimeInSeconds": 1}}
            ]
        }
    }
    planned = service.upsert_artifact("dev", "pipeline", "New", definition, source="live")
    assert planned["dry_run"] and "proposed" in planned["diff"]
    artifacts.pipeline.begin_create_or_update_pipeline.assert_not_called()
    artifacts.pipeline.begin_create_or_update_pipeline.return_value = Poller(definition)
    result = service.upsert_artifact(
        "dev", "pipeline", "New", definition, dry_run=False, source="live"
    )
    assert "bypass" in result["warning"]
    body = artifacts.pipeline.begin_create_or_update_pipeline.call_args.args[1]
    assert isinstance(body, models.PipelineResource)
    assert body.activities[0].wait_time_in_seconds == 1


def test_execution_forwards_recovery_livy_and_debug_parameters(synapse):
    service, artifacts, spark, _ = synapse
    service.config.workspaces["dev"].allow_run = True
    artifacts.pipeline.create_pipeline_run.return_value = {"runId": "new"}
    assert (
        service.run_pipeline(
            "dev",
            "Load",
            {"p": 1},
            reference_pipeline_run_id="old",
            is_recovery=True,
            start_activity_name="Copy",
        )["runId"]
        == "new"
    )
    arguments = artifacts.pipeline.create_pipeline_run.call_args.kwargs
    assert arguments["is_recovery"] and arguments["start_activity_name"] == "Copy"
    assert service.run_pipeline("dev", "Load", dry_run=True)["dry_run"]
    artifacts.pipeline_run.cancel_pipeline_run.return_value = None
    service.cancel_pipeline_run("dev", "new")
    artifacts.pipeline_run.cancel_pipeline_run.assert_called_with("new", is_recursive=True)
    spark.spark_session.create_spark_session.return_value = {"id": 1}
    assert service.create_spark_session("dev", "pool", "session")["id"] == 1
    spark.spark_session.create_spark_statement.return_value = {"id": 2}
    service.run_spark_statement("dev", "pool", 1, "SELECT 1", language="sql")
    assert spark.spark_session.create_spark_statement.call_args.args[1].kind == "sql"
    spark.spark_batch.create_spark_batch_job.return_value = {"id": 3}
    service.submit_spark_batch("dev", "pool", "batch", "abfss://raw@lake/file.py")
    assert spark.spark_batch.create_spark_batch_job.call_args.args[0].file.endswith("file.py")
    debug = artifacts.data_flow_debug_session
    debug.begin_create_data_flow_debug_session.return_value = Poller({"sessionId": "debug"})
    assert service.create_data_flow_debug_session("dev")["sessionId"] == "debug"
    debug.add_data_flow.return_value = {"jobVersion": "1"}
    service.add_data_flow_to_debug_session(
        "dev",
        "debug",
        {
            "dataFlow": {
                "name": "Flow",
                "properties": {
                    "type": "MappingDataFlow",
                    "typeProperties": {"script": "source(...)"},
                },
            }
        },
    )
    assert debug.add_data_flow.call_args.args[0].session_id == "debug"
    debug.begin_execute_command.return_value = Poller({"data": "rows"})
    service.run_data_flow_debug_command("dev", "debug", "executePreview", {"streamName": "source"})
    assert debug.begin_execute_command.call_args.args[0].command == "executePreviewQuery"
    debug.delete_data_flow_debug_session.return_value = None
    assert service.delete_data_flow_debug_session("dev", "debug")["closed"]


def test_wait_reports_progress_and_diagnoses_failure(synapse):
    service, _, _, _ = synapse
    service.config.workspaces["dev"].allow_run = True
    context = Mock()
    from unittest.mock import AsyncMock

    context.report_progress = AsyncMock()
    result = asyncio.run(service.wait_for_pipeline_run("dev", "parent", ctx=context))
    assert not result["timed_out"] and result["diagnosis"]["failed_leaf_activities"]
    context.report_progress.assert_awaited()


def test_spark_logs_and_cause_classification(synapse):
    service, _, _, registry = synapse
    response = Mock()
    response.text = "first\nsecond\nerror\n"
    registry.http_get.return_value = response
    logs = service.get_spark_application_logs(
        "dev", "pool", "application", livy_id="1", tail_lines=1
    )
    assert logs["text"] == "error" and logs["best_effort"] and logs["truncated"]
    assert (
        "/livyid/1/applications/application/driverlog/stderr/"
        in registry.http_get.call_args.args[1]
    )
    for text, cause in [
        ("401 unauthorized", "auth"),
        ("Firewall denied", "firewall"),
        ("schema conversion failed", "schema_drift"),
        ("timeout", "timeout"),
        ("Java heap space", "out_of_memory"),
    ]:
        assert cause in [item["cause"] for item in classify_failure(text)]


GATED = [
    ("run_pipeline", {"pipeline": "P"}, "allow_run"),
    ("cancel_pipeline_run", {"run_id": "r"}, "allow_run"),
    ("start_trigger", {"trigger": "t"}, "allow_run"),
    ("stop_trigger", {"trigger": "t"}, "allow_run"),
    ("rerun_trigger_run", {"trigger": "t", "run_id": "r"}, "allow_run"),
    ("create_spark_session", {"pool": "p", "name": "n"}, "allow_run"),
    ("run_spark_statement", {"pool": "p", "session_id": 1, "code": "x"}, "allow_run"),
    ("close_spark_session", {"pool": "p", "session_id": 1}, "allow_run"),
    ("submit_spark_batch", {"pool": "p", "name": "n", "file": "f"}, "allow_run"),
    ("pause_sql_pool", {"pool": "p"}, "allow_manage"),
    ("resume_sql_pool", {"pool": "p"}, "allow_manage"),
    (
        "upsert_artifact",
        {"artifact_type": "pipeline", "name": "p", "artifact": {}, "source": "live"},
        "allow_manage",
    ),
    (
        "delete_artifact",
        {"artifact_type": "pipeline", "name": "p", "source": "live"},
        "allow_manage",
    ),
    ("create_data_flow_debug_session", {}, "allow_run"),
    ("add_data_flow_to_debug_session", {"session_id": "s", "package": {}}, "allow_run"),
    (
        "run_data_flow_debug_command",
        {"session_id": "s", "command": "executePreview", "payload": {}},
        "allow_run",
    ),
    ("delete_data_flow_debug_session", {"session_id": "s"}, "allow_run"),
    ("run_sql_query", {"query": "DELETE FROM t"}, "allow_sql_write"),
]


@pytest.mark.parametrize("name,arguments,flag", GATED)
def test_every_synapse_mutation_checks_flag_before_clients(synapse, name, arguments, flag):
    service, _, _, registry = synapse
    with pytest.raises(PermissionError, match=flag):
        getattr(service, name)("dev", **arguments)
    registry.get.assert_not_called()


def test_wait_permission_guard(synapse):
    service, _, _, registry = synapse
    with pytest.raises(PermissionError, match="allow_run"):
        asyncio.run(service.wait_for_pipeline_run("dev", "r"))
    registry.get.assert_not_called()


def test_sql_queries_cap_close_generators_and_block_writes(synapse, monkeypatch):
    service, _, _, _ = synapse
    sources, closed = [], []

    def batches(source, batch_size):
        sources.append(source)
        try:
            yield pl.DataFrame({"id": list(range(10))})
        finally:
            closed.append(True)

    monkeypatch.setattr(sql, "iter_sql_batches", batches)
    result = service.run_sql_query("dev", "SELECT * FROM data", limit=2)
    assert result["rows"] == [{"id": 0}, {"id": 1}] and result["truncated"]
    assert closed
    assert sources[0].server == "workspace.sql.azuresynapse.net"
    assert sources[0].auth == "token"
    with pytest.raises(PermissionError):
        service.run_sql_query("dev", "SELECT * INTO new FROM old")
    service.config.workspaces["dev"].allow_sql_write = True
    execute = Mock(return_value={"affected_rows": 2})
    monkeypatch.setattr(sql, "execute_sql", execute)
    assert service.run_sql_query("dev", "DELETE FROM t")["affected_rows"] == 2
    assert service.run_sql_query("dev", "DELETE FROM t", dry_run=True)["dry_run"]
    assert execute.call_count == 1


def test_sql_diagnostics_use_safe_literals_and_correct_pool(synapse, monkeypatch):
    service, _, _, _ = synapse
    queries = []

    def batches(source, batch_size):
        queries.append(source)
        if "distribution_id" in source.query:
            yield pl.DataFrame({"distribution_id": [1, 2], "row_count": [10, 30]})
        else:
            yield pl.DataFrame({"v": [1]})

    monkeypatch.setattr(sql, "iter_sql_batches", batches)
    service.list_sql_objects("dev", object_type="view", schema="a'; DELETE FROM x; --")
    assert "a''; DELETE FROM x; --" in queries[-1].query
    service.get_request_steps("dev", "request'; DROP TABLE x; --")
    sql.ensure_read_only(queries[-1].query)
    skew = service.check_table_skew("dev", "table")
    assert skew["max_to_mean"] == 1.5 and skew["total_rows"] == 40
    service.query_history("dev")
    assert queries[-1].pool == "serverless"
    service.explain_query("dev", "SELECT 1")
    assert queries[-1].query == "EXPLAIN SELECT 1"
    with pytest.raises(ValueError, match="dedicated"):
        service.list_active_requests("dev", pool="serverless")


def test_toolset_registration_and_workspace_disable(synapse):
    service, _, _, registry = synapse
    service.config.enabled_toolsets = ["workspace", "monitoring"]
    server = create_server(service.config, registry)
    assert {tool.name for tool in asyncio.run(server.list_tools())} == set(
        TOOLSETS["workspace"] + TOOLSETS["monitoring"]
    )
    service.config.workspaces["dev"].enabled_toolsets = ["workspace"]
    with pytest.raises(PermissionError):
        service.get_pipeline_run("dev", "parent")


def test_debug_and_wait_work_with_monitoring_tools_disabled(synapse):
    service, _, _, _ = synapse
    settings = service.config.workspaces["dev"]
    settings.enabled_toolsets = ["debugging", "execution"]
    assert service.diagnose_pipeline_run("dev", "parent")["failed_leaf_activities"]
    settings.enabled_toolsets = ["execution"]
    settings.allow_run = True
    assert asyncio.run(service.wait_for_pipeline_run("dev", "parent"))["diagnosis"][
        "failed_leaf_activities"
    ]


def test_run_character_cap_keeps_continuation(synapse):
    service, artifacts, _, _ = synapse
    rows = [{"runId": "1", "message": "x" * 40_000}, {"runId": "2", "message": "x" * 40_000}]
    artifacts.pipeline_run.query_pipeline_runs_by_workspace.return_value = {
        "value": rows,
        "continuationToken": None,
    }
    first = service.query_pipeline_runs("dev", limit=2)
    assert len(json.dumps(first)) <= 50_000 and first["continuation"]
    second = service.query_pipeline_runs("dev", limit=2, continuation=first["continuation"])
    assert second["items"][0]["runId"] == "2"


def test_workspace_arm_and_accesscontrol_responses(synapse):
    from types import SimpleNamespace

    from azure.mgmt.synapse.models import SqlPool
    from azure.synapse.accesscontrol.models import RoleAssignmentDetailsList

    service, artifacts, spark, registry = synapse
    arm = SimpleNamespace(
        workspaces=Mock(),
        sql_pools=Mock(),
        big_data_pools=Mock(),
        integration_runtimes=Mock(),
        integration_runtime_status=Mock(),
    )
    arm.workspaces.get.return_value = {
        "name": "workspace",
        "properties": {"provisioningState": "Succeeded"},
    }
    arm.sql_pools.list_by_workspace.return_value = [
        SqlPool.deserialize({"name": "warehouse", "properties": {"status": "Online"}})
    ]
    arm.big_data_pools.list_by_workspace.return_value = [{"name": "spark"}]
    arm.integration_runtimes.list_by_workspace.return_value = [{"name": "runtime"}]
    arm.integration_runtime_status.get.return_value = {"properties": {"state": "Started"}}
    access = SimpleNamespace(role_assignments=Mock())

    def role_assignments(**kwargs):
        return kwargs["cls"](
            None,
            RoleAssignmentDetailsList.deserialize(
                {"value": [{"id": "role", "principalId": "person"}]}
            ),
            {"x-ms-continuation": "next"},
        )

    access.role_assignments.list_role_assignments.side_effect = role_assignments
    registry.get.side_effect = lambda workspace, kind, pool=None: {
        "artifacts": artifacts,
        "spark": spark,
        "arm": arm,
        "accesscontrol": access,
    }[kind]
    assert service.get_workspace_info("dev")["properties"]["provisioningState"] == "Succeeded"
    assert service.list_sql_pools("dev")["pools"][0]["properties"]["status"] == "Online"
    assert service.list_spark_pools("dev")["pools"][0]["name"] == "spark"
    assert (
        service.list_integration_runtimes("dev")["runtimes"][0]["status"]["properties"]["state"]
        == "Started"
    )
    roles = service.list_role_assignments("dev", principal_id="person")
    assert roles["assignments"][0]["id"] == "role" and roles["continuation"] == "next"
    service.list_role_assignments("dev", continuation="next")
    assert (
        access.role_assignments.list_role_assignments.call_args.kwargs[
            "continuation_token_parameter"
        ]
        == "next"
    )


def test_notebook_diagnosis_resolves_livy_application_and_oom_logs(synapse, fixture_runs):
    service, _, spark, registry = synapse
    fixture_runs["activities"]["child"] = [
        {
            "activityName": "Notebook",
            "activityRunId": "notebook",
            "activityType": "SynapseNotebook",
            "status": "Failed",
            "input": {"sparkPool": {"referenceName": "pool"}},
            "output": {"result": {"sessionId": 42}},
            "error": {"message": "Notebook failed"},
        }
    ]
    spark.spark_session.get_spark_session.return_value = {
        "id": 42,
        "appId": "application",
        "errorInfo": [],
    }
    response = Mock()
    response.text = "java.lang.OutOfMemoryError: Java heap space"
    registry.http_get.return_value = response
    failed = service.diagnose_pipeline_run("dev", "child")["failed_leaf_activities"][0]
    assert failed["spark_application_id"] == "application"
    assert "heap space" in failed["driver_stderr"]["text"]
    assert "out_of_memory" in [item["cause"] for item in failed["causes"]]
    spark.spark_session.get_spark_session.assert_called_with(42, detailed=True)
