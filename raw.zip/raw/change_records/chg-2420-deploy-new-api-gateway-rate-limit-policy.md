---
doc_id: CHG-2420
title: Deploy New API Gateway Rate-Limit Policy
doc_type: change_record
service_id: svc_internal_api_gateway
owner_group: Platform Engineering
visibility: internal
status: completed
created_at: "2026-06-17T13:00:00"
updated_at: "2026-06-18T20:50:00"
related_records:
  - KI-307
  - INC-1302
  - REL-API-2026-06
source_facts:
  - CHG-2420
  - KI-307
  - svc_internal_api_gateway
difficulty_tags:
  - temporal-reasoning
  - plan-specific-behavior
  - change-to-incident-linkage
---

# Deploy New API Gateway Rate-Limit Policy

## Change summary

CHG-2420 deployed a new API Gateway rate-limit policy for Internal API Gateway. The service routes internal API traffic and enforces rate limits, and the change was owned by Platform Engineering.

Change deployed a new API Gateway rate-limit policy.

Change risk was medium. Related known issue is KI-307.

## Change window

Change window was 2026-06-18T20:00:00 to 2026-06-18T20:45:00.

| Field | Value |
| --- | --- |
| Planned start | 2026-06-18T20:00:00 |
| Planned end | 2026-06-18T20:45:00 |
| Owner group | Platform Engineering |
| Service | Internal API Gateway |
| Risk | Medium |
| Status | Completed |

The change record was updated at 2026-06-18T20:50:00 after deployment completion.

## Services affected

Primary service:

- Internal API Gateway, service ID svc_internal_api_gateway.

Dependencies in scope:

- Kong.
- Vault.
- Splunk.

The policy change affected rate-limit behavior for internal API traffic. Different customer tiers may have different expected burst behavior.

## Implementation notes

Platform Engineering deployed the new rate-limit policy through the Internal API Gateway path. The intended result was improved burst control and platform stability.

The change completed within the planned maintenance window. No rollback was recorded at change closure.

## Validation performed

Post-change validation included:

- Confirming the gateway accepted the new policy.
- Confirming API routing remained available.
- Reviewing initial gateway behavior after the policy deployment.

The validation did not identify the later entitlement mismatch pattern. INC-1302 was opened after the change when Business-tier clients reported unexpected 429 responses.

## Risk and rollback notes

The operational risk was that a newly applied rate-limit policy could reject traffic differently than expected for some client groups. Because Internal API Gateway enforces rate limits, unexpected policy behavior can appear as HTTP 429 Too Many Requests rather than a gateway outage.

Rollback would have required restoring the prior rate-limit policy. For INC-1302, Platform Engineering adjusted the applied rate-limit policy instead of rolling back the entire change.

## Post-change monitoring

Monitor after CHG-2420 for:

- Increased 429 volume in Splunk.
- Business-tier clients reporting unexpected throttling.
- Differences between Business-tier and Enterprise-tier client behavior.
- Client groups receiving stricter burst limits than their entitlement allows.

If reported errors begin after CHG-2420, link the incident to KI-307 and use RUNBOOK-API-005.

## Related records

- KI-307: API Clients Receive Unexpected 429 Responses After Rate-Limit Policy Update.
- INC-1302: Business-Tier API Clients Receive 429 Errors After Rate-Limit Policy Deployment.
- REL-API-2026-06: June 2026 API Gateway Rate-Limit Policy Release Notes.
