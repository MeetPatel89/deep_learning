# Enterprise NL-to-SQL application: implementation design

Version 3.1 • 2026-09-27 • Catalog schema version 4 • Schema-independent planning edition

Companions: [semantic-layer constitution](01-semantic-layer-constitution.md) and [catalog schema](catalog-schema.sql). These three files are the complete planning input. Section 17 provides a reusable planning prompt for an AI coding editor; section 18 makes modular components and MCP harness integration first-class requirements.

## Contents

- [1. Scope and architecture decisions](#1-scope-and-architecture-decisions)
- [2. System architecture and responsibilities](#2-system-architecture-and-responsibilities)
- [3. Enterprise catalog model and incremental onboarding](#3-enterprise-catalog-model-and-incremental-onboarding)
- [4. Catalog storage, projections and publication](#4-catalog-storage-projections-and-publication)
- [5. Configurable retrieval and context assembly](#5-configurable-retrieval-and-context-assembly)
- [6. Semantic graph and relationship planning](#6-semantic-graph-and-relationship-planning)
- [7. Value resolution, examples and domain procedures](#7-value-resolution-examples-and-domain-procedures)
- [8. General semantic query model and compiler](#8-general-semantic-query-model-and-compiler)
- [9. Managed LangGraph workflow from the first production release](#9-managed-langgraph-workflow-from-the-first-production-release)
- [10. Execution, security and trust boundaries](#10-execution-security-and-trust-boundaries)
- [11. Reliability, observability and capacity](#11-reliability-observability-and-capacity)
- [12. Production evaluation and release gates](#12-production-evaluation-and-release-gates)
- [13. Implementation contracts and repository organization](#13-implementation-contracts-and-repository-organization)
- [14. Phased delivery plan](#14-phased-delivery-plan)
- [15. Decision rationale and tradeoffs](#15-decision-rationale-and-tradeoffs)
- [16. Planning package, unknowns and verification scope](#16-planning-package-unknowns-and-verification-scope)
- [17. Handoff to an AI coding editor](#17-handoff-to-an-ai-coding-editor)
- [18. Modular components, interchangeable harnesses and MCP](#18-modular-components-interchangeable-harnesses-and-mcp)

## 1. Scope and architecture decisions

Build an enterprise NL-to-SQL application whose actual company schemas and business definitions are unknown at planning time. The platform must discover structural metadata, help selected stewards establish meaning, publish approved definitions, and answer only questions covered by validated semantics and current access. Company-specific definitions are data authored through the platform; they are not hardcoded into the agent, compiler or UI.

The first production platform includes **a React + TypeScript frontend, Python semantic services, SQLite catalog persistence and in-memory reads, selectable vector retrieval with lexical search and reranking, a typed NetworkX graph, durable LangGraph orchestration for managed mode, deterministic planning/SQL compilation, and first-class MCP/HTTP/Python interfaces over shared services**. Delivery proceeds domain by domain. A catalog inventory of 1,000 tables does not require defining, embedding, approving or exposing all of them together.

### 1.1 Confirmed constraints and discovery inputs

| Item | Required design |
|---|---|
| Frontend | React + TypeScript, with end-user query experience and a separately authorized catalog-steward area |
| Backend | Python, strict Pydantic request/plan/payload schemas, deterministic domain services |
| Metadata authority | Persistent SQLite owned by CatalogService on one durable host/volume; remote clients use APIs |
| Runtime exact reads | Read-only in-memory SQLite loaded from immutable published releases; complete immutable-file fallback for larger releases |
| Later metadata authority | PostgreSQL or a separate Azure SQL metadata store through tested adapters and migrations |
| Vector backend options | NumPy, Chroma, FAISS or Azure AI Search, selected by a versioned retrieval profile |
| Initial small-catalog profile | NumPy exact vectors + SQLite FTS5 lexical retrieval + a separately configured/evaluated reranker, subject to workload/security acceptance |
| Graph | Typed in-memory NetworkX multigraph per release; graph-server adapter only when requirements justify it |
| Workflow | Managed mode: LangGraph with durable versioned state and independently sized checkpoint persistence. Host-controlled component mode: external agent loop, no LangGraph dependency |
| Harness integration | Reusable semantic services through Python/HTTP/MCP adapters; full workflow or selected component profiles; verified target-host compatibility |
| First business execution target | Azure SQL Database/T-SQL, preserving the earlier target choice; source discovery, dialect and execution adapters make subsequent engines explicit extensions |
| Unknown company details | Tables, identities, business definitions, policies, deployment scale, target question families and SLOs must be discovered and approved |

Provision only selected providers. NumPy and FAISS are libraries/index implementations, not database services; Chroma has embedded and server deployment choices; Azure AI Search is an optional managed search service. None supplies authoritative business meaning. Metadata storage, vector backend, embedding provider, reranker, graph backend and workflow persistence are independent choices.

Use a **provisional capacity test envelope**, not a product limit or statement about the company: 1,000–10,000 inventoried relations, 20,000–300,000 fields, 10–100 domains, tens of thousands of approved graph edges and 50 simultaneous workflow requests. Test the full expected inventory separately from the smaller published semantic subset. Replace these inputs with measured requirements during Phase 0. Operational data rows remain in source systems.

### 1.2 Technology decisions and stable boundaries

| Capability | Initial implementation | Replaceable boundary / acceptance condition |
|---|---|---|
| UI | React + TypeScript; generated API types and validated forms | API contract separates frontend from storage and orchestration |
| API/domain logic | Python modules with Pydantic; selected API framework | Service methods own business rules, not route handlers |
| Catalog authority | SQLite, serialized short writes, optimistic revisions | `CatalogAuthoringStore`, `ReleaseStore`; change backend for measured contention/HA requirements |
| Published metadata | Immutable SQLite files and query-only RAM readers | `CatalogReader`; stable IDs and canonical export survive authority migration |
| Retrieval | Configured vector + lexical + fusion + reranking adapters | `VectorIndex`, `LexicalIndex`, `HybridRetriever`, `Reranker`; conformance and relevance gates |
| Graph planning | Immutable NetworkX `MultiDiGraph` plus typed records | `GraphProjection` and `SemanticPlanner`; benchmark graph memory and bounded traversals |
| Orchestration | Managed mode: LangGraph with separate SQLite checkpoints for admitted single-host workload; external hosts may own their own loop | State versioning and application ports; host-controlled deployments omit LangGraph and retain durable execution/context state |
| MCP interface | Tool adapter over the same authorized application facade used by HTTP/Python | Managed workflow or component profiles; no copied rules or dependence on React |
| Work dispatch | Durable execution/publication jobs and worker admission | Queue adapter; Azure Service Bus is an optional Azure-hosted deployment choice |
| Artifacts | Immutable, checksummed catalog/search/graph/evaluation artifacts | Local durable artifact directory for admitted single-host deployment or managed object storage |
| Execution | Restricted parameterized Azure SQL adapter | `SourceAdapter`/`SqlDialectCompiler` and sealed execution interface |
| Observability | OpenTelemetry-compatible traces and metrics | Enterprise-approved sink, sensitive-data handling and retention |

This is a design and planning contract, not an implementation claim. A development run may use local durable files and workers; the first production release must satisfy the same security, evaluation, recovery and admission obligations. A larger deployment changes provider topology rather than the meaning of a semantic query.

### 1.3 Non-negotiable boundaries and deliberate flexibility

The LLM interprets intent and can request additional evidence; it does not authorize data access, define source keys, invent mappings or produce directly executable SQL. Catalog authoring and publication establish governed meaning. Deterministic services enforce that meaning. A graph finds permitted structural alternatives but does not establish their business correctness. Search discovers candidates but cannot issue authoritative value bindings.

The core must be reusable without the web UI, MCP SDK or LangGraph runtime. Section 18 defines dependency rules, packages, two orchestration modes and the host-integration acceptance tests. No particular table names, domain schemas or status rules are seeded by the bootstrap. Initial catalog migrations create an empty platform schema. A separate fixture suite exercises generic relational properties. Domain onboarding produces the actual definitions. Additional sources require discovery, type/dialect, identity, security, consistency and execution conformance; listing another source in metadata alone does not implement federation.

## 2. System architecture and responsibilities

### 2.1 Control services and managed query composition

This diagram shows the full web/managed deployment. Section 18.3 shows the shared component composition for HTTP, Python and MCP, including an external host-owned loop.

```mermaid
flowchart TB
    UI[React and TypeScript frontend] --> API
    UI --> STEWARD[Restricted catalog steward area]
    STEWARD --> CS
    subgraph Control[Metadata authoring and publication]
        DISC[Schema discovery and governed profiling] --> STAGE[Candidate metadata and evidence]
        OWN[Business stewards and engineers] --> STAGE
        STAGE --> CS[CatalogService and serialized writes]
        CS --> CAT[(Persistent SQLite authority)]
        CAT --> PUB[Release validation and publisher]
        PUB --> BLOB[Versioned release artifacts]
        PUB --> SEARCH[Configured lexical and vector projections]
        PUB --> GRAPH[Typed graph projection]
        PUB --> MAN[Active release manifest]
    end
    subgraph Query[Production query services]
        API[Authenticated API] --> WF[LangGraph workflow workers]
        WF --> RET[Domain routing and hybrid retrieval]
        SEARCH --> RET
        GRAPH --> PLAN[Relationship and grain planner]
        RET --> CTX[Authorized context package]
        CTX --> LLM[Intent interpreter]
        LLM --> IR[Typed semantic query proposal]
        IR --> PLAN
        PLAN --> COMP[Deterministic compiler and validators]
        COMP --> QUEUE[Execution ledger and workload queue]
        QUEUE --> EXEC[Restricted source execution adapter]
        EXEC --> DATA[(Company Azure SQL database)]
        DATA --> RESULT[Result storage and answer assembly]
    end
    BLOB --> FILE[Immutable SQLite release file]
    FILE --> SNAP[(Per-worker in-memory SQLite)]
    MAN --> WF
    SNAP --> CTX
    SNAP --> PLAN
    WF --> CP[(Separate persistent workflow checkpoints)]
    POL[Live authorization service] --> API
    POL --> CTX
    POL --> EXEC
```

Metadata authoring and query execution have different write rates, permissions and availability requirements. Deploy them as separate roles even if they initially share a repository and some application code. Start with an API/workflow deployment, catalog/publisher workers and execution workers; split other modules only when independent scaling or isolation requires it. This provides enterprise boundaries without requiring one microservice per box.

### 2.2 Ownership of decisions

| Step | LLM judgment | Deterministic/service responsibility |
|---|---|---|
| Domain routing | Propose relevant business areas and alternate meanings | Enforce authorized domains; retrieve ranked alternatives; track coverage |
| Field/metric interpretation | Interpret wording using descriptions and approved examples | Resolve IDs/types, required dependencies and applicable versions |
| Value interpretation | Select candidate meaning or ask a focused question | Exact/alias lookup, indexed candidates, authoritative physical bindings |
| Relationship choice | Express intended role: holder, seller, approver, current owner, etc. | Find approved paths, apply role/time constraints and operation contracts |
| Output shape | Specify counted unit, grouping, detail expansion and time scope | Prove applicable grain constraints within supported algebra |
| SQL generation | No executable SQL authority in normal query path | Lower typed plan to T-SQL and bind parameters |
| Repair | Revise a mistaken intent or clarify missing scope | Bounded errors; no weakened permission or join policy |
| Answer | Explain executed scope and caveats in natural language | Supply exact results, lineage, completeness and execution metadata |

“Typed semantic query” means a schema-constrained proposal about entities, metrics, populations, relationships and operations. Retrieval happens **before and during** proposal construction. The plan is then bound and checked against authoritative definitions. A plan can be well-typed and still reflect a misunderstood request, which is why reviewed examples, clarification and semantic evaluations are also required.

### 2.3 End-to-end request flow

1. Authenticate the caller, establish server-owned access context and pin a compatible release manifest.
2. Interpret scope/history from the conversation and route to authorized domain candidates.
3. Retrieve domain/object/example candidates with exact, lexical and vector methods; rerank within the trusted retrieval boundary.
4. Expand the graph to include required bridge entities, predicates, metrics, identity/temporal facts and policy dependencies.
5. Rehydrate all selected objects from the release snapshot, reauthorize, and assemble a bounded context package.
6. Resolve business values and produce a typed semantic query. Clarify material ambiguity or retrieve additional evidence within budget.
7. Bind IDs/values, plan relationships and grain, apply source restrictions, compile T-SQL and validate its complete AST.
8. Seal a query artifact, admit it to a workload class, and execute with current access checks.
9. Return results with units, interpretation, completeness, versions and source freshness. Persist only the authorized audit/result data.

## 3. Enterprise catalog model and incremental onboarding

### 3.1 Semantic objects and their ownership

| Object | Meaning | Primary persistence |
|---|---|---|
| Domain/glossary | Ownership, vocabulary and supported question scope | `business_domain`, `semantic_concept`, `domain_membership`, `catalog_object` |
| Source/entity/field | Physical binding, row meaning, attributes and access | `data_source`, `entity`, `field` |
| Identity/grain | Physical row key, business identity, version/time selection and evidence | Typed payloads in `entity`, plus `assertion` |
| Value domain/member | Canonical meaning, aliases and source-specific typed values | `value_domain`, `canonical_value`, `value_alias`, `value_binding` |
| Relationship/operation | Correspondence facts and separately permitted query uses | `relationship`, `relationship_operation` |
| Predicate/metric/template | Reusable executable meaning and approved parameterized plans | `predicate`, `metric`, `query_template` |
| Evidence/example | Provenance, constraint confidence and expected intent/results | `assertion`, `verified_example` |
| Semantic dependencies | Typed context, lineage and change-impact edges | `semantic_edge`; executable edges derive from relationships |
| Capability | Versioned supported operator and domain enablement | `capability`, `domain_capability` |
| Retrieval profile | Backend, embedding, metric, fusion, reranking and filter contract | `retrieval_profile` |

Fields ending in `_json` hold typed, versioned payloads, not unstructured descriptions or arbitrary SQL. Define JSON Schema/Pydantic contracts for each payload before implementing forms or importers. `catalog_object` provides shared label, definition, owner, policy, lifecycle and provenance for its declared kinds; specialized tables carry executable facts. Value domains and business domains are distinct concepts despite each using a `domain_id` column in its own table.

### 3.2 Discovery before semantic approval

The source connector collects object names, columns/types, declared keys, constraints and dependencies within authorized scope. The Azure SQL implementation can use catalog views. Structural constraints are evidence, not complete business meaning. [Microsoft catalog views](https://learn.microsoft.com/en-us/sql/relational-databases/system-catalog-views/catalog-views-transact-sql?view=sql-server-ver17)

Persist a `discovery_run` and its `discovered_asset` records with source fingerprint, scope, observed facts, optional suggestions and triage state. Stage approved dictionaries, lineage, documentation and versioned CSV/Excel/JSON/YAML imports through the same process. LLM-generated descriptions or inferred relationships remain visibly marked suggestions with provenance and confidence; accepting one writes a draft, not a published rule.

Profiling is a separate permissioned job with explicit source budget, sampling/full-scan method and evidence scope. Raw source values are not collected into metadata by default. A foreign key can support correspondence, but cannot decide preservation, applicable roles, time rules or measure allocation. Repeated source discovery creates a diff; it never silently overwrites approved descriptions or mappings.

```mermaid
flowchart LR
    SRC[Authorized schemas and documentation] --> INV[Discovery staging and fingerprints]
    INV --> TRI[Steward triage by domain]
    TRI --> DRAFT[Scoped change set and semantic definitions]
    DRAFT --> REV[Exact revision review and evaluations]
    REV --> PUB[Complete published manifest]
    PUB --> RUN[Enabled runtime coverage]
    SRC --> DRIFT[Drift report]
    DRIFT --> TRI
```

### 3.3 Identity, grain and source history

Each entity declares what its rows represent, physical-row identity, business identity, version identity if relevant, namespace, normalization and null handling, current/as-of row selection and evidence. “One row per record” is insufficient. The exact identity can be a field combination or an authoritative stable business ID; a surrogate primary key alone proves only physical uniqueness unless its business meaning is established.

Source rows, distinct business units, events, current versions and historical snapshots are different counted units. Missing version/effective-time fields may make a requested historical metric impossible. Expose a precisely named source-row metric if appropriate, or return an unsupported-semantic outcome; never choose an arbitrary latest row or deduplicate merely to make counts plausible.

Profiles record time and scope. A sample without duplicate keys does not prove global uniqueness. Relationship operations that require at-most-one match need appropriate constraints, verified views or an approved runtime validation strategy with defined failure behavior.

### 3.4 Domain onboarding as a repeatable delivery unit

1. Inventory the relevant source scope; register a domain owner and priority in `domain_onboarding`.
2. Agree a small set of useful question families and acceptance cases with intended users. Record explicit exclusions and missing semantics.
3. Select the minimal semantic subset required for those questions, including bridges, value bindings, source restrictions and all other dependencies. Never select tables solely by count.
4. Establish field meanings, identities/grain, predicates, metrics, operations, sensitive metadata rules and example expectations.
5. Run domain-specific and affected cross-domain evaluations against approved fixtures and the real target engine in a controlled environment.
6. Pilot with selected principals and published capability flags. Expand only when accuracy, useful coverage, latency and operational criteria pass.
7. Repeat for another domain, preserving regression cases from earlier releases. Approve cross-domain paths explicitly.

Backlog stages are `inventoried`, `modeling`, `evaluation`, `pilot`, `enabled`, `paused`, `retired`. This is work tracking; changing a stage does not expose metadata. Runtime availability is determined by the pinned approved release, enabled domain capabilities, current principal policy and emergency withdrawals. Pilot access is an authorization policy, not a frontend switch.

A first rollout may cover one domain. Cross-domain functionality is gated until an actual combined path and its meanings are tested. There is no requirement to onboard all tables, or multiple domains, before the first useful production release. Conversely, a domain cannot be declared supported if its agreed core questions require unavailable semantics.

Track four separate measures: discovered inventory, modeled/reviewed definitions, enabled operators/question families, and observed successful request coverage. Show gaps in the steward backlog and explain unsupported scope to users without disclosing protected inventory.

### 3.5 React + TypeScript catalog-steward experience

The frontend contains a normal query area and an authorized `/catalog` area. Route guards and hidden buttons improve usability; the backend enforces every permission regardless of browser state. The browser never receives database credentials, provider secrets, writable catalog files or internal model credentials.

| Page/workspace | Main actions and displayed evidence |
|---|---|
| Domain dashboard | Prioritize scope, owners, onboarding stage, enabled coverage, open issues and release/evaluation status |
| Discovery inbox | View schema diffs, inspect structural evidence, select/exclude candidates and promote to a draft |
| Object editor | Edit meanings, aliases, source bindings, types, policy references, business keys, grain and evidence |
| Values/mappings | Manage canonical members, ambiguity, source-specific bindings, validity and coverage gaps |
| Relationship workbench | Table/graph views of roles and composite keys; preservation, multiplicity, temporal rules and permitted operations |
| Predicate/metric/template builder | Guided typed forms, parameter/dependency validation and generated read-only plan/SQL preview |
| Examples/evaluation lab | Curate questions and expected intent/results, run scoped suites and inspect failures with access checks |
| Change-set diff/review | Compare semantic definitions and affected dependencies, exact revision/digest, evidence and reviewer decisions |
| Publication/rollback | Inspect projection readiness, activate approved candidates, see active/pinned versions and execute validated rollback |
| Administration | Manage scoped role grants, approved provider/source configuration references, retention and audit access |

The graph editor edits typed relationships through APIs; it does not write directly to NetworkX or infer executable joins from drawn lines. The advanced JSON editor uses the same typed schema as guided forms and shows validation errors at field/expression paths. Generated SQL preview is derived by the compiler; it is not a field that permits arbitrary production SQL execution.

Use generated OpenAPI TypeScript clients/types from backend contracts. TypeScript provides compile-time assistance; server-side Pydantic and semantic validation remain authoritative. Forms preserve unsaved work and handle `409 RevisionConflict` by presenting a diff/reload/reapply flow. Never resolve conflicting definitions by silently retaining whichever save arrived last. Long jobs expose authenticated status polling or SSE, with cancellation and clear failed/incomplete states.

### 3.6 Roles, domain scope and separation of duties

Integrate the enterprise identity provider. Store role bindings to verified user/group IDs, scoped to the catalog or a domain, with expiry/revocation. Bootstrap the first administrator through an explicit deployment procedure; the DDL seeds no account and there is no public self-registration for stewardship.

| Role | Allowed stewardship actions | Additional constraint |
|---|---|---|
| Viewer | Read authorized steward metadata, diffs and reports | No mutation; query-user access does not automatically confer this role |
| Author | Create/edit/import draft definitions and request evaluation | Own granted domains; cannot self-approve by default |
| Reviewer | Read scoped changes and record approval/request changes/rejection | Current role and correct revision/digest; independent reviewer by default |
| Publisher | Request projection builds and activate/rollback an approved complete release | Gates, base-manifest CAS and applicable ownership approvals must pass |
| Admin | Manage grants and approved configuration references | Does not bypass semantic release gates or grant business-data access implicitly |

Roles are explicit permission sets, not a simple rank hierarchy. A user may hold multiple roles; separation-of-duties checks still apply. Domain authors can change objects exclusively owned in their scope. Shared objects, domain reassignment, security policy references and cross-domain relationship changes require all applicable ownership approvals or catalog-scoped authority. A domain-scoped publisher can request publication of that approved change set; it cannot edit the global active pointer directly or include unrelated changes.

Source connections and policy IDs resolve through trusted server configuration. A metadata author cannot invent a connection reference or a permissive policy to escape source restrictions. Preview/evaluation uses the caller's allowed test scope and a restricted execution service; no special steward route accepts raw SQL or bypasses current data access.

### 3.7 Change sets, review invalidation and concurrent domains

`catalog_change_set` owns a complete draft release cloned from `base_manifest_id`; initial bootstrap has no base. The draft includes unchanged approved content from prior domains plus the authorized delta. Release-level `edit_revision` enables optimistic concurrency; it is coarse and sufficient initially. More granular editing may later use object revisions while retaining atomic candidate digests.

State transitions: `draft -> submitted -> approved -> published`; reviewers may move submitted changes to `changes_requested` or `rejected`; authors resubmit a changed draft at a new revision. An abandoned draft is retained according to policy. Do not conflate this change-set state with `catalog_release.status` or the domain backlog stage.

Every mutation checks current role, scope, editable state and expected revision, validates the full change, increments the revision and appends an audit event in one authority transaction. Submission records exact revision and canonical semantic digest. Review and evaluation refer to that identity. Any semantic edit after submission clears effective approval, returns to an editable state and requires rerunning affected gates. Old review rows remain audit history, not active approval.

Different domains may work in separate draft releases simultaneously. If domain A publishes while domain B is still based on the earlier manifest, B must rebase onto A's release and repeat affected validation/review. Activation compares the expected base pointer in the same transaction that marks publication and records audit/outbox events. A stale branch cannot overwrite A's published definitions. Missing changes or overlapping ownership conflicts are shown to stewards, never auto-resolved by the LLM.

```mermaid
sequenceDiagram
    participant UI as Steward UI
    participant CS as CatalogService
    participant DB as SQLite authority
    participant EV as Evaluation workers
    participant PB as Publisher
    UI->>CS: Save change set with expected revision
    CS->>DB: Atomic scope check, revision update, edits and audit
    DB-->>UI: New revision or conflict
    UI->>CS: Submit exact revision and request evaluation
    CS->>EV: Scoped immutable candidate identity
    EV->>CS: Versioned report and digest
    UI->>CS: Independent review of matching content
    CS->>PB: Freeze approved candidate and durable build event
    PB->>PB: Build and verify all projections
    PB->>CS: Activate against expected base manifest
    CS->>DB: Atomic pointer CAS, publication, audit and outbox
    DB-->>UI: Published or stale-base conflict
```

### 3.8 Authoring APIs and job contracts

All paths below are proposed versioned application APIs. Return typed error codes, validation paths, correlation IDs and safe explanations. Pagination and scope filtering apply to every list/read endpoint; bulk export is also authorized.

| Endpoint | Purpose | Required guard |
|---|---|---|
| `GET /v1/catalog/domains` | List permitted domains and work status | Steward read scope |
| `POST /v1/catalog/discovery-runs` | Start structural discovery for configured source/scope | Approved connector/scope and discovery permission |
| `POST /v1/catalog/change-sets` | Clone base manifest into scoped draft | Author/domain scope; idempotency key |
| `PATCH /v1/catalog/change-sets/{id}/objects/{objectId}` | Atomic typed object and subtype edit | Expected revision, ownership and editable state |
| `POST /v1/catalog/change-sets/{id}/imports` | Validate/promote staged bulk content | Same rules as UI, bounded transaction batches |
| `POST /v1/catalog/change-sets/{id}/submit` | Freeze submitted identity for review | Exact revision/digest and completeness |
| `POST /v1/catalog/evaluation-runs` | Run versioned suites on candidate | Authorized scope, profile and test execution budget |
| `POST /v1/catalog/change-sets/{id}/reviews` | Record review decision | Reviewer scope, identity match, separation of duties |
| `POST /v1/catalog/change-sets/{id}/publish` | Start reviewed build/activation workflow | Publisher rights, gates, idempotency and base CAS |
| `GET /v1/catalog/jobs/{id}` | Read authorized job progress/report | Job scope and redacted output |
| `POST /v1/catalog/role-bindings` | Grant an approved scoped role | Admin plus auditable identity/policy validation |

Updates to grants, source configurations and provider settings need their own typed routes and audit. `evaluation_run` stores candidate revision/digest and report identity; workers store detailed artifacts externally. Discovery and evaluation run IDs also serve as durable job IDs. Publication dispatch uses `publication_outbox`. If broader job orchestration requires an additional operational store, implement it outside the immutable semantic read model; do not use process memory as the only durable job registry.

### 3.9 Schema boundaries and migration obligations

`catalog-schema.sql` is a 35-table schema-version-4 bootstrap, not an automatic upgrade script. Compared with earlier metadata-only designs, it persists retrieval configuration, discovery staging, domain work status, scoped roles, change sets, exact-revision reviews/evaluations and audit records. Publication controls and these authoring workflow rows stay out of runtime semantic snapshots.

Implement migration history and reviewed version-to-version migrations before retaining production data. New non-null fields require deliberate backfills and validation; never rerun bootstrap DDL over a populated database. Test upgrades and authority backup/restore. The schema provides FK, enum, JSON-syntax and selected state constraints; workflow, access, specialized object kinds and payload meaning are validated by services and publisher gates. Direct writes to authority files are restricted to the service owner.

## 4. Catalog storage, projections and publication

### 4.1 SQLite persistence and in-memory reads by default

The initial catalog authority is `catalog-authority.sqlite` on a durable volume attached to one catalog-service host. All editors, importers and publishers access it through CatalogService. The service owns transactions, write admission, review permissions and revision checks. A shared application service can serve multiple users while serializing short database writes. Operational data remains in Azure SQL.

The authority stores drafts, approved definitions, release records, projection state, manifests and a transactional outbox. Workers consume immutable published semantic releases. Each worker loads its selected release into a read-only in-memory SQLite database for exact metadata lookups, alongside the matching graph and search projection references. The RAM database is a disposable copy of the published file; authoring never happens in that copy.

| Storage role | Default representation | Writes and recovery |
|---|---|---|
| Catalog authority | Durable `catalog-authority.sqlite` | CatalogService writes; consistent backups preserve drafts and publication state |
| Published release | Immutable `catalog-r42.sqlite` plus external checksum/manifest | Publisher creates once; retained artifact rebuilds read copies |
| Worker lookup store | In-memory SQLite for release `r42` | Loaded once then query-only; discarded and reloaded after restart |
| Workflow checkpoints | Separate durable `workflow-checkpoints.sqlite` for the initial admitted deployment | Workflow persistence writes independently; never copied into semantic releases |

Multiple query workers can read their own release copies without contending for the authority's write lock. Only one host owns the writable authority file. Remote editors/workers use the service API; they do not mount the live database over a network filesystem. SQLite's deployment guidance supports an application server owning the database while identifying concurrent-write and distributed-access limits. [SQLite deployment guidance](https://www.sqlite.org/whentouse.html)

This is a production deployment option with an explicit workload and recovery envelope, rather than a promise of automatic failover. If the initial service's availability, write load or restore time fails the accepted requirements, adopt a server catalog backend before that requirement is released. Table count alone does not settle that choice.

`catalog-schema.sql` is the schema-version-4 bootstrap for authority and published read representations. It includes semantic definitions, retrieval profiles, publication controls, discovery staging and steward workflow records. PostgreSQL and Azure SQL authority adapters/migrations remain optional implementation work under sections 4.8–4.10. Execution ledger and LangGraph checkpoint schemas are separate operational stores. Publication exports an explicit allowlist of semantic tables; it never copies all authority rows indiscriminately.

### 4.2 Projection contents

| Projection | Content | Rebuild source |
|---|---|---|
| SQLite release file and in-memory copy | Approved objects, bindings, predicates, metrics, contracts, capabilities and evidence references | Canonical release export, then file-to-memory load |
| Search index | Atomic semantic documents and embeddings with release/security/domain metadata | Canonical export plus approved text transforms/embedding model |
| Graph artifact | Typed nodes, executable relationships, dependencies and reviewed lineage | Same release's structured records |
| Example index | Approved questions/intent summaries and expected-plan references | Versioned example registry |
| Value index/provider | Authorized business dictionary entries; source bindings and freshness | Reference source or catalog domain, with separate lifecycle |

Store secrets only in the approved secret-management system. Catalog connection references identify configured providers without carrying passwords, tokens or full privileged connection strings.

Snapshot export copies only approved semantic records and canonical release identity. Projection-build, active-pointer, manifest, outbox, discovery, onboarding, role, change-set, review, evaluation-run and audit rows remain in the persistent authority; their matching tables are empty in the published SQLite file and its RAM copy. The selected release's `retrieval_profile` records are semantic configuration and are exported. Approved examples may reference external fixture/report artifacts, but runtime readers receive neither draft evaluations nor steward grants. Draft rows are excluded. Keep the snapshot's file checksum in the authority/external manifest, outside the file being checksummed. Canonical semantic hashes exclude audit timestamps, `edit_revision`, hashes themselves and build-control records. Specify canonical JSON and timestamp normalization identically across backend adapters.

The export allowlist is `catalog_release`, `catalog_object`, `data_source`, `entity`, `value_domain`, `field`, `canonical_value`, `value_alias`, `value_binding`, `relationship`, `relationship_operation`, `predicate`, `metric`, `verified_example`, `assertion`, `business_domain`, `domain_membership`, `semantic_concept`, `semantic_edge`, `query_template`, `capability`, `domain_capability` and `retrieval_profile`. Apply selected-release and approval/dependency filters inside this allowlist. New tables default to excluded until their export policy is reviewed.

Define one canonical *candidate semantic export* before hashing or building projections. Normalize approved candidate object states to their published representation; preserve explicit deprecated/disabled semantics where applicable. Exclude operational release status, edit revision, publication/review timestamps and self-referential digests from the semantic-content digest. Preserve meaningful source fingerprints, evidence validity and provenance revisions. Review and evaluation bind to that export digest plus the draft revision; snapshot file hashes are separate. Updating authority status from reviewed to published must not change the reviewed semantic payload.

### 4.3 Release manifest

```json
{
  "manifest_version": 1,
  "release_id": "release-r1",
  "catalog_schema_version": 4,
  "catalog_hash": "sha256-example",
  "sqlite_artifact": "catalog/r1/catalog.sqlite",
  "search_projection_id": "semantic-r1",
  "graph_projection_id": "graph-r1",
  "embedding_config_id": "embedding-config-v1",
  "retrieval_profile_id": "retrieval.default.v1",
  "retrieval_config_id": "hybrid-rerank-v1",
  "compiler_capability_set": "query-algebra-v1",
  "workflow_version": "workflow-v1",
  "prompt_version": "intent-v1",
  "model_config_id": "approved-model-v1",
  "compatible_policy_schema": 1
}
```

IDs are illustrative; choose actual approved model/deployment configurations during implementation. Pin dimensions, model identity, input-text transformation and index metric in the embedding configuration. Similarity scores from different configurations are not directly interchangeable. Authorization grants and emergency revocations are evaluated live rather than frozen by this manifest. Workflow/prompt/interpretation-model pins apply to application-managed mode; host-controlled mode records available external provenance separately and never claims to pin hidden host configuration (section 18.9).

### 4.4 Publish atomically at the logical level

1. Commit authorized draft edits with actor/audit attribution and optimistic concurrency; separate authorship from independent review of the exact revision/digest. Validate references, typed expressions, source bindings, grain/identity evidence and policy dependencies.
2. Freeze a candidate catalog release and canonical export. A transactional outbox records projection-build events in the same database transaction as the release state.
3. Build SQLite, search and graph projections under immutable IDs. Workers process outbox messages idempotently; retries cannot create another logical release.
4. Verify content/hash and referential coverage, run retrieval/graph/compiler evaluations, and mark each projection ready.
5. Activate the manifest only when all required projections and application versions are compatible. The active-manifest pointer changes in one catalog transaction with an expected-base comparison, publication state and audit/outbox writes. If another domain has published, rebase the stale candidate and repeat affected review and gates.
6. New requests pin the new manifest. In-flight requests keep their old release unless access revocation, a critical semantic error or retirement policy invalidates it.

There is no distributed transaction spanning the catalog authority, search and object storage. SQLite commits the release transition and outbox event together; projection work occurs afterward. Immutable artifacts and the manifest activation gate provide coherent request behavior. Do not overwrite a live index while independently updating the catalog. Use versioned indexes where quotas permit or strict release filtering in a shared index with complete build verification; requests always specify their pinned release.

Rollback selects a previously validated complete manifest, subject to current policy and source compatibility. An urgent source change can invalidate old SQL even if the old catalog still exists. Retention and garbage collection must account for checkpoint references, active requests and audit policy.

### 4.5 Change impact and revocation

Traverse dependency edges to find metrics, predicates, contracts and examples affected by a changed field, code set or identity rule. Rebuild only content-addressed unchanged-safe artifacts where possible, but evaluate the affected closure. Alias-only changes still require retrieval checks; grain and scope changes require answer-impact review.

An access revocation immediately invalidates entitlement/cache/artifact checks and prevents affected content from reaching model context, even if an old search index contains the document. If the application cannot enforce current policy, it must not serve that protected context from a stale projection. Withdrawn definitions can be denied by ID immediately while a new complete release is built.

### 4.6 Persistent SQLite transactions, concurrency and recovery

Initialize authority connections with `PRAGMA foreign_keys=ON`, `PRAGMA journal_mode=WAL`, `PRAGMA synchronous=FULL` and an initial `PRAGMA busy_timeout=5000` bounded lock wait. Configure/check these settings before transactions; WAL mode persists on the database, while connection settings must be applied per connection. Use a supported SQLite build with current fixes and verify actual driver/runtime versions at deployment. [SQLite WAL](https://www.sqlite.org/wal.html), [SQLite configuration](https://www.sqlite.org/pragma.html)

CatalogService admits one write transaction at a time. Keep edits short; do retrieval, model calls, profiling, embedding generation and artifact uploads outside the transaction. Batch imports into bounded drafts and freeze a complete candidate before publication. A long read transaction can delay WAL checkpoint progress, so the publisher should materialize a frozen canonical export promptly rather than holding the authority transaction open during external builds.

Use `catalog_release.edit_revision` for optimistic concurrency. Within one SQLite `BEGIN IMMEDIATE` transaction, conditionally advance the revision only when the caller's expected revision matches and the release is still editable. If no row matches, roll back and return a conflict; perform no semantic writes. Otherwise apply all related metadata changes and commit together. Freeze transitions also compare the expected revision. Published semantic records are immutable through the service; editing them starts a new draft release. These lifecycle rules are application obligations, not a side effect of adding the integer column.

Independent author sessions can therefore submit concurrently, but conflicting edits cannot silently overwrite each other. Handle transient lock contention with a bounded deadline and explicit errors; a timeout never counts as a successful edit. SQLite serializes writes, and snapshot readers can coexist with a writer under WAL. [SQLite isolation](https://www.sqlite.org/isolation.html)

The authority and publication outbox share one database so the release transition and dispatch record commit atomically. The outbox consumer records retries and delivery only through the same owning service. Workflow checkpoints and the execution ledger have separate storage/lifecycles to avoid their frequent writes extending catalog transactions. Cross-store effects use durable IDs and reconciliation; they are not one atomic transaction.

Store the live file on a durable volume whose locking and flush behavior are supported by SQLite. Back up the complete authority using an online-backup procedure or a quiesced consistent backup, then retain protected copies off the host and rehearse restoration. Published semantic files are useful rebuild inputs but omit drafts, outbox progress and activation history; they are not full authority backups. Do not copy only the live main file while a WAL contains uncheckpointed commits. [SQLite backup API](https://www.sqlite.org/backup.html)

The initial service has one writable authority owner and a measured restore procedure. It does not provide automatic multi-host failover. A failover process must fence the old owner before admitting a new writer and establish the restored manifest/outbox state. When that operational requirement exceeds the accepted single-host envelope, use PostgreSQL or Azure SQL authority instead of improvising network-file sharing.

### 4.7 Loading published SQLite into memory

The default exact-lookup path is `published release file -> in-memory SQLite -> typed catalog objects`. It is not a write-through cache of drafts.

1. Resolve the request's manifest and obtain the matching immutable file. Verify its checksum, supported catalog schema version, release identity and semantic export completeness before using it.
2. The publisher finishes and closes a standalone release file without live WAL dependencies. It contains approved semantic records; authority-control tables are empty.
3. Open that file read-only. Create a fresh in-memory SQLite connection and copy the finished release using SQLite's backup API, exposed by Python's `Connection.backup`. Validate the loaded release ID and required contents.
4. Set the memory connection to query-only and expose a `CatalogReader` interface containing approved read operations. A connection pragma is a misuse guard; trusted service boundaries and authorization still provide security.
5. Build/load the matching graph and register the reader under its release/manifest identity. A worker marks the release ready only when all local components are compatible.
6. New requests acquire that reader. Existing requests retain their previously acquired release. Release references are counted; close an old reader only when no request holds it, subject to configured retention and retirement policy.
7. After a process restart, reconstruct memory from the persisted artifact. No approved edits or durable workflow state depend on the RAM copy surviving.

Each `:memory:` connection normally creates an independent database. Do not open a new connection per query expecting it to contain another connection's rows. The initial reader owns one connection on a designated execution thread/actor per loaded release, or explicitly creates separately loaded read connections with a measured memory budget. Named shared-memory connections are a possible later within-process adapter detail; they do not provide cross-host persistence. [SQLite in-memory databases](https://www.sqlite.org/inmemorydb.html), [Python SQLite backup support](https://docs.python.org/3/library/sqlite3.html#sqlite3.Connection.backup)

Budget total memory for every worker and simultaneously retained release, including the graph, decoded objects and query overhead. Atomic replacement may briefly require both old and new releases. Enforce a configurable upper bound on loaded releases; recover older pinned requests from retained artifacts or return an explicit retired/unavailable outcome. Never silently substitute a newer release for an old request.

Support `read_mode=immutable_file` through the same reader contract if the complete release exceeds the RAM allowance. Memory mode is the requested default, but its benefit should be measured against a read-only file with the operating system's cache. A file fallback must keep the same complete semantic contents and version checks. Avoid partial in-memory catalogs that omit bridge or policy dependencies merely to fit a budget.

Live authorization and emergency revocation checks remain outside this immutable read view. A ready RAM snapshot does not permit using withdrawn definitions or stale access grants.

### 4.8 Storage interfaces and backend portability

Keep backend choice below semantic services. Application modules use typed records and operations, not SQLite cursors or engine-specific JSON queries. The ports are:

| Interface | Required operations | Default implementation | Later implementation |
|---|---|---|---|
| `CatalogAuthoringStore` | Read/edit draft at expected revision; atomically freeze with outbox event; manage review records | Local SQLite transactions inside CatalogService | PostgreSQL or Azure SQL transaction adapter |
| `ReleaseStore` | Read manifest, record artifact readiness, conditionally activate expected prior manifest, record outbox progress | Persistent authority tables in SQLite | Same logical tables/operations in selected server backend |
| `CatalogReader` | Resolve objects, fields, values, contracts, capabilities and dependencies within one release | Query-only in-memory SQLite; optional immutable-file reader | The same SQLite read implementation can continue after authority migration |
| `CatalogExporter` | Export canonical approved records with stable IDs and deterministic hash rules | SQLite authority adapter | PostgreSQL/Azure SQL authority adapter |
| `ReleaseArtifactStore` | Put/get immutable snapshots and graph artifacts, verify checksums and retention | Versioned artifact storage plus local verified files | Same contract regardless of authority engine |

The runtime semantic planner and compiler must depend on `CatalogReader`, not the authoring backend. Search and graph builders consume canonical records through `CatalogExporter`. This allows the authority to migrate while workers retain the same release format and read path.

Normalize transaction outcomes into application errors such as `RevisionConflict`, `CatalogBusy`, `ReleaseNotReady`, `UnsupportedSchema` and `StorageUnavailable`. The adapter owns locking, isolation, placeholders, JSON serialization, timestamp conversion, upsert strategy and driver retries. An ORM can reduce repetition but cannot make those semantics identical automatically.

Preserve stable semantic IDs and exact ID comparison across all backends. Use portable typed JSON payload contracts; define canonical timestamp, decimal and null encodings. Validate string lengths explicitly before introducing a backend with bounded indexed strings. Separate semantic content hashes from backend-specific file hashes.

| Storage detail | SQLite default | PostgreSQL option | Azure SQL option |
|---|---|---|---|
| Metadata text and IDs | Text; application enforces ID rules | Text with exact ID comparison | Bounded identifier columns with deliberate case/binary collation and index-width design |
| JSON payload storage | JSON text with syntax checks plus typed validation | JSONB with typed validation | JSON text in `nvarchar(max)` with appropriate validation, or evaluated compatible native representation |
| Binding literals | JSON may contain scalar strings, numbers or booleans | Preserve scalar JSON and exact type rules | Preserve scalar JSON semantics; default object/array-only validation is insufficient |
| UTC times | Canonical sortable text | Native timestamp conversion with canonical export | Chosen UTC `datetime2`/`datetimeoffset` conversion with canonical export |
| Edit concurrency | Serialized short transactions plus expected `edit_revision` | Expected-revision update and appropriate transaction isolation | Expected-revision update and appropriate transaction isolation |
| Publication | Atomic authority/outbox transaction and conditional activation | Equivalent atomic transaction/activation | Equivalent atomic transaction/activation |
| Published reads | SQLite release files and RAM copies | Retain the same read format | Retain the same read format |

Azure SQL supports storing and querying JSON text, but payload validation must preserve this catalog's scalar bindings as well as objects and arrays. A future adapter must test that behavior; do not mechanically replace every JSON check with an object-only check. [Azure SQL JSON features](https://learn.microsoft.com/en-us/azure/azure-sql/database/json-features?view=azuresql)

An Azure SQL metadata backend should use an explicitly managed metadata database/schema and credentials, separated from operational query access. Choosing the same engine does not imply merging metadata with the company's business tables. No future adapter is considered implemented merely because it appears in this table.

### 4.9 Measured triggers for a server catalog

SQLite can remain the authority as long as it satisfies the accepted requirements. There is no scheduled mandatory migration and no universal table-count cutoff.

| Observation or requirement | Action |
|---|---|
| Many catalog reads or query users, with infrequent metadata edits | Scale read workers/caches and measure memory; this alone does not require an authority migration |
| Large catalogs but acceptable imports, publication time, disk use and backup/restore time | Continue SQLite; measure release load and in-memory capacity |
| Sustained write queue growth, lock timeouts or edit/publication latency above the agreed SLO after sensible batching | Benchmark PostgreSQL and Azure SQL using the same workload |
| Concurrent independently scaled catalog writers across hosts are required | Move authority to a server backend |
| Required automatic failover, recovery time or central database operations cannot be met by the single-owner deployment | Choose an appropriate managed server topology before accepting that requirement |
| Workflow checkpoint writes exceed their separate envelope | Upgrade checkpoint storage independently; this does not automatically require moving the metadata catalog |

Phase 0 sets measured thresholds for author count/write bursts, commit and publication latency, maximum accepted queue wait, disk/WAL growth, release RAM use, startup time, backup duration and restore objectives. The large-schema test envelope in section 1 is input to those measurements, not proof that SQLite meets them. Record actual evidence before rollout.

### 4.10 Migration to PostgreSQL or Azure SQL

1. Implement the selected authority adapter and versioned schema migrations. Verify identical typed payload, ID, null, collation, transaction and canonical-export behavior with a backend conformance suite.
2. Provision the target with the needed permissions, backup/recovery and availability configuration. Validate representative authoring/publication loads and failure behavior.
3. Pause authoring and publication dispatch, drain or reconcile in-progress writes/builds, and take a consistent authority backup. Existing query requests can use retained releases only while current authorization remains enforceable.
4. Export and import all authority state: drafts, approved releases, object IDs, `edit_revision`, evidence/review records, artifact references, manifests, active pointer and outbox progress. Treat transient job ownership as expired and reconcile work rather than duplicating it.
5. Verify row/reference coverage, normalized semantic hashes, active-manifest identity and compatible artifact access. Build a trial release through the new backend and check that its logical content matches the expected export.
6. Switch the authority backend configuration once, with the old authority fenced against writes. Resume authoring/builds on the new store; retain existing immutable release files and workers' valid pinned readers.
7. Validate service behavior and retain the old consistent backup for the agreed rollback window. A rollback after new writes requires quiescing and transferring/reconciling those writes; pointing back to an old file would lose them.

This is a controlled data migration with limited catalog-write downtime. It avoids dual writable authorities and does not claim that SQL dialects are interchangeable. Semantic object identities, query-plan contracts, search/graph release linkage and the in-memory SQLite reader remain stable across the migration.

## 5. Configurable retrieval and context assembly

### 5.1 Retrieval responsibilities are separate

An embedding model converts approved text into vectors. A vector backend stores/indexes those vectors and returns candidates. A lexical backend searches words and technical names. Fusion combines candidate rankings; a reranker evaluates relevance; exact catalog lookup supplies authoritative records. None of these responsibilities changes the semantic compiler contract.

```mermaid
flowchart TB
    Q[Question and current authorized scope] --> DOM[Candidate domains and meanings]
    DOM --> EXACT[Exact IDs and curated aliases]
    DOM --> LEX[Lexical adapter]
    DOM --> EMB[Configured embedding provider]
    EMB --> VP[VectorIndex interface]
    VP --> N[NumPy]
    VP --> C[Chroma]
    VP --> F[FAISS]
    VP --> A[Azure AI Search]
    N --> UNION[Authorized candidate fusion]
    C --> UNION
    F --> UNION
    A --> UNION
    LEX --> UNION
    EXACT --> UNION
    UNION --> RERANK[Configured reranker]
    RERANK --> DEP[Typed graph dependency expansion]
    DEP --> LOOKUP[Exact catalog rehydration and live policy checks]
    LOOKUP --> CTX[Complete bounded context]
```

The four vector nodes represent alternatives. A deployment selects one profile for a request's release; it does not query all four by default. Routing retains several plausible authorized domains when wording overlaps, then widens retrieval within budget if necessary. Selecting a domain is candidate generation, not an irrevocable classification that can omit required cross-domain dependencies.

### 5.2 Backend choices and deployment implications

| Backend | Suitable initial use | Persistence and sharing | Important implementation obligations |
|---|---|---|---|
| NumPy | Small/moderate approved catalog that fits per-worker memory and exact-scan latency budgets | Persist matrix, ID map and descriptor as immutable artifacts; load into RAM or use an explicitly tested read-only mapped-file mode | No ANN index, database, ACL service or embedding generation is supplied; implement filtering, scoring, top-k, batching and version checks |
| Chroma | Embedded persistent development/admitted single-host use or a shared server/service deployment | Versioned collections and configured persistent/server storage | Explicit collection/model/dimension/metric contract, metadata filters, access isolation, backup and concurrency tests |
| FAISS | Local exact/approximate vector indexing when measured vector-search costs justify it | Persist index and stable ID mapping as immutable files, loaded by retrieval workers | It is a library, not a managed database; own metadata filters, serving, updates, checksums and index-specific search parameters |
| Azure AI Search | Managed deployment requiring supported text/vector search, filtering and operational service features | Versioned indexes or rigorously isolated release partitions | Provisioning, quotas, service identity, filter modes, lexical/vector fusion configuration, cost and data-processing boundary |

NumPy supports the matrix operations required for exact scoring. FAISS exposes several index types and metric choices. Chroma supports metadata filtering and server deployment. Azure AI Search offers native hybrid text/vector retrieval. The application contracts below are our responsibilities, not guarantees inferred from a product name. [NumPy matrix multiplication](https://numpy.org/doc/stable/reference/generated/numpy.matmul.html), [FAISS getting started](https://github.com/facebookresearch/faiss/wiki/Getting-started), [Chroma metadata filtering](https://docs.trychroma.com/docs/querying-collections/metadata-filtering), [Chroma server deployment](https://docs.trychroma.com/production/chroma-server/client-server-mode), [Azure hybrid search](https://learn.microsoft.com/en-us/azure/search/hybrid-search-overview)

The provisional small-catalog choice is NumPy + SQLite FTS5. It avoids provisioning a search server while retaining real hybrid retrieval. It must pass the same relevance, authorization, latency and recovery gates as other choices. Use Chroma, FAISS or Azure AI Search from the first release if measured requirements favor them. Backend changes are explicit evaluated releases, not automatic runtime cost optimizations.

### 5.3 Adapter interfaces and capability negotiation

Define typed ports independently from any provider SDK:

```text
EmbeddingProvider.embed(texts, embedding_config) -> vectors + model_revision
VectorIndex.build(approved_documents, vectors, profile, artifact_id) -> descriptor
VectorIndex.open(descriptor) -> immutable_release_handle
VectorIndex.search(handle, query_vector, authorized_filter, top_k, budget) -> candidates
LexicalIndex.search(handle, text, authorized_filter, top_k, budget) -> candidates
Reranker.rank(question, authorized_candidate_texts, config, budget) -> ranked_candidates
HybridRetriever.retrieve(question, manifest, access_context, scope, budget) -> candidate_bundle
```

Descriptors declare supported metric, dimensions, dtype, normalization, exact/approximate mode, provider/library version, immutable component IDs/hashes, release ID, object-ID mapping, filtering semantics, deployment configuration reference and build provenance. Search returns semantic/document IDs, raw score type, normalized score direction, source channel, rank, release/profile identity and relevant diagnostics. Do not expose secrets or accept arbitrary artifact paths supplied by the browser.

Capabilities declare exact eligible-subset search, supported metadata predicates, native hybrid/reranking availability, maximum filters/batches and immutable-release strategy. Reject an incompatible requested profile at validation/startup. An unavailable optional dependency produces `ProviderNotInstalled`; invalid credentials or unreachable services produce their corresponding operational error; unsupported filtering produces `UnsupportedFilterContract`. None permits silently swapping the embedding model, vector backend or authorization scope.

The search service builds filters from trusted identity/current policy. Abstract filters use a restricted typed AST, such as release equals, object kind in, authorized semantic IDs in, and domain intersects. Provider adapters compile only supported forms. Capability testing must cover small authorized subsets and zero authorized results; provider feature names alone are insufficient.

### 5.4 Release-scoped retrieval profile

`retrieval_profile` persists vector/lexical selection, embedding config/dimensions, distance metric, normalization, fusion, reranking, filter contract, backend configuration references and canonical configuration hash. It is included in semantic release content. `projection_artifact` identifies the profile for a search projection; `release_manifest` pins the same profile. The publisher checks agreement between those records and every component descriptor.

Illustrative configuration shape; IDs and dimensions below are placeholders that must be replaced by the selected approved embedding configuration, not a recommended model:

```json
{
  "profile_id": "retrieval.default.v1",
  "vector_backend": "numpy",
  "lexical_backend": "sqlite_fts5",
  "embedding_config_ref": "approved-embedding-config-v1",
  "embedding_dimensions": 768,
  "distance_metric": "cosine",
  "normalization": {"document": "l2", "query": "l2", "zero_norm": "reject"},
  "fusion": {"kind": "rrf", "rank_constant": 60},
  "reranker": {"provider_config_ref": "approved-reranker-v1", "candidate_limit": 80},
  "security_filter_contract": {"eligible_before_selection": true, "live_recheck": true},
  "backend_config": {"dtype": "float32", "search_mode": "exact", "artifact_store_ref": "catalog-artifacts"}
}
```

Starting values such as rank constant and candidate limit are evaluation parameters, not universal defaults. Store the typed JSON subobjects in the corresponding `_json` columns and calculate `configuration_hash` from canonical configuration. Profile changes create a new release/projection, even if business definitions are unchanged. A profile selects server-registered provider settings; credentials remain in secret management.

Implement and document four supported deployment profiles: NumPy + FTS5; FAISS + FTS5; Chroma + FTS5 (or another tested lexical adapter); Azure AI Search for both lexical/vector retrieval. A dedicated local BM25 adapter is an additional lexical option. Other combinations are enabled only after conformance testing; the schema enums enumerate providers, not a promise that every Cartesian combination is valid.

### 5.5 NumPy implementation and capacity contract

Publish a float32 vector matrix with shape `(N, D)`, a stable row-to-document-ID mapping, approved document metadata and a descriptor. Store vectors as a numeric `.npy` artifact, not pickled Python objects. Verify hash, numeric dtype, rank, shape, finiteness, dimensions, model/text-transform identity and ID cardinality before admitting it. Load with `allow_pickle=False`. A hash authenticates integrity only relative to a trusted manifest/artifact source. [NumPy loading](https://numpy.org/doc/stable/reference/generated/numpy.load.html)

For a cosine profile, normalize each nonzero document vector at build time and the query vector at request time. Scores are the authorized matrix rows multiplied by the query vector. Derive the current eligible row IDs before score selection; process in blocks if needed to limit temporary allocations. Select top-k with explicit deterministic tie breaking by document ID. Reject zero-norm/nonfinite vectors and wrong dimensions rather than producing arbitrary rankings. For dot or L2 profiles, implement their explicit score conventions; never apply cosine normalization silently to another metric.

Raw matrix memory is `N × D × 4` bytes for float32. For example, 20,000 vectors of dimension 768 require 61,440,000 bytes (about 58.6 MiB) before document metadata, indexes, graph, SQLite, temporary arrays and Python overhead. Multiple workers and simultaneously retained releases multiply costs. Measure resident memory and p95 latency under actual authorization masks; raw matrix size alone is not a capacity estimate.

An in-memory index is reconstructed from immutable artifacts after restart. Persisting the authoritative catalog alone does not preserve embeddings unless rebuilding them under the exact pinned model/configuration remains possible. Retain approved embedding artifacts or a reproducible governed regeneration path. If exact search violates latency/memory limits, switch profile to a measured alternative while retaining semantic IDs and adapter contracts.

### 5.6 FAISS, Chroma and Azure adapter specifics

**FAISS:** choose Flat exact search or an evaluated approximate index and record index parameters, training input identity where applicable, model dimensions and metric. A normalized inner-product configuration can implement cosine; L2 scores have different interpretation. Use stable integer IDs mapped to semantic document IDs, with mapping/index integrity checks. Never assume all index types implement the same metadata filtering API. Use tested eligible-ID selection where supported; otherwise use a policy-partitioned index or exact search over authorized vectors retained as a sidecar. If no correct supported strategy exists, reject the profile. Fetching global top-k and deleting unauthorized neighbors afterward can lose all relevant authorized candidates. [FAISS metrics and distances](https://github.com/facebookresearch/faiss/wiki/MetricType-and-distances)

**Chroma:** select topology explicitly. Prefer server-backed Chroma for production; its persistent local client is intended primarily for development/testing. An embedded production exception needs explicit operating-envelope acceptance. [Chroma client guidance](https://docs.trychroma.com/reference/python) Supply approved embeddings directly so a library default embedding function cannot change the model. Pin collection configuration and release IDs; use immutable per-release collections or rigorously tested release filters. Translate authorized metadata predicates, then reauthorize returned semantic IDs before text leaves the retrieval boundary. Scope tenancy, persistence, backup, concurrency and API versions through deployment configuration; embedded and server modes have different operational envelopes.

**Azure AI Search:** select schema fields for exact IDs, lexical text, vectors, release/domain tags and policy filtering. Pin vector metric and search configuration. Native hybrid fusion is permitted when selected by the profile; do not inadvertently fuse the same channels again in application code. Configure a tested prefilter strategy for authorized recall and recheck policy before context release. Native semantic ranking or external reranking is a profile choice whose processing boundary must be approved. [Azure vector filters](https://learn.microsoft.com/en-us/azure/search/vector-search-filters), [Azure semantic ranking](https://learn.microsoft.com/en-us/azure/search/semantic-search-overview)

### 5.7 Lexical retrieval, fusion and reranking

For local vector choices, build an immutable lexical projection containing the same approved document IDs, text transformations and release identity. SQLite FTS5 supports full-text retrieval and ranking functions; it is a separate projection, not a reason to make the metadata authority a live search endpoint. Check runtime FTS5 availability and tokenizer configuration during setup. [SQLite FTS5](https://www.sqlite.org/fts5.html)

Exact identifiers and curated aliases remain a distinct channel; a resolved value lookup can finish without embeddings. Lexical retrieval handles technical names/abbreviations while vectors address paraphrases. A shared fusion layer can use reciprocal-rank fusion, followed by a configured cross-encoder or other evaluated reranker. Normalize rank direction first: SQLite FTS5 BM25 uses lower-is-better ranking; vector metric score conventions differ. Avoid treating unrelated raw provider scores as calibrated probabilities.

The reranker may be local or an approved service. Pin its model/configuration and input limits separately from the embedding model. The production platform includes reranking capability; a particular request may skip it under an evaluated exact-match path. A profile-wide ablation needs explicit quality evidence and recorded rationale. Missing required reranker availability produces an explicit failure/degraded mode only if that mode has its own approved contract, not silent arbitrary ranking changes.

### 5.8 Documents, authorization and context completeness

Index atomic semantic documents: entities with grain and field summaries; fields with parent/domain context; predicates/metrics with meaning, population and units; relationships with roles; and approved examples with intent and dependencies. Keep executable definitions in the catalog. Embed labels, descriptions, curated aliases and concise approved examples. Avoid raw operational rows, unrestricted dictionaries and raw query logs.

```json
{
  "document_id": "r1__domain_alpha.metric_x",
  "object_id": "domain_alpha.metric_x",
  "object_kind": "metric",
  "release_id": "release-r1",
  "domain_ids": ["domain_alpha"],
  "label": "Owner-approved metric label",
  "description": "Owner-approved population, identity, unit and time meaning.",
  "dependency_ids": ["domain_alpha.entity_x"],
  "policy_scope_ids": ["approved-policy-scope"],
  "content_hash": "sha256-placeholder",
  "embedding_config_id": "approved-embedding-config-v1"
}
```

The placeholder IDs illustrate the document contract, not a seeded domain. Embeddings and search indexes contain approved metadata only. Steward search over discovery/drafts is a separate authorized scope and cannot feed normal query context. Protect reports and examples as well as table descriptions.

Apply release and current access restrictions before ranking/returning candidate text. Exact eligible-subset retrieval is straightforward with a NumPy mask; remote/ANN providers require their declared supported filtering strategy. Approximate recall may vary, but authorization must never be approximate. Verify candidate IDs against the immutable catalog and current policy before external reranking/model use. Index ACL tags are acceleration data, not authoritative authentication. Cache keys include release/profile, principal policy scope/epoch and relevant request context.

Graph expansion adds mandatory bridges, field dependencies, predicate/metric definitions, identities, time rules and policy conditions. Rehydrate exact definitions through `CatalogReader`; summaries cannot replace compiler contracts. If dependencies exceed prompt budget, use staged tool access or approved subplans. Do not omit required constraints to fit tokens. Services load enforcement dependencies regardless of what the model sees.

### 5.9 Retrieval budgets and quality gates

Initial evaluation parameters might retain 3–5 plausible domains, tens of candidates per channel and a bounded reranker union. These are adjustable budgets, not correctness thresholds. Annotate the complete required semantic set for evaluation questions and measure complete-set recall, ambiguity/clarification quality, unauthorized-result rate, downstream intent correctness, p95 latency, memory and cost.

Include homonyms, abbreviations, misspellings, renamed bindings, low-similarity bridge entities, rare codes, unpublished objects, restrictive authorization and confusing domains. Add distracting inventory separately from the published subset. A failed plan can trigger bounded retrieval for a missing dependency; distinguish missing retrieval, no approved relationship, unsupported capability, exhausted search budget and access denial. Wider retrieval must not weaken policy.

Conformance tests apply to all four vector adapters: build/open round trip; stable ID mapping; wrong model/dimension rejection; deterministic exact fixture ranking where applicable; documented approximate recall; empty/small authorized scope; release isolation; revoked object removal before context; score direction; retry/rebuild; hash mismatch; supported filters; and provider-unavailable errors. Domain quality thresholds are measured for the selected deployed profile and repeated after changes.

### 5.10 Publication, migration and fallback

A `search` projection is a bundle descriptor, even when its components are local files. It binds vector artifact/index, lexical artifact/index, document mappings, transforms, embedding configuration, profile and reranker settings. Mark it ready only when every required component is built, checked and evaluated against the same candidate release. The snapshot, graph and search bundle activate together through the manifest.

Changing NumPy to FAISS, Chroma or Azure AI Search does not require changing business definitions. Build a parallel immutable projection under a new profile/release; run conformance and held-out relevance/security tests; shadow comparison may use only authorized inputs; activate atomically and retain the previous complete manifest for rollback. Reusing vectors is permissible only when model revision, input transformation, dimension, dtype/precision and normalization contracts remain compatible; a new embedding model requires re-embedding.

Do not fall back to an older index while claiming the new manifest. A same-release alternative provider can be used only if explicitly built, pinned and approved as a fallback with equivalent policy/semantic compatibility. Otherwise return an unavailable result and preserve the pinned request identity. No automatic provisioning of a new paid provider is implied by selecting a backend name.

## 6. Semantic graph and relationship planning

### 6.1 Required graph model

Use a typed directed multigraph from the first production release. Multiple edges between the same entities capture different business roles, time rules or operations. Distinguish these edge kinds:

| Edge kind | Permitted use |
|---|---|
| Approved executable correspondence | Candidate for query planning under its operation contract |
| Metric/predicate/field dependency | Context completion, compilation and impact analysis |
| Derived dataset lineage | Provenance, dependency invalidation and source traceability |
| Concept equivalence or taxonomy | Retrieval expansion with provenance and scope |
| Inferred association | Stewardship suggestion only; never a query join |

A language-generated knowledge-graph summary is not an executable relationship contract. The graph backend must preserve typed nodes/edges and exact referenced definitions. NetworkX's `MultiDiGraph` supports directed parallel edges and is a viable initial projection representation; validate its footprint and algorithms with the full enterprise benchmark. [NetworkX MultiDiGraph](https://networkx.org/documentation/stable/reference/classes/multidigraph.html)

### 6.2 Relationship correspondence versus operation

A correspondence states endpoint roles, namespace-qualified composite key pairs, temporal predicates, directional multiplicity, null-key semantics and evidence. Operations state intended use: existence, absence, one-record enrichment, child expansion, membership bridge or approved allocation. A mandatory left enrichment must preserve its source population, including after target filtering. An existence condition can use a many-to-many correspondence without multiplying the outer rows.

```json
{
  "id": "entity_x.entity_y_as_of_event_time",
  "source_entity": "domain_alpha.entity_x",
  "target_entity": "domain_alpha.entity_y_history",
  "source_role": "base_record",
  "target_role": "related_record_at_event",
  "key_pairs": [
    {"source": "entity_x.related_key", "target": "entity_y.business_key"},
    {"source": "entity_x.identity_namespace", "target": "entity_y.identity_namespace"}
  ],
  "temporal_rule_id": "event_time_inside_related_valid_interval",
  "source_to_target": "zero_or_one_after_temporal_filter",
  "required_assertions": ["entity_y_intervals_nonoverlapping"],
  "operations": [
    {"purpose": "enrich", "operator": "enrich_left", "preserve_source": true},
    {"purpose": "qualify", "operator": "exists"}
  ],
  "status": "illustrative_requires_approval"
}
```

These neutral semantic IDs illustrate a temporal relationship payload shape; they are not seeded catalog definitions or discovered company tables. Missing fields or temporal evidence make that particular operation unavailable; the platform is designed to represent it.

### 6.3 General relationship cases

Support composite and namespace-scoped keys, role-playing dimensions, temporal joins, slowly changing dimensions, self-relationships and explicit bridge datasets in the model. Reversing an edge does not inherit its preservation rule or multiplicity. For a many-to-many bridge, pure eligibility can use existence; attributing a measure through the bridge needs an allocation/deduplication rule. No default equal allocation may be invented.

Temporal uniqueness requires nonoverlapping valid intervals for the matched key and time basis, not just uniqueness of a version ID. Define boundary conventions, open-ended intervals, timezone and current-vs-as-of semantics. A matching row's technical restriction belongs inside the target relation or ON clause for preserving enrichment; a user-requested base qualification is modeled separately.

### 6.4 Bounded multi-target planning

Input: selected metrics/base entity, desired dimensions and roles, population predicates, output grain, time context, pinned graph and current authorization. Output: an approved relational plan or typed ambiguity/coverage error.

Algorithm:

1. Remove unpublished, revoked and unauthorized executable edges; load required dependencies separately.
2. Resolve endpoint roles and available operation contracts for each requested semantic object.
3. Enumerate a bounded candidate set using allowed path templates plus guided graph search. Keep independent alternatives; do not choose solely by shortest path.
4. Reject namespace/type/time incompatibilities, unsupported cycles, invalid fanout and required-evidence failures.
5. Combine candidate paths into a bounded plan search across all requested targets. Reusing a relation under incompatible roles requires separate aliases/subplans.
6. Rank remaining plans by semantic role match, approved preferred path, simplicity and estimated work, in that order. Performance cannot override business meaning.
7. Clarify materially different valid meanings. If search bounds are exhausted, return that distinct reason or route to an approved template; it is not proof that no path exists.

A shortest-path algorithm alone is inadequate for multiple targets and grain constraints. General path/plan search can grow combinatorially. Cap candidate counts, depth and runtime; instrument pruned paths and search exhaustion. Domain templates and curated preferred paths keep common queries predictable without hardcoding physical SQL into the interpreter.

### 6.5 Graph database decision before production

Default to an immutable per-release graph served by horizontally replicated planner workers. The size of the operational database does not determine the graph's size: this graph contains metadata nodes and contracts, not every operational record. Provisional planner objective is p95 under 250 ms for supported bounded searches at the benchmark envelope, with worker memory leaving at least 40% headroom. These are design targets to validate, not measured results.

Choose a dedicated graph service such as Neo4j in Phase 0/1 if the benchmark fails, if interactive lineage/impact exploration requires large shared traversals, or if independent graph consumers and operational query needs justify it. Store graph data as a release projection keyed by semantic IDs; the configured catalog backend remains authoritative, initially SQLite. Validate licensing, managed/private deployment and HA requirements for the selected edition. Neo4j documents clustered topology options; a database label alone is not a reliability design. [Neo4j clustering](https://neo4j.com/docs/operations-manual/current/clustering/)

This decision is intentionally about the graph backend. **Graph modeling, graph traversal and graph-based planning are already mandatory in the initial architecture.**

## 7. Value resolution, examples and domain procedures

### 7.1 Values need their own resolver

Metadata search identifies a field or metric. Value resolution identifies a canonical member and its exact physical encoding for each source binding. For a small domain, use exact code, normalized label and curated alias matching first. For large dictionaries, an authorized lexical/vector index can generate candidates; fetch the authoritative record before issuing a resolved handle.

The same concept can bind to several codes in one source and different codes in another. Return a typed set per field, including mapping validity and provider revision. A canonical classification can be one-to-many in stored codes without being ambiguous. Ambiguity means multiple competing meanings, not simply several approved encodings.

```json
{
  "status": "resolved",
  "resolution_id": "opaque-example-handle",
  "value_id": "classification.member_x",
  "catalog_release_id": "release-r1",
  "provider_revision": "catalog-r1",
  "bindings": [
    {"field_id": "domain_alpha.entity_x.classification", "binding_ids": ["binding_source_a"]},
    {"field_id": "domain_beta.entity_y.classification", "binding_ids": ["binding_source_b"]}
  ],
  "match_method": "curated_alias"
}
```

Real handles bind principal/access scope, requested fields, effective time and expiry on the server. Outcomes are resolved, ambiguous, not_found, binding_missing, stale or not_authorized. A missing source binding must not silently remove a branch of an either-source condition. Sensitive candidate labels may themselves require access checks.

### 7.2 Large and changing dictionaries

For customers, products or accounts, use a provider contract: search candidates, read authoritative member, obtain source-specific typed binding, check visibility, and pin revision/freshness. Avoid live `SELECT DISTINCT` scans over large operational tables for every question. Build authorized reference projections or query indexed lookup tables with bounded results.

Invalidation includes code reassignment, merges/splits, deprecation, source-sync lag and access changes. Define whether historical queries use historical value bindings. Mapping a current label onto old data is a business rule that must be explicit. Embeddings propose candidate meanings; they never manufacture product/customer keys.

### 7.3 Examples and Agent Skills

A verified example stores question, disambiguated intent, expected semantic plan, definition dependencies, data fixture/reference result, reviewer and applicable capability set. Retrieve relevant examples from the enterprise index. Promote recurring business rules into predicates, metrics or templates so copied SQL does not compete with current catalog definitions.

Domain procedures can use Agent Skills packaging: explain vocabulary discovery, evidence retrieval, clarification, query submission and answer presentation; load domain resources only as needed. The skill is distributed as versioned procedural context and cannot authorize SQL or override policy. The [Agent Skills specification](https://agentskills.io/specification) describes that instruction/resource format; the runtime enforcement in this design is application code.

## 8. General semantic query model and compiler

### 8.1 Three representations

| Representation | Author | Contents and purpose |
|---|---|---|
| Proposed semantic query | LLM/interpreter | Typed business intent, selected IDs, roles, filters, metrics, time and output shape |
| Validated logical plan | Deterministic semantic services | Fully bound relation/operation DAG, values, grain, policies, lineage and assertions |
| Compiled execution artifact | Compiler | T-SQL AST/text, ordered typed parameters, manifest, access binding, expiry and immutable hash |

Do not require a separately hardcoded query kind for every business question. Model a general algebra from the beginning and enable supported operators through a versioned capability registry. A friendly proposal format can use detail/aggregate/cohort shorthand, but it lowers into the same logical operators. Old proposal versions have explicit adapters; arbitrary unknown fields are rejected.

### 8.2 Operator model

| Operator family | Contract required | Rollout treatment |
|---|---|---|
| Scan physical/derived dataset | Authorized binding, source restrictions, row semantics | Initial production |
| Project, typed filter, sort, page | Allowed fields/operators; output identity and completeness | Initial production |
| Semi/anti qualification | Approved correlation, scoped target predicates | Initial production |
| One-record enrichment | Role/key/time contract; right-side uniqueness; preservation | Initial production |
| Child expansion/collection | Parent preservation, changed output grain, complete-child paging rule | Initial production for selected shapes |
| Aggregate and group | Measure unit, counted identity, additivity and allowed dimensions | Initial production for approved metrics |
| Union/intersection/cohort operations | Compatible schema and identity; explicit duplicate semantics | Initial production for required domain templates, broaden later |
| Temporal as-of join | Valid intervals, nonoverlap, timezone and boundary rules | Represented now; enable in domains with verified history |
| Window/ranking/period comparison | Partition grain, ordering, frame and time/calendar semantics | Phase 2 capability releases unless initial demand requires them |
| Multiple-fact combination | Independent aggregates to conformed dimensions; compatible filters | Phase 2 by default; earlier for required production use cases |
| Many-to-many measure attribution | Explicit bridge and allocation/deduplication definition | Governed capability; no implicit allocation |

Capability phases are planning defaults. Phase 0 demand analysis can move an operator into the first release. Safety is attached to the operator contract; product scope should not be frozen to a minimal demonstration.

### 8.3 Illustrative general proposal

```json
{
  "proposal_version": 2,
  "catalog_release_id": "release-r1",
  "requested_measures": ["domain_alpha.metric_x"],
  "group_by": ["shared_calendar.period", "domain_alpha.entity_y.grouping_attribute"],
  "population": {
    "entity_id": "domain_alpha.entity_x",
    "filters": [{"field_id": "domain_alpha.entity_x.event_date", "op": "in_period", "period_id": "resolved-last-quarter"}]
  },
  "relationship_roles": [
    {"target": "domain_alpha.entity_y_history", "role": "related_record_at_event", "purpose": "enrich"}
  ],
  "time_context": {"calendar_id": "approved-business-calendar", "timezone_id": "approved-business-timezone"},
  "output": {"shape": "table", "order_by": [{"field_id": "shared_calendar.period", "direction": "asc"}]}
}
```

The neutral IDs illustrate the proposal structure, not actual company definitions. The server resolves periods using an explicit request timestamp/calendar and validates the metric's base grain. Combining a base-level measure with expanded child-level categories requires an approved attribution definition even when every field exists.

### 8.4 Structural typing versus semantic validity

Implement proposal, expression, logical-plan and artifact schemas with Pydantic, strict types, forbidden extra fields and discriminated unions. Generate JSON Schema/OpenAPI for tools and TypeScript clients. Do not let ordinary string coercion convert IDs, booleans or numbers in ways that change intent. Wire encodings for dates, timestamps and decimals need explicit validated parsers; Pydantic strictness alone does not define a portable storage/wire representation. [Pydantic strict validation](https://docs.pydantic.dev/latest/concepts/strict_mode/), [discriminated unions](https://docs.pydantic.dev/latest/concepts/unions/)

An illustrative fragment, not the complete query-language implementation:

```python
from typing import Annotated, Literal
from pydantic import BaseModel, ConfigDict, Field

class ContractModel(BaseModel):
    model_config = ConfigDict(strict=True, extra="forbid")

class IsNull(ContractModel):
    op: Literal["is_null"]
    field_id: str

class InResolvedValues(ContractModel):
    op: Literal["in_resolved_values"]
    field_id: str
    resolution_handle: str

FilterExpression = Annotated[
    IsNull | InResolvedValues, Field(discriminator="op")
]
```

This fragment can validate shape but cannot establish that a field exists, that its owner/entity/type is correct, that a value handle belongs to the caller/release, or that a requested relationship is safe. Those are resolver/planner/policy checks. Extend the full language through versioned nodes for the operator families in section 8.2 and reject unknown operators. Model structured errors with code, semantic path, safe detail, retryability and required clarification; never place protected alternatives in an unauthorized error.

Use distinct runtime types for `ProposedQuery`, `ValidatedLogicalPlan` and `CompiledArtifact`. Only trusted services construct validated/sealed objects. A model cannot self-assert validation through a JSON flag. Named predicates are loaded and expanded from typed catalog definitions; descriptions are for discovery and explanation. A proposal is a draft interpretation that may need repair, while a well-typed proposal still needs semantic and authorization validation.

### 8.5 Grain propagation

Each logical node carries input/output identity, row unit, multiplicity, population restriction, time basis and field lineage. Existence changes population while preserving the remaining base rows' multiplicity. One-to-many expansion changes output grain and prevents unsafe downstream base-measure sums. An aggregate produces one row per grouping tuple; ratio metrics carry numerator/denominator semantics and cannot generally be summed across groups.

For multiple fact tables, aggregate each fact at a common approved dimensional grain, then combine. Two independently measured fact relations can each contain several rows for the same grouping key; joining their raw rows can multiply both measures. A combined result requires compatible date/population definitions and conformed grouping dimensions. Reaggregation must respect additive, semi-additive and nonadditive measures.

For business distinct counts, specify the complete identity and null policy. A distinct count over a composite tuple may require a grouped subquery in T-SQL; do not concatenate keys with a delimiter and risk collisions. If multiple source rows represent one entity, first apply the approved current/as-of or version rule. Declared grain plus a surrogate key is not sufficient evidence.

### 8.6 Compiler pipeline

```mermaid
flowchart LR
    I[Typed proposal] --> B[Bind IDs values and time]
    B --> P[Plan approved relationships]
    P --> G[Propagate grain and population]
    G --> S[Apply source and access restrictions]
    S --> L[Validated logical DAG]
    L --> T[T-SQL AST compiler]
    T --> V[Independent AST and manifest checks]
    V --> A[Sealed execution artifact]
```

Validate schema shape, known IDs, kind/type compatibility, domain capabilities, value bindings, role/time paths, required evidence, source authorization and query budget. Build only supported AST nodes. Deterministically generate aliases and parameter order. Identify every physical scan and approved derived relation in the manifest.

Identifiers come from validated bindings and are quoted component by component. Values use the driver's parameter interface, with approved type/length mappings. Multi-value mappings expand to separate placeholders or an explicitly supported large-set binding strategy. The agent cannot pass raw SQL snippets, arbitrary identifiers, credentials, policy claims or proof flags.

Validate the final AST against expected structure and obligations. This is tractable because the compiler emits a closed algebra. It is not a claim to prove arbitrary SQL equivalent to a business question. SQL parsers such as SQLGlot provide AST/dialect infrastructure; application policy and target-engine tests remain necessary. [SQLGlot documentation](https://sqlglot.com/sqlglot.html)

### 8.7 Advanced questions and escape-hatch policy

Add an approved derived dataset, reusable typed template or compiler operator when a needed business question exceeds current capabilities. An engineer may author reviewed SQL behind a secured database view with declared grain and lineage. That source becomes a governed binding.

Do not silently fall back to arbitrary LLM-authored SQL when semantic compilation fails. If an organization later chooses an expert SQL workbench, treat it as a separate permissioned product path with its own review, provenance and guarantees. It must not inherit the promise that normal agent answers satisfy all semantic contracts.

## 9. Managed LangGraph workflow from the first production release

### 9.1 Why it belongs in this scope

The application-managed production workflow needs multi-domain retrieval, parallel evidence gathering, bounded repair, clarification across sessions and recovery after worker restart. Use LangGraph for this composition, with deterministic services implementing the business rules. MCP may invoke this complete workflow or expose components to a host-owned loop. The latter deployment omits LangGraph and follows the context/job persistence and enforcement rules in section 18. LangGraph supports stateful orchestration and deterministic/agentic nodes. [LangGraph overview](https://docs.langchain.com/oss/python/langgraph/overview)

LangGraph is not responsible for business identity, joins, source permissions or SQL correctness. Those services remain directly callable and separately evaluated. A retrieval branch is usually a tool/service node, not necessarily another autonomous agent. Add specialist agents only where they demonstrate quality or throughput gains.

### 9.2 Workflow graph

```mermaid
flowchart TB
    START[Authenticate and pin release: code] --> ROUTE[Interpret domain candidates: LLM plus code]
    ROUTE --> RET[Parallel lexical vector and example retrieval: code]
    RET --> EXP[Graph expansion and context validation: code]
    EXP --> INT[Propose business query: LLM]
    INT --> RES[Resolve values roles and dates: code]
    RES --> DEC{Meaning complete?}
    DEC -->|Clarify| ASK[Ask user and checkpoint]
    ASK -->|Resume with access recheck| ROUTE
    DEC -->|More evidence within budget| RET
    DEC -->|Yes| PLAN[Plan compile and validate: code]
    PLAN -->|Recoverable intent error| INT
    PLAN -->|Valid| ADMIT[Workload admission and execution ledger: code]
    ADMIT --> EXEC[Execute bounded Azure SQL query: code]
    EXEC --> RESULT[Verify result envelope: code]
    RESULT --> ANSWER[Explain executed result: LLM plus code]
    PLAN -->|Unsafe or unsupported| STOP[Typed failure]
```

All backward transitions share a global attempt/tool/token/time budget. Define maximum retrieval expansions and interpretation repairs centrally; an error cannot reset the budget. A reasonable initial evaluation profile is two intent repairs and two targeted retrieval expansions, adjusted by measured task complexity and latency.

### 9.3 Durable state and access binding

State includes request ID, caller scope reference, conversation scope, pinned manifest, explicit interpretations/clarifications, context-object IDs, resolution handles, proposal/plan versions, typed errors, budget usage, artifact handle and execution/result IDs. Prefer references over full schema/result payloads. Encrypt and expire checkpoints according to classification; stored text may contain sensitive information.

Use persistent workflow storage separately from semantic metadata. The default initial deployment uses the supported asynchronous SQLite checkpoint integration with a dedicated `workflow-checkpoints.sqlite` file, one owning workflow-service host, bounded concurrent runs and serialized access as required by the selected adapter. Never use an in-memory saver for work that must survive restart. Checkpointer tables/setup are managed by that integration, outside `catalog-schema.sql`.

LangGraph positions its SQLite checkpoint package for local development, testing and lightweight deployments. Selecting it here is conditional on the admitted workflow load and recovery tests, not a claim that every enterprise workload fits it. The synchronous SqliteSaver has additional scaling limits; do not assume switching to async removes SQLite's write constraints. If the required workflow concurrency, multi-host operation or availability exceeds the measured envelope, use a supported server checkpointer such as PostgreSQL independently of the metadata backend. [SQLite checkpoint package](https://reference.langchain.com/python/langgraph.checkpoint.sqlite), [SqliteSaver scope](https://reference.langchain.com/python/langgraph.checkpoint.sqlite/SqliteSaver), [production persistence guidance](https://docs.langchain.com/oss/python/langgraph/add-memory)

An Azure SQL **catalog** adapter does not imply an Azure SQL LangGraph checkpointer exists or is compatible. That is a separate integration decision. Workflow and catalog stores may migrate at different times. Choose safe checkpoint deserialization, retention, backup and resume-compatibility settings for the selected package version.

The public API maps authenticated users to permitted workflow IDs. Possession of a LangGraph thread ID does not grant access. Resume checks current entitlement, catalog retirement, value-handle freshness and workflow-state compatibility. A conversation's earlier assumptions must be visible in the explicit plan and may be revised by the user; hidden free-form memory cannot override catalog rules.

### 9.4 Side effects, retries and cancellation

Keep clarification nodes separate from database submission. Interrupt/resume can rerun code in a node, so code before an interrupt must be safe to repeat. Persist an execution request in a durable ledger before dispatch; queue consumers use an idempotency key derived from request, accepted artifact version and intended execution instance. [LangGraph interrupt behavior](https://docs.langchain.com/oss/python/langgraph/interrupts)

Ledger states: prepared → queued → running → succeeded/failed/cancelled/unknown. Worker ownership uses a lease/fencing token so an expired worker cannot publish over a replacement's result. After a network loss, a SELECT may still be running on the database; do not claim exactly-once execution or blindly submit again. Attempt driver/server cancellation and reconcile the execution record. If outcome remains unknown, report it and apply the defined bounded retry policy.

Cancellation propagates from API to workflow, queue and execution worker. It stops new work and attempts to cancel current work, but database cancellation may not be instantaneous. Redelivery must not restart a cancelled request. Long exports return a job ID and expose status/result retrieval under the original access scope.

### 9.5 Recovery and model behavior

Transient provider failures can retry within budget with backoff. Semantic ambiguity asks the user; permission failures terminate; source drift disables affected capabilities; malformed output can receive one bounded schema-repair attempt. SQL syntax/policy defects from the deterministic compiler are engineering errors, not a request for the model to rewrite executable SQL.

Pin workflow/prompt/model configurations and support checkpoint migration or draining on deployment. Model changes require held-out evaluation. Resume a previous checkpoint only with a compatible state schema or a deliberate restart that explains any changed interpretation.

## 10. Execution, security and trust boundaries

### 10.1 Access applies before context and at execution

Authenticate through the organization's identity provider. The API constructs trusted caller/domain/policy context. Enforce metadata visibility, value visibility, eligible relationships, selectable fields and source-row access. Check authorization before sensitive text enters an LLM, reranker outside the approved boundary, trace exporter, checkpoint or cache.

Use least-privilege database roles, approved secured views and applicable Azure SQL row-level security. RLS is available through security policies and predicates; implementation depends on actual company identity/schema, which was not supplied. The model cannot invent tenant fields or select a tenant/group claim. [Microsoft RLS documentation](https://learn.microsoft.com/en-us/sql/relational-databases/security/row-level-security?view=sql-server-ver17)

For pooled shared database connections, set and validate trusted session context on acquisition and ensure it cannot leak between users. For separate user/delegated identities, test entitlement propagation. Read-intent connection settings alone do not enforce a read-only or least-privilege role.

Every relation used by a query, including an EXISTS subquery, receives its required access restrictions. Related-record existence can reveal sensitive eligibility information even when no related column is projected. If broader eligibility access than raw related-record access is intended, publish a deliberately authorized eligibility view/service with that definition.

### 10.2 Closed execution interface

The executor accepts a sealed artifact ID plus trusted context. It rechecks principal, policy revision, expiry, withdrawn definitions and source compatibility. It does not accept SQL text, credentials or arbitrary connection references from the agent. Displaying SQL in a preview does not make edited SQL executable through the same handle.

Inspect all AST scopes. Allow only compiler-supported SELECT/CTE/operators and approved functions/bindings. Reject dynamic SQL, multiple statements, DML/DDL, SELECT INTO, external/linked sources, unapproved table functions/hints and hidden operations inside nested queries. Source permissions still protect against parser/compiler defects; neither SQL parsing nor a prompt is a sufficient access boundary.

Approved derived sources and UDFs require review of their underlying behavior and privileges. A syntactically read-only SELECT can still cause costly or externally visible behavior through an unapproved function, so function allowlisting is part of the execution contract.

### 10.3 Workload admission and Azure SQL

Separate interactive, scheduled/reporting and export classes. Per-class limits include workflow concurrency, per-user/tenant fairness, SQL concurrency, command timeout, result rows/bytes, tool/model cost and daily consumption where required. The scheduler queues or rejects work with a clear reason; it does not silently sample an exact count.

The Azure SQL adapter quotes bound object names, maps semantic types to driver types, uses parameter APIs, streams permitted rows and handles cancellation/resource cleanup. Keep a database command timeout distinct from the total workflow deadline. Configure the pool so API replicas cannot collectively overwhelm the database.

Optional estimated-plan preflight uses a capability such as SHOWPLAN_XML on an isolated, correctly permissioned connection. It does not execute the statement while enabled, and it must follow the driver's session/batch rules. It is not a correctness proof or a firm resource estimate. If the role lacks SHOWPLAN permission, record that capability as unavailable rather than granting broad access by default. [Microsoft SHOWPLAN_XML](https://learn.microsoft.com/en-us/sql/t-sql/statements/set-showplan-xml-transact-sql?view=sql-server-ver17)

Production rollout needs actual target-engine results, collation/null/date behavior, index/query-plan analysis and load testing. Use supported isolation appropriate to the data; avoid NOLOCK for correctness-sensitive analytical answers. Offloading to a read replica or curated reporting copy is a DBA architecture choice with an explicit freshness contract, not an agent decision.

### 10.4 Result integrity, paging and exports

Counts operate over the entire authorized requested population. Do not place TOP/page limits before aggregate computation. Detail results have stable ordering based on verified output identity and explicit `has_more`/completeness. A table with a synthetic row ID but unresolved business duplication still needs an honest source-row description.

For nested child details, paging flat rows can split a parent across pages. Select an approved shape: page parents and return bounded complete children, or page flat pairs and state the grain. An unmatched LEFT child is an empty child set, not one invented all-null business record. Child limits must be reported explicitly.

For multi-query result assembly, use a tested snapshot/transaction strategy or disclose potentially different read times. Retain source data version/watermark when available. Pinning the catalog guarantees rule reproducibility, not identical results after business data changes.

### 10.5 Data residency, model and prompt boundaries

Select model/embedding/reranker deployments through the enterprise approval process for residency, retention, data processing and access. This document intentionally does not pick a model name or size without workload evaluation and organizational constraints. Record model identity/version and configuration in the manifest; benchmark stronger/smaller models on semantic accuracy and latency rather than assuming one is sufficient.

Retrieved descriptions, examples and SQL comments are data, not executable instructions. Test prompt-injection attempts in catalog text and user requests. Keep tool schemas strict, authenticate service calls and apply authorization regardless of a model's explanation. Result summarization receives only the fields needed and must preserve exact numbers/units; never execute model-authored code over sensitive result sets without a separately approved runtime.

## 11. Reliability, observability and capacity

### 11.1 Initial operating objectives

These are **proposed acceptance targets for capacity planning**, to confirm with stakeholders and measurement. They are not current performance claims or guaranteed provider SLAs.

| Measure | Initial target | Scope |
|---|---|---|
| Interactive API availability | 99.9% monthly | Request/status service; report correctness/coverage separately |
| Context retrieval latency | p95 ≤ 2 seconds | Authorized domain+hybrid+graph context on benchmark catalog; excludes model/database execution |
| Bounded graph planning | p95 ≤ 250 ms | Supported planner workload, excluding LLM interpretation |
| Interactive complete response | p95 ≤ 15 seconds | Agreed common-query class; expensive jobs become asynchronous |
| Interactive SQL timeout | Initial 10 seconds, workload-specific | Engineering default to tune with DBA; does not change requested semantics |
| Authoring recovery | RPO ≤ 15 minutes, RTO ≤ 1 hour | Provisional objectives; validate SQLite backup/restore and artifact recovery; migrate if the accepted availability requirement cannot be met |
| Published release recovery | Restore last known-good complete manifest | Snapshot/index rebuild or standby projection; measured runbook |
| Authorization revocation | Live recheck before context delivery and execution | No new entitlement inferred from pinned release; measure propagation delay |

Long analytical queries and exports have separate deadlines/queues. If the common-query class cannot meet the target without data modeling/index work, revise scope or infrastructure explicitly. Do not hide database delays by returning estimated or sampled answers as exact.

### 11.2 Deployment and failure domains

The initial full managed SQLite deployment has one catalog-service owner and one workflow-service owner of their respective durable files; they may share a host with separate files and resource budgets. Component-only deployments omit the managed workflow store and retain the operational stores their composition requires. Stateless API instances and independent query/execution workers may scale through service APIs and the queue, while their metadata readers use local release copies. They must not mount writable catalog/checkpoint files across hosts. A durable execution ledger can also start with a separately owned SQLite store behind its service; admission, claims and state transitions use that service, with load/recovery gates independent of the catalog. Its schema is separate implementation work.

Multiple active workflow-owner hosts require a compatible shared checkpoint backend and request-ownership strategy. Multiple active catalog writers require the server authority adapter. These decisions are independent of read-worker scaling. Use approved networking and identities and choose availability configurations to meet measured requirements. For an optional Azure AI Search deployment, reliability depends on its configured replicas and workload. Local NumPy/FAISS availability depends on artifact recovery and retrieval-worker topology; Chroma availability depends on its selected embedded/server deployment. [Azure AI Search reliability](https://learn.microsoft.com/en-us/azure/reliability/reliability-ai-search)

Separate data-ingestion/index-build resource budgets from interactive serving. Cache immutable catalog/graph projections by hash. Avoid global mutable in-process catalog state that can change halfway through compilation. A replica becomes ready only after it can serve a supported manifest and policy checks.

### 11.3 Failure behavior

| Failure | Required response |
|---|---|
| Search projection unavailable | Use an explicitly evaluated and pinned exact/template path if sufficient; otherwise report retrieval unavailable. Do not pretend full-schema understanding. |
| Reranker unavailable | Use only an explicitly pinned compatible fallback with its own gates; otherwise stop affected retrieval; retain authorization and record degradation |
| Graph projection missing/incompatible | Load the pinned artifact or stop affected planning; no unapproved join fallback |
| Catalog publisher unavailable | Existing immutable releases may continue if current policy/source checks work; authoring/publication pauses |
| SQLite authority host/storage unavailable | Pause catalog edits/activation; retained authorized releases may serve under the manifest/revocation policy; restore the full authority with one fenced owner |
| RAM catalog lost or over budget | Rebuild from the verified release artifact or use the configured immutable-file reader; do not substitute another release |
| Policy service unavailable | Deny affected protected requests unless a formally approved time-bounded policy cache applies |
| Managed checkpointer unavailable | Stop managed workflows that depend on it; independent component mode can continue only while all of its required context/job/policy stores remain available |
| Azure SQL timeout/network loss | Cancel/reconcile, return typed failure/unknown outcome, preserve execution ledger |
| Source schema/identity drift | Withdraw affected objects/operations, block dependent artifacts, notify owners |
| New model/index degrades quality | Canary stop and rollback complete compatible manifest/configuration |

### 11.4 Observability

Trace request → workflow stage → retrieval query → selected object IDs → graph path → semantic plan → compiler artifact → database execution → response. Include versions and timings, not hidden model reasoning. Redact sensitive literals, SQL parameters and result content by policy. Record why a path or value was rejected in structured diagnostics accessible to appropriate engineers.

Dashboards track domain coverage, complete retrieval recall on replay sets, ambiguity rate, repair rate, incorrect accepted answers from reviews, unsupported requests, query timeouts, queue delay, database load, token/cost distribution, projection lag, revoked-access attempts and snapshot/hash mismatches. Assign ownership and alert thresholds per failure class; a generic model-error counter is insufficient.

### 11.5 Cache, cost and retention

Context caches key by release, normalized query, domain scope, policy scope and retrieval configuration. Resolution caches additionally include provider version/time/field set. Compiled artifacts key by canonical plan plus catalog/policy/compiler/dialect configuration. Results need principal/access scope, parameter values, source watermark or TTL and time context. A matching question string is never a sufficient cache key.

Budget model calls, embedding changes, ranker calls, search capacity, graph memory, database time and exported bytes separately. Measure marginal cost per successful supported answer and wasted work from failed retrieval/repair. Re-embed only changed semantic text when configuration remains compatible; a model/dimension change requires a new vector projection and evaluation.

Checkpoint, result, trace and catalog retention differ. Deleting a user conversation does not automatically delete immutable business definitions, and retaining a catalog release does not authorize indefinite retention of a sensitive query result. Document deletion/retention behavior and verify it operationally.

## 12. Production evaluation and release gates

### 12.1 Evaluation corpus

Construct reviewed questions from real business demand across domains, plus synthetic adversarial/edge cases. Use neutral synthetic relation fixtures to verify general invariants before real domain definitions are available. Include large-schema distractors, duplicate table names, deprecated copies, competing definitions, bridge tables, composite keys, surrogate IDs, historical versions, multi-fact metrics, role-playing dimensions and access-scope variations.

Separate training/prompt-tuning examples from held-out evaluation. Include domain-disjoint or newly onboarded-domain evaluation to test generalization. Store gold intent and result expectations independently of generated SQL; text equality of SQL is not the success criterion.

| Layer | Measurements and acceptance |
|---|---|
| Discovery/catalog | Reference integrity, owner approval, physical bindings, identity evidence, policy coverage, drift behavior |
| Domain routing | Recall of all required authorized domains; avoid forced single-domain classification |
| Retrieval | Complete required-object-set recall, bridge recall, ranking quality, prompt size, latency and no unauthorized context |
| Value resolution | Exact/alias accuracy, ambiguity calibration, binding coverage, stale/reassigned-code behavior |
| Intent | Correct metric/entity/time/scope/grain, useful clarification and explicit abstention |
| Planning/compiler | Correct cardinality/temporal/role decisions, AST obligations, parameter binding and result equivalence |
| Azure SQL | Executed expected results, data types/collation, resource consumption, timeout/cancellation/isolation |
| Orchestration | Restart during every stage, resume compatibility, bounded retries, queue redelivery, unknown execution handling |
| Security | Negative entitlements, revoked policy, forged handle/thread ID, pooled connections, cache/checkpoint/result isolation |
| Operations | Load/soak tests, search/catalog outage, partial release failure, backup restore and manifest rollback |

### 12.2 Initial quality gates

For required regression cases, tolerate zero unauthorized context/execution and zero incorrect accepted results in the deterministic/compiler suite. Track large-schema retrieval complete-set recall with a proposed initial target of at least 98% on the agreed supported corpus; a failure should lead to repair/clarification rather than fabricated SQL. That target is an engineering proposal, not a guarantee about an unmeasured model.

For end-to-end evaluation, separately report supported-answer coverage, answer correctness, clarification burden and incorrect accepted-answer rate. Define severity thresholds with business owners before rollout; a high average score must not conceal material wrong counts. Stratify by domain, query complexity, language and permission scope.

Require target-engine and operational gates before calling a release production-ready. Passing design-document checks or SQLite fixtures cannot establish Azure SQL integration, large-catalog retrieval or LangGraph recovery.

### 12.3 Change-specific gates

- Catalog semantics: rerun affected dependency closure, expected results and relevant retrieval cases.
- Embedding/ranker configuration: rebuild required index; compare complete-set recall, latency, cost and domain fairness.
- Prompt/model: held-out intent/clarification/security evaluations plus end-to-end answers.
- Compiler/operator: unit/property tests, SQL mutation negatives, target-engine results and performance cases.
- Workflow/checkpointer: state migration, restart, retries, cancellation and security tests.
- Access policy: pre-context and source-result restrictions, cache invalidation and old-handle rejection.

Use shadow evaluation without executing extra production queries unless that workload is explicitly authorized and bounded. Canary releases route a controlled cohort and retain a tested rollback manifest. Automatically collected feedback becomes review evidence; it does not automatically rewrite metrics or join policy.

## 13. Implementation contracts and repository organization

### 13.1 Service interfaces

| Service | Input | Output/invariant |
|---|---|---|
| `CatalogService` | Authenticated scoped draft/review/import actions | Atomic revision, metadata, audit and role enforcement |
| `CatalogPublisher` | Approved revision/digest and expected base | Complete immutable projections and conditional activation |
| `DiscoveryService` | Approved connector and scope | Staged structural facts; no automatic runtime enablement |
| `EvaluationService` | Candidate identity, suites, profile and access | Versioned reports bound to content; no approval inference |
| `ReleaseResolver` | Trusted user/workload context | Compatible manifest and access scope |
| `DomainRouter` | Question and authorized domain summaries | Multiple candidate domains with explicit uncertainty |
| `HybridRetriever` | Question, domain candidates, manifest, trusted filters | Ranked versioned candidates with source-channel evidence |
| `ContextAssembler` | Candidates + graph + policy | Exact authorized dependency-complete context package or missing evidence |
| `ValueResolver` | Domain/text/fields/time | Resolved handle or explicit ambiguity/coverage error |
| `SemanticPlanner` | Typed proposal, graph, snapshot, capabilities | Bound logical DAG with grain and policy obligations |
| `SqlCompiler` | Validated plan/dialect | Immutable AST/text/parameters/manifest |
| `ArtifactValidator` | Artifact and expected plan | Checked execution eligibility or structured error |
| `ExecutionService` | Sealed handle and trusted context | Durable job/typed result; no caller SQL |
| `AnswerAssembler` | Result and executed manifest | Exact units/scope/completeness with readable explanation |

All deterministic services are usable outside LangGraph and independently evaluated. Managed and host-controlled orchestration call the same application facade and do not duplicate its rules. Python, HTTP and MCP adapters are first-class entry points; section 18 defines composition profiles, tool contracts, package boundaries and compatibility tests. An optional future gRPC adapter follows the same boundary.

### 13.2 Repository layout

```text
apps/
  web/                  React + TypeScript query UI and restricted steward area
services/
  api/                  HTTP adapter: identity, request/status/results, catalog endpoints
  mcp/                  MCP adapter over the shared application facade; selectable profiles
  workflow/             LangGraph state, nodes, routing, budgets
  catalog/              SQLite store, discovery, stewardship, migrations, publisher
  retrieval/            vector/lexical/reranker adapters and context assembly
  planning/             graph projections, relationship search, grain algebra
  compiler/             typed IR, expressions, dialect AST, artifact validation
  execution/            ledger, queue consumers, source adapters, exports
packages/
  semantic_contracts/   versioned objects, payloads, IR, tools and errors
  semantic_core/        pure rules and typed ports used by planner/compiler modules
  semantic_application/ authorized use-case facade shared by HTTP, MCP, Python, workflows
  compositions/         dependency injection and optional runtime/provider packages
  generated_api/        OpenAPI-derived TypeScript client/types
  policy_adapters/      current authorization and source-policy bindings
  telemetry/            redacted trace/metric conventions
evals/
  synthetic_relational/ neutral identities, nulls, history, fanout, ambiguity
  domain_suites/        reviewed real-domain questions and target-engine fixtures
  provider_contracts/   NumPy, Chroma, FAISS, Azure and lexical/reranker conformance
  retrieval_scale/     catalog distractors, restricted recall and bridge dependencies
  stewardship/         API/UI roles, scope, review invalidation and publication races
  harness_adapters/     HTTP/Python/MCP parity and target-host compatibility
  package_boundaries/   minimal installs, optional imports and dependency rules
  operations/          failure, load, recovery, migration and rollback
infrastructure/        deployment profiles, configuration, secret refs and runbooks
```

Modules may initially run together in a modular service; the layout does not mandate a microservice per folder. Share versioned contracts while keeping dependency direction explicit. Semantic contracts must not import a vector provider, database driver or LangGraph. Source adapters and orchestration call domain services through interfaces.

### 13.3 Catalog payload contracts and validation ownership

Every JSON payload declares a schema version in its canonical application representation. Define exact schemas, required fields, allowed enum values and migration adapters before implementing importers or editors. The table below is the required design inventory, not permission to accept arbitrary JSON when a field is omitted from a form.

| Payload family | Required content | Validation owner |
|---|---|---|
| Object provenance/source freshness | Origin, owner/reviewer, evidence timestamps, transformation/source revision | CatalogService and publisher |
| Entity row semantics/keys/versioning | Unit, referenced field IDs, namespace, equality/null rules, current/as-of selection, uniqueness evidence | Typed schemas, source validator, grain planner |
| Field expression/types/roles/operators | Versioned expression AST, input IDs, output type, allowed operations and sensitivity | Compiler type checker and policy |
| Value normalization/resolution/bindings | Unicode/case rules, exact alias policy, typed scalar or binding set, validity/coverage | ValueResolver and publisher |
| Relationship keys/cardinality/identity/time | Directed roles, composite pairs, namespaces, match bounds, intervals, nulls and required predicates | Relationship validator/planner |
| Operation contract | Preservation, input/output grain, filter placement, fanout, time/evidence preconditions, allowed aggregates | SemanticPlanner and compiler |
| Predicate/metric/template | Typed expression/plan, parameter schemas, dependencies, population/unit/additivity/time/capabilities | Semantic services and compiler |
| Assertions/examples | Typed subject, requirement/evidence scope, expiry/failure action, expected intent/results, fixture provenance | Publisher and evaluation services |
| Domains/semantic edges | Vocabulary, coverage, memberships, typed approved dependencies and lineage | CatalogService and graph projector |
| Capability requirements | Supported operator version/dialect, input constraints, workload and evidence gates | Compiled capability registry |
| Retrieval configuration | Model/dimension/metric/normalization, filtering, fusion, reranker, provider configuration refs | Retrieval adapters and publisher |
| Manifest/artifact descriptors | Complete component IDs/hashes, profiles, application versions and compatibility | Publisher and ReleaseResolver |
| Authoring/discovery/evaluation control | Authorized scopes, immutable candidate identity, observed metadata, report provenance and audit details | CatalogService and trusted workers |

SQLite `json_valid` proves JSON syntax only. `catalog_object.object_kind` must match its subtype row; field references must belong to the declared entities; predicate cycles/invalid graph dependencies must be rejected. Foreign keys do not check IDs embedded in JSON, derived relation type consistency, policy legitimacy or code-binding meaning. Build a publisher validation pass over the dependency-complete candidate and record structured diagnostics for the steward UI.

### 13.4 Source, storage and provider adapter boundaries

`SourceDiscoveryAdapter` inventories authorized physical structure and fingerprints changes. `SourceProfiler` collects bounded evidence. `SqlDialectCompiler` lowers validated logical operators into supported target syntax/types. `SourceExecutor` manages restricted connections, parameters, isolation, streaming and cancellation. `SourcePolicyAdapter` maps current application scope to tested source restrictions. The first implementations target Azure SQL, while semantic definitions reference provider-neutral IDs and types where possible.

Keep catalog storage ports from section 4.8 separate from these business-source ports. Selecting Azure SQL as an operational source does not require Azure SQL metadata storage; moving metadata to PostgreSQL does not change generated business SQL. Vector adapters from section 5 and graph projection ports also evolve independently.

Source-specific semantics such as collation, timestamps, null ordering, numeric precision and supported functions are declared capabilities. Do not silently force every engine into one lossy type model. Multi-source plans require explicit source-placement and consistency support; reject them until a tested capability is enabled.

## 14. Phased delivery plan

### 14.1 Phase 0: platform contracts and discovery readiness

**Outputs:** repository/module boundaries; modular-package/import rules; shared application facade; MCP tool contracts and two orchestration modes; target-host capability/egress matrix; Pydantic/JSON Schema and generated TypeScript contracts; source/dialect ports; catalog schema migrations; constitutional traceability; role/policy model; steward UI wireframes; retrieval/graph/workflow adapter contracts; synthetic relational fixtures; capacity assumptions; evaluation plan; and approved configuration/secret references.

Implement source inventory without requiring known company names. Where source access is unavailable, use a generated neutral schema exercising composite identity, history, missing relationships, duplicate rows and restricted fields. Keep pending real-source discovery and business-definition approvals visible. Do not infer them from fixture names.

Benchmark the expected published metadata subset and the larger inventory separately. Compare NumPy, Chroma, FAISS and Azure AI Search against relevance, filter support, latency, memory, deployment requirements and cost. Pin approved embedding/reranker choices only after evaluation. Validate NetworkX footprint and bounded planning. Validate catalog, checkpoint and execution-ledger storage independently.

**Exit gate:** reviewed typed contracts, source-discovery/fixture path, agreed pilot question families and owners, security boundaries, known deployment constraints and a measured/provisional provider decision with explicit unresolved inputs. No promise that synthetic benchmarks establish real-domain correctness.

### 14.2 Phase 1A: governed authoring and published metadata

Deliver reusable core/application packages, direct Python and HTTP entry points, and context/planning MCP profiles with minimal dependency and parity tests. Build React + TypeScript steward pages for domain backlog, discovery triage, metadata editing, mapping, relationship/predicate/metric definitions, example management, evaluation reports, diffs and review/publication status. Implement authenticated APIs, scoped roles, audit, optimistic revisions and exact-content review invalidation. All imports/connectors use the same service rules.

Implement persistent SQLite authority, consistent backups, schema migrations, canonical export, immutable SQLite release files, query-only RAM loading, typed NetworkX projection, publication outbox and manifest activation with base CAS. Implement retrieval adapters for all four declared vector choices as optional dependencies/configurations and local lexical retrieval. A deployment installs/configures only selected providers. Unverified/unconfigured adapters are marked unavailable rather than shown as production-ready.

**Exit gate:** empty bootstrap and upgrade checks, atomic edit/audit/revision behavior, no unauthorized stewardship, stale review/base rejection, profile compatibility, deterministic snapshot exports excluding control rows, projection integrity, backup/restore and concurrent-domain publication tests. Provider-specific integration environments gate availability of each adapter; every deployed choice needs its own passing conformance checks.

### 14.3 Phase 1B: first production domain and agentic query path

Build the end-user query UI, authenticated request/status/results APIs, execution and managed-workflow MCP profiles, managed LangGraph workflow, domain routing, hybrid retrieval/reranking, context expansion, authoritative value resolution, typed proposals, deterministic planner/compiler, independent artifact checks, execution ledger/queue, restricted Azure SQL execution and exact result explanation.

Onboard one selected domain or a small coherent domain group. Establish the actual business identities, definitions, mappings, operations, example results and policy restrictions through the steward path. Support detail queries, typed filters, approved counts/sums/groupings, membership/absence and required enrichment/expansion. Add temporal, multi-fact or other operators now if they are necessary for agreed pilot questions; capability labels must reflect actual tested implementation.

**Exit gate:** held-out useful coverage/intent/retrieval targets, target-engine expected results and fanout/null/identity negatives, source/data access and revocation checks, clarification/restart/retry/cancellation tests, workload limits, measured latency/cost, retained rollback artifacts and named support owners. A pilot runs against a published manifest with restricted audience, never a draft bypass. Require at least one tested external host, direct component operation without React/LangGraph, managed-flow reuse and cross-adapter enforcement parity; report untested target hosts as unverified.

### 14.4 Phase 2: repeatable domain expansion and richer semantics

Add further domains via the same UI/import/discovery/review/evaluation process. Promote approved cross-domain paths only after combined identity/time/role/metric tests. Extend calendar semantics, windows/ranking, reusable cohorts, ratios, multi-fact aggregation, historical joins, large value providers and governed many-to-many attribution according to demand.

Expand automated drift detection and affected-dependency evaluation. Improve steward usability and feedback triage. Maintain separate coverage and correctness measurements, retain old-domain regressions and benchmark distractor metadata as the published catalog grows. No bulk enablement of every discovered relation.

**Exit gate for each wave:** owner approval, complete value/relationship/evidence coverage, compatible capabilities, source-engine results, retrieval/security regressions and operational capacity for the enlarged release. Measure cross-domain ambiguity rather than assuming single-domain routing remains sufficient.

### 14.5 Phase 3: scale and provider evolution

Retain SQLite while it meets accepted write, storage and recovery needs. Add PostgreSQL or Azure SQL authority adapters and controlled migrations when contention, multi-host availability or operational requirements justify them. Upgrade workflow/ledger storage independently. Scale vector serving or choose another approved backend when relevance/latency/operations warrant it. Introduce a graph service when shared traversal or memory needs justify one.

Additional source engines need source discovery, physical type/binding, dialect compiler, execution/security and consistency conformance. Federation is a separately planned capability with cross-source identity, snapshot, pushdown, join, resource and data-movement contracts. A general semantic model does not make those execution guarantees automatic.

**Exit gate:** provider-equivalence/conformance, migration and rollback rehearsal, updated load/failure tests, accepted recovery objectives and sustainable cost. Rebuild/evaluate vector projections whenever embedding compatibility changes. Preserve public semantic IDs and published query contracts through versioned migrations.

### 14.6 Phase boundaries and dependencies

```mermaid
flowchart LR
    P0[Phase 0 contracts and discovery] --> A[Phase 1A authoring and publication]
    A --> B[Phase 1B first production domain]
    B --> D[Phase 2 domain and capability waves]
    D --> S[Phase 3 measured scale changes]
    P0 --> RET[Four vector adapters and conformance]
    RET --> A
    P0 --> SEC[Identity and current policy]
    SEC --> A
    SEC --> B
    D --> E[Continuous evaluation and drift]
    E --> D
    E --> S
```

Platform phases and domain rollout are different axes. Later infrastructure can be adopted earlier if initial requirements demand it; a small approved catalog can remain on NumPy/SQLite/NetworkX for a long time. Every production domain still receives the full governing boundaries. This is extensible infrastructure with incremental useful coverage, not a commitment to provision the maximum topology immediately.

## 15. Decision rationale and tradeoffs

| Decision | Why it fits the stated scope | Cost/tradeoff | Stable interface |
|---|---|---|---|
| Hybrid retrieval with configurable providers in first release | Large, heterogeneous terminology already requires robust candidate discovery | Embedding/index lifecycle, provider conformance, memory/service cost and evaluation | `HybridRetriever` + versioned context objects |
| Graph model in first release | Safe paths, bridge dependencies and change impact are structural | Owner-reviewed edges and bounded search complexity | `SemanticPlanner` + typed edge contracts |
| LangGraph for managed mode | Durable enterprise workflows require branching, clarification and recovery | Checkpointer operations, state versions and replay discipline; omitted for host-owned component mode | Shared application services + workflow state schema |
| First-class MCP and modular packages | External hosts can reuse governed components or the entire managed flow | Tool contracts, authentication/egress, compatibility and dependency tests | Same application facade, semantic contracts and execution boundary |
| SQLite authority + in-memory SQLite reads | Fits modest metadata writes while supporting coherent indexed reads and multiple authors through one service | Single write owner, memory budget, consistent backups and measured availability | `CatalogAuthoringStore`, `CatalogReader`, exporter and release manifest |
| Optional PostgreSQL/Azure SQL authority | Accommodates requirements exceeding the SQLite deployment envelope | Adapter validation, provisioned infrastructure and controlled migration | Same semantic IDs, payload contracts and worker release format |
| Configurable vector backend with separate lexical/reranker contracts | NumPy, Chroma, FAISS and Azure AI Search serve different deployment/capacity needs | Adapter conformance, artifact lifecycle and provider-specific operations | `VectorIndex`, `LexicalIndex`, `Reranker`, versioned retrieval profile |
| Graph backend chosen by enterprise benchmark | Graph structures are mandatory; server benefits depend on actual traversals/consumers | A dedicated graph DB adds operations and consistency work | Graph projection and planner interfaces |
| Deterministic SQL compilation | Makes join/grain/value enforcement explicit across many domains | Building and maintaining a query algebra | Typed proposal/logical plan/compiled artifact |
| Capability-gated rollout | Allows broad future semantics while controlling released guarantees | Unsupported requests need useful feedback and prioritization | Versioned operator registry |

These choices preserve the boundary between LLM interpretation and deterministic execution across unknown company schemas and incremental domain rollout. Requirements may cause ordinary schema migrations and new operators; the goal is to avoid replacing the core model of meaning, identity, authorization and execution.

## 16. Planning package, unknowns and verification scope

### 16.1 Three self-contained artifacts

1. [Semantic-layer constitution](01-semantic-layer-constitution.md) defines required meaning, authority, enforcement and component-to-table accountability.
2. This implementation design defines architecture, contracts, storage/retrieval choices, steward workflows, query execution and phased acceptance.
3. [Catalog schema](catalog-schema.sql) defines the schema-version-4 SQLite bootstrap for the logical metadata and authoring/publication control model.

Use these three files together as the input to an AI coding editor. No prior sample database, conversation or companion guide is required. Other historical files may exist beside them; they are outside this version's planning package. The SQL file contains no seeded company schema or business mappings. Its tables are metadata tables for the application, not the tables queried on behalf of end users.

### 16.2 What is specified and what still requires discovery

The architecture specifies stable semantic identity, typed plans, relationship operations, deterministic compilation, version-coherent publication, authoring controls, provider ports and modular HTTP/Python/MCP compositions. It deliberately does not define actual source entities, business identity keys, activity/status meanings, metric formulas, join purposes, code mappings or ownership for the company.

Phase 0 must establish deployment/security policy, target schemas and access, intended users, priority question families, availability/recovery goals, concurrency, metadata sizes, sensitivity, model/embedding/reranker constraints and budget. Initial runtime defaults are engineering starting points subject to those requirements. A plan can proceed with explicit assumptions and neutral fixtures while real-source-dependent tasks remain clearly marked.

### 16.3 What the artifacts do and do not implement

This package is a design and runnable SQLite bootstrap, not a deployed application. Local verification covers DDL creation, foreign keys/checks, retrieval-profile relationships, selected authoring/control constraints, transaction/revision behavior, immutable export and in-memory loading, and document structure/link/JSON consistency. A report accompanying a delivered package records actual performed checks; design requirements are not reported as passing tests.

The DDL does not implement API permissions, typed payload meaning, workflow transitions, audit append enforcement, approval validity, background workers, vector adapters, LangGraph state, SQL compilation or source execution. These need application code and the phase gates above. It also does not replace migration scripts for an existing authority. Mermaid diagrams are source artifacts; unless explicitly reported, visual rendering has not been verified.

Native PostgreSQL/Azure SQL metadata adapters, real vector services, actual company queries, model accuracy, permissions, throughput and recovery require implementation/integration environments. SQLite fixture checks cannot establish those properties. Versioned reports must distinguish local structural checks, synthetic behavior and actual deployed-service evaluations.

### 16.4 Official references and implementation version pinning

Technology claims are linked in relevant sections. Additional primary references include [SQLite foreign keys](https://www.sqlite.org/foreignkeys.html), [SQLite WAL](https://www.sqlite.org/wal.html), [Azure SQL overview](https://learn.microsoft.com/en-us/azure/azure-sql/database/sql-database-paas-overview?view=azuresql), [T-SQL EXISTS](https://learn.microsoft.com/en-us/sql/t-sql/language-elements/exists-transact-sql?view=sql-server-ver17), [T-SQL joins](https://learn.microsoft.com/en-us/sql/t-sql/queries/from-transact-sql?view=sql-server-ver17), and [LangGraph persistence](https://docs.langchain.com/oss/python/langgraph/persistence).

During implementation pin supported versions of Python, SQLite, Pydantic, frontend dependencies, orchestration packages, provider clients and source drivers. Recheck their APIs and security/operational guidance. Provider-specific algorithms and deployment limits must be verified against the selected versions; generic interfaces here do not promise API compatibility across unpinned library releases.

## 17. Handoff to an AI coding editor

### 17.1 Planning task and required output

Ask the coding editor to produce an extensive implementation plan before generating the application. The plan must be executable by an engineering team: work packages, dependencies, files/modules, schemas, API contracts, migrations, tests, deployment steps, evidence and acceptance criteria. It must not merely repeat this architecture diagram or assume unknown company definitions.

Required planning outputs:

- Requirement/decision register distinguishing fixed requirements, provisional implementation choices, measurements needed and business-owner decisions.
- Constitution-to-implementation traceability mapping every C01–C17 rule and component to services, persistence, payload contracts, tests and release gates.
- Repository layout and dependency boundaries, including React/TypeScript UI, reusable Python core/application packages, source/provider adapters, deterministic compiler, managed LangGraph state and independent HTTP/MCP adapters.
- Two orchestration/composition modes: reuse the complete managed workflow from MCP, or let an external host orchestrate semantic tools without React/LangGraph; define dependency closure, tool schemas, context/job state, current policy/egress, host compatibility and parity tests.
- Full typed payload/IR/error schemas, frontend generation strategy, API endpoints and ownership of every validation step.
- Database migration plan from an empty schema and upgrade policy, control-versus-published export allowlist, hash/version contracts, backup and restore.
- Steward UI screens, role matrix, domain scoping, discovery triage, draft/review/evaluation/publication/rollback state machines and concurrency conflict behavior.
- Retrieval implementation tasks for NumPy, Chroma, FAISS and Azure AI Search, optional dependencies, capability negotiation, local lexical adapter, embedding/reranker configuration and conformance/integration availability gates.
- Domain onboarding playbook and first-domain acceptance template, including real-source inputs that cannot be guessed.
- Compiler and graph contracts for identity, nulls, temporal behavior, preservation, multiplicity, population, parameterization and source restrictions.
- Durable orchestration state, retries, idempotency, checkpoints, execution ledger, job admission, cancellation and policy rechecks after resume.
- Security/privacy model for UI, imports, discovery, source access, context, vectors, reports, artifacts, results and caches; deployment configuration and secret ownership.
- Test/evaluation matrix with generic adversarial fixtures, provider contract tests, target-engine integration, held-out intent/retrieval tests, frontend/API authorization and operational recovery.
- Phased milestones with entry/exit gates, work-package dependencies, rough effort/uncertainty if requested, pilot rollout and rollback runbooks.
- Risk/unknown register and a concise set of genuinely blocking questions. Proceed independently on work that does not depend on the answers.

### 17.2 Reusable planning prompt

```text
Use the attached 01-semantic-layer-constitution.md, 02-implementation-design.md
and catalog-schema.sql as one coordinated specification. Produce an extensive,
implementation-ready, phased engineering plan for an enterprise NL-to-SQL
agentic application. Plan first; do not generate the application yet.

The company source schema and domain semantics are not known in advance.
Build discovery, governed authoring and repeatable domain onboarding into the
product. Do not invent company tables, keys, mappings, metric formulas or joins.
Use neutral synthetic fixtures only for platform and invariant testing.

Keep React + TypeScript frontend; Python/Pydantic semantic services; SQLite
persistent catalog and read-only in-memory published readers by default;
optional later PostgreSQL/Azure SQL catalog adapters; NumPy, Chroma, FAISS or
Azure AI Search as configurable vector backends; separate lexical, embedding
and reranking contracts; NetworkX typed graph initially; LangGraph durable
orchestration for managed mode; deterministic typed planning/SQL compilation; current access
controls; and Azure SQL as the first business execution adapter. Preserve
source/dialect interfaces for subsequent systems without assuming federation.

Make components reusable through a shared authorized application facade with
Python, HTTP and MCP adapters. Apply section 18 dependency/package rules.
Support both complete managed-flow invocation and host-controlled semantic
tools. The latter must work without React or LangGraph while retaining all
required policy, validation, context persistence and execution controls. Include
a tested compatibility matrix for target hosts, egress rules, versioned tool
contracts and HTTP/Python/MCP parity/minimal-install acceptance tests.

Provide a restricted catalog-steward UI and APIs for selected team members,
scoped roles, discovery/import staging, metadata editing, exact-revision
review, evaluation and publication. Onboard domains incrementally; broad
inventory must not imply broad runtime access or approved semantics.

Cover all outputs in section 17.1. For each work package state its purpose,
dependencies, concrete modules/artifacts, contracts, implementation tasks,
tests and acceptance evidence. Separate structural typing, semantic validation,
authorization and source-engine behavior. Distinguish DDL constraints from
service/publisher obligations. Include the versioned migration/export rules
and schema-version-4 bootstrap limitations.

Mark assumptions and unresolved company inputs explicitly. Ask only blocking
questions; propose measured defaults for reversible implementation choices.
Do not silently simplify away enforcement, review or recovery. Provision only
selected providers; all four vector choices require specified adapter and
conformance tasks, and unconfigured/unverified providers remain unavailable.
Do not call the plan production-ready merely because local fixture tests pass.
```

### 17.3 Definition of a satisfactory plan

A reviewer must be able to identify which service owns every constitutional guarantee, which data records support it, which failure outcome occurs if it cannot be established, and which test proves the supported behavior. Every deployment choice has a measured boundary; every domain has owners and coverage gates; every unknown source fact has a discovery/approval task. The plan may add implementation detail and justified refinements, but changes to these governing boundaries must be explicit decisions with consequences and updated acceptance criteria.


## 18. Modular components, interchangeable harnesses and MCP

### 18.1 Architectural requirement and terminology

The enterprise web application is one composition of reusable components. A supported external AI application must also be able to invoke those components through MCP, without running the React UI, copying business definitions into its prompts, or reimplementing join/grain/security rules. MCP is a first-class delivery interface from the initial platform phases, not a deferred integration workaround.

An MCP **host** is the AI application that manages model interaction and tool use. Its **client** communicates with an MCP **server** exposing our selected capabilities. We implement the server adapter; compatible hosts connect their clients to it. MCP standardizes that exchange rather than prescribing the host's agent loop. Verify target host versions and capabilities during integration. [MCP architecture](https://modelcontextprotocol.io/docs/learn/architecture)

GitHub Copilot, Cursor and Codex are requested target harnesses, not assumed to share every transport, authentication mechanism, schema feature or optional protocol capability. Maintain a tested compatibility matrix. No design statement here claims that these products have already been configured or tested against this application.

The goal is **shared semantics and enforcement with replaceable presentation, transport, orchestration, models and infrastructure adapters**. Modular does not mean every class becomes a network service or an MCP tool. Stable component interfaces allow in-process composition first and separate deployment where useful. Keep enforcement-critical operations cohesive.

### 18.2 Two agentic execution modes

| Mode | What the MCP host invokes | Who owns the inner agent loop? | LangGraph requirement | Guarantee |
|---|---|---|---|---|
| Managed workflow | Submit question, inspect status, supply clarification, fetch results, cancel | Our application | Used by the managed workflow deployment, including when invoked through MCP | Same implemented workflow and governing services as the web application |
| Host orchestration | Open query context, retrieve definitions, resolve values, prepare typed query, execute sealed artifact, fetch results | External host and its chosen model | Not required in the component-only deployment | Same semantic contracts and service enforcement; host interpretation/tool sequence can differ |

Use **managed workflow mode** when “the same agentic flow” means the same state machine, bounded repair, prompts/model configuration, clarification handling and durable orchestration. The host acts as a conversational client around the existing workflow. It need not reproduce internal retrieval/planning steps or provide an embedding/model service. Our managed workflow uses its configured model adapters.

Use **host orchestration mode** when the host should interpret the user's question and decide which exposed semantic tools to call. The host's model receives authorized context and submits a typed proposal. Our deterministic services still resolve and validate every executable obligation. This removes a mandatory LangGraph dependency from that deployment without removing policy, grain, relationship or execution checks. The executor's durable ledger and server-side query-context/artifact records remain required when execution is exposed.

The host loop may ask different clarifying questions or choose a different interpretation. MCP cannot make independent agent loops behaviorally identical, and even the managed workflow is not a promise of identical LLM output across runs. For the same validated logical intent, release, current authorization and source state, the shared deterministic services must preserve the same semantics regardless of entry point. Evaluate end-to-end answer quality separately for each supported mode/host/model combination.

Choose orchestration ownership when opening a run/context. Do not run two competing loops that repeatedly reinterpret each other's output. A host-controlled context can deliberately start a separate managed run, but that is an explicit operation with its own ownership, budget and audit linkage.

### 18.3 Composition architecture

```mermaid
flowchart TB
    WEB[React and TypeScript web client] --> HTTP[HTTP API adapter]
    HOST[External MCP host and client] --> MCP[MCP server adapter]
    SDK[Trusted Python consumer or batch job] --> SDKAPI[Python application facade]
    HTTP --> MANAGED[Managed query workflow]
    MCP --> MANAGED
    MCP --> PUBLIC[Composable semantic operations]
    SDKAPI --> PUBLIC
    SDKAPI --> MANAGED
    MANAGED --> PUBLIC
    MANAGED --> LG[LangGraph runtime and model adapters]
    PUBLIC --> CORE[Shared semantic application services]
    CORE --> CTX[Catalog retrieval and value resolution]
    CORE --> PLAN[Graph planning and grain validation]
    CORE --> COMP[Compiler and artifact validation]
    COMP --> EXEC[Sealed-artifact execution service]
    POL[Current policy and workload control] --> PUBLIC
    POL --> EXEC
    CTX --> ADAPT[Catalog vector graph and source ports]
    PLAN --> ADAPT
    EXEC --> SOURCE[Restricted source adapter]
```

Every path into the application facade constructs a trusted `RequestContext` from authenticated identity and approved configuration. An MCP wrapper must not call low-level database helpers directly to avoid the application facade. A Python caller is likewise not trusted merely because it imports the package: deployed endpoints always perform current policy checks. Direct in-process embedding is available only within an approved service boundary, whose composition root supplies real identity/policy dependencies.

The facade exposes use cases such as retrieval, query preparation and execution. Private planner/compiler helpers can be reusable Python modules without being public MCP tools. One query-oriented MCP server can expose several coherent operations. Separate servers for administrative stewardship, isolated policy zones or distinct trust/deployment ownership are optional compositions over the same services.

### 18.4 Module boundaries, ports and dependency rules

| Module | Public responsibility | Permitted dependencies | Must not require |
|---|---|---|---|
| `semantic_contracts` | Versioned DTOs, IR, errors, value types and serialization rules | Standard library and selected schema/type library | React, HTTP/MCP SDKs, LangGraph, provider clients, database connections |
| `semantic_core` | Relationship/grain/type rules, bound plan validation and compiler logic | Contracts, pure algorithms, narrow injected read/policy/dialect ports | Browser state, conversation history format, MCP context objects, LangGraph checkpoints |
| `semantic_application` | Authorized retrieval, value resolution, prepare/execute/run use cases | Core/contracts and injected catalog, policy, retrieval, execution and job ports | Specific route handlers, MCP sessions or frontend models |
| `catalog_services` | Authoring, discovery, publication and immutable readers | Contracts and configured persistence/artifact/source ports | React forms or one particular authoring channel |
| `workflow_langgraph` | Managed state machine, clarification, bounded interpretation/repair | Application use cases, model/checkpoint ports and LangGraph | Duplicated semantic rules, direct bypass execution |
| `transport_http` | HTTP authentication, payload mapping and response delivery | Application facade and HTTP/identity adapters | Independent business definitions or compiler logic |
| `transport_mcp` | MCP discovery/tool/resource mapping, authentication and result encoding | Application facade, MCP SDK and transport identity adapters | Copied rules, React, mandatory LangGraph in component mode |
| Infrastructure adapters | SQLite/server storage, NumPy/Chroma/FAISS/Azure search, graph, source/dialect, models, queue/artifacts | The corresponding port contracts and selected libraries | Imports from a frontend or an external host's private runtime |
| Composition roots | Wire selected adapters and expose chosen capability profiles | The selected modules only | Hidden global provider selection or import-time network/database work |

Use explicit constructor/factory injection. Canonical DTOs have no transport-specific fields; HTTP/MCP metadata is translated into a separate trusted context and audit envelope. No singleton mutable release, global user identity or ambient credentials. Pass a pinned release reader/context explicitly through a request.

Package optional integrations independently: `catalog-sqlite`, `vector-numpy`, `vector-chroma`, `vector-faiss`, `vector-azure-search`, `graph-networkx`, `source-azure-sql`, `workflow-langgraph`, `transport-mcp` and `transport-http` are illustrative distribution/extras boundaries. Exact package names are implementation choices. Installing a metadata-only MCP server must not require React, LangGraph, Azure search credentials or a SQL execution driver. Installing one vector adapter must not import the other providers on startup.

Maintain import/dependency tests and package-install smoke tests in minimal environments. Backend classes register through explicit factories/entry points; never execute code embedded in catalog JSON. The same core version is used behind HTTP, Python and MCP adapters. A replacement workflow/harness adapter should require no changes to semantic rules, catalog objects or source bindings.

### 18.5 Reuse profiles and required dependency closure

| Composition profile | Exposed use | Required pieces | Optional pieces |
|---|---|---|---|
| Catalog/context | Discover approved meanings and retrieve authorized context | CatalogReader, policy, selected retrieval/graph dependencies and facade | Query compiler, executor, LangGraph, React UI |
| Planning | Resolve values and prepare a validated query/preview | Catalog/context plus resolver, planner, compiler, artifact validation and trusted artifact store | Source execution, LangGraph, React UI |
| Execution | Execute prepared governed queries | Planning dependency closure plus current policy, execution service/ledger, workload admission and source adapter | Managed workflow, React UI |
| Managed question-to-answer | Entire agentic workflow | Execution closure plus workflow/model/checkpoint/result assembly services | React UI when used through MCP |
| Stewardship administration | Govern metadata changes | CatalogService, authoring roles, audit, review/evaluation/publication services | Query-facing MCP tools; steward web UI is one client |

Selecting components means selecting a valid dependency closure. A compiler requires authoritative bindings; an executor requires validated, sealed, access-bound artifacts. It is not a supported composition to expose raw SQL execution while retaining the semantic correctness promise. Metadata-only use is useful but does not imply that SQL produced elsewhere is governed by this platform.

Remote service reuse is the default enterprise MCP topology: a small MCP server adapter calls the existing application facade/services under verified identity. A local stdio adapter may proxy those services without copying catalog authority or source secrets. Fully local embedding is another allowed topology for explicitly authorized metadata/data environments and must supply the same required policy, persistence and source controls. There is no requirement to copy the enterprise writable SQLite file to every developer workstation.

### 18.6 MCP tool contracts

The names below are **application tool names**, not MCP protocol methods. Publish a bounded set for the selected authorized composition profile; do not expose every source table as a separate tool. Generate schemas from canonical versioned contracts, while keeping tool descriptions concise enough for host context budgets. MCP defines tool input schemas and result structures; implement encoding appropriate to the chosen protocol/SDK versions. [MCP tools](https://modelcontextprotocol.io/specification/latest/server/tools)

| Tool | Application input | Result / service obligation |
|---|---|---|
| `get_semantic_capabilities` | Optional approved scope hint | Visible domains, API/IR versions, workload/operator capabilities and selected composition; no hidden inventory |
| `open_query_context` | Purpose, optional domain hints, supported contract version | Opaque principal-bound `context_id`, pinned manifest and server-owned expiry/budget |
| `retrieve_semantics` | Context, question/terms, optional semantic IDs | Authorized exact definitions, ranked candidates and required dependencies or coverage errors |
| `resolve_values` | Context, field/domain IDs, user wording and time scope | Opaque resolved handles or authorized ambiguity/staleness/binding errors |
| `prepare_semantic_query` | Context, typed proposal, idempotency key | Validated preview and sealed `artifact_id`, or typed clarification/coverage errors; always bind, plan, validate and compile internally |
| `execute_prepared_query` | Context, artifact ID, idempotency key | Durable `job_id` or access/expiry/workload error; never accepts raw SQL |
| `fetch_query_result` | Context, job ID and opaque pagination cursor | Typed rows/aggregates, unit/grain, executed scope, completeness, provenance and safe explanation fields |
| `start_managed_query` | Natural-language question, explicit authorized conversation facts, idempotency key | Durable managed `run_id` and status; pins its own context/manifest |
| `get_query_status` | Authorized run/job reference | Pending/running/completed/failed/cancelled or needs-clarification, with current status version |
| `continue_managed_query` | Run ID, clarification ID, expected run version, answer, idempotency key | Resume the same workflow after current policy/version checks |
| `cancel_query` | Authorized run/job reference and idempotency key | Recorded cancellation intent/status and bounded source cancellation attempt |

Managed-only profiles need not expose low-level retrieval/preparation tools; component-only profiles need not install or advertise managed-run tools. Tool listing is scoped and reveals only authorized capability descriptions; invocation performs authorization again. Separate steward mutation tools are disabled in the query profile and, if enabled, invoke the identical reviewed CatalogService use cases as the UI. Prompt text or tool annotations never grants publishing rights.

Pseudostructure for an application result (the MCP adapter wraps it in the protocol's appropriate tool result):

```json
{
  "api_version": "semantic.v1",
  "context_id": "opaque-context",
  "manifest_id": "opaque-manifest",
  "status": "prepared",
  "artifact_id": "opaque-artifact",
  "output_contract": {
    "shape": "table",
    "grain_ref": "validated-output-grain",
    "columns": []
  },
  "execution": {"requires_explicit_execute_call": true},
  "correlation_id": "opaque-correlation"
}
```

The empty columns and placeholder IDs illustrate envelope shape only. Real artifacts require a validated nonempty output schema as appropriate to their operator. The host may see a permitted SQL/plan preview, but editing that preview cannot change the artifact. The service verifies all handles against its trusted store; possession alone is not authorization. Model assertions such as `validated: true` are ignored or rejected by the input schema.

### 18.7 Context, manifest, handles and durable operation

`context_id` is an application request context, not an MCP transport session or host conversation ID. Store it in the query service's operational state/ledger, with principal/tenant, authorized calling application where available, manifest, composition mode, server-owned policy reference, budget counters, expiry and lifecycle. Store artifact/job/run records with corresponding ownership and version references. These are not semantic catalog records and do not enter published snapshots.

Do not require process-local memory or an open protocol connection to retain context. Requests may reach different instances or reconnect; load authorized operational state by opaque ID. `run_id`, `job_id` and `artifact_id` are distinct typed references even when an API accepts a tagged reference union. A host ID, conversation ID or MCP client-information string is an audit hint, not proof of principal identity.

Pin the same manifest throughout retrieval, value resolution, preparation and execution. Recheck current access, withdrawals, source compatibility and handle freshness at each relevant boundary. Reject cross-context/cross-principal handles; explicit server-side adoption may be a later separately authorized capability. Expired or incompatible contexts require a clear restart/migration outcome, not silently using the newest release.

Use backend-owned idempotency and quotas across all transports. Repeating an execute/continue call must not create accidental duplicate logical jobs. Bind idempotency to principal, operation, context and canonical input; reuse with changed input is an error. Per-context counters constrain repair/retrieval; per-principal/tenant quotas also constrain repeated new contexts, so opening another context does not reset all workload limits. Durable execution still needs reconciliation of unknown database outcomes.

For long operations, return application job/run handles and support polling through ordinary tools. Optional protocol task/progress/cancellation features can map onto that state when supported; they are not required for correctness. For clarification, return a bounded typed question/options and an opaque clarification ID, and resume through `continue_managed_query`. Optional host elicitation can improve presentation but is not the only way to clarify. Do not require host model sampling; managed mode uses a configured model adapter, and component mode uses the host's normal agent loop.

### 18.8 Authentication, egress and trust boundaries

Use a supported remote MCP transport, ordinarily Streamable HTTP, with the approved identity integration; local stdio is a separate deployment profile. Pin SDK/protocol versions and implement their required discovery/lifecycle/transport behavior inside the adapter. Hosts differ in supported revisions and optional capabilities, so fail clearly on incompatible contracts rather than assuming a particular handshake everywhere. [MCP transports](https://modelcontextprotocol.io/specification/latest/basic/transports)

Remote authenticated calls map to a verified enterprise principal and allowed calling application. Follow applicable MCP authorization requirements, including token audience/resource validation and safe credential handling; server-to-backend calls use approved service/delegation/token-exchange mechanisms. Never blindly forward a token issued for the MCP server to a different upstream API. A shared service credential must not erase the user's data-access restrictions. Local stdio process ownership alone is not an enterprise entitlement grant. [MCP authorization](https://modelcontextprotocol.io/specification/latest/basic/authorization), [MCP security practices](https://modelcontextprotocol.io/specification/latest/basic/security_best_practices)

External hosts and their model providers are additional data recipients. Govern which registered applications may receive metadata, value candidates, query results and traces. Construct egress scope from verified application identity/configuration and current policy, not a model-supplied host name. Existing source-query permission does not automatically authorize exporting that data into every external host. If a channel cannot establish the required recipient identity/control, restrict it to the data class explicitly approved for that channel or deny it.

Never put source credentials, writable catalog files or unrestricted connection configuration into MCP resources/tool responses. Apply current authorization to resources and prompts too. Treat retrieved descriptions, examples, source strings and host-supplied content as data, including when they contain instructions. Protected result previews, pagination cursors and exports retain the same access/retention constraints as the web UI.

The platform enforces guarantees for operations executed through its services. It cannot prevent an external host from using unrelated tools or credentials outside this boundary. Label returned plan/results with provenance so users and audits can distinguish governed service output from subsequent host-authored interpretations.

### 18.9 Versioning, portability and optional protocol features

Maintain separate versions for semantic object payloads, query IR, application APIs/tools, workflow state, catalog releases, compiler capabilities and MCP protocol/SDK adapters. Transport compatibility does not establish semantic API compatibility. A host must use an advertised supported proposal version, and unsupported shapes produce structured errors rather than coercion or a raw-SQL fallback.

`release_manifest.application_config_json` can reference compatible `semantic_api_version`, `tool_contract_version` and `execution_policy_schema` alongside existing compiler/workflow/model configuration. Actual endpoint topology, host registrations, tokens and active request/job/context state belong in deployment/operational stores, not the semantic catalog. The 35-table schema therefore remains at version 4; this enhancement does not require host-specific semantic tables.

Managed mode records the actual configured model/prompt/workflow versions. Host-controlled mode records mode, tool-contract version, authenticated client identity and any model/prompt details reliably available from the host; unknown details remain explicitly unknown. A service cannot honestly claim to pin an external host's hidden model/prompt. If an application's policy requires verified model identity, enable only an integration that supplies an acceptable verified identity or require managed mode.

Build correctness on ordinary discoverable tools and bounded request/results. Resources for metadata and prompts/skills for procedure are optional conveniences. Hosts may differ in resource visibility, prompt handling, structured output presentation, progress, elicitation and asynchronous protocol features. Provide application-tool alternatives for indispensable behavior. Use host-specific instructions only to improve use; all executable rules remain in shared services. Current protocol features must be verified against target implementations, not assumed from the specification alone.

### 18.10 Delivery and acceptance criteria

Treat modularity as a tested product requirement:

1. Import core/contracts without React, MCP, LangGraph, vector-provider SDKs or source-driver dependencies. Test minimal installation for each supported composition profile.
2. Run equivalent authorized retrieval/preparation/execution scenarios through direct application facade, HTTP and MCP adapters. Compare canonical plans, parameter types/values, semantic provenance and fixture results; ignore transport envelopes and nondeterministic IDs.
3. Remove LangGraph from a component-only deployment and still complete a host-controlled governed query. Remove React from an MCP deployment and retain all required functionality.
4. Invoke the same managed workflow through web/API and MCP, including clarification, checkpoint resume, cancellation and final result retrieval. Verify shared workflow version and policy gates.
5. Replace a vector, graph, storage, source or workflow adapter through configuration/composition without changing business definitions or duplicating semantic rules. Only the adapter's supported capability differences may change advertised coverage.
6. Attempt forged/expired/cross-principal handles, unapproved tool discovery, raw SQL input, skipped preparation, unauthorized source/egress and stale policy after resume. All entry points enforce the same boundaries.
7. Test reconnects, request routing across replicas, duplicate execute/continue calls, changed-input idempotency reuse, long jobs, incomplete results and source-unknown outcomes.
8. Maintain a compatibility matrix for target host name/version, protocol/SDK revision, transport, auth, advertised tools, supported schemas, result handling, clarification, polling and optional features. Unsupported combinations fail explicitly.
9. Evaluate host-controlled intent quality separately from managed mode. Do not report adapter parity tests as proof that different host LLMs interpret questions identically.

In Phase 0 define ports, dependency rules, tool schemas, trust/egress policy and the compatibility test harness. In Phase 1A deliver minimal reusable packages plus catalog/planning MCP profiles and adapter tests. In Phase 1B deliver execution and managed-flow MCP profiles alongside the web application, with at least one explicitly tested target host and a published status for the others. Expand supported hosts/modes in subsequent releases; no particular host is advertised as supported before its tests pass.

This is a design specification. No MCP server or external-host integration is implemented or tested by editing these artifacts; implementation evidence belongs to the phase gates.
