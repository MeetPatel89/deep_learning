"""JSON conversion, redaction and bounded, resumable tool results."""

import base64
import hashlib
import json
import math
import re
from datetime import date, datetime, time, timedelta
from decimal import Decimal
from pathlib import Path
from typing import Any

from pydantic import BaseModel, SecretStr

MAX_ROWS = 1000
MAX_CHARS = 50_000
_secrets: set[str] = set()
_sensitive = re.compile(
    r"password|secret|accountkey|accesskey|apikey|connectionstring|sastoken|accesstoken|"
    r"refreshtoken|authorization|^token$",
    re.I,
)


def register_secret(value: str) -> None:
    if value:
        _secrets.add(value)


def json_safe(value: Any) -> Any:
    if isinstance(value, SecretStr):
        return "[REDACTED]"
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [json_safe(item) for item in value]
    if isinstance(value, (date, datetime, time)):
        return value.isoformat()
    if isinstance(value, (Decimal, timedelta, Path)):
        return str(value)
    if isinstance(value, bytes):
        return value.hex()
    if isinstance(value, float) and not math.isfinite(value):
        return str(value)
    if isinstance(value, BaseModel):
        return json_safe(value.model_dump())
    if callable(getattr(type(value), "serialize", None)):
        return json_safe(value.serialize(keep_readonly=True))
    if callable(getattr(type(value), "as_dict", None)):
        return json_safe(value.as_dict())
    return value


def redact(value: Any) -> Any:
    value = json_safe(value)
    if isinstance(value, dict):
        secure = str(value.get("type", "")).lower() in {"securestring", "secureobject"}
        return {
            key: "[REDACTED]"
            if _sensitive.search(key.replace("_", "").replace("-", ""))
            or (secure and key in {"value", "defaultValue", "default_value"})
            else redact(item)
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [redact(item) for item in value]
    if isinstance(value, str):
        for secret in sorted(_secrets, key=len, reverse=True):
            value = value.replace(secret, "[REDACTED]")
        value = re.sub(r"(?i)([?&](?:sig|token|key)=)[^&\s]+", r"\1[REDACTED]", value)
        value = re.sub(
            r"(?i)((?:AccountKey|SharedAccessSignature|Password|PWD|ClientSecret)\s*=)[^;\s]+",
            r"\1[REDACTED]",
            value,
        )
        return re.sub(r"(?i)Bearer\s+[A-Za-z0-9._~+/=-]+", "Bearer [REDACTED]", value)
    return value


def truncate_text(value: str, max_chars: int = MAX_CHARS) -> dict[str, Any]:
    if not 1 <= max_chars <= MAX_CHARS:
        raise ValueError(f"max_chars must be between 1 and {MAX_CHARS}")
    return {"text": value[:max_chars], "truncated": len(value) > max_chars}


def _context_id(context: str) -> str:
    return hashlib.sha256(context.encode()).hexdigest()[:16]


def continuation(offset: int, context: str) -> str:
    return base64.urlsafe_b64encode(
        json.dumps({"offset": offset, "context": _context_id(context)}).encode()
    ).decode()


def read_continuation(token: str | None, context: str) -> int:
    if token is None:
        return 0
    try:
        if len(token) > 1024:
            raise ValueError
        data = json.loads(base64.b64decode(token, altchars=b"-_", validate=True))
        offset = data["offset"]
        if data["context"] != _context_id(context) or type(offset) is not int or offset < 0:
            raise ValueError
        return offset
    except (ValueError, KeyError, TypeError) as error:
        raise ValueError("Invalid continuation token for this request") from error


def paginate(
    items: list[Any],
    limit: int = 100,
    token: str | None = None,
    context: str = "",
    max_chars: int = MAX_CHARS,
) -> dict[str, Any]:
    if not 1 <= limit <= MAX_ROWS or not 1 <= max_chars <= MAX_CHARS:
        raise ValueError("Result limits exceed the permitted row or character cap")
    offset = read_continuation(token, context)
    page = []
    size = 0
    budget = max(1, max_chars - 2048)
    for item in items[offset : offset + limit]:
        item = redact(item)
        length = len(json.dumps(item, ensure_ascii=False))
        if size + length > budget:
            if not page:
                page.append(bounded_result(item, budget))
            break
        page.append(item)
        size += length
    next_offset = offset + len(page)
    return {
        "items": page,
        "total": len(items),
        "continuation": continuation(next_offset, context) if next_offset < len(items) else None,
    }


def cap_rows(rows: list[dict], limit: int = 100, total: int | None = None) -> dict[str, Any]:
    page = paginate(rows, limit, context="rows")
    return {
        "rows": page["items"],
        "returned_rows": len(page["items"]),
        "row_count": len(rows) if total is None else total,
        "row_count_is_exact": total is not None or page["continuation"] is None,
        "truncated": page["continuation"] is not None or (total or 0) > len(page["items"]),
    }


def bounded_result(value: Any, max_chars: int = MAX_CHARS) -> Any:
    value = redact(value)
    encoded = json.dumps(value, ensure_ascii=False)
    if len(encoded) <= max_chars:
        return value
    # A preview is itself a JSON string; reserve space for its escaping and envelope.
    return {"truncated": True, "preview": encoded[: max(0, (max_chars - 64) // 2)]}
