import asyncio
import copy
import hashlib
import json
from types import SimpleNamespace
from unittest.mock import Mock

import httpx
import pytest
from azure.core.exceptions import HttpResponseError, ResourceNotFoundError
from synapse_mcp_server.branch_package import build_package
from synapse_mcp_server.server import SynapseService
from synapse_mcp_server.studio_http import StudioHTTPAdapter, UnsupportedStudioContract

from .conftest import git, write_artifact


class Poller:
    def __init__(self, result=None):
        self.value = result

    def result(self, timeout=None):
        return self.value

    def done(self):
        return True

    def continuation_token(self):
        return "synthetic-lro"


class FakeSDK:
    def __init__(self):
        self.definitions = {
            ("pipeline", "existing"): {"name": "existing", "properties": {"activities": []}}
        }
        self.events = []
        self.runs = {}
        self.activities = {}
        self.fail_kind = None
        self.fail_submit = False
        for kind in ("pipeline", "dataset", "linked_service", "notebook", "data_flow"):
            setattr(self, kind, self.operations(kind))
        self.pipeline.create_pipeline_run = self.submit
        self.pipeline_run = SimpleNamespace(
            get_pipeline_run=lambda identifier: copy.deepcopy(self.runs[identifier]),
            query_activity_runs=lambda name, identifier, parameters: {
                "value": copy.deepcopy(self.activities[identifier])
            },
            cancel_pipeline_run=self.cancel,
        )

    def operations(self, kind):
        def get(name):
            self.events.append(("get", kind, name))
            if (kind, name) not in self.definitions:
                raise ResourceNotFoundError("missing")
            return copy.deepcopy(self.definitions[kind, name])

        def create(name, body, **kwargs):
            self.events.append(("create", kind, name))
            if self.fail_kind == kind:
                error = HttpResponseError("Rejected")
                error.status_code = 400
                raise error
            assert kwargs["headers"]["If-None-Match"] == "*"
            assert (kind, name) not in self.definitions
            definition = (
                json.load(body)
                if hasattr(body, "read")
                else {"name": name, "properties": body.serialize()}
            )
            definition["etag"] = '"etag"'
            self.definitions[kind, name] = definition
            return Poller(definition)

        def delete(name, **kwargs):
            self.events.append(("delete", kind, name))
            assert kwargs["headers"]["If-Match"] == '"etag"'
            del self.definitions[kind, name]
            return Poller()

        return SimpleNamespace(
            **{
                "get_" + kind: get,
                "begin_create_or_update_" + kind: create,
                "begin_delete_" + kind: delete,
            }
        )

    def submit(self, name, **kwargs):
        self.events.append(("submit", "pipeline", name))
        if self.fail_submit:
            raise TimeoutError("submission timeout")

        def create_run(pipeline):
            identifier = "run" + str(len(self.runs) + 1)
            self.runs[identifier] = {
                "runId": identifier,
                "pipelineName": pipeline,
                "status": "Succeeded",
            }
            self.activities[identifier] = []
            for activity in self.definitions["pipeline", pipeline]["properties"]["activities"]:
                output = {}
                if activity["type"] == "ExecutePipeline":
                    child = activity["typeProperties"]["pipeline"]["referenceName"]
                    output["pipelineRunId"] = create_run(child)
                self.activities[identifier].append(
                    {
                        "activityName": activity["name"],
                        "activityType": activity["type"],
                        "activityRunId": identifier + ":" + activity["name"],
                        "status": "Succeeded",
                        "output": output,
                    }
                )
            return identifier

        return {"runId": create_run(name)}

    def cancel(self, run_id, is_recursive):
        self.events.append(("cancel", "pipeline", run_id))
        self.runs[run_id]["status"] = "Cancelled"


@pytest.fixture
def staging(repo_service):
    service, root, settings, clients = repo_service
    settings.branch_execution_backend = "sdk_staging"
    settings.allow_live_env = settings.allow_manage = True
    sdk = FakeSDK()
    clients.get.return_value = sdk
    return service, root, settings, clients, sdk


def add_child(root):
    write_artifact(
        root,
        "pipeline",
        "Child",
        {
            "activities": [
                {"name": "Wait", "type": "Wait", "typeProperties": {"waitTimeInSeconds": 1}}
            ]
        },
    )
    write_artifact(
        root,
        "pipeline",
        "P",
        {
            "activities": [
                {
                    "name": "Child",
                    "type": "ExecutePipeline",
                    "typeProperties": {
                        "pipeline": {"type": "PipelineReference", "referenceName": "Child"},
                        "waitOnCompletion": True,
                    },
                }
            ]
        },
    )


def test_staging_dry_run_no_azure_and_exact_provenance(staging):
    service, root, _, clients, _ = staging
    result = service.run_branch_pipeline("dev", "P", "feature")
    assert result["dry_run"] and result["backend"] == "sdk_staging"
    assert result["provenance"]["commit"] == git(root, "rev-parse", "HEAD")
    assert result["provenance"]["test_profile"] == "dev"
    assert len(result["provenance"]["execution_fingerprint"]) == 64
    assert not service.execution_store.list()
    clients.get.assert_not_called()


@pytest.mark.parametrize("flag", ["allow_run", "allow_live_env", "allow_manage"])
def test_staging_permissions_before_any_client(staging, flag):
    service, _, settings, clients, _ = staging
    setattr(settings, flag, False)
    with pytest.raises(PermissionError, match=flag):
        service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    clients.get.assert_not_called()


def test_staging_child_completion_and_reverse_cleanup(staging):
    service, root, _, _, sdk = staging
    add_child(root)
    heads = {b: git(root, "rev-parse", b) for b in ("main", "release", "workspace_publish")}
    result = service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    identifier = result["execution_id"]
    assert result["native_run_id"] == "run1"
    created = [e[2] for e in sdk.events if e[0] == "create"]
    assert len(created) == 2 and all(n.startswith("mcp_" + identifier) for n in created)
    sdk.runs["run2"]["status"] = "InProgress"
    assert service.get_branch_pipeline_run("dev", identifier)["cleanup"] == "pending"
    assert not any(e[0] == "delete" for e in sdk.events)
    sdk.runs["run2"]["status"] = "Succeeded"
    completed = service.get_branch_pipeline_run("dev", identifier)
    assert completed["state"] == "finished" and completed["cleanup"] == "complete"
    assert [e[2] for e in sdk.events if e[0] == "delete"] == list(reversed(created))
    assert set(sdk.definitions) == {("pipeline", "existing")}
    assert heads == {b: git(root, "rev-parse", b) for b in heads}
    assert len(service.get_branch_activity_results("dev", identifier)["items"]) == 2


def test_staging_ownership_limits_cleanup_and_restart_can_retry(staging):
    service, _, settings, clients, sdk = staging
    result = service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    identifier = result["execution_id"]
    name = result["staged_artifacts"][0]["name"]
    owner = sdk.definitions["pipeline", name]["properties"]["annotations"]
    sdk.definitions["pipeline", name]["properties"]["annotations"] = ["someone else"]
    completed = service.get_branch_pipeline_run("dev", identifier)
    assert (
        completed["cleanup"] == "pending" and "ownership" in completed["cleanup_errors"][0]["error"]
    )
    assert ("pipeline", name) in sdk.definitions
    sdk.definitions["pipeline", name]["properties"]["annotations"] = owner
    restarted = SynapseService(service.config, clients)
    settings.allow_manage = False
    before = len(sdk.events)
    with pytest.raises(PermissionError):
        restarted.get_branch_pipeline_run("dev", identifier)
    assert len(sdk.events) == before
    settings.allow_manage = True
    assert restarted.get_branch_pipeline_run("dev", identifier)["cleanup"] == "complete"
    restarted.close()


def test_staging_partial_failure_preserves_existing_and_cleans_created_artifacts(staging):
    service, root, settings, _, sdk = staging
    write_artifact(
        root,
        "dataset",
        "D",
        {
            "type": "Json",
            "linkedServiceName": {"type": "LinkedServiceReference", "referenceName": "L"},
        },
    )
    write_artifact(root, "linked_service", "L", {"type": "AzureBlobStorage", "typeProperties": {}})
    write_artifact(
        root,
        "pipeline",
        "P",
        {
            "activities": [
                {
                    "name": "Copy",
                    "type": "Copy",
                    "inputs": [{"type": "DatasetReference", "referenceName": "D"}],
                }
            ]
        },
    )
    settings.test_profiles["dev"].integration_runtimes = ["AutoResolveIntegrationRuntime"]
    sdk.fail_kind = "pipeline"
    result = service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    assert result["state"] == "deployment_failed" and result["cleanup"] == "complete"
    assert set(sdk.definitions) == {("pipeline", "existing")}
    assert not any(e[0] == "submit" for e in sdk.events)


def test_submission_timeout_never_replays_or_deletes_staging(staging):
    service, _, _, _, sdk = staging
    sdk.fail_submit = True
    result = service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    assert result["state"] == "submission_unknown"
    with pytest.raises(ValueError, match="uncertain"):
        service.cleanup_branch_pipeline_run("dev", result["execution_id"], dry_run=False)
    service.get_branch_pipeline_run("dev", result["execution_id"])
    assert len([e for e in sdk.events if e[0] == "submit"]) == 1
    assert not any(e[0] == "delete" for e in sdk.events)


def test_concurrent_executions_have_distinct_names_and_ownership(staging):
    service, _, _, _, sdk = staging
    first = service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    second = service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    assert first["staged_artifacts"][0]["name"] != second["staged_artifacts"][0]["name"]
    service.get_branch_pipeline_run("dev", first["execution_id"])
    assert ("pipeline", second["staged_artifacts"][0]["name"]) in sdk.definitions


def test_staging_cancel_and_wait(staging):
    service, _, _, _, sdk = staging
    result = service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    service.cancel_branch_pipeline_run("dev", result["execution_id"], dry_run=False)
    completed = asyncio.run(service.wait_for_branch_pipeline_run("dev", result["execution_id"]))
    assert not completed["timed_out"] and completed["execution"]["status"] == "Cancelled"


def test_pr_provenance_invalidates_changed_artifacts_and_profiles(staging):
    service, root, settings, _, _ = staging
    result = service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    service.get_branch_pipeline_run("dev", result["execution_id"])
    prepared = service.prepare_git_pr("dev", "feature", "Improve P")
    assert prepared["has_matching_successful_test"]
    settings.test_profiles["dev"].spark_pools.append("different")
    assert not service.prepare_git_pr("dev", "feature", "Improve P")["has_matching_successful_test"]
    settings.test_profiles["dev"].spark_pools.clear()
    write_artifact(root, "pipeline", "P", {"activities": [], "description": "edited after test"})
    changed = service.prepare_git_pr("dev", "feature", "Improve P")
    assert (
        not changed["has_matching_successful_test"]
        and "does not establish a pass" in changed["body"]
    )


def synthetic_contract(settings, tmp_path):
    # Synthetic protocol for transport tests ONLY. These are not captured Synapse fixtures.
    operations = {
        "submit": {
            "method": "POST",
            "path": "/debug/submit",
            "body": "$package",
            "run_id_field": "runId",
        },
        "status": {"method": "GET", "path": "/debug/runs/{run_id}", "status_field": "status"},
        "activities": {
            "method": "POST",
            "path": "/debug/runs/{run_id}/activities",
            "body": {"continuation": "$continuation"},
            "items_field": "value",
            "continuation_field": "continuationToken",
        },
        "cancel": {
            "method": "POST",
            "path": "/debug/runs/{run_id}/cancel",
            "body": {"recursive": "$recursive"},
        },
    }
    for spec in operations.values():
        spec["fixture"] = {
            "request": {},
            "response": {
                "runId": "root",
                "status": "Succeeded",
                "value": [],
                "continuationToken": None,
            },
        }
        spec["query"] = {"api-version": "synthetic-test"}
    value = {
        "version": StudioHTTPAdapter.VERSION,
        "validation": {
            "workspace": settings.name,
            "authenticated_at": "2026-01-01T00:00:00Z",
            "synthetic_test_only": True,
        },
        "supported_artifacts": ["pipeline", "dataset", "linked_service", "notebook", "data_flow"],
        "operations": operations,
    }
    path = tmp_path / "synthetic-contract.json"
    path.write_text(json.dumps(value))
    settings.studio_http.contract_path = str(path)
    settings.studio_http.contract_sha256 = hashlib.sha256(path.read_bytes()).hexdigest()
    return value, path


@pytest.fixture
def studio(repo_service, tmp_path, monkeypatch):
    service, root, settings, clients = repo_service
    contract, path = synthetic_contract(settings, tmp_path)
    calls = []
    states = {"root": "Succeeded", "child": "Failed"}

    def handler(request):
        calls.append(request)
        route = request.url.path
        if route == "/debug/submit":
            package = json.loads(request.content)
            assert package["pipeline"] == "P" and "pipeline/P" in package["artifacts"]
            return httpx.Response(202, json={"runId": "root"})
        if route.endswith("/activities"):
            token = json.loads(request.content)["continuation"]
            values = (
                [
                    {
                        "activityType": "ExecutePipeline",
                        "activityName": "Child",
                        "status": "Failed",
                        "output": {"pipelineRunId": "child"},
                    }
                ]
                if "/root/" in route
                else [
                    {
                        "activityType": "Copy",
                        "activityName": "Copy",
                        "status": "Failed",
                        "error": {"message": "PathNotFound"},
                    }
                ]
            )
            return httpx.Response(
                200,
                json={
                    "value": values if token is None else [],
                    "continuationToken": "page2" if token is None else None,
                },
            )
        if route.endswith("/cancel"):
            assert json.loads(request.content)["recursive"]
            states[route.split("/")[-2]] = "Cancelled"
            return httpx.Response(204)
        return httpx.Response(200, json={"status": states[route.rsplit("/", 1)[-1]]})

    token = Mock(return_value=SimpleNamespace(token="fake-token"))
    monkeypatch.setattr("synapse_mcp_server.studio_http.get_token", token)

    def adapter(workspace, backend):
        assert backend == "studio_http"
        return StudioHTTPAdapter(
            service.config,
            workspace,
            httpx.Client(base_url=settings.endpoint, transport=httpx.MockTransport(handler)),
        )

    monkeypatch.setattr(service, "_branch_adapter", adapter)
    return service, root, settings, clients, calls, states, token, path


def test_http_debug_submission_children_activities_diagnosis_cancel_without_live(studio):
    service, root, settings, clients, calls, _, _, _ = studio
    add_child(root)
    assert not settings.allow_live_env
    result = service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    assert result["native_run_id"] == "root"
    diagnosis = service.diagnose_branch_pipeline_run("dev", result["execution_id"])
    assert diagnosis["status"] == "Failed"
    assert diagnosis["failed_leaf_activities"][0]["run_id"] == "child"
    assert diagnosis["failed_leaf_activities"][0]["causes"][0]["cause"] == "missing_path"
    service.cancel_branch_pipeline_run("dev", result["execution_id"], dry_run=False)
    assert all(r.url.path.startswith("/debug/") for r in calls)
    assert len([r for r in calls if r.url.path.endswith("/cancel")]) == 2
    clients.get.assert_not_called()
    clients.http_get.assert_not_called()


def test_http_permission_and_contract_changes_before_auth(studio):
    service, _, settings, _, calls, _, token, path = studio
    result = service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    before = len(calls)
    settings.allow_run = False
    with pytest.raises(PermissionError, match="allow_run"):
        service.get_branch_pipeline_run("dev", result["execution_id"])
    assert len(calls) == before
    settings.allow_run = True
    path.write_text(path.read_text() + " ")
    with pytest.raises(UnsupportedStudioContract, match="digest"):
        service.get_branch_pipeline_run("dev", result["execution_id"])
    assert token.call_count == 1


def test_missing_http_contract_and_profile_never_fall_back(repo_service):
    service, _, settings, clients = repo_service
    settings.allow_live_env = settings.allow_manage = True
    with pytest.raises(UnsupportedStudioContract, match="not integration-validated"):
        service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    settings.default_test_profile = None
    with pytest.raises(ValueError, match="test_profile"):
        service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    clients.get.assert_not_called()


@pytest.mark.parametrize("status", [401, 403, 404, 405, 500])
def test_http_authentication_contract_and_server_errors_never_fall_back(
    repo_service, tmp_path, monkeypatch, status
):
    service, _, settings, clients = repo_service
    synthetic_contract(settings, tmp_path)
    monkeypatch.setattr(
        "synapse_mcp_server.studio_http.get_token", lambda *args: SimpleNamespace(token="fake")
    )
    client = httpx.Client(
        base_url=settings.endpoint, transport=httpx.MockTransport(lambda r: httpx.Response(status))
    )
    adapter = StudioHTTPAdapter(service.config, "dev", client)
    package = build_package(
        service.repository("dev").snapshot("feature"), "P", "dev", settings.test_profiles["dev"]
    )
    checksum = adapter.validate(package)
    with pytest.raises((httpx.HTTPStatusError, UnsupportedStudioContract)):
        adapter.submit(package, checksum)
    clients.get.assert_not_called()
    adapter.close()


def test_http_rejects_published_endpoint_even_in_pinned_contract(
    repo_service, tmp_path, monkeypatch
):
    (
        service,
        _,
        settings,
        _,
    ) = repo_service
    value, path = synthetic_contract(settings, tmp_path)
    value["operations"]["submit"]["path"] = "/pipelines/{pipeline}/createRun"
    path.write_text(json.dumps(value))
    settings.studio_http.contract_sha256 = hashlib.sha256(path.read_bytes()).hexdigest()
    token = Mock()
    monkeypatch.setattr("synapse_mcp_server.studio_http.get_token", token)
    with pytest.raises(UnsupportedStudioContract, match="debug endpoints"):
        service.run_branch_pipeline("dev", "P", "feature")
    token.assert_not_called()


def test_sdk_collision_is_checked_before_any_deployment(staging, monkeypatch):
    service, _, _, _, sdk = staging
    original = sdk.pipeline.get_pipeline

    def collide(name):
        if name.startswith("mcp_"):
            return {"name": name, "properties": {"activities": []}}
        return original(name)

    monkeypatch.setattr(sdk.pipeline, "get_pipeline", collide)
    result = service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    assert result["state"] == "deployment_failed" and "collision" in result["error"]
    assert not any(event[0] in {"create", "delete", "submit"} for event in sdk.events)


def test_restart_resumes_pending_lro_without_resubmitting(staging, monkeypatch):
    service, _, _, clients, sdk = staging
    result = service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    record = service.execution_store.get("dev", result["execution_id"])
    record["native_run_id"] = None
    record["state"] = "deploying"
    record["staged"][0]["state"] = "creating"
    record["staged"][0]["continuation"] = "saved-create-lro"
    service.execution_store.save(record)
    calls = []

    def resume(name, body, **kwargs):
        calls.append(kwargs)
        assert kwargs == {"continuation_token": "saved-create-lro"}
        return Poller(sdk.definitions["pipeline", name])

    monkeypatch.setattr(sdk.pipeline, "begin_create_or_update_pipeline", resume)
    restarted = SynapseService(service.config, clients)
    recovered = restarted.get_branch_pipeline_run("dev", record["execution_id"])
    assert recovered["state"] == "deployment_failed" and recovered["cleanup"] == "complete"
    assert len(calls) == 1
    assert len([e for e in sdk.events if e[0] == "submit"]) == 1
    restarted.close()


def test_journal_id_collision_cannot_replace_existing_ownership(staging, monkeypatch):
    import sqlite3

    service, _, _, _, sdk = staging
    first = service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    monkeypatch.setattr(
        "synapse_mcp_server.branch_execution.uuid.uuid4",
        lambda: SimpleNamespace(hex=first["execution_id"]),
    )
    with pytest.raises(sqlite3.IntegrityError):
        service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    assert service.execution_store.get("dev", first["execution_id"])["native_run_id"] == "run1"
    assert len([e for e in sdk.events if e[0] == "create"]) == 1


def test_profile_override_is_frozen_and_secure_parameters_redacted(staging):
    service, root, settings, _, sdk = staging
    secret = "a-private-run-input"
    write_artifact(
        root,
        "pipeline",
        "P",
        {
            "activities": [],
            "parameters": {"credential": {"type": "secureString", "defaultValue": secret}},
        },
    )
    settings.test_profiles["dev"].artifact_overrides = {"pipeline/P": {"description": "test-only"}}
    result = service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    assert secret not in json.dumps(result)
    assert (
        service.get_artifact("dev", "pipeline", "P")["properties"]["parameters"]["credential"][
            "defaultValue"
        ]
        == "[REDACTED]"
    )
    staged = sdk.definitions["pipeline", result["staged_artifacts"][0]["name"]]
    assert staged["properties"]["description"] == "test-only"
    assert "description" not in json.loads((root / "pipeline/P.json").read_text())["properties"]


def test_http_rejects_response_contract_change_and_foreign_run(studio, monkeypatch):
    service, _, _, clients, _, _, _, _ = studio
    result = service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    with pytest.raises(ValueError, match="does not belong"):
        service.get_branch_activity_results("dev", result["execution_id"], run_id="published-run")
    adapter = service._branch_adapter("dev", "studio_http")
    record = service.execution_store.get("dev", result["execution_id"])
    monkeypatch.setattr(adapter, "_request", lambda *args: {"renamed-status": "Succeeded"})
    # Pin the validated field mapping; a changed response cannot report a false pass.
    adapter.validate()
    with pytest.raises(UnsupportedStudioContract, match="missing"):
        adapter.status(record, "root")
    adapter.close()
    clients.get.assert_not_called()


def test_child_pipeline_without_results_prevents_cleanup(staging):
    service, root, _, _, sdk = staging
    add_child(root)
    result = service.run_branch_pipeline("dev", "P", "feature", dry_run=False)
    sdk.activities["run1"][0]["output"] = {}
    status = service.get_branch_pipeline_run("dev", result["execution_id"])
    assert not status["tree_complete"] and status["cleanup"] == "pending"
    assert not any(event[0] == "delete" for event in sdk.events)
