"""Connect vectorstore-ai's existing retrieval observer to telemetry."""

from typing import TYPE_CHECKING, cast

from ..attributes import TraceAttributes
from ..telemetry import Telemetry

if TYPE_CHECKING:
    from vectorstore.observability import OTelRetrievalObserver


def retrieval_observer(
    telemetry: Telemetry,
    *,
    trace: TraceAttributes | None = None,
) -> OTelRetrievalObserver:
    """Build the native observer with Langfuse attributes on its retrieval root.

    Install ``observe-eval-ai[vectorstore]`` to use this factory. The observer
    retains the library's phase spans and never captures query or document text.
    Trace dimensions and the retriever type apply to ``retrieve``; the upstream
    observer does not copy custom attributes onto its phase children.
    """
    try:
        from vectorstore.observability import OTelRetrievalObserver
    except ModuleNotFoundError as exc:
        if exc.name is None or exc.name.split(".")[0] != "vectorstore":
            raise
        raise ImportError(
            "vectorstore support is not installed; install observe-eval-ai[vectorstore]"
        ) from exc

    attributes = trace.as_otel_attributes() if trace is not None else {}
    attributes["langfuse.observation.type"] = "retriever"
    return OTelRetrievalObserver(
        telemetry.tracer("observability_ai.adapters.vectorstore"),
        # TraceAttributes emits only strings and tag tuples, which also satisfy
        # vectorstore's narrower attribute type alias.
        attributes=cast("dict[str, str | tuple[str, ...]]", attributes),
    )


__all__ = ["retrieval_observer"]
