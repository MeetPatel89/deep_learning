"""Streaming comparison artifacts."""
