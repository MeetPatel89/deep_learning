"""Opt-in serialization of observation inputs and outputs."""

from collections.abc import Callable
from dataclasses import dataclass, field
from json import dumps
from logging import getLogger
from os import getenv

from opentelemetry.util.types import AttributeValue

_logger = getLogger(__name__)


def _capture_from_env() -> bool:
    return (
        getenv("OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT", "").casefold()
        == "true"
    )


@dataclass(frozen=True, slots=True)
class ContentCapturePolicy:
    """Snapshot the GenAI capture flag, or override it with an explicit bool.

    Only case-insensitive ``true`` enables the environment default. This policy
    controls explicitly supplied payloads, not arbitrary span attributes, SDK
    calls, or exception details recorded by OpenTelemetry. An optional redactor
    transforms each supplied value before serialization. A positive character
    limit retains that many JSON characters and appends ``...[truncated]``;
    the marker is additional and truncated output need not be valid JSON.
    """

    enabled: bool = field(default_factory=_capture_from_env)
    redactor: Callable[[object], object] | None = None
    max_characters: int | None = None

    def __post_init__(self) -> None:
        """Validate the capture flag, redactor, and optional positive limit."""
        if not isinstance(self.enabled, bool):
            raise TypeError("enabled must be a bool")
        if self.redactor is not None and not callable(self.redactor):
            raise TypeError("redactor must be callable or None")
        if self.max_characters is not None:
            if not isinstance(self.max_characters, int) or isinstance(
                self.max_characters, bool
            ):
                raise TypeError("max_characters must be an integer or None")
            if self.max_characters < 1:
                raise ValueError("max_characters must be positive")

    def as_otel_attributes(
        self, *, input: object = None, output: object = None
    ) -> dict[str, AttributeValue]:
        """Serialize supplied payloads as JSON strings when capture is enabled.

        ``None`` means omitted. Each value is serialized independently; failures
        skip that value and log a warning without its contents. Disabled capture
        does not inspect payloads. No fallback to object ``str`` or ``repr`` is
        used for unsupported values.
        """
        attributes: dict[str, AttributeValue] = {}
        if not self.enabled:
            return attributes
        for name, value in (("input", input), ("output", output)):
            if value is None:
                continue
            try:
                if self.redactor is not None:
                    value = self.redactor(value)
                serialized = dumps(value, ensure_ascii=False, allow_nan=False)
                if (
                    self.max_characters is not None
                    and len(serialized) > self.max_characters
                ):
                    serialized = serialized[: self.max_characters] + "...[truncated]"
                attributes[f"langfuse.observation.{name}"] = serialized
            except Exception:
                # Exception messages from custom containers can contain payloads.
                _logger.warning("Could not serialize observation %s; omitted", name)
        return attributes


__all__ = ["ContentCapturePolicy"]
