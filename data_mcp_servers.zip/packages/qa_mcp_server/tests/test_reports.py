import json
from pathlib import Path

import openpyxl
import polars as pl
from qa_mcp_server.models import OutputOptions

from .conftest import read_dump


def test_excel_splits_and_colors(run_compare, tmp_path):
    expected = [{"id": i, "v": "same", "bad": "expected"} for i in range(7)]
    actual = [{"id": i, "v": "same", "bad": "actual"} for i in range(7)]
    result = run_compare(
        expected,
        actual,
        primary_keys=["id"],
        output=OutputOptions(output_dir=tmp_path, max_rows_per_file=2),
    )
    assert len(result["report_files"]) == 4
    data_rows = 0
    for index, path in enumerate(result["report_files"]):
        workbook = openpyxl.load_workbook(path)
        assert ("Summary" in workbook.sheetnames) == (index == 0)
        sheet = workbook["Mismatches"]
        assert [cell.value for cell in sheet[1]] == [
            "id_expected",
            "id_actual",
            "v_expected",
            "v_actual",
            "bad_expected",
            "bad_actual",
            "occurrences",
        ]
        assert sheet["C2"].font.color.rgb == "FF008000"
        assert sheet["D2"].font.color.rgb == "FF008000"
        assert sheet["E2"].font.color.rgb == "FFFF0000"
        assert sheet["F2"].font.bold
        assert sheet.max_row - 1 <= 2
        data_rows += sheet.max_row - 1
        workbook.close()
    assert data_rows == 7
    workbook = openpyxl.load_workbook(result["report_files"][0])
    summary = dict(workbook["Summary"].iter_rows(min_row=2, values_only=True))
    assert json.loads(summary["report_files"]) == result["report_files"]
    workbook.close()


def test_cap_never_truncates_parquet(run_compare, tmp_path):
    result = run_compare(
        [{"id": i, "v": i} for i in range(9)],
        [{"id": i, "v": -1} for i in range(9)],
        primary_keys=["id"],
        output=OutputOptions(output_dir=tmp_path, max_rows_per_file=2, max_total_report_rows=3),
    )
    assert result["report_rows_written"] == 3
    assert result["report_rows_omitted"] == 6
    assert result["report_truncated"]
    assert len(result["report_files"]) == 2
    assert read_dump(result).height == 9


def test_zero_cap_and_identical_data_still_produce_artifacts(run_compare, tmp_path):
    result = run_compare(
        [{"id": 1}], [{"id": 2}], output=OutputOptions(output_dir=tmp_path, max_total_report_rows=0)
    )
    assert result["report_rows_written"] == 0
    assert result["report_rows_omitted"] == 2
    assert read_dump(result).height == 2
    identical = run_compare([{"id": 1}], [{"id": 1}])
    assert read_dump(identical).is_empty()
    assert Path(identical["summary_file"]).is_file()


def test_split_cap_is_across_all_data_sheets(run_compare, tmp_path):
    result = run_compare(
        [{"id": 1, "v": "a"}, {"id": 1, "v": "b"}, {"id": 2, "v": "c"}],
        [{"id": 1, "v": "a"}, {"id": 1, "v": "x"}, {"id": 3, "v": "d"}],
        primary_keys=["id"],
        output=OutputOptions(output_dir=tmp_path, max_rows_per_file=2, include_matched_rows=True),
    )
    total = 0
    for path in result["report_files"]:
        workbook = openpyxl.load_workbook(path)
        count = sum(workbook[name].max_row - 1 for name in workbook.sheetnames if name != "Summary")
        assert count <= 2
        total += count
        workbook.close()
    assert total == 8  # Four duplicate entries plus four comparison entries.


def test_formula_like_values_are_written_as_text(run_compare):
    result = run_compare(
        [{"id": 1, "v": "=1+1"}], [{"id": 1, "v": "https://example.org"}], primary_keys=["id"]
    )
    workbook = openpyxl.load_workbook(result["report_files"][0])
    assert workbook["Mismatches"]["C2"].data_type == "s"
    assert workbook["Mismatches"]["D2"].hyperlink is None
    workbook.close()


def test_parquet_preserves_large_integers_and_decimals(run_compare):
    result = run_compare([{"id": 1, "v": 2**60}], [{"id": 1, "v": 2**60 + 1}], primary_keys=["id"])
    dump = read_dump(result)
    assert dump["expected.v"][0] == 2**60
    assert dump["actual.v"][0] == 2**60 + 1
    assert dump.schema["expected.v"] == pl.Int64
