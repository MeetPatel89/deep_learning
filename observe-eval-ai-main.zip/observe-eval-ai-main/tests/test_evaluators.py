"""Check deterministic evaluators against boundary cases and incorrect inputs."""

from collections.abc import Callable
from re import IGNORECASE, PatternError
from typing import Any

from pytest import mark, raises

from observability_ai.evaluation import (
    Contains,
    Evaluator,
    ExactMatch,
    JsonParsable,
    LengthWithin,
    NumericTolerance,
    RegexMatch,
)


@mark.parametrize(
    ("output", "expected", "match"),
    [
        ("a", "a", 1),
        ("a ", "a", 0),
        ("A", "a", 0),
        ({"a": [1, 2]}, {"a": [1, 2]}, 1),
        (None, None, 1),
        ("1", 1, 0),
    ],
)
def test_exact_match(output: object, expected: object, match: int) -> None:
    """Use equality without case, whitespace, or numeric-string normalization."""
    result = ExactMatch(name="custom")(output=output, expected_output=expected)
    assert (result.name, result.value, result.data_type) == ("custom", match, "BOOLEAN")


def test_substring_and_regex_semantics() -> None:
    """Contains uses expected text; regex uses a configured search expression."""
    assert Contains()(output="hello world", expected_output="world").value == 1
    assert Contains()(output="Hello", expected_output="hello").value == 0
    assert Contains()(output="", expected_output="").value == 1
    assert RegexMatch(r"\d+")(output="answer: 42").value == 1
    assert RegexMatch(r"^\d+$")(output="answer: 42").value == 0
    assert RegexMatch("yes", flags=IGNORECASE)(output="YES").value == 1
    with raises(PatternError):
        RegexMatch("[")


@mark.parametrize(
    ("output", "expected", "absolute", "relative", "match"),
    [
        (1.25, 1, 0.25, 0, 1),
        (1.251, 1, 0.25, 0, 0),
        (101, 100, 0, 0.01, 1),
        (102, 100, 0, 0.01, 0),
        (0, 0, 0, 0, 1),
        (-10, -10.1, 0.2, 0, 1),
    ],
)
def test_numeric_tolerance(
    output: float, expected: float, absolute: float, relative: float, match: int
) -> None:
    """Include exact boundaries and math.isclose relative scaling."""
    evaluator = NumericTolerance(abs_tolerance=absolute, rel_tolerance=relative)
    assert evaluator(output=output, expected_output=expected).value == match


@mark.parametrize("value", [True, "1", None, float("nan"), float("inf"), 10**400])
def test_numeric_inputs_must_be_finite_numbers(value: object) -> None:
    """Reject invalid values on either side of the comparison."""
    for output, expected in ((value, 1), (1, value)):
        with raises((ValueError, TypeError)):
            NumericTolerance()(output=output, expected_output=expected)


@mark.parametrize(
    ("output", "match"),
    [
        (' {"a": [1, true, null]} ', 1),
        ('"text"', 1),
        ("42", 1),
        ("null", 1),
        ("", 0),
        ("{} {}", 0),
        ("```json\n{}\n```", 0),
        ("NaN", 0),
        ("Infinity", 0),
        ("1e999", 0),
        ('{"a": 1, "a": 2}', 0),
    ],
)
def test_json_parsable(output: str, match: int) -> None:
    """Accept JSON scalars as well as containers; reject ambiguous/nonfinite JSON."""
    assert JsonParsable()(output=output).value == match


def test_length_bounds_are_inclusive() -> None:
    """Count characters or collection items with optional upper bound."""
    evaluator = LengthWithin(min_length=1, max_length=2)
    assert evaluator(output="é").value == 1
    assert evaluator(output=[1, 2]).value == 1
    assert evaluator(output=[]).value == 0
    assert evaluator(output="abc").value == 0
    assert LengthWithin()(output=[]).value == 1
    assert LengthWithin(min_length=2)(output=[1, 2, 3]).value == 1


@mark.parametrize(
    ("evaluator", "output", "expected"),
    [
        (Contains(), 1, "a"),
        (Contains(), "a", None),
        (RegexMatch("a"), [], None),
        (JsonParsable(), {}, None),
        (LengthWithin(), 1, None),
    ],
)
def test_bad_input_types(
    evaluator: Evaluator, output: object, expected: object
) -> None:
    """Programming errors are distinct from a failed quality check."""
    with raises(TypeError):
        evaluator(input=None, output=output, expected_output=expected, metadata=None)


@mark.parametrize(
    ("factory", "kwargs"),
    [
        (ExactMatch, {"name": " "}),
        (Contains, {"name": 1}),
        (JsonParsable, {"name": ""}),
        (NumericTolerance, {"abs_tolerance": -1}),
        (NumericTolerance, {"rel_tolerance": float("nan")}),
        (NumericTolerance, {"abs_tolerance": True}),
        (LengthWithin, {"min_length": True}),
        (LengthWithin, {"min_length": -1}),
        (LengthWithin, {"max_length": 1.5}),
        (LengthWithin, {"min_length": 2, "max_length": 1}),
    ],
)
def test_invalid_configuration(
    factory: Callable[..., object], kwargs: dict[str, Any]
) -> None:
    """Configuration failures occur when constructing the evaluator."""
    with raises((TypeError, ValueError)):
        factory(**kwargs)
