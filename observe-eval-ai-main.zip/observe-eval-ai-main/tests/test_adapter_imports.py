"""Verify lazy optional imports independently of installed development extras."""

from subprocess import run
from sys import executable

from pytest import mark


@mark.parametrize(
    ("module", "factory", "kwargs", "extra"),
    [
        (
            "model_runtime",
            "model_runtime_observer",
            {"provider_name": "test"},
            "model-runtime",
        ),
        ("vectorstore", "retrieval_observer", {}, "vectorstore"),
    ],
)
@mark.parametrize("failure", ["missing", "transitive"])
def test_optional_imports_are_lazy_and_errors_are_specific(
    module: str,
    factory: str,
    kwargs: dict[str, str],
    extra: str,
    failure: str,
) -> None:
    """Missing extras get install hints; broken transitive dependencies stay visible."""
    result = run(
        [
            executable,
            "-c",
            f"""
from importlib.abc import MetaPathFinder
from sys import meta_path, modules
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

class BlockOptional(MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in ('model_runtime', 'vectorstore', 'langfuse'):
            missing = fullname if {failure!r} == 'missing' else 'broken_transitive'
            raise ModuleNotFoundError('dependency unavailable', name=missing)

meta_path.insert(0, BlockOptional())
from observability_ai import LangfuseSettings, Telemetry
from observability_ai.adapters import model_runtime_observer, retrieval_observer
from observability_ai.genai import model_attributes, usage_attributes
assert not any(name in modules for name in ('model_runtime', 'vectorstore', 'langfuse'))
assert model_attributes(provider_name='test', request_model='model')
assert usage_attributes(input_tokens=1, output_tokens=0)

exporter = InMemorySpanExporter()
with Telemetry(LangfuseSettings('pk-test', 'sk-test'),
               service_name='test', service_version='1',
               span_processor=SimpleSpanProcessor(exporter)) as telemetry:
    try:
        {factory}(telemetry, **{kwargs!r})
    except ImportError as exc:
        if {failure!r} == 'missing':
            assert 'observe-eval-ai[{extra}]' in str(exc), str(exc)
            assert isinstance(exc.__cause__, ModuleNotFoundError)
            assert exc.__cause__.name == {module!r}
        else:
            assert isinstance(exc, ModuleNotFoundError)
            assert exc.name == 'broken_transitive'
    else:
        raise AssertionError('optional import unexpectedly succeeded')
    with telemetry.observe('core still works'):
        pass
assert [span.name for span in exporter.get_finished_spans()] == ['core still works']
""",
        ],
        capture_output=True,
        text=True,
        check=False,
        timeout=20,
    )
    assert result.returncode == 0, result.stderr
