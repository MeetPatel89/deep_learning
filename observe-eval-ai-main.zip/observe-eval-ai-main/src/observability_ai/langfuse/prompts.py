"""Retrieve SDK prompt objects while preserving compilation and version links."""

from typing import Literal, overload

from langfuse import Langfuse
from langfuse.model import ChatPromptClient, TextPromptClient

from ..config import _validate_text


class PromptRepository:
    """Fetch prompts through an application-owned SDK client and its cache.

    ``get()`` returns the original SDK prompt. Use its ``compile(**variables)``
    method for content and pass the prompt itself to a generation's ``prompt=``
    parameter to preserve attribution to its managed version.
    """

    def __init__(self, client: Langfuse) -> None:
        """Reuse the supplied client without taking ownership of its lifecycle."""
        self._client = client

    @overload
    def get(
        self,
        name: str,
        *,
        label: str | None = None,
        version: int | None = None,
        type: Literal["text"] = "text",
    ) -> TextPromptClient: ...

    @overload
    def get(
        self,
        name: str,
        *,
        label: str | None = None,
        version: int | None = None,
        type: Literal["chat"],
    ) -> ChatPromptClient: ...

    def get(
        self,
        name: str,
        *,
        label: str | None = None,
        version: int | None = None,
        type: Literal["text", "chat"] = "text",
    ) -> TextPromptClient | ChatPromptClient:
        """Get a label or positive version; omit both for SDK ``production``.

        Label and version are mutually exclusive. The SDK owns caching, retries,
        and fetch errors; the repository never creates or updates remote prompts.
        """
        _validate_text("name", name)
        if label is not None:
            _validate_text("label", label)
        if version is not None:
            if isinstance(version, bool) or not isinstance(version, int):
                raise TypeError("version must be an integer")
            if version < 1:
                raise ValueError("version must be positive")
        if label is not None and version is not None:
            raise ValueError("label and version are mutually exclusive")
        if type not in ("text", "chat"):
            raise ValueError("type must be text or chat")
        return self._client.get_prompt(name, label=label, version=version, type=type)
