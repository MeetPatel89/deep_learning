# fs-mcp-server

Independent stdio MCP server for local, ADLS Gen2, S3 and GCS files and datasets.
Set `FS_MCP_CONFIG` to a TOML file defining named stores. All writes and deletes
are disabled by default; each path is relative to a configured store root.

From the workspace: `uv run --package fs-mcp-server fs-mcp-server`.
Optional extras are `s3`, `gcs`, `iceberg` and `legacy`.

See the [workspace guide](../../README.md), [example config](../../examples/fs.toml)
and [MCP configuration](../../examples/mcp.json) for tools, formats and permissions.
Tests live in `tests/` and use generated local datasets and mocked ADLS clients.
