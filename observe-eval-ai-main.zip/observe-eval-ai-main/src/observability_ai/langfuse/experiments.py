"""Execute SDK experiments, summarize results, and enforce CI score thresholds."""

from collections.abc import Awaitable, Callable, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import datetime
from inspect import isawaitable
from statistics import mean
from types import MappingProxyType
from typing import Protocol

from langfuse import Langfuse
from langfuse._client.datasets import DatasetClient
from langfuse.api import DatasetItem
from langfuse.experiment import (
    Evaluation,
    ExperimentData,
    ExperimentItemResult,
    ExperimentResult,
    LocalExperimentItem,
    RunEvaluatorFunction,
    TaskFunction,
)

from ..config import _validate_text
from ..evaluation.results import (
    EvaluationOutput,
    EvaluationResult,
    Evaluator,
    _metadata_snapshot,
    _validated_value,
)
from ._evaluation import _adapt_evaluator, _sdk_evaluations, _validate_integer
from .datasets import DatasetItemRecord


class RunEvaluator(Protocol):
    """Evaluate the SDK's completed items and return core result values."""

    def __call__(
        self, *, item_results: Sequence[ExperimentItemResult]
    ) -> EvaluationOutput | Awaitable[EvaluationOutput]:
        """Evaluate aggregate behavior synchronously or asynchronously."""
        ...


def _core_evaluation(evaluation: Evaluation) -> EvaluationResult:
    return EvaluationResult(
        name=evaluation.name,
        value=evaluation.value,
        data_type=evaluation.data_type or "NUMERIC",
        comment=evaluation.comment,
        metadata=evaluation.metadata or {},
    )


@dataclass(frozen=True, slots=True)
class ExperimentReport:
    """Immutable summary snapshot, retaining the original mutable SDK result.

    Means include item-level NUMERIC and BOOLEAN scores only. Run-level scores
    remain separate so they cannot accidentally change the item metric means.
    Failed items are absent from the SDK result; evaluator failures are captured
    by the runner before the SDK logs them. Delivery errors remain SDK-owned.
    """

    sdk_result: ExperimentResult
    total_count: int
    evaluator_failures: tuple[str, ...] = ()
    completed_count: int = field(init=False)
    failed_count: int = field(init=False)
    evaluation_count: int = field(init=False)
    metric_means: Mapping[str, float] = field(init=False)
    metric_counts: Mapping[str, int] = field(init=False)
    run_evaluations: tuple[EvaluationResult, ...] = field(init=False)

    def __post_init__(self) -> None:
        """Validate and snapshot counts and numeric aggregates."""
        _validate_integer("total_count", self.total_count, minimum=0)
        completed = len(self.sdk_result.item_results)
        if completed > self.total_count:
            raise ValueError("completed items cannot exceed total_count")
        failures = tuple(self.evaluator_failures)
        if any(not isinstance(failure, str) for failure in failures):
            raise TypeError("evaluator_failures must contain strings")
        values: dict[str, list[float]] = {}
        types: dict[str, str] = {}
        count = 0
        for item in self.sdk_result.item_results:
            for evaluation in item.evaluations:
                result = _core_evaluation(evaluation)
                count += 1
                if types.setdefault(result.name, result.data_type) != result.data_type:
                    raise ValueError(f"conflicting data types for metric {result.name}")
                if isinstance(result.value, float):
                    values.setdefault(result.name, []).append(result.value)
        object.__setattr__(self, "evaluator_failures", failures)
        object.__setattr__(self, "completed_count", completed)
        object.__setattr__(self, "failed_count", self.total_count - completed)
        object.__setattr__(self, "evaluation_count", count)
        object.__setattr__(
            self,
            "metric_means",
            MappingProxyType({name: mean(scores) for name, scores in values.items()}),
        )
        object.__setattr__(
            self,
            "metric_counts",
            MappingProxyType({name: len(scores) for name, scores in values.items()}),
        )
        object.__setattr__(
            self,
            "run_evaluations",
            tuple(
                _core_evaluation(result) for result in self.sdk_result.run_evaluations
            ),
        )


def _adapt_run_evaluator(
    evaluator: RunEvaluator, on_error: Callable[[str], None]
) -> RunEvaluatorFunction:
    if not callable(evaluator):
        raise TypeError("run_evaluators must contain callable evaluators")

    async def adapted(
        *, item_results: list[ExperimentItemResult], **kwargs: object
    ) -> list[Evaluation]:
        try:
            result = evaluator(item_results=tuple(item_results))
            evaluated = await result if isawaitable(result) else result
            return _sdk_evaluations(evaluated)
        except Exception as exc:
            on_error(f"run {adapted.__name__}: {type(exc).__name__}: {exc}")
            raise

    adapted.__name__ = getattr(evaluator, "__name__", type(evaluator).__name__)
    return adapted


def _prepare_data(
    data: DatasetClient
    | Sequence[DatasetItemRecord]
    | Sequence[LocalExperimentItem]
    | Sequence[DatasetItem],
) -> tuple[ExperimentData, datetime | None]:
    version = data.version if isinstance(data, DatasetClient) else None
    items = tuple(data.items if isinstance(data, DatasetClient) else data)
    if all(isinstance(item, DatasetItem) for item in items):
        return [item for item in items if isinstance(item, DatasetItem)], version
    local: list[LocalExperimentItem] = []
    for item in items:
        if isinstance(item, DatasetItemRecord):
            local.append(
                LocalExperimentItem(
                    input=item.input,
                    expected_output=item.expected_output,
                    metadata=dict(item.metadata),
                )
            )
        elif isinstance(item, dict):
            dimensions = item.get("metadata")
            local.append(
                LocalExperimentItem(
                    input=item.get("input"),
                    expected_output=item.get("expected_output"),
                    metadata=(
                        dict(_metadata_snapshot(dimensions))
                        if dimensions is not None
                        else None
                    ),
                )
            )
        else:
            raise TypeError("data must contain local records or only SDK dataset items")
    return local, version


class ExperimentRunner:
    """Run local or hosted data through an application-owned Langfuse client.

    The SDK controls concurrency, tracing, score delivery, flushing, and event
    loop handling. Tasks use its ``task(*, item, **kwargs)`` contract. Local
    records become SDK dictionaries; hosted items retain their remote identity.
    """

    def __init__(self, client: Langfuse) -> None:
        """Reuse the supplied client without owning its lifecycle."""
        self._client = client

    def run(
        self,
        name: str,
        *,
        data: DatasetClient
        | Sequence[DatasetItemRecord]
        | Sequence[LocalExperimentItem]
        | Sequence[DatasetItem],
        task: TaskFunction,
        evaluators: Sequence[Evaluator],
        run_evaluators: Sequence[RunEvaluator] = (),
        run_name: str | None = None,
        description: str | None = None,
        metadata: Mapping[str, str] | None = None,
        max_concurrency: int = 50,
    ) -> ExperimentReport:
        """Run an experiment and report partial failures without hiding them."""
        _validate_text("name", name)
        if run_name is not None:
            _validate_text("run_name", run_name)
        if description is not None and not isinstance(description, str):
            raise TypeError("description must be a string")
        if not callable(task):
            raise TypeError("task must be callable")
        _validate_integer("max_concurrency", max_concurrency)
        dimensions: dict[str, str] | None = None
        if metadata is not None:
            _metadata_snapshot(metadata)
            if any(not isinstance(value, str) for value in metadata.values()):
                raise TypeError("experiment metadata values must be strings")
            dimensions = dict(metadata)
        prepared, version = _prepare_data(data)
        failures: list[str] = []
        result = self._client.run_experiment(
            name=name,
            data=prepared,
            task=task,
            evaluators=[
                _adapt_evaluator(e, on_error=failures.append) for e in evaluators
            ],
            run_evaluators=[
                _adapt_run_evaluator(e, failures.append) for e in run_evaluators
            ],
            run_name=run_name,
            description=description,
            metadata=dimensions,
            max_concurrency=max_concurrency,
            _dataset_version=version,
        )
        return ExperimentReport(result, len(prepared), tuple(failures))


class RegressionDetected(Exception):  # noqa: N818 - public exception from the plan
    """An experiment failed a minimum score or completeness requirement."""


@dataclass(frozen=True, slots=True)
class RegressionGate:
    """Require minimum item-metric means and an experiment without failures.

    Missing metrics, empty experiments, failed tasks, and evaluator failures all
    fail the gate. Threshold equality passes. Run-level metrics are not gated.
    """

    thresholds: Mapping[str, float]

    def __post_init__(self) -> None:
        """Snapshot named, finite minimum thresholds."""
        snapshot = _metadata_snapshot(self.thresholds)
        checked: dict[str, float] = {}
        for name, value in snapshot.items():
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise TypeError("thresholds must be finite numbers")
            score = _validated_value(name, value, "NUMERIC", None)
            assert isinstance(score, float)
            checked[name] = score
        object.__setattr__(self, "thresholds", MappingProxyType(checked))

    def check(self, report: ExperimentReport) -> None:
        """Raise ``RegressionDetected`` with all failed requirements for CI."""
        reasons: list[str] = []
        if report.total_count == 0:
            reasons.append("experiment has no items")
        if report.failed_count:
            reasons.append(f"{report.failed_count} item(s) failed")
        if report.evaluator_failures:
            reasons.append(f"{len(report.evaluator_failures)} evaluator(s) failed")
        for name, minimum in self.thresholds.items():
            actual = report.metric_means.get(name)
            if actual is None:
                reasons.append(f"missing metric {name}")
            elif actual < minimum:
                reasons.append(f"{name}: {actual:g} < {minimum:g}")
        if reasons:
            raise RegressionDetected("; ".join(reasons))
