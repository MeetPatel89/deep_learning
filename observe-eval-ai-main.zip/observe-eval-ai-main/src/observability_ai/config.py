"""Validated connection and sampling settings for Langfuse."""

from dataclasses import dataclass, field
from os import environ
from re import fullmatch
from typing import Self
from urllib.parse import urlsplit


@dataclass(frozen=True, slots=True)
class LangfuseSettings:
    """Configure one Langfuse project without loading files or changing globals.

    Credentials are required. Environment and release are optional deployment
    dimensions; ``sample_ratio`` controls sampling of root spans only.
    """

    public_key: str
    secret_key: str = field(repr=False)
    base_url: str = "http://localhost:3000"
    environment: str | None = None
    release: str | None = None
    sample_ratio: float = 1.0

    def __post_init__(self) -> None:
        """Reject invalid credentials, URLs, dimensions, and sampling ratios."""
        for name, value in (
            ("public_key", self.public_key),
            ("secret_key", self.secret_key),
        ):
            _validate_text(name, value)
            if any(character.isspace() for character in value):
                raise ValueError(f"{name} must not contain whitespace")
        if ":" in self.public_key:
            raise ValueError("public_key must not contain a colon")

        _validate_text("base_url", self.base_url)
        try:
            parsed = urlsplit(self.base_url)
            valid_url = (
                parsed.scheme in {"http", "https"}
                and bool(parsed.hostname)
                and parsed.username is None
                and parsed.password is None
                and "?" not in self.base_url
                and "#" not in self.base_url
                and not any(character.isspace() for character in self.base_url)
            )
            # Accessing port also validates its syntax and range.
            parsed.port
        except ValueError:
            valid_url = False
        if not valid_url:
            raise ValueError(
                "base_url must be an absolute HTTP(S) URL without credentials, "
                "whitespace, a query, or a fragment"
            )
        object.__setattr__(self, "base_url", self.base_url.rstrip("/"))

        if self.environment is not None:
            _validate_text("environment", self.environment)
            if fullmatch(r"(?!langfuse)[a-z0-9_-]{1,40}", self.environment) is None:
                raise ValueError(
                    "environment must contain 1 to 40 lowercase letters, digits, "
                    "hyphens, or underscores and must not start with 'langfuse'"
                )
        if self.release is not None:
            _validate_text("release", self.release)

        if isinstance(self.sample_ratio, bool) or not isinstance(
            self.sample_ratio, (int, float)
        ):
            raise TypeError("sample_ratio must be a number")
        if not 0.0 <= self.sample_ratio <= 1.0:
            raise ValueError("sample_ratio must be between 0.0 and 1.0")

    @classmethod
    def from_env(cls) -> Self:
        """Read LANGFUSE_* variables from the current process environment.

        ``LANGFUSE_PUBLIC_KEY`` and ``LANGFUSE_SECRET_KEY`` are required.
        Optional variables are ``LANGFUSE_BASE_URL``,
        ``LANGFUSE_TRACING_ENVIRONMENT``, ``LANGFUSE_RELEASE``, and
        ``LANGFUSE_SAMPLE_RATE``. No dotenv file is loaded implicitly.
        """
        for name in ("LANGFUSE_PUBLIC_KEY", "LANGFUSE_SECRET_KEY"):
            if not environ.get(name):
                raise ValueError(f"{name} is required")
        try:
            sample_ratio = float(environ.get("LANGFUSE_SAMPLE_RATE", "1.0"))
        except ValueError as error:
            raise ValueError("LANGFUSE_SAMPLE_RATE must be a number") from error
        return cls(
            public_key=environ["LANGFUSE_PUBLIC_KEY"],
            secret_key=environ["LANGFUSE_SECRET_KEY"],
            base_url=environ.get("LANGFUSE_BASE_URL", "http://localhost:3000"),
            environment=environ.get("LANGFUSE_TRACING_ENVIRONMENT"),
            release=environ.get("LANGFUSE_RELEASE"),
            sample_ratio=sample_ratio,
        )


def _validate_text(name: str, value: str) -> None:
    """Require a nonblank string without including its value in errors."""
    if not isinstance(value, str):
        raise TypeError(f"{name} must be a string")
    if not value.strip():
        raise ValueError(f"{name} must not be empty")
