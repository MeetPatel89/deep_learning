"""Verify the historical evaluation SDK boundary and shared evaluator adaptation."""

from asyncio import CancelledError, get_running_loop
from collections.abc import Mapping
from typing import Any
from unittest.mock import Mock, create_autospec

from pytest import importorskip, mark, raises

importorskip("langfuse", reason="requires observe-eval-ai[langfuse]")

from langfuse import Langfuse  # noqa: E402
from langfuse.api import ObservationsView, TraceWithFullDetails  # noqa: E402
from langfuse.batch_evaluation import (  # noqa: E402
    BatchEvaluationResumeToken,
    EvaluatorInputs,
)

from observability_ai.evaluation import EvaluationResult, ExactMatch  # noqa: E402
from observability_ai.langfuse import BatchEvaluation  # noqa: E402


def _mapper(
    *, item: TraceWithFullDetails | ObservationsView, **kwargs: object
) -> EvaluatorInputs:
    return EvaluatorInputs(input=item.input, output=item.output)


async def test_batch_forwards_sdk_options_and_converts_core_evaluations() -> None:
    """Enforce the SDK signature and preserve native result/resume objects."""
    client = create_autospec(Langfuse, instance=True)
    token = Mock(spec=BatchEvaluationResumeToken)
    metadata = {"experiment": "backfill"}

    async def metric(
        *,
        input: object,
        output: object,
        expected_output: object,
        metadata: Mapping[str, object] | None,
    ) -> tuple[EvaluationResult, ...]:
        assert metadata == {"slice": "test"}
        return (EvaluationResult("quality", 0.8, comment="checked", metadata={"v": 1}),)

    returned = BatchEvaluation(client).run(
        scope="observations",
        mapper=_mapper,
        evaluators=[ExactMatch(), metric],
        filter='[{"type":"string","column":"name","operator":"=","value":"qa"}]',
        fetch_batch_size=10,
        fetch_trace_fields="core,input,output",
        max_items=25,
        max_retries=0,
        max_concurrency=2,
        metadata=metadata,
        resume_from=token,
        verbose=True,
    )
    assert returned is client.run_batched_evaluation.return_value
    arguments = client.run_batched_evaluation.call_args.kwargs
    assert arguments | {"evaluators": None} == {
        "scope": "observations",
        "mapper": _mapper,
        "evaluators": None,
        "filter": '[{"type":"string","column":"name","operator":"=","value":"qa"}]',
        "fetch_batch_size": 10,
        "fetch_trace_fields": "core,input,output",
        "max_items": 25,
        "max_retries": 0,
        "max_concurrency": 2,
        "metadata": {"experiment": "backfill"},
        "resume_from": token,
        "verbose": True,
    }
    assert arguments["metadata"] is not metadata
    first, second = arguments["evaluators"]
    assert first.__name__ == "ExactMatch"
    converted = await first(input="q", output="a", expected_output="a", metadata=None)
    assert converted[0].data_type == "BOOLEAN"
    assert converted[0].value == 1.0
    converted = await second(
        input="q",
        output="a",
        expected_output=None,
        metadata={"slice": "test"},
        future_sdk_option={},
    )
    assert converted[0].metadata == {"v": 1}
    assert converted[0].comment == "checked"
    client.shutdown.assert_not_called()
    client.flush.assert_not_called()


async def test_adaptation_awaits_general_awaitables_and_preserves_cancellation() -> (
    None
):
    """Core evaluators may return futures, and cancellation is not a score failure."""
    client = Mock(spec=Langfuse)
    future = get_running_loop().create_future()
    future.set_result(EvaluationResult("ready", True, "BOOLEAN"))
    BatchEvaluation(client).run(mapper=_mapper, evaluators=[lambda **kwargs: future])
    adapted = client.run_batched_evaluation.call_args.kwargs["evaluators"][0]
    scores = await adapted(input=None, output=None, expected_output=None, metadata=None)
    assert scores[0].value == 1.0

    async def cancelled(**kwargs: object) -> EvaluationResult:
        raise CancelledError()

    BatchEvaluation(client).run(mapper=_mapper, evaluators=[cancelled])
    adapted = client.run_batched_evaluation.call_args.kwargs["evaluators"][0]
    with raises(CancelledError):
        await adapted(input=None, output=None, expected_output=None, metadata=None)


@mark.parametrize(
    "options",
    [
        {"scope": "wrong"},
        {"mapper": None},
        {"evaluators": [None]},
        {"fetch_batch_size": 0},
        {"max_concurrency": False},
        {"max_concurrency": 0},
        {"max_retries": -1},
        {"max_retries": True},
        {"max_items": 0},
        {"filter": {}},
        {"fetch_trace_fields": []},
        {"verbose": "yes"},
        {"metadata": {"": 1}},
    ],
)
def test_invalid_batch_configuration_never_starts(options: dict[str, Any]) -> None:
    """Invalid limits and SDK options fail before history is fetched or scored."""
    client = Mock(spec=Langfuse)
    arguments: dict[str, Any] = {"mapper": _mapper, "evaluators": []} | options
    with raises((TypeError, ValueError)):
        BatchEvaluation(client).run(**arguments)
    client.run_batched_evaluation.assert_not_called()


def test_batch_defaults_and_sdk_failure_are_preserved() -> None:
    """The trace scope and SDK limits are explicit, and invocation errors propagate."""
    client = Mock(spec=Langfuse)
    batch = BatchEvaluation(client)
    batch.run(mapper=_mapper, evaluators=[])
    client.run_batched_evaluation.assert_called_once_with(
        scope="traces",
        mapper=_mapper,
        evaluators=[],
        filter=None,
        fetch_batch_size=50,
        fetch_trace_fields=None,
        max_items=None,
        max_retries=3,
        max_concurrency=5,
        metadata=None,
        resume_from=None,
        verbose=False,
    )
    failure = RuntimeError("SDK fetch failure")
    client.run_batched_evaluation.side_effect = failure
    with raises(RuntimeError) as caught:
        batch.run(mapper=_mapper, evaluators=[])
    assert caught.value is failure
