"""Contain processor and exporter failures without changing application behavior."""

from concurrent.futures import ThreadPoolExecutor
from contextlib import nullcontext
from typing import override
from unittest.mock import patch

from opentelemetry.context import Context
from opentelemetry.sdk.trace import ReadableSpan, Span, SpanProcessor
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.trace import StatusCode, get_current_span
from pytest import LogCaptureFixture, mark, raises

from observability_ai import LangfuseSettings, Telemetry, build_tracer_provider


class _Processor(SpanProcessor):
    """Record observable callbacks and optionally fail after receiving each one."""

    def __init__(self, failure: str = "") -> None:
        self.failure = failure
        self.calls: list[str] = []
        self.spans: list[ReadableSpan] = []
        self.parents: list[Context | None] = []

    def _call(self, name: str) -> None:
        self.calls.append(name)
        if name == self.failure:
            raise RuntimeError(f"{name} failed")

    @override
    def on_start(self, span: Span, parent_context: Context | None = None) -> None:
        """Record parent context and stamp a processor-owned attribute."""
        self.parents.append(parent_context)
        span.set_attribute("processor.started", True)
        self._call("on_start")

    @override
    def _on_ending(self, span: Span) -> None:
        self._call("_on_ending")

    @override
    def on_end(self, span: ReadableSpan) -> None:
        """Retain ended spans even when simulating a downstream failure."""
        self.spans.append(span)
        self._call("on_end")

    @override
    def force_flush(self, timeout_millis: int = 30_000) -> bool:
        """Report normal completion unless a flush failure is requested."""
        self._call("force_flush")
        return True

    @override
    def shutdown(self) -> None:
        """Record close attempts, including failed attempts."""
        self._call("shutdown")


@mark.parametrize(
    "failure", ["on_start", "_on_ending", "on_end", "force_flush", "shutdown"]
)
@mark.parametrize("application_error", [False, True])
def test_processor_failures_preserve_application_and_context(
    settings: LangfuseSettings,
    caplog: LogCaptureFixture,
    failure: str,
    application_error: bool,
) -> None:
    """Every callback is guarded; cleanup cannot replace the application's error."""
    processor = _Processor(failure)
    previous = get_current_span()
    error = ValueError("application failure")
    result = "not run"
    telemetry = Telemetry(
        settings,
        service_name="failure-test",
        service_version="1",
        span_processor=processor,
    )
    with raises(ValueError) if application_error else nullcontext() as caught:
        with telemetry:
            try:
                with telemetry.agent("agent"):
                    with telemetry.tool("tool"):
                        result = "application completed"
                        if application_error:
                            raise error
            finally:
                assert telemetry.force_flush() is (failure != "force_flush")
    if application_error:
        assert caught is not None and caught.value is error
    assert result == "application completed"
    assert get_current_span() is previous
    assert len(processor.spans) == 2
    assert processor.spans[0].parent == processor.spans[1].context
    for span in processor.spans:
        assert span.end_time is not None
        assert span.attributes is not None and span.attributes["processor.started"]
        assert span.status.status_code is (
            StatusCode.ERROR if application_error else StatusCode.UNSET
        )
    assert any(
        record.name == "opentelemetry.sdk.trace"
        and f"{failure} failed" in str(record.exc_info)
        for record in caplog.records
    )
    telemetry.shutdown()
    assert processor.calls.count("shutdown") == 1
    assert not telemetry.force_flush()


def test_provider_factory_guards_raw_tracers_and_preserves_parent_context(
    settings: LangfuseSettings, caplog: LogCaptureFixture
) -> None:
    """Direct provider users receive the same protection as facade observations."""
    processor = _Processor("on_end")
    provider = build_tracer_provider(
        settings, service_name="raw", service_version="1", span_processor=processor
    )
    context = Context()
    try:
        with provider.get_tracer("external").start_as_current_span(
            "raw", context=context
        ):
            pass
        assert provider.force_flush()
    finally:
        provider.shutdown()
    provider.shutdown()
    assert processor.parents == [context]
    assert processor.calls == [
        "on_start",
        "_on_ending",
        "on_end",
        "force_flush",
        "shutdown",
    ]
    assert "on_end failed" in caplog.text


@mark.parametrize("failure", ["", "shutdown"])
def test_concurrent_shutdown_calls_close_processor_once(
    settings: LangfuseSettings, failure: str
) -> None:
    """Concurrent lifecycle owners make only one close attempt, even if it fails."""
    processor = _Processor(failure)
    telemetry = Telemetry(
        settings, service_name="shutdown", service_version="1", span_processor=processor
    )
    with ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(lambda _: telemetry.shutdown(), range(20)))
    telemetry.shutdown()
    assert processor.calls == ["shutdown"]
    assert not telemetry.force_flush()
    with telemetry.observe("after shutdown"):
        pass
    assert processor.calls == ["shutdown"]


class _ShutdownFailureExporter(InMemorySpanExporter):
    """Simulate a transport that fails while releasing resources."""

    def __init__(self) -> None:
        super().__init__()
        self.shutdown_calls = 0

    @override
    def shutdown(self) -> None:
        """Fail on close after accounting for the attempt."""
        self.shutdown_calls += 1
        raise RuntimeError("exporter shutdown failed")


@mark.parametrize("batched", [False, True])
def test_exporter_shutdown_failure_is_logged_and_not_retried(
    settings: LangfuseSettings, caplog: LogCaptureFixture, batched: bool
) -> None:
    """Both standard export paths remain fail-open during teardown."""
    exporter = _ShutdownFailureExporter()
    with patch("observability_ai.export.langfuse_span_exporter", return_value=exporter):
        with Telemetry(
            settings,
            service_name="exporter-shutdown",
            service_version="1",
            span_processor=None if batched else SimpleSpanProcessor(exporter),
        ) as telemetry:
            with telemetry.tool("work"):
                pass
            assert telemetry.force_flush()
    telemetry.shutdown()
    assert len(exporter.get_finished_spans()) == 1
    assert exporter.shutdown_calls == 1
    assert "exporter shutdown failed" in caplog.text


def test_processor_guard_does_not_swallow_process_control(
    settings: LangfuseSettings,
) -> None:
    """Fail-open handles ordinary exceptions, preserving process-control signals."""
    processor = SpanProcessor()
    with Telemetry(
        settings,
        service_name="interrupt",
        service_version="1",
        span_processor=processor,
    ) as telemetry:
        with patch.object(processor, "on_start", side_effect=KeyboardInterrupt):
            with raises(KeyboardInterrupt):
                with telemetry.observe("interrupt"):
                    raise AssertionError("interrupted body must not execute")
