# data-mcp-core

Shared library for the three data MCP servers. It has no MCP dependency or tools.

Modules provide Azure credentials, TOML/env configuration, explicit permissions and
path guards, named fsspec stores, Polars format readers/writers, cached ODBC SQL
connections and bounded/redacted results. Optional extras are `sql`, `formats`,
`s3`, `gcs`, `iceberg` and `legacy`.

See the [workspace guide](../../README.md) for configuration and backend details.
Run its tests from the workspace with `uv run --all-packages --all-extras pytest
packages/data_mcp_core/tests`.
