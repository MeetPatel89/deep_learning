from qa_mcp_server.server import main

main()
