# v0.7.0 provisioning verification

Executed on 2026-09-25 against the local Langfuse v4 Compose stack, using Python
3.14.3. This record covers the library release. Fieldguide's dependency migration,
dataset/baseline execution, and app-specific trace verification follow after the
`v0.7.0` tag is available on GitHub.

## Automated checks

| Check | Result |
| --- | --- |
| `uv sync --locked --all-extras` | Passed |
| `uv run --no-sync ruff format --check .` | Passed, 76 files |
| `uv run --no-sync ruff check .` | Passed |
| `uv run --no-sync ty check` | Passed |
| `uv run --no-sync mypy` | Passed, 72 source files |
| `uv run --no-sync pytest -q` | 692 passed, including 61 provisioning tests |
| `uv build --no-sources` | Wheel and source distribution built |
| Isolated Python 3.14 wheel and source-distribution smoke checks | Both passed, including provisioning imports and installed console entry point |

The package smoke checks used `uv run --isolated --no-project --no-cache --python
3.14 --with <artifact> tests/package_smoke.py 0.7.0`. No optional SDK or adapter
dependencies were installed in those environments. After correcting the smoke
check's entry-point lookup for Python 3.14, both artifacts were rebuilt, both
smoke checks passed, and the affected file passed Ruff, ty, and mypy again.

## Live scratch project

Started the central stack with its existing `.env`. From
`/tmp/observe-eval-provision-scratch`, invoked the installed `observability-ai`
console script with:

```bash
observability-ai provision --app scratch --app-env .env \
  --stack-dir /home/nautilus89/projects/observe-eval-ai/observability --yes
```

The command verified project `scratch` in organization `observability-ai` and
wrote its credentials into the scratch app's `.env`. API keys and passwords are
excluded from this record.

- Exported a `Telemetry` span named `scratch-provisioning-smoke`, trace ID
  `df3b0b027eed1ff17d1afe0a26bdf463`, with `local` environment and app metadata.
- Queried the current observations API through `langfuse-cli`; it returned the
  span with `projectId: scratch`, root type `SPAN`, and expected name/metadata.
- The original stack project's credentials still authenticated its project.
  Querying the same trace ID using those credentials returned zero observations.
- Re-provisioning reused the exact saved key pair.
- `--rotate-keys` generated a different public and secret key. Both old and new
  pairs authenticated `scratch` afterward, matching the documented rotation
  behavior.
- Compared stack `.env` hashes before/after repeat provisioning and rotation:
  identical. Compared running container IDs: the worker and all datastore
  containers were unchanged; only the web service was recreated.

The local trace can be inspected at
[scratch provisioning smoke](http://localhost:3000/project/scratch/traces/df3b0b027eed1ff17d1afe0a26bdf463).
This link requires access to this local stack and the scratch organization.

The stack and scratch project remain available for the next app verification
phase. The scratch credentials are local only; the public registry is gitignored.
The live check did not exercise creating a new owner login or destructive volume
reset recovery; those command paths have offline test coverage where applicable.
