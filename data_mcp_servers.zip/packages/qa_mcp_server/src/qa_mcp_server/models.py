"""Validated tool inputs. Paths refer to the machine running the server."""

from pathlib import Path
from typing import Annotated, Any, Literal

from data_mcp_core.sql import SQLConnection as SQLConnection
from data_mcp_core.sql import SQLSource
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class Model(BaseModel):
    model_config = ConfigDict(extra="forbid")


class FileSourceBase(Model):
    path: str = Field(min_length=1)
    store: str | None = None

    @field_validator("path", mode="before")
    @classmethod
    def path_string(cls, value):
        return str(value) if isinstance(value, Path) else value


class CSVSource(FileSourceBase):
    type: Literal["csv"] = "csv"
    delimiter: str = Field(default=",", min_length=1, max_length=1)
    encoding: str = "utf-8"
    has_header: bool = True
    null_values: str | list[str] | dict[str, str] | None = None

    @model_validator(mode="after")
    def single_byte_delimiter(self):
        if len(self.delimiter.encode("utf-8")) != 1:
            raise ValueError("delimiter must be a single byte")
        return self


class ParquetSource(FileSourceBase):
    type: Literal["parquet"] = "parquet"


class ExcelSource(FileSourceBase):
    type: Literal["excel"] = "excel"
    sheet: str | int | None = None


class FileSource(FileSourceBase):
    type: Literal["file"] = "file"
    format: str | None = None
    options: dict[str, Any] = Field(default_factory=dict)
    version: int | None = Field(default=None, ge=0)
    timestamp: str | None = None

    @model_validator(mode="after")
    def one_delta_version(self):
        if self.version is not None and self.timestamp is not None:
            raise ValueError("Specify version or timestamp, not both")
        return self


class InlineSource(Model):
    type: Literal["inline"] = "inline"
    rows: list[dict[str, Any]]


DatasetSource = Annotated[
    SQLSource | CSVSource | ParquetSource | ExcelSource | FileSource | InlineSource,
    Field(discriminator="type"),
]


class CompareOptions(Model):
    primary_keys: list[str] | None = None
    column_mapping: dict[str, str] = Field(default_factory=dict)
    ignore_columns: list[str] = Field(default_factory=list)
    numeric_tolerance: float = Field(default=0, ge=0, allow_inf_nan=False)
    trim_strings: bool = False
    case_insensitive: bool = False
    treat_null_as_equal: bool = True
    memory_budget_mb: float = Field(default=1024, gt=0, allow_inf_nan=False)
    num_partitions: int | None = Field(default=None, ge=1, le=65536)

    @model_validator(mode="after")
    def unambiguous_columns(self):
        if len(set(self.primary_keys or [])) != len(self.primary_keys or []):
            raise ValueError("primary_keys must be unique")
        if len(set(self.column_mapping.values())) != len(self.column_mapping):
            raise ValueError("column_mapping must be one-to-one")
        if set(self.primary_keys or []) & set(self.ignore_columns):
            raise ValueError("Cannot ignore a primary key")
        return self


class OutputOptions(Model):
    output_dir: Path = Path("reports")
    max_rows_per_file: int = Field(default=100_000, ge=1, le=1_048_575)
    include_matched_rows: bool = False
    max_total_report_rows: int | None = Field(default=None, ge=0)
