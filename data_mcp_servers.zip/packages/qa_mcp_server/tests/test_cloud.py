import json

import polars as pl
import pytest
from data_mcp_core import sql
from pydantic import TypeAdapter
from qa_mcp_server.config import resolve_sql_source
from qa_mcp_server.models import DatasetSource, FileSource, SQLSource
from qa_mcp_server.service import inspect


def test_generic_file_source_and_named_store(tmp_path, monkeypatch):
    pl.DataFrame({"id": [1, 2]}).write_ndjson(tmp_path / "data.jsonl")
    config = tmp_path / "qa.toml"
    config.write_text(f'[stores.raw]\nprotocol="file"\nroot={json.dumps(str(tmp_path))}\n')
    monkeypatch.setenv("QA_MCP_CONFIG", str(config))
    source = TypeAdapter(DatasetSource).validate_python(
        {"type": "file", "store": "raw", "path": "data.jsonl"}
    )
    assert inspect(source)["row_count"] == 2
    assert FileSource(
        path="abfss://raw@lake.dfs.core.windows.net/sales/data.parquet"
    ).path.startswith("abfss://")
    assert FileSource(path="s3://bucket/file.orc", format="orc").path == "s3://bucket/file.orc"
    with pytest.raises(PermissionError):
        inspect(FileSource(store="raw", path="../outside.csv"))


def test_qa_synapse_named_workspace_and_token_auth(tmp_path, monkeypatch):
    config = tmp_path / "qa.toml"
    config.write_text(
        '[auth_profiles.dev]\nmode="cli"\n[workspaces.prod]\nname="actual-workspace"\nauth="dev"\n'
    )
    monkeypatch.setenv("QA_MCP_CONFIG", str(config))
    source = SQLSource(
        workspace="prod", pool="serverless", database="db", auth="token", query="SELECT 1"
    )
    resolved = resolve_sql_source(source)
    assert resolved.server == "actual-workspace-ondemand.sql.azuresynapse.net"
    assert resolved.auth_profile.mode == "cli"
    assert "Authentication=" not in sql.connection_string(resolved)


def test_qa_generic_delta_version(tmp_path):
    from data_mcp_core.formats import write_dataset

    path = str(tmp_path / "table")
    write_dataset(pl.DataFrame({"id": [1]}), path, "delta", {"mode": "overwrite"})
    write_dataset(pl.DataFrame({"id": [2]}), path, "delta", {"mode": "append"})
    assert inspect(FileSource(path=path, format="delta", version=0))["row_count"] == 1


def test_qa_workspace_alias_with_underscore(tmp_path, monkeypatch):
    config = tmp_path / "qa.toml"
    config.write_text('[workspaces.prod_west]\nname="actual-workspace"\n')
    monkeypatch.setenv("QA_MCP_CONFIG", str(config))
    source = SQLSource(
        workspace="prod_west", pool="serverless", database="db", auth="token", query="SELECT 1"
    )
    assert resolve_sql_source(source).server == "actual-workspace-ondemand.sql.azuresynapse.net"
