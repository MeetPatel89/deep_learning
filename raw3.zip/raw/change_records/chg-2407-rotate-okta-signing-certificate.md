---
doc_id: CHG-2407
title: Rotate Okta Signing Certificate for Identity Gateway
doc_type: change_record
service_id: svc_identity_gateway
owner_group: IAM Platform
visibility: internal
status: completed
created_at: "2026-06-10T14:00:00"
updated_at: "2026-06-12T23:05:00"
related_records:
  - KI-104
  - INC-1104
  - REL-IDENTITY-2026-06
  - TASK-CHG-2407
  - POL-CAB-001
source_facts:
  - CHG-2407
  - KI-104
  - svc_identity_gateway
difficulty_tags:
  - temporal-reasoning
  - change-to-incident-linkage
servicenow:
  table: change_request
  number: CHG002407
  type: Normal
  state: Closed
  close_code: Successful
  risk: Medium
  impact: 2
  cab_required: true
  cab_date: "2026-06-11"
  approval: Approved
  approval_policy: POL-CAB-001
  business_service: Employee Portal
  cmdb_ci: Identity Gateway
  assignment_group: IAM Platform
  requested_by_group: IAM Platform
  related_incident: INC001104
  related_known_issue: KI00104
  visibility: internal
  contains_customer_safe_wording: false
---

# Rotate Okta Signing Certificate for Identity Gateway

## Record details

| Field | Value |
| --- | --- |
| Table | change_request |
| Number | CHG002407 |
| Type | Normal |
| State | Closed |
| Close code | Successful |
| Risk | Medium |
| Impact | 2 |
| CAB required | true |
| CAB date | 2026-06-11 |
| Approval | Approved |
| Approval policy | POL-CAB-001 |
| Business service | Employee Portal |
| Configuration item | Identity Gateway |
| Assignment group | IAM Platform |
| Requested by group | IAM Platform |
| Related incident | INC001104 |
| Related known issue | KI00104 |
| Visibility | internal |
| Contains customer-safe wording | false |

## Change summary

CHG-2407 rotated the Okta signing certificate used by Identity Gateway. The change was owned by IAM Platform and applied to the enterprise SSO path used for internal applications, including Employee Portal.

The related known issue is KI-104. KI-104 was documented after post-change login failures showed that some Identity Gateway nodes may continue using stale IdP metadata after certificate rotation.

## Change window

Change window was 2026-06-12T22:00:00 to 2026-06-12T23:00:00.

| Field | Value |
| --- | --- |
| Planned start | 2026-06-12T22:00:00 |
| Planned end | 2026-06-12T23:00:00 |
| Implementation owner | IAM Platform |
| Risk | Medium |
| Status | Completed |

The change record was updated at 2026-06-12T23:05:00 after implementation notes were entered.

## Services affected

Primary service affected:

- Identity Gateway, service ID svc_identity_gateway.

Relevant dependencies:

- Okta.
- Employee Portal.
- Internal API Gateway.

Expected user-visible behavior was no interruption to Employee Portal sign-in once the new certificate was active and trusted by the gateway path.

## Implementation notes

IAM Platform completed the certificate rotation inside the planned maintenance window. The implementation followed the normal identity maintenance sequence:

1. Confirm active Okta signing certificate state before the window.
2. Apply the certificate rotation for Identity Gateway.
3. Validate that Identity Gateway accepted the active IdP certificate thumbprint.
4. Confirm test sign-in path through Employee Portal.
5. Close implementation activity after the planned end time.

Change completed successfully according to the implementation notes. No immediate rollback was recorded at closure.

## Validation performed

Validation focused on confirming the sign-in path after the certificate rotation:

- Identity Gateway accepted the active IdP certificate thumbprint.
- Test sign-in to Employee Portal succeeded during post-change validation.
- No universal outage was observed before closure.

The validation did not prove that every Identity Gateway node had refreshed metadata at the same time. INC-1104 was opened at 2026-06-12T23:18:00, 18 minutes after the planned completion time, after users reported invalid SAML response errors and partial login failures.

## Risk and rollback notes

The change risk was medium because it touched enterprise SSO. The main operational risk was sign-in interruption if certificate trust was not consistent across the gateway path.

Rollback would have required restoring the previous certificate trust path. Rollback was not used because the change itself completed and the later incident matched KI-104, where the approved workaround is metadata cache refresh and certificate thumbprint verification.

## Post-change monitoring

Post-change monitoring should include:

- Employee Portal sign-in failures.
- Invalid SAML response errors.
- Partial impact where some users can log in while others cannot.
- Any Service Desk L1 reports within 24 hours of the change.

When those symptoms appear after CHG-2407, Service Desk L1 should link the incident to KI-104 and escalate unresolved SSO platform issues to IAM Platform. Release Management should be notified for change-to-incident tracking.

## Related records

- KI-104: SSO Metadata Cache Delay After Certificate Rotation.
- INC-1104: Employee Portal Login Failures After Okta Certificate Rotation.
- REL-IDENTITY-2026-06: June 2026 Identity Gateway Maintenance Release Notes.
- TASK-CHG-2407: Change tasks executed under CHG-2407.
- POL-CAB-001: Change advisory board approval policy applied to CHG-2407.
