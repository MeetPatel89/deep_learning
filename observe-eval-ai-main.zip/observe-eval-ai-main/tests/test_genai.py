"""Validate model identity and inclusive versus exclusive token accounting."""

from typing import cast

from pytest import mark, raises

from observability_ai.genai import (
    agent_attributes,
    cost_details,
    langfuse_usage_details,
    model_attributes,
    prompt_attributes,
    tool_attributes,
    usage_attributes,
)


def test_model_identity_attributes() -> None:
    """Request identity is required and unknown response identity is omitted."""
    assert model_attributes(provider_name="test", request_model="requested") == {
        "gen_ai.operation.name": "chat",
        "gen_ai.provider.name": "test",
        "gen_ai.request.model": "requested",
    }
    assert model_attributes(
        provider_name="test",
        request_model="requested",
        operation_name="embeddings",
        response_model="returned",
    ) == {
        "gen_ai.operation.name": "embeddings",
        "gen_ai.provider.name": "test",
        "gen_ai.request.model": "requested",
        "gen_ai.response.model": "returned",
    }


@mark.parametrize(
    "field", ["provider_name", "request_model", "operation_name", "response_model"]
)
@mark.parametrize("value", ["", " \t"])
def test_model_names_must_not_be_blank(field: str, value: str) -> None:
    """Invalid model identity is rejected before values can be attached to a span."""
    names = {"provider_name": "test", "request_model": "model", field: value}
    with raises(ValueError, match=field):
        model_attributes(**names)


@mark.parametrize(
    ("input_tokens", "output_tokens", "cached_tokens"),
    [(7, 3, 2), (7, 0, 7), (0, 0, 0), (10, 2, 0)],
)
def test_cache_reads_are_counted_once_in_each_usage_format(
    input_tokens: int, output_tokens: int, cached_tokens: int
) -> None:
    """OTel retains inclusive inputs; flat Langfuse buckets preserve the same total."""
    counts = {
        "input_tokens": input_tokens,
        "output_tokens": output_tokens,
        "cached_tokens": cached_tokens,
    }
    attributes = usage_attributes(**counts)
    details = langfuse_usage_details(**counts)
    assert attributes["gen_ai.usage.input_tokens"] == input_tokens
    assert attributes["gen_ai.usage.output_tokens"] == output_tokens
    assert details["input"] == input_tokens - cached_tokens
    assert details["output"] == output_tokens
    assert sum(details.values()) == input_tokens + output_tokens
    if cached_tokens:
        assert attributes["gen_ai.usage.cache_read.input_tokens"] == cached_tokens
        assert details["cache_read_input_tokens"] == cached_tokens
    else:
        assert "gen_ai.usage.cache_read.input_tokens" not in attributes
        assert "cache_read_input_tokens" not in details


def test_cache_count_defaults_to_zero() -> None:
    """Callers with no cache information can pass only input and output totals."""
    assert usage_attributes(input_tokens=4, output_tokens=0) == {
        "gen_ai.usage.input_tokens": 4,
        "gen_ai.usage.output_tokens": 0,
    }
    assert langfuse_usage_details(input_tokens=4, output_tokens=0) == {
        "input": 4,
        "output": 0,
    }


@mark.parametrize("field", ["input_tokens", "output_tokens", "cached_tokens"])
@mark.parametrize("value", [True, 1.5, "2", None])
def test_token_counts_reject_nonintegers(field: str, value: object) -> None:
    """Do not accept booleans or silently coerce provider usage values."""
    counts = {"input_tokens": 5, "output_tokens": 3, "cached_tokens": 0, field: value}
    with raises(TypeError, match=field):
        usage_attributes(**counts)  # type: ignore[arg-type]
    with raises(TypeError, match=field):
        langfuse_usage_details(**counts)  # type: ignore[arg-type]


@mark.parametrize("field", ["input_tokens", "output_tokens", "cached_tokens"])
def test_token_counts_must_be_nonnegative(field: str) -> None:
    """Invalid usage fails validation consistently in both representations."""
    counts = {"input_tokens": 5, "output_tokens": 3, "cached_tokens": 0, field: -1}
    with raises(ValueError, match=field):
        usage_attributes(**counts)
    with raises(ValueError, match=field):
        langfuse_usage_details(**counts)


def test_cache_count_cannot_exceed_inclusive_input() -> None:
    """Reject inconsistent usage instead of losing tokens or inventing a total."""
    with raises(ValueError, match="cached_tokens must not exceed input_tokens"):
        usage_attributes(input_tokens=2, output_tokens=3, cached_tokens=4)
    with raises(ValueError, match="cached_tokens must not exceed input_tokens"):
        langfuse_usage_details(input_tokens=2, output_tokens=3, cached_tokens=4)


def test_tool_agent_prompt_and_cost_attributes() -> None:
    """Pure helpers map explicit identity and cost data without importing an SDK."""
    assert tool_attributes(name="search", call_id="call", description="Search") == {
        "gen_ai.tool.name": "search",
        "gen_ai.tool.call.id": "call",
        "gen_ai.tool.description": "Search",
    }
    assert tool_attributes(name="search") == {"gen_ai.tool.name": "search"}
    assert agent_attributes(name="agent", agent_id="id", description="Answer") == {
        "gen_ai.agent.name": "agent",
        "gen_ai.agent.id": "id",
        "gen_ai.agent.description": "Answer",
    }
    assert agent_attributes(name="agent") == {"gen_ai.agent.name": "agent"}
    assert prompt_attributes(name="prompt", version=1) == {
        "langfuse.observation.prompt.name": "prompt",
        "langfuse.observation.prompt.version": 1,
    }
    assert cost_details(input_cost=0, output_cost=0.2, total_cost=0.2) == {
        "langfuse.observation.cost_details.input": 0,
        "langfuse.observation.cost_details.output": 0.2,
        "langfuse.observation.cost_details.total": 0.2,
    }
    assert cost_details() == {}
    assert cost_details(input_cost=0.1) == {
        "langfuse.observation.cost_details.input": 0.1
    }


@mark.parametrize("value", [True, "1", -0.1, float("nan"), float("inf")])
def test_cost_validation(value: object) -> None:
    """Costs cannot be negative, non-finite, boolean, or coerced from strings."""
    with raises((TypeError, ValueError), match="input_cost"):
        cost_details(input_cost=cast(float, value))


@mark.parametrize("value", [True, "1", 0, -1])
def test_prompt_version_validation(value: object) -> None:
    """Prompt versions are positive integers, excluding bools."""
    with raises((TypeError, ValueError), match="version"):
        prompt_attributes(name="prompt", version=cast(int, value))


def test_new_identity_helpers_reject_blank_names() -> None:
    """Optional identity fields still require meaningful text when supplied."""
    with raises(ValueError, match="name"):
        tool_attributes(name=" ")
    with raises(ValueError, match="call.id"):
        tool_attributes(name="tool", call_id="")
    with raises(ValueError, match="description"):
        tool_attributes(name="tool", description=" ")
    with raises(ValueError, match="id"):
        agent_attributes(name="agent", agent_id="")
    with raises(ValueError, match="name"):
        prompt_attributes(name="", version=1)
