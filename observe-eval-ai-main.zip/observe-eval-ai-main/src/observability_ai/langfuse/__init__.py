"""Optional Langfuse-native clients, evaluation workflows, and managed prompts.

Import this subpackage only when the ``langfuse`` extra is installed. Importing
the core package never imports the SDK or constructs a client.
"""

try:
    from langfuse import Langfuse as _Langfuse
    from langfuse import propagate_attributes
except ModuleNotFoundError as exc:
    if exc.name is None or exc.name.split(".")[0] != "langfuse":
        raise
    raise ImportError(
        "Langfuse SDK support is not installed; install observe-eval-ai[langfuse]"
    ) from exc

from .batch import BatchEvaluation
from .client import build_langfuse_client
from .datasets import DatasetItemRecord, DatasetRepository, load_jsonl
from .experiments import (
    ExperimentReport,
    ExperimentRunner,
    RegressionDetected,
    RegressionGate,
    RunEvaluator,
)
from .prompts import PromptRepository
from .scores import ScoreDataType, Scorer

# Preserve the SDK's overloads and require the application-owned client first.
start_as_current_observation = _Langfuse.start_as_current_observation

__all__ = [
    "BatchEvaluation",
    "DatasetItemRecord",
    "DatasetRepository",
    "ExperimentReport",
    "ExperimentRunner",
    "PromptRepository",
    "RegressionDetected",
    "RegressionGate",
    "RunEvaluator",
    "ScoreDataType",
    "Scorer",
    "build_langfuse_client",
    "load_jsonl",
    "propagate_attributes",
    "start_as_current_observation",
]
