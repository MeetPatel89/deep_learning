"""Canonical hash partitions with a disk-backed fallback for skewed buckets."""

import math
import pickle
import sqlite3
from collections import defaultdict
from pathlib import Path

import polars as pl

from qa_mcp_server.engine.compare import (
    ROW_INDEX,
    Record,
    canonicalize,
    compare_frames,
    key_expressions,
    row_record,
)
from qa_mcp_server.engine.planner import Plan
from qa_mcp_server.models import CompareOptions


def canonical_batches(side, plan: Plan, actual: bool = False):
    for frame in side.batches():
        yield canonicalize(frame, plan.schema, plan.rename if actual else {})


def empty_frame(plan: Plan):
    return pl.DataFrame(schema={**plan.schema, ROW_INDEX: pl.UInt64})


def _combined(frames, plan: Plan):
    frames = list(frames)
    return pl.concat(frames, how="vertical") if frames else empty_frame(plan)


def _parquet_batches(paths: list[Path], batch_size: int):
    for path in paths:
        yield from pl.scan_parquet(path).collect_batches(chunk_size=batch_size, engine="streaming")


def _key_bytes(values):
    # Dtypes have already been harmonized, so serialization is stable across sides.
    return pickle.dumps(
        tuple(
            ("__qa_nan__",) if isinstance(value, float) and math.isnan(value) else value
            for value in values
        ),
        protocol=5,
    )


def _disk_compare(
    expected_paths: list[Path],
    actual_paths: list[Path],
    plan: Plan,
    options: CompareOptions,
    directory: Path,
):
    """SQLite sorts keys and occurrences on disk, including a single enormous key group."""
    columns = list(plan.schema)
    keys = options.primary_keys or columns
    multiset = not options.primary_keys
    database = directory / "skew.sqlite"
    directory.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(database)
    try:
        connection.execute("PRAGMA temp_store=FILE")
        connection.execute(f"PRAGMA cache_size=-{max(1, plan.budget_bytes // 1024 // 8)}")
        for side, paths in (("e", expected_paths), ("a", actual_paths)):
            connection.execute(f"CREATE TABLE {side}(k BLOB, d BLOB, seq INTEGER, payload BLOB)")
            for frame in _parquet_batches(paths, 1024):
                normalized = frame.select(*key_expressions(plan.schema, keys, options))

                def rows(frame=frame, normalized=normalized, side=side):
                    for row, normalized_key in zip(
                        frame.iter_rows(named=True), normalized.iter_rows(), strict=True
                    ):
                        duplicate_key = _key_bytes(normalized_key)
                        unmatched = (
                            not options.treat_null_as_equal and None in normalized_key
                        ) or (multiset and bool(plan.schema_difference))
                        key = (
                            _key_bytes((duplicate_key, side, row[ROW_INDEX]))
                            if unmatched
                            else duplicate_key
                        )
                        payload = {column: row[column] for column in columns}
                        yield key, duplicate_key, row[ROW_INDEX], pickle.dumps(payload, protocol=5)

                connection.executemany(f"INSERT INTO {side} VALUES (?, ?, ?, ?)", rows())
            connection.execute(f"CREATE INDEX {side}_key ON {side}(k, seq)")
            connection.execute(f"CREATE INDEX {side}_duplicate ON {side}(d)")
            if not multiset:
                duplicates = connection.execute(
                    f"SELECT {side}.payload, counts.n FROM {side} JOIN "
                    f"(SELECT d, COUNT(*) n FROM {side} GROUP BY d HAVING COUNT(*) > 1) counts "
                    f"ON {side}.d = counts.d ORDER BY {side}.seq"
                )
                for payload, count in duplicates:
                    values = pickle.loads(payload)
                    yield Record(
                        "duplicate_key",
                        values if side == "e" else None,
                        values if side == "a" else None,
                        [],
                        side="expected" if side == "e" else "actual",
                        duplicate_count=count,
                    )
                connection.execute(
                    f"CREATE TABLE {side}rank AS SELECT k, payload, "
                    f"ROW_NUMBER() OVER (PARTITION BY k ORDER BY seq) occurrence FROM {side}"
                )
                connection.execute(f"CREATE INDEX {side}_rank ON {side}rank(k, occurrence)")
            else:
                # SQLite's bare-column MIN rule returns the first input occurrence's payload.
                connection.execute(
                    f"CREATE TABLE {side}rank AS SELECT k, payload, MIN(seq), COUNT(*) n "
                    f"FROM {side} GROUP BY k"
                )
                connection.execute(f"CREATE INDEX {side}_rank ON {side}rank(k)")
            connection.commit()
        predicate = "e.k = a.k" + (" AND e.occurrence = a.occurrence" if not multiset else "")
        selection = "e.payload, a.payload" + (", e.n, a.n" if multiset else "")
        query = (
            f"SELECT {selection} FROM erank e LEFT JOIN arank a ON {predicate} "
            f"UNION ALL SELECT {selection} FROM arank a LEFT JOIN erank e "
            f"ON {predicate} WHERE e.k IS NULL"
        )
        for result in connection.execute(query):
            e = pickle.loads(result[0]) if result[0] is not None else None
            a = pickle.loads(result[1]) if result[1] is not None else None
            if not multiset:
                yield row_record(e, a, columns, keys, options, plan.schema_difference)
            else:
                ec, ac = result[2] or 0, result[3] or 0
                if common := min(ec, ac):
                    yield Record("matched", e, a, [], common)
                if ec > ac:
                    yield Record("missing_in_actual", e, None, [], ec - ac)
                if ac > ec:
                    yield Record("extra_in_actual", None, a, [], ac - ec)
    finally:
        connection.close()
        database.unlink(missing_ok=True)


def execute_plan(plan: Plan, options: CompareOptions, directory: Path, metrics: dict):
    if not plan.schema:
        return
    if not plan.partitioned:
        yield from compare_frames(
            _combined(canonical_batches(plan.expected, plan), plan),
            _combined(canonical_batches(plan.actual, plan, True), plan),
            plan.schema,
            options,
            plan.schema_difference,
        )
        return
    paths = {"expected": defaultdict(list), "actual": defaultdict(list)}
    sizes = defaultdict(int)
    keys = options.primary_keys or list(plan.schema)
    written = {"expected": 0, "actual": 0}
    for name, side in (("expected", plan.expected), ("actual", plan.actual)):
        for batch in canonical_batches(side, plan, name == "actual"):
            if batch.is_empty():
                continue
            buckets = batch.select(*key_expressions(plan.schema, keys, options)).hash_rows(seed=0)
            batch = batch.with_columns((buckets % plan.partitions).alias("__qa_bucket"))
            for bucket, frame in batch.partition_by("__qa_bucket", as_dict=True).items():
                number = bucket[0]
                frame = frame.drop("__qa_bucket")
                target = directory / name / f"part_{number:05d}"
                target.mkdir(parents=True, exist_ok=True)
                path = target / f"batch_{len(paths[name][number]):08d}.parquet"
                frame.write_parquet(path)
                paths[name][number].append(path)
                sizes[number] += frame.estimated_size()
                written[name] += frame.height
    if written != {"expected": plan.expected.row_count, "actual": plan.actual.row_count}:
        raise RuntimeError("Partition completeness check failed: input rows were lost")
    metrics["disk_fallback_buckets"] = 0
    for number in sorted(sizes):
        e_paths, a_paths = paths["expected"][number], paths["actual"][number]
        if not e_paths and not a_paths:
            continue
        if sizes[number] > max(1, plan.budget_bytes // 4):
            metrics["disk_fallback_buckets"] += 1
            yield from _disk_compare(e_paths, a_paths, plan, options, directory)
        else:
            yield from compare_frames(
                _combined((pl.read_parquet(path) for path in e_paths), plan),
                _combined((pl.read_parquet(path) for path in a_paths), plan),
                plan.schema,
                options,
                plan.schema_difference,
            )
