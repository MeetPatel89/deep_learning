"""Compatibility entry point; prefer `uv run --package qa-mcp-server qa-mcp-server`."""

from qa_mcp_server.server import main

if __name__ == "__main__":
    main()
