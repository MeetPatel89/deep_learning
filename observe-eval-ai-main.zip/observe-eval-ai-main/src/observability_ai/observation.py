"""Immutable handles for updating observations owned by Telemetry."""

from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import UTC, datetime
from json import dumps
from typing import Literal

from opentelemetry.trace import Span
from opentelemetry.util.types import Attributes, AttributeValue

from .config import _validate_text
from .content import ContentCapturePolicy
from .genai import cost_details, prompt_attributes, usage_attributes

type ObservationLevel = Literal["DEBUG", "DEFAULT", "WARNING", "ERROR"]


@dataclass(frozen=True, slots=True)
class Observation:
    """Update a span without owning its lifetime; use ``span`` for raw OTel APIs.

    Handle IDs remain available after completion and on valid unsampled spans.
    Input/output updates obey the injected capture policy and recording state.
    Other attributes and exception details are explicitly supplied, ungated data.
    """

    span: Span
    _content_capture: ContentCapturePolicy = field(
        default_factory=ContentCapturePolicy, repr=False
    )

    @property
    def trace_id(self) -> str | None:
        """The trace's 32-digit hex ID, or None for an invalid context."""
        context = self.span.get_span_context()
        return f"{context.trace_id:032x}" if context.is_valid else None

    @property
    def observation_id(self) -> str | None:
        """The span's 16-digit hex ID, or None for an invalid context."""
        context = self.span.get_span_context()
        return f"{context.span_id:016x}" if context.is_valid else None

    def set_attribute(self, key: str, value: AttributeValue) -> None:
        """Set an explicitly supplied OTel attribute."""
        self.span.set_attribute(key, value)

    def set_attributes(self, attributes: Mapping[str, AttributeValue]) -> None:
        """Set explicitly supplied OTel attributes."""
        self.span.set_attributes(attributes)

    def add_event(
        self, name: str, attributes: Attributes = None, timestamp: int | None = None
    ) -> None:
        """Add a raw OTel span event, optionally with a nanosecond timestamp."""
        self.span.add_event(name, attributes=attributes, timestamp=timestamp)

    def record_exception(
        self,
        exception: BaseException,
        attributes: Attributes = None,
        timestamp: int | None = None,
        escaped: bool = False,
    ) -> None:
        """Record exception details using standard OTel behavior."""
        self.span.record_exception(
            exception, attributes=attributes, timestamp=timestamp, escaped=escaped
        )

    def set_input(self, value: object) -> None:
        """Snapshot input through the capture policy on a recording span."""
        if self.span.is_recording():
            self.span.set_attributes(
                self._content_capture.as_otel_attributes(input=value)
            )

    def set_output(self, value: object) -> None:
        """Snapshot output through the capture policy on a recording span."""
        if self.span.is_recording():
            self.span.set_attributes(
                self._content_capture.as_otel_attributes(output=value)
            )

    def set_metadata(self, mapping: Mapping[str, AttributeValue]) -> None:
        """Attach flat OTel values as filterable Langfuse observation metadata."""
        attributes: dict[str, AttributeValue] = {}
        for key, value in mapping.items():
            _validate_text("metadata key", key)
            attributes[f"langfuse.observation.metadata.{key}"] = value
        self.set_attributes(attributes)

    def set_level(
        self, level: ObservationLevel, status_message: str | None = None
    ) -> None:
        """Set Langfuse severity and a message independently of OTel status."""
        if level not in ("DEBUG", "DEFAULT", "WARNING", "ERROR"):
            raise ValueError("level must be DEBUG, DEFAULT, WARNING, or ERROR")
        attributes: dict[str, AttributeValue] = {"langfuse.observation.level": level}
        if status_message is not None:
            _validate_text("status_message", status_message)
            attributes["langfuse.observation.status_message"] = status_message
        self.set_attributes(attributes)


@dataclass(frozen=True, slots=True)
class Generation(Observation):
    """An observation with model, usage, cost, and prompt attribution updates."""

    def set_model(self, request_model: str, response_model: str | None = None) -> None:
        """Set the requested model and, when known, the returned model."""
        _validate_text("request_model", request_model)
        attributes: dict[str, AttributeValue] = {"gen_ai.request.model": request_model}
        if response_model is not None:
            _validate_text("response_model", response_model)
            attributes["gen_ai.response.model"] = response_model
        self.set_attributes(attributes)

    def set_model_parameters(self, mapping: Mapping[str, object]) -> None:
        """Snapshot explicit JSON-serializable model parameters."""
        self.set_attribute(
            "langfuse.observation.model.parameters",
            dumps(dict(mapping), ensure_ascii=False, allow_nan=False),
        )

    def set_usage(
        self, input_tokens: int, output_tokens: int, cached_tokens: int = 0
    ) -> None:
        """Replace usage totals, including zero cache reads on repeated updates."""
        attributes = usage_attributes(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cached_tokens=cached_tokens,
        )
        # OTel cannot remove an attribute; reset a previous cache count explicitly.
        attributes["gen_ai.usage.cache_read.input_tokens"] = cached_tokens
        self.set_attributes(attributes)

    def mark_completion_start(self) -> None:
        """Record the current UTC time as the start of model output."""
        self.set_attribute(
            "langfuse.observation.completion_start_time", datetime.now(UTC).isoformat()
        )

    def link_prompt(self, name: str, version: int) -> None:
        """Link this generation to a versioned Langfuse prompt without an SDK call."""
        self.set_attributes(prompt_attributes(name=name, version=version))

    def set_cost(
        self,
        *,
        input_cost: float | None = None,
        output_cost: float | None = None,
        total_cost: float | None = None,
    ) -> None:
        """Record explicit USD costs without estimating omitted values."""
        self.set_attributes(
            cost_details(
                input_cost=input_cost, output_cost=output_cost, total_cost=total_cost
            )
        )


__all__ = ["Generation", "Observation", "ObservationLevel"]
