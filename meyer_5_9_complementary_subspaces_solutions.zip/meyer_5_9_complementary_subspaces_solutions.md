---
title: "Meyer Section 5.9: Complementary Subspaces"
subtitle: "Detailed Solutions and a Time-Efficient Study Plan"
author: ""
date: ""
geometry: margin=0.82in
fontsize: 10pt
linestretch: 1.08
colorlinks: true
linkcolor: blue
urlcolor: blue
header-includes:
  - \usepackage{microtype}
  - \usepackage{mathtools}
  - \usepackage{amssymb}
  - \usepackage{booktabs}
  - \usepackage{longtable}
  - \usepackage{array}
  - \usepackage{enumitem}
  - \usepackage{needspace}
  - \setlength{\emergencystretch}{3em}
  - \renewcommand{\arraystretch}{1.15}
  - \newcommand{\R}{\mathbb{R}}
  - \newcommand{\C}{\mathbb{C}}
  - \newcommand{\Range}{\mathcal{R}}
  - \newcommand{\Null}{\mathcal{N}}
  - \newcommand{\Span}{\operatorname{span}}
---

# Meyer Section 5.9: Complementary Subspaces

**Source section:** Carl D. Meyer, *Matrix Analysis and Applied Linear Algebra*, Section 5.9, "Complementary Subspaces," pp. 383-393.

**Exercise range solved:** 5.9.1-5.9.20, all parts.

> **Copyright-conscious note.** The exercise statements below are restated only briefly. The mathematical data needed for the solutions are retained, but the textbook's surrounding prose is not reproduced.

## Source and notation notes

Throughout, \(\Range(T)\) and \(\Null(T)\) denote the range and nullspace of a linear operator or matrix \(T\). A projector is an idempotent linear operator: \(P^2=P\). If \(V=X\oplus Y\), the projector onto \(X\) along \(Y\) has range \(X\) and nullspace \(Y\).

Three source details deserve explicit attention.

1. **Exercise 5.9.15 contains a typographical error in the printed display.** In the fourth block identity, the lower-right block must be \(A_{22}\), not \(A_{12}\). The explanatory display immediately following the exercise also labels that block \(A_{22}\). The solution below states and proves the dimensionally and algebraically correct identity.
2. **Exercise 5.9.10 implicitly assumes \(n\ge 2\).** If \(n=1\), the condition \(v^Tu=1\) forces \(uv^T=I\), so \(\|I-uv^T\|_2=0\ne 1=\|uv^T\|_2\). The intended rank-one, nonidentity projector case is \(n\ge 2\).
3. **Exercise 5.9.5 distinguishes a concatenated family from an ordinary set union.** A concatenated family retains repeated vectors; an ordinary set union removes duplicates. This distinction is exactly what part (b) is designed to expose.

# Recommended Study Plan

## Section strategic importance: core

Complementary subspaces and projectors are structural tools, not isolated definitions. They support the range-nullspace decomposition in Section 5.10, orthogonal decomposition, generalized inverses, singular value decomposition, least squares, and block representations of operators. The same reasoning reappears in statistics and machine learning whenever a vector is decomposed into signal and residual components, parameters and nonidentifiable directions, or fitted and unexplained parts.

## Concept clusters

1. **Direct sums and uniqueness:** 5.9.1-5.9.5, 5.9.14.
2. **Projector range-nullspace structure:** 5.9.6-5.9.7, 5.9.11-5.9.13.
3. **Norms and rank-one projectors:** 5.9.8-5.9.10.
4. **Block and full-rank representations:** 5.9.15-5.9.16.
5. **Algebra of multiple projectors:** 5.9.17-5.9.19.
6. **Pseudoinverses and affine solution sets:** 5.9.20.

\begingroup\small

| Exercise | Recommendation | Timebox | Concept cluster | Marginal reason |
|---:|:---|---:|:---|:---|
| 5.9.1 | `solve_fully` | 30 min | Direct sums; projector computation | Best computational anchor: verifies complementarity, constructs both projectors, and checks all range/nullspace identities. |
| 5.9.2 | `read_explanation_only` | 3 min | Direct-sum construction | Almost entirely subsumed by 5.9.1 and 5.9.5; a brief mental construction is enough. |
| 5.9.3 | `attempt_then_read` | 8 min | Failure of uniqueness | Short counterexample with high diagnostic value; finding one matters more than polishing prose. |
| 5.9.4 | `attempt_then_read` | 12 min | Canonical symmetric/skew decomposition | Important reusable decomposition, but it largely revisits Exercise 3.2.6. |
| 5.9.5 | `solve_fully` | 25 min | Bases, intersections, and subtle set notation | High-value proof and a useful warning about duplicate vectors disappearing under set union. |
| 5.9.6 | `read_explanation_only` | 3 min | Fixed-point characterization | Foundational but immediate once idempotence is understood; 5.9.7 supplies the richer active test. |
| 5.9.7 | `attempt_then_read` | 10 min | Range/nullspace identities | Core identities, but much of the proof overlaps 5.9.6 and the definition of a projector. |
| 5.9.8 | `solve_fully` | 25 min | Projector norm and orthogonality | Excellent conceptual anchor linking operator norm, geometry, and orthogonal projection. |
| 5.9.9 | `read_explanation_only` | 3 min | Complementary projector norms | A short consequence of 5.9.7-5.9.8 and the symmetry of the angle between subspaces. |
| 5.9.10 | `attempt_then_read` | 18 min | Rank-one projectors and matrix norms | Strong transfer to low-rank methods; time-box the norm proof rather than overworking it. |
| 5.9.11 | `read_explanation_only` | 4 min | Coordinate projection algorithm | Useful, but computationally redundant after 5.9.1 and formula (5.9.12). |
| 5.9.12 | `solve_fully` | 30 min | Comparing projectors by range/nullspace | Central algebraic diagnostic; later projector identities become much easier after this is internalized. |
| 5.9.13 | `attempt_then_read` | 12 min | Rank-trace identity | Important invariant with statistical "degrees of freedom" relevance, but the proof is compact. |
| 5.9.14 | `solve_fully` | 40 min | Multiway direct sums | Major proof anchor: develops induction-free decomposition reasoning and basis synthesis. |
| 5.9.15 | `solve_fully` | 30 min | Block operator decomposition | Very high transfer to block matrices, invariant subspaces, numerical methods, and latent-component models. |
| 5.9.16 | `attempt_then_read` | 15 min | Full-rank factorization of a projector | Valuable bridge to low-rank factorizations, but it follows efficiently from the block basis formula. |
| 5.9.17 | `solve_fully` | 35 min | Sum of projectors | Best representative of projector algebra; combines idempotence, range sums, and nullspace intersections. |
| 5.9.18 | `attempt_then_read` | 15 min | Difference of projectors | Useful extension of 5.9.17; discovering the complement trick is the main benefit. |
| 5.9.19 | `attempt_then_read` | 15 min | Product of commuting projectors | High-transfer intersection argument, but shorter than the sum theorem once the pattern is known. |
| 5.9.20 | `solve_fully` | 55 min | Inner/reflexive pseudoinverses | Capstone problem connecting projectors, consistent systems, complements, and generalized inverses. |

\endgroup

## Full-solve anchors

\[
\boxed{5.9.1,\ 5.9.5,\ 5.9.8,\ 5.9.12,\ 5.9.14,\ 5.9.15,\ 5.9.17,\ 5.9.20}
\]

## Attempt-then-read exercises

\[
\boxed{5.9.3,\ 5.9.4,\ 5.9.7,\ 5.9.10,\ 5.9.13,\ 5.9.16,\ 5.9.18,\ 5.9.19}
\]

## Read-explanation-only exercises

\[
\boxed{5.9.2,\ 5.9.6,\ 5.9.9,\ 5.9.11}
\]

## Cumulative review anchors

- **5.9.1:** recompute \(P\) and \(Q\) from the combined basis without looking.
- **5.9.12:** reproduce the range/nullspace equivalences from first principles.
- **5.9.20:** reproduce the proof skeleton showing \(XA=Q\), \(AX=P\), and uniqueness.

## Estimated active problem-solving time

The recommended timeboxes total about **388 minutes**, or **6 hours 28 minutes**. This is intentionally near the upper end for one section because the set is a structural bridge to generalized inverses and orthogonal decomposition.

## Stopping criterion

Move on when you can do all of the following without notes:

1. State three equivalent characterizations of \(V=X\oplus Y\).
2. Construct the projector onto \(X\) along \(Y\) from bases.
3. Recover \(\Range(P)\) and \(\Null(P)\) from an idempotent \(P\).
4. Explain why \(\|P\|_2=1\) characterizes orthogonal projection for \(P\ne 0\).
5. Prove one nontrivial algebraic identity involving two projectors.
6. Explain how \(I-A^{-}A\) parametrizes the homogeneous freedom in a consistent system.

# Table of Contents

- [Key concepts from Section 5.9](#key-concepts-from-section-5.9)
- [Exercise 5.9.1](#exercise-5.9.1)
- [Exercise 5.9.2](#exercise-5.9.2)
- [Exercise 5.9.3](#exercise-5.9.3)
- [Exercise 5.9.4](#exercise-5.9.4)
- [Exercise 5.9.5](#exercise-5.9.5)
- [Exercise 5.9.6](#exercise-5.9.6)
- [Exercise 5.9.7](#exercise-5.9.7)
- [Exercise 5.9.8](#exercise-5.9.8)
- [Exercise 5.9.9](#exercise-5.9.9)
- [Exercise 5.9.10](#exercise-5.9.10)
- [Exercise 5.9.11](#exercise-5.9.11)
- [Exercise 5.9.12](#exercise-5.9.12)
- [Exercise 5.9.13](#exercise-5.9.13)
- [Exercise 5.9.14](#exercise-5.9.14)
- [Exercise 5.9.15](#exercise-5.9.15)
- [Exercise 5.9.16](#exercise-5.9.16)
- [Exercise 5.9.17](#exercise-5.9.17)
- [Exercise 5.9.18](#exercise-5.9.18)
- [Exercise 5.9.19](#exercise-5.9.19)
- [Exercise 5.9.20](#exercise-5.9.20)
- [Appendix: recurring facts](#appendix-recurring-facts)

# Key concepts from Section 5.9

For subspaces \(X,Y\subseteq V\),

\[
V=X\oplus Y
\]

means simultaneously

\[
V=X+Y
\qquad\text{and}\qquad
X\cap Y=\{0\}.
\]

Equivalently, every \(v\in V\) has a unique decomposition

\[
v=x+y,\qquad x\in X,\quad y\in Y.
\]

The projector onto \(X\) along \(Y\) is the linear map \(P\) defined by

\[
P(x+y)=x.
\]

It satisfies

\[
P^2=P,\qquad
\Range(P)=X,\qquad
\Null(P)=Y,
\]

and \(I-P\) is the complementary projector onto \(Y\) along \(X\).

If \(X\in\mathbb{F}^{n\times r}\) and \(Y\in\mathbb{F}^{n\times(n-r)}\) contain basis vectors for the two complementary subspaces, then

\[
B=[X\mid Y]
\]

is nonsingular and

\[
P=[X\mid 0]B^{-1}
=
B
\begin{bmatrix}
I_r&0\\
0&0
\end{bmatrix}
B^{-1}.
\]

This similarity representation is the source of many later identities.

# Exercise 5.9.1

**Recommendation:** `solve_fully`  
**What it tests:** Complementarity, construction of oblique projectors from a combined basis, projection of a vector, idempotence, and range/nullspace verification.

**Relevant facts:** The combined basis criterion (5.9.4), the basis formula for a projector (5.9.12), and \(Q=I-P\).  
**Strategy:** Verify that \([X\mid Y]\) is nonsingular, form \(P=[X\mid0][X\mid Y]^{-1}\), and then check the defining identities directly.

Let

\[
x_1=
\begin{bmatrix}
1\\1\\1
\end{bmatrix},
\qquad
x_2=
\begin{bmatrix}
1\\2\\2
\end{bmatrix},
\qquad
y=
\begin{bmatrix}
1\\2\\3
\end{bmatrix},
\]

with \(X=\Span\{x_1,x_2\}\) and \(Y=\Span\{y\}\).

## Strategy

Place the basis vectors in the combined basis matrix

\[
B=[X\mid Y]=[x_1\mid x_2\mid y].
\]

If \(B\) is nonsingular, then its columns form a basis of \(\R^3\), so \(\R^3=X\oplus Y\). Formula (5.9.12) then gives the projector onto \(X\) along \(Y\).

## (a) Verify that \(X\) and \(Y\) are complementary

We have

\[
B=
\begin{bmatrix}
1&1&1\\
1&2&2\\
1&2&3
\end{bmatrix}.
\]

Its determinant is

\[
\begin{aligned}
\det B
&=
1\begin{vmatrix}2&2\\2&3\end{vmatrix}
-
1\begin{vmatrix}1&2\\1&3\end{vmatrix}
+
1\begin{vmatrix}1&2\\1&2\end{vmatrix}\\
&=(6-4)-(3-2)+(2-2)\\
&=2-1+0\\
&=1.
\end{aligned}
\]

Thus \(B\) is nonsingular. Hence

\[
\{x_1,x_2,y\}
\]

is a basis of \(\R^3\). The first two vectors span \(X\), and the last spans \(Y\), so every vector in \(\R^3\) has a unique representation as an \(X\)-vector plus a \(Y\)-vector. Therefore

\[
\boxed{\R^3=X\oplus Y.}
\]

## (b) Compute \(P\) and \(Q\)

Row reduction or direct inversion gives

\[
B^{-1}
=
\begin{bmatrix}
2&-1&0\\
-1&2&-1\\
0&-1&1
\end{bmatrix}.
\]

The projector onto \(X\) along \(Y\) is

\[
P=[X\mid 0]B^{-1},
\]

where

\[
[X\mid 0]
=
\begin{bmatrix}
1&1&0\\
1&2&0\\
1&2&0
\end{bmatrix}.
\]

Therefore

\[
\begin{aligned}
P
&=
\begin{bmatrix}
1&1&0\\
1&2&0\\
1&2&0
\end{bmatrix}
\begin{bmatrix}
2&-1&0\\
-1&2&-1\\
0&-1&1
\end{bmatrix}\\[2mm]
&=
\begin{bmatrix}
1&1&-1\\
0&3&-2\\
0&3&-2
\end{bmatrix}.
\end{aligned}
\]

The complementary projector onto \(Y\) along \(X\) is

\[
Q=I-P,
\]

so

\[
\begin{aligned}
Q
&=
\begin{bmatrix}
1&0&0\\
0&1&0\\
0&0&1
\end{bmatrix}
-
\begin{bmatrix}
1&1&-1\\
0&3&-2\\
0&3&-2
\end{bmatrix}\\[2mm]
&=
\begin{bmatrix}
0&-1&1\\
0&-2&2\\
0&-3&3
\end{bmatrix}.
\end{aligned}
\]

Thus

\[
\boxed{
P=
\begin{bmatrix}
1&1&-1\\
0&3&-2\\
0&3&-2
\end{bmatrix},
\qquad
Q=
\begin{bmatrix}
0&-1&1\\
0&-2&2\\
0&-3&3
\end{bmatrix}.
}
\]

A useful structural check is

\[
P+Q=I.
\]

## (c) Project \(v\) onto \(Y\) along \(X\)

Let

\[
v=
\begin{bmatrix}
2\\-1\\1
\end{bmatrix}.
\]

The projection onto \(Y\) along \(X\) is \(Qv\):

\[
\begin{aligned}
Qv
&=
\begin{bmatrix}
0&-1&1\\
0&-2&2\\
0&-3&3
\end{bmatrix}
\begin{bmatrix}
2\\-1\\1
\end{bmatrix}\\[2mm]
&=
\begin{bmatrix}
1+1\\
2+2\\
3+3
\end{bmatrix}
=
\begin{bmatrix}
2\\4\\6
\end{bmatrix}
=
2
\begin{bmatrix}
1\\2\\3
\end{bmatrix}.
\end{aligned}
\]

This is visibly in \(Y\). Therefore

\[
\boxed{\operatorname{proj}_{Y\text{ along }X}(v)=
\begin{bmatrix}
2\\4\\6
\end{bmatrix}.}
\]

For completeness, the \(X\)-component is

\[
Pv=v-Qv
=
\begin{bmatrix}
0\\-5\\-5
\end{bmatrix}
=-5(x_2-x_1)\in X.
\]

Thus the decomposition is

\[
v=
\underbrace{
\begin{bmatrix}
0\\-5\\-5
\end{bmatrix}}_{\in X}
+
\underbrace{
\begin{bmatrix}
2\\4\\6
\end{bmatrix}}_{\in Y}.
\]

## (d) Verify idempotence

Direct multiplication gives

\[
\begin{aligned}
P^2
&=
\begin{bmatrix}
1&1&-1\\
0&3&-2\\
0&3&-2
\end{bmatrix}
\begin{bmatrix}
1&1&-1\\
0&3&-2\\
0&3&-2
\end{bmatrix}\\[2mm]
&=
\begin{bmatrix}
1&1&-1\\
0&3&-2\\
0&3&-2
\end{bmatrix}
=P.
\end{aligned}
\]

Similarly,

\[
\begin{aligned}
Q^2
&=
\begin{bmatrix}
0&-1&1\\
0&-2&2\\
0&-3&3
\end{bmatrix}
\begin{bmatrix}
0&-1&1\\
0&-2&2\\
0&-3&3
\end{bmatrix}\\[2mm]
&=
\begin{bmatrix}
0&-1&1\\
0&-2&2\\
0&-3&3
\end{bmatrix}
=Q.
\end{aligned}
\]

Hence both are projectors:

\[
\boxed{P^2=P,\qquad Q^2=Q.}
\]

There is also a shorter check. Since \(Q=I-P\) and \(P^2=P\),

\[
Q^2=(I-P)^2=I-2P+P^2=I-P=Q.
\]

## (e) Verify the range and nullspace identities

### Show \(\Range(P)=X\)

Because \(P\) projects onto \(X\), we expect \(Px_i=x_i\). Indeed,

\[
Px_1=x_1,\qquad Px_2=x_2.
\]

Thus \(X\subseteq\Range(P)\).

On the other hand, the columns of \(P\) are

\[
\begin{bmatrix}1\\0\\0\end{bmatrix},
\quad
\begin{bmatrix}1\\3\\3\end{bmatrix},
\quad
\begin{bmatrix}-1\\-2\\-2\end{bmatrix}.
\]

They lie in \(X\). For example,

\[
\begin{bmatrix}1\\0\\0\end{bmatrix}=2x_1-x_2,
\qquad
\begin{bmatrix}1\\3\\3\end{bmatrix}=-x_1+2x_2,
\qquad
\begin{bmatrix}-1\\-2\\-2\end{bmatrix}=-x_2.
\]

Hence \(\Range(P)\subseteq X\). Therefore

\[
\Range(P)=X.
\]

### Show \(\Null(P)=Y\)

First,

\[
Py=0,
\]

so \(Y\subseteq\Null(P)\).

Since \(\operatorname{rank}(P)=2\), rank-nullity gives

\[
\dim\Null(P)=3-2=1.
\]

But \(Y\) is already a one-dimensional subspace contained in \(\Null(P)\). Therefore

\[
\Null(P)=Y.
\]

### Use \(Q=I-P\)

For complementary projectors,

\[
\Range(Q)=\Null(P)=Y,
\qquad
\Null(Q)=\Range(P)=X.
\]

These can also be checked directly:

\[
Qx_1=0,\qquad Qx_2=0,\qquad Qy=y.
\]

Thus

\[
\boxed{
\Range(P)=X=\Null(Q),
\qquad
\Null(P)=Y=\Range(Q).
}
\]

**Final answer.**

\[
\boxed{
P=
\begin{bmatrix}
1&1&-1\\
0&3&-2\\
0&3&-2
\end{bmatrix},
\qquad
Q=
\begin{bmatrix}
0&-1&1\\
0&-2&2\\
0&-3&3
\end{bmatrix},
\qquad
Qv=
\begin{bmatrix}
2\\4\\6
\end{bmatrix}.
}
\]

**Transfer note.** This is the finite-dimensional prototype of decomposing a signal into two modeled components. The matrix \(B^{-1}\) extracts coordinates, while \(P\) discards the \(Y\)-coordinates and reconstructs only the \(X\)-component.

# Exercise 5.9.2

**Recommendation:** `read_explanation_only`  
**What it tests:** Constructing complementary subspaces from a partition of a basis.

**Relevant facts:** Splitting any basis of \(V\) into two nonempty groups produces spans with zero intersection and total sum \(V\).  
**Strategy:** Partition the standard basis and verify the coordinate decomposition explicitly.

Take the standard basis \(e_1,\ldots,e_5\) of \(\R^5\), and define

\[
X=\Span\{e_1,e_2\},
\qquad
Y=\Span\{e_3,e_4,e_5\}.
\]

Both subspaces are nontrivial: \(X\ne\{0\}\) and \(Y\ne\{0\}\).

Every vector

\[
v=
\begin{bmatrix}
v_1\\v_2\\v_3\\v_4\\v_5
\end{bmatrix}
\]

can be written as

\[
v=
\underbrace{
\begin{bmatrix}
v_1\\v_2\\0\\0\\0
\end{bmatrix}}_{\in X}
+
\underbrace{
\begin{bmatrix}
0\\0\\v_3\\v_4\\v_5
\end{bmatrix}}_{\in Y}.
\]

Thus \(X+Y=\R^5\).

If \(z\in X\cap Y\), then the first description forces the last three coordinates of \(z\) to be zero, while the second forces the first two coordinates to be zero. Hence \(z=0\), so

\[
X\cap Y=\{0\}.
\]

Therefore

\[
\boxed{\R^5=X\oplus Y.}
\]

Equivalently, the union of the displayed bases is the standard basis of \(\R^5\).

# Exercise 5.9.3

**Recommendation:** `attempt_then_read`  
**What it tests:** Why the condition \(X\cap Y=\{0\}\) is necessary for uniqueness of a decomposition.

**Relevant facts:** A nonzero vector in \(X\cap Y\) can be moved from one component to the other without changing their sum.  
**Proof skeleton:** Choose two proper subspaces with a shared nonzero direction, then represent that shared vector once as an \(X\)-component and once as a \(Y\)-component.

Choose

\[
V=\R^3,
\qquad
X=\Span\{e_1,e_2\},
\qquad
Y=\Span\{e_2,e_3\}.
\]

Then

\[
X+Y=\Span\{e_1,e_2,e_3\}=\R^3=V.
\]

However,

\[
X\cap Y=\Span\{e_2\}\ne\{0\}.
\]

Now take \(v=e_2\). It has the two decompositions

\[
v=
\underbrace{e_2}_{x_1\in X}
+
\underbrace{0}_{y_1\in Y}
\]

and

\[
v=
\underbrace{0}_{x_2\in X}
+
\underbrace{e_2}_{y_2\in Y}.
\]

The components differ:

\[
x_1=e_2\ne 0=x_2,
\qquad
y_1=0\ne e_2=y_2.
\]

Hence

\[
\boxed{
V=X+Y\ \text{does not imply unique decompositions when }X\cap Y\ne\{0\}.
}
\]

**Learning note.** More generally, if \(0\ne w\in X\cap Y\) and \(v=x+y\), then

\[
v=(x+w)+(y-w)
\]

is another decomposition. Nonzero intersection creates a whole family of ambiguities.

# Exercise 5.9.4

**Recommendation:** `attempt_then_read`  
**What it tests:** A canonical direct-sum decomposition of all square matrices.

**Relevant facts:** \(A=(A+A^T)/2+(A-A^T)/2\), with the two summands symmetric and skew-symmetric.  
**Proof skeleton:** Establish existence by the displayed split, prove uniqueness by showing a matrix that is both symmetric and skew-symmetric must be zero, then extract the symmetric component.

Let

\[
\mathcal S=\{S\in\R^{n\times n}:S^T=S\},
\qquad
\mathcal K=\{K\in\R^{n\times n}:K^T=-K\}.
\]

## Step 1: Show every matrix lies in \(\mathcal S+\mathcal K\)

For arbitrary \(A\in\R^{n\times n}\), define

\[
S=\frac{A+A^T}{2},
\qquad
K=\frac{A-A^T}{2}.
\]

Then

\[
S^T
=
\frac{A^T+A}{2}
=S,
\]

so \(S\in\mathcal S\). Also,

\[
K^T
=
\frac{A^T-A}{2}
=-K,
\]

so \(K\in\mathcal K\).

Moreover,

\[
S+K
=
\frac{A+A^T}{2}
+
\frac{A-A^T}{2}
=A.
\]

Therefore

\[
\R^{n\times n}=\mathcal S+\mathcal K.
\]

## Step 2: Show the intersection is trivial

Suppose \(M\in\mathcal S\cap\mathcal K\). Then

\[
M^T=M
\qquad\text{and}\qquad
M^T=-M.
\]

Hence \(M=-M\), so \(2M=0\). Over \(\R\), this gives \(M=0\). Therefore

\[
\mathcal S\cap\mathcal K=\{0\}.
\]

Combining the two steps,

\[
\boxed{\R^{n\times n}=\mathcal S\oplus\mathcal K.}
\]

The projection onto \(\mathcal S\) along \(\mathcal K\) is therefore

\[
P_{\mathcal S}(A)=\frac{A+A^T}{2}.
\]

For

\[
A=
\begin{bmatrix}
1&2&3\\
4&5&6\\
7&8&9
\end{bmatrix},
\qquad
A^T=
\begin{bmatrix}
1&4&7\\
2&5&8\\
3&6&9
\end{bmatrix},
\]

we obtain

\[
\begin{aligned}
P_{\mathcal S}(A)
&=
\frac12
\begin{bmatrix}
2&6&10\\
6&10&14\\
10&14&18
\end{bmatrix}\\[2mm]
&=
\begin{bmatrix}
1&3&5\\
3&5&7\\
5&7&9
\end{bmatrix}.
\end{aligned}
\]

Thus

\[
\boxed{
\operatorname{proj}_{\mathcal S\text{ along }\mathcal K}(A)
=
\begin{bmatrix}
1&3&5\\
3&5&7\\
5&7&9
\end{bmatrix}.
}
\]

As a check, the complementary component is

\[
\frac{A-A^T}{2}
=
\begin{bmatrix}
0&-1&-2\\
1&0&-1\\
2&1&0
\end{bmatrix},
\]

which is skew-symmetric.

**Transfer note.** Splitting a matrix into symmetric and skew-symmetric parts is ubiquitous in optimization, differential equations, covariance analysis, and dynamical systems.

# Exercise 5.9.5

**Recommendation:** `solve_fully`  
**What it tests:** The exact relationship between trivial intersection and independence of concatenated bases, plus a subtle set-theoretic trap.

**Relevant facts:** A family is independent exactly when its only zero linear combination is trivial; vectors in an intersection admit representations in both bases.  
**Strategy:** Convert a dependence relation into a common vector in \(X\cap Y\), and in the reverse direction subtract the two basis representations of an intersection vector.

Let

\[
B_X=\{x_1,\ldots,x_m\},
\qquad
B_Y=\{y_1,\ldots,y_n\}
\]

be bases of \(X\) and \(Y\).

## (a) Prove the equivalence

The correct object here is the **concatenated family**

\[
(x_1,\ldots,x_m,y_1,\ldots,y_n),
\]

which retains every indexed vector.

### Forward direction

Assume

\[
X\cap Y=\{0\}.
\]

Suppose

\[
\sum_{i=1}^m \alpha_i x_i
+
\sum_{j=1}^n \beta_j y_j
=0.
\]

Rearrange:

\[
\sum_{i=1}^m \alpha_i x_i
=
-
\sum_{j=1}^n \beta_j y_j.
\]

The left side belongs to \(X\), and the right side belongs to \(Y\). Therefore their common value lies in \(X\cap Y\). Since the intersection is \(\{0\}\),

\[
\sum_{i=1}^m \alpha_i x_i=0
\qquad\text{and}\qquad
\sum_{j=1}^n \beta_j y_j=0.
\]

Because \(B_X\) and \(B_Y\) are each linearly independent,

\[
\alpha_1=\cdots=\alpha_m=0,
\qquad
\beta_1=\cdots=\beta_n=0.
\]

Hence the concatenated family is linearly independent.

### Reverse direction

Assume the concatenated family is linearly independent. Let \(z\in X\cap Y\). Since \(z\in X\),

\[
z=\sum_{i=1}^m \alpha_i x_i
\]

for some scalars \(\alpha_i\). Since \(z\in Y\),

\[
z=\sum_{j=1}^n \beta_j y_j.
\]

Subtracting gives

\[
\sum_{i=1}^m \alpha_i x_i
-
\sum_{j=1}^n \beta_j y_j
=0.
\]

Independence of the concatenated family forces all coefficients to vanish. Hence \(z=0\). Thus

\[
X\cap Y=\{0\}.
\]

Therefore

\[
\boxed{
X\cap Y=\{0\}
\iff
(x_1,\ldots,x_m,y_1,\ldots,y_n)
\text{ is linearly independent}.
}
\]

## (b) Does ordinary set-union independence imply \(X\cap Y=\{0\}\)?

No. The ordinary union \(B_X\cup B_Y\) removes duplicate vectors.

Take

\[
X=\Span\{e_1,e_2\},
\qquad
Y=\Span\{e_2,e_3\}
\subseteq\R^3,
\]

with

\[
B_X=\{e_1,e_2\},
\qquad
B_Y=\{e_2,e_3\}.
\]

As an ordinary set,

\[
B_X\cup B_Y=\{e_1,e_2,e_3\},
\]

which is linearly independent. Nevertheless,

\[
e_2\in X\cap Y,
\]

so

\[
X\cap Y=\Span\{e_2\}\ne\{0\}.
\]

Thus

\[
\boxed{\text{No.}}
\]

The concatenated family would be

\[
(e_1,e_2,e_2,e_3),
\]

and this family is dependent because it contains \(e_2\) twice. That is why part (a) and part (b) are not contradictory.

## (c) Does independence imply that \(X\) and \(Y\) are complementary?

No. Even when the concatenated bases are independent, they may fail to span the ambient space.

Let

\[
V=\R^3,
\qquad
X=\Span\{e_1\},
\qquad
Y=\Span\{e_2\}.
\]

Then

\[
B_X\cup B_Y=\{e_1,e_2\}
\]

is linearly independent, and \(X\cap Y=\{0\}\). But

\[
X+Y=\Span\{e_1,e_2\}
\ne \R^3.
\]

Therefore

\[
\boxed{\text{No; independence gives a trivial intersection but not necessarily }X+Y=V.}
\]

**Learning note.** Complementarity requires two logically separate facts:

\[
\text{no overlap}
\quad+\quad
\text{complete coverage of }V.
\]

Linear independence addresses the first; spanning addresses the second.

# Exercise 5.9.6

**Recommendation:** `read_explanation_only`  
**What it tests:** The fixed-point characterization of the range of an idempotent.

**Relevant facts:** \(x\in\Range(P)\) means \(x=Py\) for some \(y\), and a projector satisfies \(P^2=P\).  
**Strategy:** Prove the two set inclusions directly.

Let \(P\) be a projector, so \(P^2=P\). We prove

\[
\Range(P)=\{x\in V:Px=x\}.
\]

## First inclusion

Suppose \(x\in\Range(P)\). Then \(x=Py\) for some \(y\in V\). Hence

\[
Px=P(Py)=P^2y=Py=x.
\]

Thus every vector in \(\Range(P)\) is fixed by \(P\):

\[
\Range(P)\subseteq\{x:Px=x\}.
\]

## Reverse inclusion

Suppose \(Px=x\). Then \(x\) is explicitly an image under \(P\), namely

\[
x=Px.
\]

Therefore \(x\in\Range(P)\), and so

\[
\{x:Px=x\}\subseteq\Range(P).
\]

Combining the inclusions,

\[
\boxed{\Range(P)=\{x\in V:Px=x\}.}
\]

**Common pitfall.** The identity \(Px=x\) is not true for every \(x\in V\); it characterizes precisely the vectors already lying in the range.

# Exercise 5.9.7

**Recommendation:** `attempt_then_read`  
**What it tests:** Recovering the two complementary subspaces from a projector.

**Relevant facts:** \(P(x+y)=x\), \((I-P)(x+y)=y\), and the fixed points of a projector equal its range.  
**Proof skeleton:** Prove \(\Range(P)=X\) and \(\Null(P)=Y\) from the unique decomposition, then identify the other two spaces using \(I-P\).

Suppose

\[
V=X\oplus Y
\]

and \(P\) is the projector onto \(X\) along \(Y\). Every \(v\in V\) has a unique decomposition

\[
v=x+y,\qquad x\in X,\quad y\in Y,
\]

and

\[
Pv=x,\qquad (I-P)v=y.
\]

We prove

\[
\Range(P)=\Null(I-P)=X
\]

and

\[
\Range(I-P)=\Null(P)=Y.
\]

## Show \(\Range(P)=X\)

For every \(v=x+y\),

\[
Pv=x\in X,
\]

so \(\Range(P)\subseteq X\).

Conversely, if \(x\in X\), then \(x=x+0\) is its \(X\oplus Y\) decomposition. Therefore

\[
Px=x.
\]

Thus \(x\in\Range(P)\), and \(X\subseteq\Range(P)\). Hence

\[
\Range(P)=X.
\]

## Show \(\Null(I-P)=X\)

For any \(v\in V\),

\[
v\in\Null(I-P)
\iff
(I-P)v=0
\iff
Pv=v.
\]

By Exercise 5.9.6, the condition \(Pv=v\) is equivalent to \(v\in\Range(P)\). Since \(\Range(P)=X\),

\[
\Null(I-P)=X.
\]

Thus

\[
\Range(P)=\Null(I-P)=X.
\]

## Show \(\Null(P)=Y\)

If \(y\in Y\), then \(y=0+y\), so its \(X\)-component is zero:

\[
Py=0.
\]

Therefore \(Y\subseteq\Null(P)\).

Conversely, let \(v=x+y\) and suppose \(Pv=0\). Since \(Pv=x\), we get \(x=0\), so \(v=y\in Y\). Hence \(\Null(P)\subseteq Y\), and

\[
\Null(P)=Y.
\]

## Show \(\Range(I-P)=Y\)

For \(v=x+y\),

\[
(I-P)v=y\in Y,
\]

so \(\Range(I-P)\subseteq Y\). Conversely, for \(y\in Y\),

\[
(I-P)y=y,
\]

so \(y\in\Range(I-P)\). Thus

\[
\Range(I-P)=Y.
\]

Therefore

\[
\boxed{
\Range(P)=\Null(I-P)=X,
\qquad
\Range(I-P)=\Null(P)=Y.
}
\]

# Exercise 5.9.8

**Recommendation:** `solve_fully`  
**What it tests:** The geometric meaning of the operator norm of a projector.

**Relevant facts:** The induced norm is \(\|P\|_2=\max_{\|x\|_2=1}\|Px\|_2\), and \(P\) fixes its range.  
**Strategy:** Use a unit range vector for the lower bound. For equality, compare \(\|r+n\|_2\) with \(\|r\|_2\) for \(r\in\Range(P)\), \(n\in\Null(P)\).

Let \(P\ne 0\) be a projector on \(\R^n\).

## Prove \(\|P\|_2\ge 1\)

Because \(P\ne 0\), its range contains a nonzero vector \(r\). Normalize it:

\[
u=\frac{r}{\|r\|_2}.
\]

Then \(\|u\|_2=1\), and since \(u\in\Range(P)\), Exercise 5.9.6 gives

\[
Pu=u.
\]

By the definition of the induced \(2\)-norm,

\[
\|P\|_2
=
\max_{\|x\|_2=1}\|Px\|_2
\ge
\|Pu\|_2
=
\|u\|_2
=1.
\]

Therefore

\[
\boxed{\|P\|_2\ge 1.}
\]

## Characterize equality

We claim

\[
\boxed{
\|P\|_2=1
\iff
\Range(P)\perp\Null(P).
}
\]

In words: a nonzero projector has norm one exactly when it is an orthogonal projector.

### If the range and nullspace are orthogonal, then \(\|P\|_2=1\)

Write any \(x\in\R^n\) uniquely as

\[
x=r+n,
\qquad
r\in\Range(P),\quad n\in\Null(P).
\]

Then \(Px=r\). If \(r\perp n\), the Pythagorean theorem gives

\[
\|x\|_2^2
=
\|r+n\|_2^2
=
\|r\|_2^2+\|n\|_2^2
\ge
\|r\|_2^2
=
\|Px\|_2^2.
\]

Hence

\[
\|Px\|_2\le \|x\|_2
\]

for every \(x\), so \(\|P\|_2\le 1\). Together with the previously proved lower bound,

\[
\|P\|_2=1.
\]

### If \(\|P\|_2=1\), then the range and nullspace are orthogonal

Take arbitrary

\[
r\in\Range(P),
\qquad
n\in\Null(P).
\]

For every real scalar \(t\),

\[
P(r+tn)=Pr+tPn=r.
\]

Since \(\|P\|_2=1\),

\[
\|r\|_2
=
\|P(r+tn)\|_2
\le
\|r+tn\|_2.
\]

Squaring,

\[
\|r\|_2^2
\le
\|r\|_2^2+2t\,r^Tn+t^2\|n\|_2^2,
\]

so

\[
0\le 2t\,r^Tn+t^2\|n\|_2^2
\qquad\text{for every }t\in\R.
\]

If \(n=0\), orthogonality is automatic. If \(n\ne 0\), the quadratic on the right has minimum at

\[
t_*=-\frac{r^Tn}{\|n\|_2^2}.
\]

At that value,

\[
2t_*r^Tn+t_*^2\|n\|_2^2
=
-\frac{(r^Tn)^2}{\|n\|_2^2}.
\]

This can be nonnegative only if \(r^Tn=0\). Since \(r\) and \(n\) were arbitrary,

\[
\Range(P)\perp\Null(P).
\]

Thus the characterization is proved:

\[
\boxed{
\|P\|_2=1
\text{ exactly when }P\text{ projects orthogonally onto its range}.
}
\]

This includes \(P=I\): its nullspace is \(\{0\}\), which is orthogonal to every subspace.

**Transfer note.** Oblique projectors can amplify perturbations because their norm can be much larger than one. Near-parallel complementary subspaces produce large projector norms, a conditioning phenomenon that recurs in regression, subspace estimation, and numerical algorithms.

# Exercise 5.9.9

**Recommendation:** `read_explanation_only`  
**What it tests:** Symmetry between a projector and its complementary projector.

**Relevant facts:** \(\Range(I-P)=\Null(P)\), \(\Null(I-P)=\Range(P)\), and (5.9.18) relates projector norm to the angle between these subspaces.  
**Strategy:** Observe that swapping the two complementary subspaces leaves the angle unchanged.

Assume \(P\ne 0\) and \(P\ne I\). Then both \(\Range(P)\) and \(\Null(P)\) are nonzero. Let \(\theta\) be the angle between these complementary subspaces.

Section 5.9 gives

\[
\sin\theta=\frac{1}{\|P\|_2}.
\]

Now \(I-P\) is the complementary projector, and Exercise 5.9.7 gives

\[
\Range(I-P)=\Null(P),
\qquad
\Null(I-P)=\Range(P).
\]

Swapping the two subspaces does not change their angle. Therefore the same \(\theta\) satisfies

\[
\sin\theta=\frac{1}{\|I-P\|_2}.
\]

Hence

\[
\frac{1}{\|P\|_2}
=
\frac{1}{\|I-P\|_2},
\]

and therefore

\[
\boxed{\|I-P\|_2=\|P\|_2.}
\]

The exclusions are necessary. If \(P=0\), then \(\|P\|_2=0\) but \(\|I-P\|_2=1\); if \(P=I\), the roles reverse.

# Exercise 5.9.10

**Recommendation:** `attempt_then_read`  
**What it tests:** Rank-one projectors and exact formulas for induced and Frobenius norms.

**Relevant facts:** \(uv^Tuv^T=u(v^Tu)v^T\), the Cauchy-Bunyakovsky-Schwarz inequality, and the rank-one Frobenius formula.  
**Proof skeleton:** First recognize \(uv^T\) as a projector, use Exercise 5.9.9 for its complement, then prove the two norm formulas by upper bounds with explicit equality cases.

Assume \(n\ge 2\) and let \(u,v\in\R^{n\times 1}\) satisfy

\[
v^Tu=1.
\]

Define

\[
P=uv^T.
\]

## Step 1: Show \(P\) is a projector

We have

\[
P^2
=
(uv^T)(uv^T)
=
u(v^Tu)v^T
=
u(1)v^T
=
uv^T
=
P.
\]

Thus \(P\) is idempotent and hence a projector.

Because \(v^Tu=1\), neither \(u\) nor \(v\) is zero. Thus \(\operatorname{rank}(P)=1\). For \(n\ge 2\), \(P\ne I\). Exercise 5.9.9 therefore gives

\[
\boxed{\|I-uv^T\|_2=\|uv^T\|_2.}
\]

## Step 2: Compute \(\|uv^T\|_2\)

For every unit vector \(x\),

\[
uv^Tx=u(v^Tx),
\]

so

\[
\|uv^Tx\|_2
=
\|u\|_2\,|v^Tx|.
\]

By the Cauchy-Bunyakovsky-Schwarz inequality,

\[
|v^Tx|
\le
\|v\|_2\|x\|_2
=
\|v\|_2.
\]

Therefore

\[
\|uv^Tx\|_2
\le
\|u\|_2\|v\|_2
\]

for every \(\|x\|_2=1\), and hence

\[
\|uv^T\|_2
\le
\|u\|_2\|v\|_2.
\]

Equality is attained at

\[
x=\frac{v}{\|v\|_2}.
\]

Indeed,

\[
\begin{aligned}
\left\|uv^T\frac{v}{\|v\|_2}\right\|_2
&=
\left\|u\frac{v^Tv}{\|v\|_2}\right\|_2\\
&=
\left\|u\frac{\|v\|_2^2}{\|v\|_2}\right\|_2\\
&=
\|u\|_2\|v\|_2.
\end{aligned}
\]

Thus

\[
\boxed{\|uv^T\|_2=\|u\|_2\|v\|_2.}
\]

## Step 3: Compute the Frobenius norm

The \((i,j)\)-entry of \(uv^T\) is \(u_iv_j\). Therefore

\[
\begin{aligned}
\|uv^T\|_F^2
&=
\sum_{i=1}^n\sum_{j=1}^n |u_iv_j|^2\\
&=
\sum_{i=1}^n |u_i|^2
\sum_{j=1}^n |v_j|^2\\
&=
\|u\|_2^2\|v\|_2^2.
\end{aligned}
\]

Taking nonnegative square roots gives

\[
\boxed{\|uv^T\|_F=\|u\|_2\|v\|_2.}
\]

Combining all results,

\[
\boxed{
\|I-uv^T\|_2
=
\|uv^T\|_2
=
\|u\|_2\|v\|_2
=
\|uv^T\|_F
\qquad(n\ge 2).
}
\]

## Edge case

For \(n=1\), \(v^Tu=1\) implies \(uv^T=I\), so

\[
\|I-uv^T\|_2=0
\quad\text{while}\quad
\|uv^T\|_2=1.
\]

Thus the first equality in the printed exercise requires the intended nonidentity case \(n\ge 2\).

**Transfer note.** The identity

\[
\|uv^T\|_2=\|uv^T\|_F=\|u\|_2\|v\|_2
\]

is a fundamental rank-one fact used in low-rank approximation, matrix perturbation bounds, and gradient calculations.

# Exercise 5.9.11

**Recommendation:** `read_explanation_only`  
**What it tests:** Extracting a projection from coordinates in the combined basis.

**Relevant facts:** \(z=B^{-1}v\) is the coordinate vector of \(v\) in the combined basis, and \(B=[X\mid Y]\).  
**Strategy:** Partition the coordinate vector and read off the \(X\)-component.

Let

\[
B=[X\mid Y]
\]

be nonsingular, with the columns of \(X\) and \(Y\) forming bases for complementary subspaces \(X\) and \(Y\), respectively.

Solve

\[
Bz=v.
\]

Since \(B\) is nonsingular,

\[
z=B^{-1}v.
\]

Partition the coordinate vector according to the two basis blocks:

\[
z=
\begin{bmatrix}
z_1\\z_2
\end{bmatrix}.
\]

Then

\[
\begin{aligned}
v
&=Bz\\
&=
[X\mid Y]
\begin{bmatrix}
z_1\\z_2
\end{bmatrix}\\
&=Xz_1+Yz_2.
\end{aligned}
\]

Here \(Xz_1\in X\) and \(Yz_2\in Y\). Since \(X\) and \(Y\) are complementary, this is the unique \(X+Y\) decomposition of \(v\). Therefore the \(X\)-component is

\[
\boxed{p=Xz_1.}
\]

Equivalently, using the projector formula,

\[
\begin{aligned}
Pv
&=[X\mid 0]B^{-1}v\\
&=[X\mid 0]z\\
&=
[X\mid 0]
\begin{bmatrix}
z_1\\z_2
\end{bmatrix}\\
&=Xz_1.
\end{aligned}
\]

**Learning note.** The two-step algorithm is often preferable to explicitly forming \(P\). Solving a linear system is usually more stable and efficient than computing an inverse.

# Exercise 5.9.12

**Recommendation:** `solve_fully`  
**What it tests:** Characterizing equality of projector ranges or nullspaces through multiplication identities.

**Relevant facts:** Projectors fix their ranges; a product identity such as \(PQ=Q\) is equivalent to a range inclusion \(\Range(Q)\subseteq\Range(P)\).  
**Strategy:** Translate equal ranges or nullspaces into mutual inclusions, then use the resulting product rules to prove idempotence of the affine combination.

Let \(P\) and \(Q\) be projectors.

## (a) Prove the range criterion

We prove

\[
\Range(P)=\Range(Q)
\iff
PQ=Q\ \text{and}\ QP=P.
\]

### Forward direction

Assume

\[
\Range(P)=\Range(Q).
\]

For arbitrary \(x\), the vector \(Qx\) lies in \(\Range(Q)=\Range(P)\). A projector fixes every vector in its range, so

\[
P(Qx)=Qx.
\]

Since this holds for every \(x\),

\[
PQ=Q.
\]

Similarly, \(Px\in\Range(P)=\Range(Q)\), so \(Q(Px)=Px\) for every \(x\), which gives

\[
QP=P.
\]

### Reverse direction

Assume

\[
PQ=Q
\qquad\text{and}\qquad
QP=P.
\]

Take \(y\in\Range(Q)\). Then \(y=Qx\) for some \(x\), and

\[
y=Qx=PQx=P(Qx)\in\Range(P).
\]

Hence

\[
\Range(Q)\subseteq\Range(P).
\]

Likewise, if \(y\in\Range(P)\), then \(y=Px\), and

\[
y=Px=QPx=Q(Px)\in\Range(Q).
\]

Thus

\[
\Range(P)\subseteq\Range(Q).
\]

Therefore

\[
\boxed{
\Range(P)=\Range(Q)
\iff
PQ=Q,\quad QP=P.
}
\]

## (b) Prove the nullspace criterion

We prove

\[
\Null(P)=\Null(Q)
\iff
PQ=P\ \text{and}\ QP=Q.
\]

### Forward direction

Assume

\[
\Null(P)=\Null(Q).
\]

For arbitrary \(x\), observe that

\[
x-Qx=(I-Q)x.
\]

Since \(Q\) is a projector,

\[
Q(I-Q)=Q-Q^2=0,
\]

so \((I-Q)x\in\Null(Q)=\Null(P)\). Hence

\[
P(x-Qx)=0,
\]

which gives

\[
Px=PQx.
\]

Therefore

\[
PQ=P.
\]

Interchanging \(P\) and \(Q\) yields

\[
QP=Q.
\]

### Reverse direction

Assume

\[
PQ=P
\qquad\text{and}\qquad
QP=Q.
\]

If \(x\in\Null(Q)\), then \(Qx=0\), so

\[
Px=PQx=0.
\]

Thus \(\Null(Q)\subseteq\Null(P)\).

If \(x\in\Null(P)\), then \(Px=0\), so

\[
Qx=QPx=0.
\]

Thus \(\Null(P)\subseteq\Null(Q)\). Therefore

\[
\boxed{
\Null(P)=\Null(Q)
\iff
PQ=P,\quad QP=Q.
}
\]

## (c) Affine combinations of projectors with a common range

Let \(E_1,\ldots,E_k\) be projectors with the same range, and let

\[
\sum_{j=1}^k\alpha_j=1.
\]

Define

\[
E=\sum_{j=1}^k\alpha_jE_j.
\]

Since all the ranges agree, part (a) gives, for every \(i,j\),

\[
E_iE_j=E_j.
\]

Therefore

\[
\begin{aligned}
E^2
&=
\left(\sum_{i=1}^k\alpha_iE_i\right)
\left(\sum_{j=1}^k\alpha_jE_j\right)\\
&=
\sum_{i=1}^k\sum_{j=1}^k
\alpha_i\alpha_jE_iE_j\\
&=
\sum_{i=1}^k\sum_{j=1}^k
\alpha_i\alpha_jE_j\\
&=
\left(\sum_{i=1}^k\alpha_i\right)
\left(\sum_{j=1}^k\alpha_jE_j\right)\\
&=1\cdot E\\
&=E.
\end{aligned}
\]

Thus \(E\) is idempotent and hence a projector:

\[
\boxed{
\sum_{j=1}^k\alpha_jE_j
\text{ is a projector whenever }
\sum_{j=1}^k\alpha_j=1.
}
\]

In fact, it has the same range as the \(E_j\)'s. If \(M\) is that common range and \(m\in M\), then \(E_jm=m\) for every \(j\), so

\[
Em=\sum_j\alpha_jm=m.
\]

Also every \(Ex\) is a linear combination of vectors in \(M\), hence lies in \(M\).

**Transfer note.** Parts (a) and (b) turn geometric equality of subspaces into algebraic identities. This is a recurring technique in comparing estimators, decompositions, and invariant components.

# Exercise 5.9.13

**Recommendation:** `attempt_then_read`  
**What it tests:** Similarity invariance of rank and cyclic invariance of trace.

**Relevant facts:** Every rank-\(r\) projector is similar to \(\operatorname{diag}(I_r,0)\); rank is unchanged by nonsingular factors; trace is cyclic.  
**Proof skeleton:** Put \(P\) into its range-nullspace basis, compute rank and trace there, and transfer both values back.

Let \(P\) be a projector on \(\R^n\), and let

\[
r=\operatorname{rank}(P)=\dim\Range(P).
\]

Because \(P\) is a projector,

\[
\R^n=\Range(P)\oplus\Null(P).
\]

Choose a basis for \(\Range(P)\) followed by a basis for \(\Null(P)\), and place these basis vectors in a nonsingular matrix \(B\). Relative to that basis,

\[
P
=
B
\begin{bmatrix}
I_r&0\\
0&0
\end{bmatrix}
B^{-1}.
\]

Let

\[
D=
\begin{bmatrix}
I_r&0\\
0&0
\end{bmatrix}.
\]

## Rank

Multiplication by nonsingular matrices does not change rank, so

\[
\operatorname{rank}(P)
=
\operatorname{rank}(D)
=r.
\]

## Trace

Using the cyclic trace identity \(\operatorname{trace}(AB)=\operatorname{trace}(BA)\),

\[
\begin{aligned}
\operatorname{trace}(P)
&=
\operatorname{trace}(BDB^{-1})\\
&=
\operatorname{trace}(DB^{-1}B)\\
&=
\operatorname{trace}(D)\\
&=
\operatorname{trace}(I_r)\\
&=r.
\end{aligned}
\]

Thus both quantities equal \(r\):

\[
\boxed{\operatorname{rank}(P)=\operatorname{trace}(P).}
\]

**Transfer note.** In least squares and smoothing, the trace of a fitted-value projector is interpreted as an effective number of fitted degrees of freedom.

# Exercise 5.9.14

**Recommendation:** `solve_fully`  
**What it tests:** Equivalent definitions of a direct sum of \(k\) subspaces.

**Relevant facts:** A direct sum is characterized by unique component representations and by a basis formed from component bases.  
**Strategy:** Prove the cycle \((i)\Rightarrow(ii)\Rightarrow(iii)\Rightarrow(i)\), grouping linear combinations by subspace and peeling off components from the last one backward.

Let \(X_1,\ldots,X_k\) be subspaces of \(V\), and let \(B_i\) be a basis for \(X_i\). We prove the equivalence of:

1. \(V=X_1+\cdots+X_k\), and
   \[
   X_j\cap(X_1+\cdots+X_{j-1})=\{0\}
   \quad (j=2,\ldots,k).
   \]
2. Every \(v\in V\) has a unique representation
   \[
   v=x_1+\cdots+x_k,\qquad x_i\in X_i.
   \]
3. The pairwise-disjoint union
   \[
   B=B_1\cup\cdots\cup B_k
   \]
   is a basis for \(V\).

We prove

\[
(i)\Longrightarrow(ii)\Longrightarrow(iii)\Longrightarrow(i).
\]

## \((i)\Rightarrow(ii)\)

The equality

\[
V=X_1+\cdots+X_k
\]

guarantees existence of at least one decomposition.

To prove uniqueness, suppose

\[
v=x_1+\cdots+x_k
=y_1+\cdots+y_k,
\qquad x_i,y_i\in X_i.
\]

Set

\[
d_i=x_i-y_i\in X_i.
\]

Then

\[
d_1+\cdots+d_k=0.
\]

Rearrange the last term:

\[
d_k=-(d_1+\cdots+d_{k-1}).
\]

The left side lies in \(X_k\), and the right side lies in \(X_1+\cdots+X_{k-1}\). Therefore

\[
d_k\in X_k\cap(X_1+\cdots+X_{k-1})=\{0\}.
\]

Hence \(d_k=0\), or \(x_k=y_k\). The remaining equation is

\[
d_1+\cdots+d_{k-1}=0.
\]

Now apply the same argument to \(d_{k-1}\), then to \(d_{k-2}\), and so on. Ultimately,

\[
d_1=\cdots=d_k=0.
\]

Therefore

\[
x_i=y_i
\qquad(i=1,\ldots,k),
\]

and the decomposition is unique.

## \((ii)\Rightarrow(iii)\)

### Spanning

Let \(v\in V\). By (ii),

\[
v=x_1+\cdots+x_k,
\qquad x_i\in X_i.
\]

Each \(x_i\) is a linear combination of vectors in \(B_i\). Hence \(v\) is a linear combination of vectors in

\[
B_1\cup\cdots\cup B_k.
\]

Therefore \(B\) spans \(V\).

### Linear independence

Suppose a linear combination of vectors in \(B\) equals zero. Group the terms according to their subspaces:

\[
0=z_1+\cdots+z_k,
\qquad z_i\in X_i.
\]

The zero vector also has the decomposition

\[
0=0+\cdots+0.
\]

By uniqueness in (ii),

\[
z_i=0
\qquad(i=1,\ldots,k).
\]

Because each \(B_i\) is linearly independent, every scalar coefficient used inside \(z_i\) must be zero. Hence \(B\) is linearly independent.

If two bases shared a vector, the concatenated family would contain a repeated vector and would be dependent. Thus the basis blocks are pairwise disjoint as required.

Therefore \(B\) is a basis for \(V\).

## \((iii)\Rightarrow(i)\)

Because \(B\) is a basis for \(V\), it spans \(V\). But the span of \(B\) is exactly

\[
X_1+\cdots+X_k.
\]

Thus

\[
V=X_1+\cdots+X_k.
\]

Now fix \(j\in\{2,\ldots,k\}\), and let

\[
z\in X_j\cap(X_1+\cdots+X_{j-1}).
\]

Since \(z\in X_j\), it has a representation using \(B_j\). Since \(z\in X_1+\cdots+X_{j-1}\), it also has a representation using vectors from \(B_1,\ldots,B_{j-1}\). Subtracting these two representations gives a linear combination of vectors in \(B\) equal to zero.

Because \(B\) is linearly independent, all coefficients are zero. Therefore \(z=0\). Hence

\[
X_j\cap(X_1+\cdots+X_{j-1})=\{0\}.
\]

Since \(j\) was arbitrary, condition (i) holds.

We have proved all three statements are equivalent:

\[
\boxed{
V=X_1\oplus\cdots\oplus X_k
}
\]

exactly when every vector has a unique \(k\)-component decomposition, exactly when the union of component bases is a basis of \(V\).

**Learning note.** The condition in (i) is ordered, but the resulting uniqueness is intrinsic. Once uniqueness holds, any permutation of the subspaces also yields a direct-sum decomposition.

# Exercise 5.9.15

**Recommendation:** `solve_fully`  
**What it tests:** Resolving an operator into four blocks relative to complementary subspaces.

**Relevant facts:** \(P=QD_XQ^{-1}\), \(I-P=QD_YQ^{-1}\), and \(Q^{-1}AQ\) is the block matrix of \(A\) in the combined basis.  
**Strategy:** Insert these three similarity formulas and multiply the block selectors on the left and right.

Let

\[
\R^n=X\oplus Y,
\]

where the columns of \(X\) and \(Y\) are bases of the respective subspaces. Define

\[
Q=[X\mid Y].
\]

Let \(P\) be the projector onto \(X\) along \(Y\), and partition the matrix of \(A\) in the \(Q\)-basis as

\[
\widetilde A=Q^{-1}AQ
=
\begin{bmatrix}
A_{11}&A_{12}\\
A_{21}&A_{22}
\end{bmatrix}.
\]

## Source correction

The printed fourth identity has \(A_{12}\) in the lower-right block. That is a typographical error. The correct lower-right block is \(A_{22}\):

\[
(I-P)A(I-P)
=
Q
\begin{bmatrix}
0&0\\
0&A_{22}
\end{bmatrix}
Q^{-1}.
\]

## Set up the coordinate projectors

If \(r=\dim X\), define

\[
D_X=
\begin{bmatrix}
I_r&0\\
0&0
\end{bmatrix},
\qquad
D_Y=
\begin{bmatrix}
0&0\\
0&I_{n-r}
\end{bmatrix}.
\]

Formula (5.9.12) gives

\[
P=QD_XQ^{-1},
\qquad
I-P=QD_YQ^{-1}.
\]

Also,

\[
A=Q\widetilde A Q^{-1}.
\]

## Compute \(PAP\)

\[
\begin{aligned}
PAP
&=
(QD_XQ^{-1})
(Q\widetilde A Q^{-1})
(QD_XQ^{-1})\\
&=
Q(D_X\widetilde A D_X)Q^{-1}.
\end{aligned}
\]

Now

\[
\begin{aligned}
D_X\widetilde A D_X
&=
\begin{bmatrix}
I&0\\0&0
\end{bmatrix}
\begin{bmatrix}
A_{11}&A_{12}\\
A_{21}&A_{22}
\end{bmatrix}
\begin{bmatrix}
I&0\\0&0
\end{bmatrix}\\[2mm]
&=
\begin{bmatrix}
A_{11}&0\\
0&0
\end{bmatrix}.
\end{aligned}
\]

Therefore

\[
\boxed{
PAP
=
Q
\begin{bmatrix}
A_{11}&0\\
0&0
\end{bmatrix}
Q^{-1}.
}
\]

## Compute \(PA(I-P)\)

\[
\begin{aligned}
PA(I-P)
&=
(QD_XQ^{-1})
(Q\widetilde A Q^{-1})
(QD_YQ^{-1})\\
&=
Q(D_X\widetilde A D_Y)Q^{-1}.
\end{aligned}
\]

The block product is

\[
D_X\widetilde A D_Y
=
\begin{bmatrix}
0&A_{12}\\
0&0
\end{bmatrix}.
\]

Hence

\[
\boxed{
PA(I-P)
=
Q
\begin{bmatrix}
0&A_{12}\\
0&0
\end{bmatrix}
Q^{-1}.
}
\]

## Compute \((I-P)AP\)

Similarly,

\[
\begin{aligned}
(I-P)AP
&=
Q(D_Y\widetilde A D_X)Q^{-1}\\
&=
Q
\begin{bmatrix}
0&0\\
A_{21}&0
\end{bmatrix}
Q^{-1}.
\end{aligned}
\]

Thus

\[
\boxed{
(I-P)AP
=
Q
\begin{bmatrix}
0&0\\
A_{21}&0
\end{bmatrix}
Q^{-1}.
}
\]

## Compute \((I-P)A(I-P)\)

Finally,

\[
\begin{aligned}
(I-P)A(I-P)
&=
Q(D_Y\widetilde A D_Y)Q^{-1}\\
&=
Q
\begin{bmatrix}
0&0\\
0&A_{22}
\end{bmatrix}
Q^{-1}.
\end{aligned}
\]

Therefore

\[
\boxed{
(I-P)A(I-P)
=
Q
\begin{bmatrix}
0&0\\
0&A_{22}
\end{bmatrix}
Q^{-1}.
}
\]

## Interpretation of the four blocks

For \(x\in X\), \(Px=x\). For \(y\in Y\), \((I-P)y=y\). Thus:

- \(PAP\) restricts to a map \(X\to X\), represented by \(A_{11}\).
- \(PA(I-P)\) restricts to a map \(Y\to X\), represented by \(A_{12}\).
- \((I-P)AP\) restricts to a map \(X\to Y\), represented by \(A_{21}\).
- \((I-P)A(I-P)\) restricts to a map \(Y\to Y\), represented by \(A_{22}\).

In Meyer's notation,

\[
A_{11}=[PAP/X]_{B_X},
\]

\[
A_{12}=[PA(I-P)/Y]_{B_YB_X},
\]

\[
A_{21}=[(I-P)AP/X]_{B_XB_Y},
\]

and

\[
A_{22}=[(I-P)A(I-P)/Y]_{B_Y}.
\]

Finally, expanding \(I=P+(I-P)\) on both sides of \(A\) gives the operator decomposition

\[
\boxed{
A
=
PAP+PA(I-P)+(I-P)AP+(I-P)A(I-P).
}
\]

**Transfer note.** This is the abstract source of \(2\times2\) block matrices. The diagonal blocks describe within-subspace action; the off-diagonal blocks describe cross-coupling.

# Exercise 5.9.16

**Recommendation:** `attempt_then_read`  
**What it tests:** A full-rank factorization of a projector.

**Relevant facts:** \(P=[X\mid0][X\mid Y]^{-1}\), and block multiplication of \([X\mid Y]^{-1}[X\mid Y]=I\).  
**Proof skeleton:** Partition the inverse by rows, identify \(P=XA\), then read \(AX=I_r\) from the upper-left block and infer both ranks.

Suppose

\[
\R^n=X\oplus Y,
\qquad
\dim X=r,
\]

and \(P\) is the projector onto \(X\) along \(Y\).

Choose basis matrices

\[
X\in\R^{n\times r},
\qquad
Y\in\R^{n\times(n-r)}
\]

whose columns span the two subspaces. Then

\[
B=[X\mid Y]
\]

is nonsingular.

Partition its inverse by rows:

\[
B^{-1}
=
\begin{bmatrix}
A\\
C
\end{bmatrix},
\]

where

\[
A\in\R^{r\times n},
\qquad
C\in\R^{(n-r)\times n}.
\]

Formula (5.9.12) gives

\[
\begin{aligned}
P
&=[X\mid 0]B^{-1}\\
&=
[X\mid 0]
\begin{bmatrix}
A\\C
\end{bmatrix}\\
&=XA.
\end{aligned}
\]

Thus

\[
\boxed{P=XA.}
\]

Now multiply \(B^{-1}B=I_n\):

\[
\begin{aligned}
I_n
&=
\begin{bmatrix}
A\\C
\end{bmatrix}
[X\mid Y]\\[1mm]
&=
\begin{bmatrix}
AX&AY\\
CX&CY
\end{bmatrix}.
\end{aligned}
\]

Comparing the upper-left block with \(I_n\) gives

\[
\boxed{AX=I_r.}
\]

This identity immediately forces both factors to have rank \(r\). Indeed,

\[
r=\operatorname{rank}(I_r)=\operatorname{rank}(AX)
\le \min\{\operatorname{rank}(A),\operatorname{rank}(X)\}.
\]

But \(A\) has only \(r\) rows and \(X\) has only \(r\) columns, so

\[
\operatorname{rank}(A)\le r,
\qquad
\operatorname{rank}(X)\le r.
\]

Therefore

\[
\boxed{\operatorname{rank}(A)=\operatorname{rank}(X)=r.}
\]

Consequently \(P=XA\) is a full-rank factorization of the rank-\(r\) projector \(P\).

**Transfer note.** The factorization isolates a basis matrix \(X\) for the image and a coordinate-extraction matrix \(A\). This pattern underlies low-rank representations and reduced-coordinate models.

# Exercise 5.9.17

**Recommendation:** `solve_fully`  
**What it tests:** When a sum of two projectors is again a projector, and how its range and nullspace are formed.

**Relevant facts:** A linear operator is a projector iff it is idempotent; projectors fix range vectors and annihilate nullspace vectors.  
**Strategy:** Expand \((E+F)^2\), force both cross-products to vanish, and then prove the range and nullspace descriptions by two inclusions.

Let \(E\) project onto \(X_1\) along \(Y_1\), and let \(F\) project onto \(X_2\) along \(Y_2\). Thus

\[
E^2=E,
\qquad
F^2=F.
\]

## Characterize when \(E+F\) is a projector

A linear operator is a projector exactly when it is idempotent. Compute

\[
\begin{aligned}
(E+F)^2
&=E^2+EF+FE+F^2\\
&=E+F+EF+FE.
\end{aligned}
\]

Therefore

\[
(E+F)^2=E+F
\iff
EF+FE=0.
\]

We now show that, for projectors over \(\R\) or \(\C\),

\[
EF+FE=0
\iff
EF=FE=0.
\]

The reverse implication is immediate. For the forward implication, assume

\[
EF+FE=0.
\]

Left-multiplying by \(E\) gives

\[
EF+EFE=0,
\]

while right-multiplying by \(E\) gives

\[
EFE+FE=0.
\]

Subtracting yields

\[
EF-FE=0,
\]

so \(EF=FE\). Combining this with \(EF+FE=0\) gives

\[
2EF=0.
\]

Since the scalar field is \(\R\) or \(\C\), \(2\ne0\), and hence

\[
EF=0.
\]

Therefore \(FE=0\) as well.

We conclude

\[
\boxed{
E+F\text{ is a projector}
\iff
EF=FE=0.
}
\]

For the remainder, assume this condition.

## Determine the range

First show

\[
\Range(E+F)\subseteq X_1+X_2.
\]

Every image has the form

\[
(E+F)z=Ez+Fz,
\]

where \(Ez\in X_1\) and \(Fz\in X_2\). Thus the inclusion holds.

For the reverse inclusion, take

\[
x_1\in X_1,
\qquad
x_2\in X_2.
\]

Because projectors fix their range vectors,

\[
Ex_1=x_1,
\qquad
Fx_2=x_2.
\]

The cross terms vanish:

\[
Fx_1=F(Ex_1)=FE x_1=0,
\]

and

\[
Ex_2=E(Fx_2)=EF x_2=0.
\]

Therefore

\[
\begin{aligned}
(E+F)(x_1+x_2)
&=Ex_1+Ex_2+Fx_1+Fx_2\\
&=x_1+x_2.
\end{aligned}
\]

Thus \(x_1+x_2\) is a fixed point of \(E+F\), hence lies in its range. Therefore

\[
\Range(E+F)=X_1+X_2.
\]

It remains to show the sum is direct. If \(z\in X_1\cap X_2\), then

\[
Ez=z
\qquad\text{and}\qquad
Fz=z.
\]

Hence

\[
z=EFz=0.
\]

Thus

\[
X_1\cap X_2=\{0\}.
\]

Therefore

\[
\boxed{\Range(E+F)=X_1\oplus X_2.}
\]

## Determine the nullspace

If \(z\in Y_1\cap Y_2\), then

\[
Ez=0
\qquad\text{and}\qquad
Fz=0,
\]

so

\[
(E+F)z=0.
\]

Hence

\[
Y_1\cap Y_2\subseteq\Null(E+F).
\]

Conversely, suppose

\[
(E+F)z=0.
\]

Then

\[
Ez=-Fz.
\]

Apply \(E\):

\[
Ez=-EFz=0.
\]

The original equation then gives \(Fz=0\). Thus

\[
z\in\Null(E)\cap\Null(F)=Y_1\cap Y_2.
\]

Therefore

\[
\boxed{\Null(E+F)=Y_1\cap Y_2.}
\]

Combining the conclusions,

\[
\boxed{
EF=FE=0
\Longrightarrow
\Range(E+F)=X_1\oplus X_2,
\quad
\Null(E+F)=Y_1\cap Y_2.
}
\]

**Transfer note.** Mutually annihilating projectors represent noninteracting components. Their sum aggregates the component ranges while retaining only vectors annihilated by both.

# Exercise 5.9.18

**Recommendation:** `attempt_then_read`  
**What it tests:** Reusing the sum theorem through the complementary-projector trick.

**Relevant facts:** \(T\) is a projector iff \(I-T\) is, and Exercise 5.9.17 characterizes sums of projectors.  
**Proof skeleton:** Rewrite \(I-(E-F)\) as \((I-E)+F\), apply the sum theorem, and swap range with nullspace for complementary projectors.

We use the fact that \(T\) is a projector if and only if \(I-T\) is a projector.

Observe that

\[
I-(E-F)=(I-E)+F.
\]

Both \(I-E\) and \(F\) are projectors. By Exercise 5.9.17,

\[
(I-E)+F
\]

is a projector exactly when

\[
(I-E)F=0
\qquad\text{and}\qquad
F(I-E)=0.
\]

These identities are equivalent to

\[
F-EF=0
\qquad\text{and}\qquad
F-FE=0,
\]

or

\[
EF=F
\qquad\text{and}\qquad
FE=F.
\]

Therefore

\[
\boxed{
E-F\text{ is a projector}
\iff
EF=FE=F.
}
\]

Now assume this condition. Exercise 5.9.17 applied to \(I-E\) and \(F\) gives

\[
\Range(I-E+F)
=
\Range(I-E)\oplus\Range(F)
\]

and

\[
\Null(I-E+F)
=
\Null(I-E)\cap\Null(F).
\]

Using the standard projector identities,

\[
\Range(I-E)=\Null(E)=Y_1,
\]

\[
\Range(F)=X_2,
\]

\[
\Null(I-E)=\Range(E)=X_1,
\]

and

\[
\Null(F)=Y_2.
\]

Hence

\[
\Range(I-E+F)=Y_1\oplus X_2
\]

and

\[
\Null(I-E+F)=X_1\cap Y_2.
\]

Because \(I-E+F=I-(E-F)\) is the complementary projector of \(E-F\),

\[
\Range(E-F)=\Null(I-E+F)
\]

and

\[
\Null(E-F)=\Range(I-E+F).
\]

Therefore

\[
\boxed{
\Range(E-F)=X_1\cap Y_2,
\qquad
\Null(E-F)=Y_1\oplus X_2.
}
\]

# Exercise 5.9.19

**Recommendation:** `attempt_then_read`  
**What it tests:** A commuting product of projectors as the projector onto an intersection.

**Relevant facts:** Commuting idempotents have an idempotent product; a projector is determined by its range and nullspace.  
**Proof skeleton:** Show \(P^2=P\), prove its fixed points are exactly \(X_1\cap X_2\), and decompose each null vector using \(E\) to obtain \(Y_1+Y_2\).

Assume

\[
EF=P=FE.
\]

## Show \(P\) is a projector

Because \(E\) and \(F\) commute,

\[
\begin{aligned}
P^2
&=(EF)(EF)\\
&=E(FE)F\\
&=E(EF)F\\
&=E^2F^2\\
&=EF\\
&=P.
\end{aligned}
\]

Thus \(P\) is a projector.

## Determine the range

Suppose \(z\in\Range(P)\). Then \(Pz=z\). Moreover,

\[
EP=E(EF)=E^2F=EF=P,
\]

and similarly

\[
FP=F(FE)=F^2E=FE=P.
\]

Hence

\[
Ez=EPz=Pz=z
\]

and

\[
Fz=FPz=Pz=z.
\]

Therefore

\[
z\in\Range(E)\cap\Range(F)=X_1\cap X_2.
\]

This proves

\[
\Range(P)\subseteq X_1\cap X_2.
\]

Conversely, if \(z\in X_1\cap X_2\), then

\[
Ez=z
\qquad\text{and}\qquad
Fz=z.
\]

Thus

\[
Pz=EFz=Ez=z,
\]

so \(z\in\Range(P)\). Therefore

\[
\boxed{\Range(P)=X_1\cap X_2.}
\]

## Determine the nullspace

First, let \(y_1\in Y_1=\Null(E)\). Since \(P=FE\),

\[
Py_1=FEy_1=0.
\]

Thus \(Y_1\subseteq\Null(P)\).

Likewise, if \(y_2\in Y_2=\Null(F)\), then \(P=EF\) gives

\[
Py_2=EFy_2=0.
\]

Hence

\[
Y_1+Y_2\subseteq\Null(P).
\]

For the reverse inclusion, take \(z\in\Null(P)\). Decompose \(z\) using \(E\):

\[
z=(I-E)z+Ez.
\]

The first term lies in \(\Null(E)=Y_1\). For the second term,

\[
F(Ez)=FEz=Pz=0,
\]

so \(Ez\in\Null(F)=Y_2\). Thus

\[
z\in Y_1+Y_2.
\]

Therefore

\[
\boxed{\Null(P)=Y_1+Y_2.}
\]

Since every projector is the projector onto its range along its nullspace,

\[
\boxed{
P=EF=FE
\text{ is the projector onto }
X_1\cap X_2
\text{ along }
Y_1+Y_2.
}
\]

**Transfer note.** Commuting projectors behave like logical filters: their product retains exactly the vectors accepted by both ranges.

# Exercise 5.9.20

**Recommendation:** `solve_fully`  
**What it tests:** Generalized inverses, affine solution sets, and construction of a reflexive pseudoinverse from prescribed complementary subspaces.

**Relevant facts:** \(AA^{-}\) and \(A^{-}A\) are projectors for every inner pseudoinverse; Exercise 5.9.12 compares projectors with equal ranges or nullspaces.  
**Strategy:** In part (a), identify a particular solution and the homogeneous projector. In part (b), prove the decisive identities \(XA=Q\) and \(AX=P\), then use them for reflexivity, prescribed spaces, and uniqueness.

Let \(A\in\C^{m\times n}\). An inner pseudoinverse \(A^{-}\in\C^{n\times m}\) satisfies

\[
AA^{-}A=A.
\]

A reflexive pseudoinverse additionally satisfies

\[
A^{-}AA^{-}=A^{-}.
\]

The exercise uses \(X\) for a general candidate reflexive pseudoinverse.

## (a) Describe every solution of a consistent system

Assume

\[
Ax=b
\]

is consistent, and let \(A^{-}\) be any inner pseudoinverse.

### Step 1: \(AA^{-}\) is a projector onto \(\Range(A)\)

First,

\[
(AA^{-})^2
=
AA^{-}AA^{-}
=
(AA^{-}A)A^{-}
=
AA^{-}.
\]

Thus \(AA^{-}\) is a projector.

Its range is contained in \(\Range(A)\) because every vector \(AA^{-}y\) is an image under \(A\). Conversely, if \(z\in\Range(A)\), then \(z=Aw\) for some \(w\), and

\[
AA^{-}z
=
AA^{-}Aw
=
Aw
=
z.
\]

Thus every vector in \(\Range(A)\) is fixed by \(AA^{-}\), so

\[
\Range(AA^{-})=\Range(A).
\]

### Step 2: \(A^{-}b\) is a particular solution

Consistency means

\[
b\in\Range(A)=\Range(AA^{-}).
\]

A projector fixes every vector in its range, so

\[
AA^{-}b=b.
\]

Therefore

\[
A(A^{-}b)=b.
\]

Thus

\[
x_p=A^{-}b
\]

is a particular solution.

### Step 3: \(\Range(I-A^{-}A)=\Null(A)\)

First,

\[
(A^{-}A)^2
=
A^{-}AA^{-}A
=
A^{-}(AA^{-}A)
=
A^{-}A.
\]

Thus \(A^{-}A\) is a projector, so \(I-A^{-}A\) is also a projector.

Now

\[
A(I-A^{-}A)
=
A-AA^{-}A
=
0.
\]

Hence every vector in \(\Range(I-A^{-}A)\) lies in \(\Null(A)\):

\[
\Range(I-A^{-}A)\subseteq\Null(A).
\]

Conversely, if \(h\in\Null(A)\), then \(Ah=0\), so

\[
(I-A^{-}A)h=h.
\]

Thus \(h\) is fixed by \(I-A^{-}A\), and therefore

\[
h\in\Range(I-A^{-}A).
\]

Consequently,

\[
\Range(I-A^{-}A)=\Null(A).
\]

### Step 4: Assemble the general solution

Every solution of a consistent system is a particular solution plus an arbitrary homogeneous solution:

\[
x=x_p+h,
\qquad
h\in\Null(A).
\]

Using the preceding identities,

\[
x=A^{-}b+h,
\qquad
h\in\Range(I-A^{-}A).
\]

Every vector in that range can be written as

\[
h=(I-A^{-}A)w
\]

for some \(w\in\C^n\). Therefore the solution set is

\[
\boxed{
A^{-}b+\Range(I-A^{-}A)
=
\left\{
A^{-}b+(I-A^{-}A)w:w\in\C^n
\right\}.
}
\]

For the real version of the system, replace \(\C^n\) by \(\R^n\).

### Direct verification

For arbitrary \(w\),

\[
\begin{aligned}
A\left(A^{-}b+(I-A^{-}A)w\right)
&=AA^{-}b+A(I-A^{-}A)w\\
&=b+0\\
&=b.
\end{aligned}
\]

Conversely, if \(Ax=b\), then

\[
\begin{aligned}
x-A^{-}b
&=x-A^{-}Ax\\
&=(I-A^{-}A)x,
\end{aligned}
\]

which belongs to \(\Range(I-A^{-}A)\). This proves equality of the two sets directly.

## (b) Construct the unique reflexive pseudoinverse with prescribed range and nullspace

Assume

\[
\C^m=\Range(A)\oplus M
\]

and

\[
\C^n=L\oplus\Null(A).
\]

Let

\[
P:\C^m\to\C^m
\]

be the projector onto \(\Range(A)\) along \(M\), and let

\[
Q:\C^n\to\C^n
\]

be the projector onto \(L\) along \(\Null(A)\).

Let \(A^{-}\) be any inner pseudoinverse, and define

\[
\boxed{X=QA^{-}P.}
\]

We prove that \(X\) is reflexive, has

\[
\Range(X)=L,
\qquad
\Null(X)=M,
\]

and is the unique matrix with these properties.

### Preliminary projector identities

As shown in part (a),

\[
AA^{-}
\]

is a projector with range \(\Range(A)\). Since \(P\) has the same range, Exercise 5.9.12(a) gives

\[
(AA^{-})P=P.
\]

Also,

\[
A^{-}A
\]

is a projector whose nullspace is \(\Null(A)\). Indeed,

\[
A^{-}Ax=0
\Longrightarrow
Ax=AA^{-}Ax=0,
\]

and the reverse implication is immediate. Since \(Q\) has the same nullspace, Exercise 5.9.12(b) gives

\[
Q(A^{-}A)=Q.
\]

Two further identities follow from the definitions of \(P\) and \(Q\):

\[
PA=A,
\]

because every column of \(A\) lies in \(\Range(A)\), where \(P\) acts as the identity; and

\[
AQ=A,
\]

because \((I-Q)z\in\Null(A)\) for every \(z\), so

\[
A(I-Q)=0.
\]

### Compute \(XA\) and \(AX\)

First,

\[
\begin{aligned}
XA
&=QA^{-}PA\\
&=QA^{-}A\\
&=Q(A^{-}A)\\
&=Q.
\end{aligned}
\]

Thus

\[
\boxed{XA=Q.}
\]

Similarly,

\[
\begin{aligned}
AX
&=AQA^{-}P\\
&=AA^{-}P\\
&=P.
\end{aligned}
\]

Thus

\[
\boxed{AX=P.}
\]

These two identities contain most of the structure of the result.

### Prove the inner pseudoinverse identity

Using \(AX=P\) and \(PA=A\),

\[
AXA=PA=A.
\]

Therefore

\[
\boxed{AXA=A.}
\]

### Prove the outer pseudoinverse identity

Using \(XA=Q\) and \(Q^2=Q\),

\[
\begin{aligned}
XAX
&=(XA)X\\
&=Q(QA^{-}P)\\
&=Q^2A^{-}P\\
&=QA^{-}P\\
&=X.
\end{aligned}
\]

Therefore

\[
\boxed{XAX=X.}
\]

Hence \(X\) is a reflexive pseudoinverse.

### Determine the range of \(X\)

Because \(X=QA^{-}P\),

\[
\Range(X)\subseteq\Range(Q)=L.
\]

On the other hand, \(XA=Q\), so

\[
\Range(Q)=\Range(XA)\subseteq\Range(X).
\]

Therefore

\[
\boxed{\Range(X)=L.}
\]

### Determine the nullspace of \(X\)

If \(z\in M=\Null(P)\), then

\[
Xz=QA^{-}Pz=0.
\]

Thus

\[
M\subseteq\Null(X).
\]

Conversely, if \(Xz=0\), then

\[
Pz=AXz=0,
\]

so \(z\in\Null(P)=M\). Therefore

\[
\boxed{\Null(X)=M.}
\]

### Prove uniqueness

Let \(\widehat X\) be any reflexive pseudoinverse of \(A\) satisfying

\[
\Range(\widehat X)=L,
\qquad
\Null(\widehat X)=M.
\]

We first identify two projectors associated with \(\widehat X\).

#### The projector \(\widehat XA\)

Because \(A\widehat XA=A\) and \(\widehat XA\widehat X=\widehat X\),

\[
(\widehat XA)^2
=
\widehat X(A\widehat XA)
=
\widehat XA.
\]

Thus \(\widehat XA\) is a projector.

Its range equals \(\Range(\widehat X)=L\). One inclusion is immediate:

\[
\Range(\widehat XA)\subseteq\Range(\widehat X).
\]

For the reverse inclusion, if \(z=\widehat Xy\), then

\[
z=\widehat Xy
=
\widehat XA\widehat Xy
=
(\widehat XA)z.
\]

Thus \(z\in\Range(\widehat XA)\).

Its nullspace equals \(\Null(A)\). If \(Az=0\), then \(\widehat XAz=0\). Conversely, if \(\widehat XAz=0\), then

\[
Az=A\widehat XAz=0.
\]

Therefore \(\widehat XA\) is the projector onto \(L\) along \(\Null(A)\). By uniqueness of a projector with prescribed range and nullspace,

\[
\widehat XA=Q.
\]

#### The projector \(A\widehat X\)

Similarly,

\[
(A\widehat X)^2
=
A(\widehat XA\widehat X)
=
A\widehat X,
\]

so \(A\widehat X\) is a projector.

Its range is \(\Range(A)\): images are clearly in \(\Range(A)\), and if \(y=Az\), then

\[
A\widehat Xy
=
A\widehat XAz
=
Az
=
y.
\]

Its nullspace is \(\Null(\widehat X)=M\). If \(\widehat Xz=0\), then \(A\widehat Xz=0\). Conversely, if \(A\widehat Xz=0\), then

\[
\widehat Xz
=
\widehat XA\widehat Xz
=
0.
\]

Thus \(A\widehat X\) is the projector onto \(\Range(A)\) along \(M\), so

\[
A\widehat X=P.
\]

Now use these identities and \(Q(A^{-}A)=Q\):

\[
\begin{aligned}
QA^{-}P
&=QA^{-}(A\widehat X)\\
&=Q(A^{-}A)\widehat X\\
&=Q\widehat X.
\end{aligned}
\]

Since \(\Range(\widehat X)=L=\Range(Q)\), \(Q\) fixes every column of \(\widehat X\). Therefore

\[
Q\widehat X=\widehat X.
\]

Hence

\[
\widehat X=QA^{-}P=X.
\]

This proves uniqueness:

\[
\boxed{
X=QA^{-}P
\text{ is the unique reflexive pseudoinverse with }
\Range(X)=L,\ \Null(X)=M.
}
\]

Because the resulting \(X\) is unique, the formula is independent of which inner pseudoinverse \(A^{-}\) is used.

**Transfer note.** Part (a) separates a solution into a canonical particular term and a nullspace freedom term. Part (b) shows that a generalized inverse is determined by choosing which complements represent identifiable inputs and admissible outputs - a viewpoint central to constrained estimation and inverse problems.

# Appendix: recurring facts

## Direct sums

For subspaces \(X,Y\subseteq V\), the following are equivalent:

\[
V=X\oplus Y,
\]

every \(v\in V\) has a unique decomposition \(v=x+y\), and the union of bases for \(X\) and \(Y\) is a basis for \(V\).

## Projector structure

For every projector \(P\),

\[
P^2=P,
\]

\[
V=\Range(P)\oplus\Null(P),
\]

\[
\Range(P)=\{x:Px=x\},
\]

and

\[
\Range(P)=\Null(I-P),
\qquad
\Null(P)=\Range(I-P).
\]

## Basis formula

If \(B=[X\mid Y]\) is formed from bases of complementary subspaces, then

\[
P=[X\mid 0]B^{-1}
=
B
\begin{bmatrix}
I&0\\
0&0
\end{bmatrix}
B^{-1}.
\]

## Two-projector tests

For projectors \(P,Q\),

\[
\Range(P)=\Range(Q)
\iff
PQ=Q,\quad QP=P,
\]

and

\[
\Null(P)=\Null(Q)
\iff
PQ=P,\quad QP=Q.
\]

## Inner pseudoinverse projectors

If

\[
AA^{-}A=A,
\]

then

\[
AA^{-}
\]

is a projector onto \(\Range(A)\), while

\[
I-A^{-}A
\]

is a projector onto \(\Null(A)\).
