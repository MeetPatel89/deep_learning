---
doc_id: TASK-INC-1302
title: INC-1302 Incident Tasks
doc_type: incident_task
service_id: svc_internal_api_gateway
owner_group: Platform Engineering
visibility: internal
status: closed
created_at: "2026-06-18T21:15:00"
updated_at: "2026-06-19T01:20:00"
related_records:
  - INC-1302
  - KI-307
  - RUNBOOK-API-005
source_facts:
  - KI-307
  - svc_internal_api_gateway
difficulty_tags:
  - action-sequencing
  - task-decomposition
servicenow:
  table: incident_task
  parent: INC001302
  task_numbers:
    - INCT0003001
    - INCT0003002
    - INCT0003003
  visibility: internal
  contains_customer_safe_wording: false
---

# INC-1302 Incident Tasks

## Record details

| Field | Value |
| --- | --- |
| Table | incident_task |
| Parent | INC001302 |
| Task numbers | INCT0003001, INCT0003002, INCT0003003 |
| Visibility | internal |
| Contains customer-safe wording | false |

## INCT0003001 — Collect affected client IDs, endpoints, and tier evidence

| Field | Value |
| --- | --- |
| Number | INCT0003001 |
| Short description | Collect affected client IDs, endpoints, and tier evidence |
| Assignment group | Service Desk L1 |
| State | Closed Complete |
| Opened at | 2026-06-18T21:15:00 |
| Closed at | 2026-06-18T22:20:00 |

Service Desk L1 collected the client ID, affected endpoint, approximate timestamp, and customer tier from each reporting client, following the required-inputs list in RUNBOOK-API-005. All reporting clients were confirmed as Business-tier, and all reported timestamps fell after the CHG-2420 change window.

No secrets, tokens, or credentials were placed in the task record. The evidence set was attached to the escalation to Platform Engineering.

## INCT0003002 — Compare applied rate-limit policy against client entitlement

| Field | Value |
| --- | --- |
| Number | INCT0003002 |
| Short description | Compare applied rate-limit policy against client entitlement |
| Assignment group | Platform Engineering |
| State | Closed Complete |
| Opened at | 2026-06-18T22:25:00 |
| Closed at | 2026-06-18T23:20:00 |

Platform Engineering compared the rate-limit policy applied by CHG-2420 against the customer entitlement for the affected client group. The comparison confirmed the KI-307 pattern: the new policy applied stricter burst limits to the Business-tier client group than the tier entitlement allows, while Enterprise-tier assignments matched entitlement.

The mismatch finding was recorded in the incident work notes and used as input to the corrective task.

## INCT0003003 — Correct policy assignment and verify client retest

| Field | Value |
| --- | --- |
| Number | INCT0003003 |
| Short description | Correct policy assignment and verify client retest |
| Assignment group | Platform Engineering |
| State | Closed Complete |
| Opened at | 2026-06-18T23:25:00 |
| Closed at | 2026-06-19T01:20:00 |

Platform Engineering corrected the policy assignment for the affected Business-tier client group so the applied burst limit matched the tier entitlement. The correction was scoped to the mismatched client group; a full rollback of CHG-2420 was not required.

After the adjustment at 2026-06-19T00:25:00, affected clients retested and confirmed burst traffic within entitlement succeeded without 429 responses. Splunk showed 429 volume returning to baseline, and the task was closed when the incident was resolved at 2026-06-19T01:20:00.
