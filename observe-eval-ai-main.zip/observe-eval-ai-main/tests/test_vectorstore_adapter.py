"""Exercise the optional retrieval adapter with real and completed retrievals."""

from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.trace import StatusCode, get_current_span
from pytest import importorskip, mark

from observability_ai import Telemetry, TraceAttributes
from observability_ai.adapters import retrieval_observer

importorskip("vectorstore", reason="requires observe-eval-ai[vectorstore]")

from vectorstore import (  # noqa: E402
    CatalogChunk,
    CatalogDocument,
    QueryKind,
    RetrievalHit,
    RetrievalResult,
    RetrievalTimings,
    Retriever,
    RetrieverConfig,
    SqliteDocumentCatalog,
)
from vectorstore.observability import OTelRetrievalObserver  # noqa: E402


@mark.parametrize(
    "trace",
    [
        None,
        TraceAttributes(
            session_id="session-123",
            user_id="user-456",
            tags=("adapter", "检索"),
            metadata={"tenant": "docs"},
        ),
    ],
)
def test_real_retrieval_uses_native_observer_under_application_parent(
    otel: tuple[Telemetry, InMemorySpanExporter],
    trace: TraceAttributes | None,
) -> None:
    """One retrieve span and its phase children retain results without query text."""
    telemetry, exporter = otel
    observer = retrieval_observer(telemetry, trace=trace)
    assert type(observer) is OTelRetrievalObserver
    assert not exporter.get_finished_spans()
    with SqliteDocumentCatalog() as catalog:
        catalog.upsert_documents([CatalogDocument("doc-1")])
        catalog.upsert_chunks(
            [CatalogChunk("chunk-1", "doc-1", "private telescope document")]
        )
        retriever = Retriever(
            catalog,
            observer=observer,
            config=RetrieverConfig(dense_enabled=False),
        )
        with telemetry.observe("request", attributes=trace) as parent:
            result = retriever.retrieve("telescope")
            assert get_current_span() is parent.span
        assert [hit.chunk.chunk_id for hit in result.hits] == ["chunk-1"]

    spans = exporter.get_finished_spans()
    by_name = {span.name: span for span in spans}
    assert len(spans) == len(by_name) == 4
    assert set(by_name) == {"request", "retrieve", "lexical.search sqlite", "fuse rrf"}
    retrieval = by_name["retrieve"]
    assert retrieval.parent == by_name["request"].context
    attributes = retrieval.attributes
    assert attributes is not None
    assert attributes["langfuse.observation.type"] == "retriever"
    assert attributes["retrieval.result.ids"] == ("chunk-1",)
    assert retrieval.instrumentation_scope is not None
    assert (
        retrieval.instrumentation_scope.name == "observability_ai.adapters.vectorstore"
    )
    if trace is None:
        assert "langfuse.session.id" not in attributes
    else:
        assert trace.as_otel_attributes().items() <= attributes.items()
    for name in ("lexical.search sqlite", "fuse rrf"):
        child = by_name[name]
        assert child.parent == retrieval.context
        # Upstream custom attributes are root-only; the adapter does not wrap it.
        assert child.attributes is not None
        assert "langfuse.observation.type" not in child.attributes
        assert "langfuse.session.id" not in child.attributes
    for span in spans:
        assert "telescope" not in str(span.attributes)
        assert "private telescope document" not in str(span.events)


@mark.parametrize("degraded", [False, True])
def test_native_phase_usage_and_failure_events_are_preserved(
    otel: tuple[Telemetry, InMemorySpanExporter],
    degraded: bool,
) -> None:
    """The factory preserves embedding usage, fallback events, and error status."""
    telemetry, exporter = otel
    observer = retrieval_observer(telemetry)
    observer.on_retrieve(
        RetrievalResult(
            hits=(
                RetrievalHit(CatalogChunk("chunk-1", "doc-1", "private text"), 0.03),
            ),
            query_id="query-123",
            query_kind=QueryKind.IDENTIFIER,
            provider="local",
            model="embedding-model",
            space_id="local-space",
            provider_reason="budget_daily_exceeded",
            fallback_occurred=True,
            degraded=degraded,
            dense_candidates=7,
            lexical_candidates=5,
            dense_weight=1.0,
            lexical_weight=2.0,
            timings=RetrievalTimings(
                dense_ms=6.0,
                lexical_ms=4.0,
                total_ms=20.0,
                embedding_ms=2.0,
                dense_search_ms=3.0,
                fusion_ms=1.0,
            ),
            errors=("lexical unavailable",) if degraded else (),
            embedding_input_tokens=12,
            dense_backend="numpy",
            lexical_backend="sqlite",
        )
    )
    spans = exporter.get_finished_spans()
    by_name = {span.name: span for span in spans}
    assert len(spans) == len(by_name) == 5
    root = by_name["retrieve"]
    assert root.parent is None
    assert all(span.parent == root.context for span in spans if span is not root)
    embedding = by_name["embeddings embedding-model"]
    assert embedding.attributes is not None
    assert embedding.attributes["gen_ai.operation.name"] == "embeddings"
    assert embedding.attributes["gen_ai.usage.input_tokens"] == 12
    events = [event.name for event in root.events]
    assert "retrieval.fallback" in events
    assert "budget.threshold_crossed" in events
    assert ("retrieval.degraded" in events) is degraded
    assert (root.status.status_code is StatusCode.ERROR) is degraded
    assert all("private text" not in str(span.attributes) for span in spans)
