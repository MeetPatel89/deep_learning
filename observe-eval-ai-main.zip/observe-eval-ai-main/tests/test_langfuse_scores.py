"""Exercise score validation and current-observation targeting without networking."""

from typing import Any, cast
from unittest.mock import Mock

from pytest import MonkeyPatch, importorskip, mark, raises

importorskip("langfuse", reason="requires observe-eval-ai[langfuse]")

from langfuse import Langfuse  # noqa: E402
from opentelemetry.sdk.trace.export.in_memory_span_exporter import (  # noqa: E402
    InMemorySpanExporter,
)

from observability_ai import Telemetry  # noqa: E402
from observability_ai.evaluation import (  # noqa: E402
    EvaluationResult,
    ExactMatch,
    LiveEvaluation,
)
from observability_ai.langfuse import (  # noqa: E402
    ScoreDataType,
    Scorer,
    start_as_current_observation,
)


@mark.parametrize("current", [False, True])
@mark.parametrize(
    ("data_type", "value", "expected"),
    [
        ("NUMERIC", 0, 0.0),
        ("NUMERIC", -1.5, -1.5),
        ("CATEGORICAL", "helpful", "helpful"),
        ("TEXT", "x" * 500, "x" * 500),
        ("BOOLEAN", True, 1.0),
        ("BOOLEAN", False, 0.0),
        ("BOOLEAN", 1, 1.0),
    ],
)
def test_scores_forward_validated_values(
    current: bool,
    data_type: ScoreDataType,
    value: float | str,
    expected: float | str,
) -> None:
    """Both APIs preserve names, types, comments, and the selected target."""
    client = Mock(spec=Langfuse)
    scorer = Scorer(client)
    if current:
        scorer.score_current(
            name="quality", value=value, data_type=data_type, comment="reviewed"
        )
        client.score_current_span.assert_called_once_with(
            name="quality", value=expected, data_type=data_type, comment="reviewed"
        )
        client.create_score.assert_not_called()
    else:
        scorer.score(
            name="quality",
            value=value,
            data_type=data_type,
            comment="reviewed",
            trace_id="trace",
            observation_id="observation",
        )
        client.create_score.assert_called_once_with(
            name="quality",
            value=expected,
            data_type=data_type,
            comment="reviewed",
            trace_id="trace",
            observation_id="observation",
            metadata=None,
        )
        client.score_current_span.assert_not_called()
    client.shutdown.assert_not_called()


def test_trace_score_defaults_to_numeric() -> None:
    """Trace-only numeric scores need no observation ID or comment."""
    client = Mock(spec=Langfuse)
    Scorer(client).score(name="quality", value=0.8, trace_id="trace")
    client.create_score.assert_called_once_with(
        name="quality",
        value=0.8,
        trace_id="trace",
        observation_id=None,
        data_type="NUMERIC",
        comment=None,
        metadata=None,
    )


@mark.parametrize("current", [False, True])
@mark.parametrize(
    ("kwargs", "error"),
    [
        ({"name": " "}, ValueError),
        ({"name": 1}, TypeError),
        ({"data_type": "UNKNOWN"}, ValueError),
        ({"value": True}, TypeError),
        ({"value": "0.5"}, TypeError),
        ({"value": float("nan")}, ValueError),
        ({"value": float("inf")}, ValueError),
        ({"value": 10**400}, ValueError),
        ({"value": None}, TypeError),
        ({"data_type": "BOOLEAN", "value": "true"}, TypeError),
        ({"data_type": "BOOLEAN", "value": 0.5}, ValueError),
        ({"data_type": "BOOLEAN", "value": float("nan")}, ValueError),
        ({"data_type": "CATEGORICAL", "value": 1}, TypeError),
        ({"data_type": "CATEGORICAL", "value": ""}, ValueError),
        ({"data_type": "TEXT", "value": " "}, ValueError),
        ({"data_type": "TEXT", "value": "x" * 501}, ValueError),
        ({"comment": 1}, TypeError),
    ],
)
def test_invalid_scores_never_reach_client(
    current: bool,
    kwargs: dict[str, object],
    error: type[Exception],
) -> None:
    """Reject invalid types and non-finite values before SDK queue submission."""
    client = Mock(spec=Langfuse)
    scorer = Scorer(client)
    # Deliberately bypass static signatures to exercise runtime validation.
    arguments: dict[str, Any] = {"name": "quality", "value": 0.8} | kwargs
    with raises(error):
        if current:
            scorer.score_current(**arguments)
        else:
            scorer.score(trace_id="trace", **arguments)
    client.create_score.assert_not_called()
    client.score_current_span.assert_not_called()


@mark.parametrize("field", ["trace_id", "observation_id"])
@mark.parametrize("value", ["", " ", 1])
def test_invalid_score_targets(field: str, value: object) -> None:
    """Require nonblank target IDs without imposing OTel formatting on legacy IDs."""
    client = Mock(spec=Langfuse)
    arguments: dict[str, Any] = {"trace_id": "trace", field: value}
    with raises((TypeError, ValueError)):
        Scorer(client).score(name="quality", value=1, **arguments)
    client.create_score.assert_not_called()


def test_current_score_tracks_nested_observations_and_leaves_no_stale_target(
    sdk: tuple[Langfuse, InMemorySpanExporter],
    monkeypatch: MonkeyPatch,
) -> None:
    """Native current-span scoring selects each current span and ignores no context."""
    client, _ = sdk
    create_score = Mock()
    monkeypatch.setattr(client, "create_score", create_score)
    scorer = Scorer(client)
    with start_as_current_observation(client, name="parent") as parent:
        with start_as_current_observation(client, name="child") as child:
            scorer.score_current(name="child-score", value=True, data_type="BOOLEAN")
        scorer.score_current(name="parent-score", value="good", data_type="TEXT")
    scorer.score_current(name="no-context", value=1)
    assert create_score.call_count == 2
    child_call, parent_call = create_score.call_args_list
    assert child_call.kwargs["trace_id"] == child.trace_id == parent.trace_id
    assert child_call.kwargs["observation_id"] == child.id
    assert parent_call.kwargs["observation_id"] == parent.id


def test_client_failures_are_not_relabelled_as_validation_errors() -> None:
    """Preserve unexpected synchronous SDK errors and their original context."""
    client = Mock(spec=Langfuse)
    failure = RuntimeError("client failure")
    client.create_score.side_effect = failure
    with raises(RuntimeError) as caught:
        Scorer(client).score(name="quality", value=1, trace_id="trace")
    assert caught.value is failure


def test_current_trace_targets_trace_from_core_span(
    sdk: tuple[Langfuse, InMemorySpanExporter],
    otel: tuple[Telemetry, InMemorySpanExporter],
    monkeypatch: MonkeyPatch,
) -> None:
    """Nested core observations share a trace score target without an observation ID."""
    client, _ = sdk
    telemetry, _ = otel
    create_score = Mock()
    monkeypatch.setattr(client, "create_score", create_score)
    scorer = Scorer(client)
    with telemetry.agent("agent") as parent:
        with telemetry.tool("tool"):
            scorer.score_current_trace(name="quality", value=1)
        scorer.score_current_trace(name="label", value="good", data_type="CATEGORICAL")
    scorer.score_current_trace(name="outside", value=0)
    assert create_score.call_count == 2
    for call in create_score.call_args_list:
        assert call.kwargs["trace_id"] == parent.trace_id
        assert call.kwargs.get("observation_id") is None
    with raises(ValueError):
        scorer.score_current_trace(name="invalid", value=float("nan"))
    assert create_score.call_count == 2


def test_score_many_preserves_result_metadata_and_order() -> None:
    """Bulk scores retain types and explanations, converting read-only metadata."""
    client = Mock(spec=Langfuse)
    results = [
        EvaluationResult("correct", True, "BOOLEAN", "checked", {"rubric": "v1"}),
        EvaluationResult("note", "reviewed", "TEXT"),
    ]
    Scorer(client).score_many(iter(results), trace_id="t", observation_id="o")
    assert [call.kwargs for call in client.create_score.call_args_list] == [
        {
            "name": r.name,
            "value": r.value,
            "data_type": r.data_type,
            "comment": r.comment,
            "metadata": dict(r.metadata),
            "trace_id": "t",
            "observation_id": "o",
        }
        for r in results
    ]
    client.flush.assert_not_called()


def test_score_many_validates_entire_input_before_queueing() -> None:
    """An invalid late result or target never produces a partial validation write."""
    client = Mock(spec=Langfuse)
    with raises(TypeError):
        Scorer(client).score_many(
            [EvaluationResult("valid", 1), cast(EvaluationResult, object())],
            trace_id="t",
        )
    with raises(ValueError):
        Scorer(client).score_many([], trace_id=" ")
    client.create_score.assert_not_called()


def test_feedback_uses_binary_user_feedback_convention() -> None:
    """Thumbs-up/down scores stay trace-level and preserve user comments."""
    client = Mock(spec=Langfuse)
    scorer = Scorer(client)
    scorer.feedback("t", False, "not helpful")
    client.create_score.assert_called_once_with(
        name="user-feedback",
        value=0.0,
        data_type="BOOLEAN",
        comment="not helpful",
        trace_id="t",
        observation_id=None,
        metadata=None,
    )
    with raises(ValueError):
        scorer.feedback("t", 0.5)
    assert client.create_score.call_count == 1


async def test_live_sink_delivers_to_captured_core_observation(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """The live evaluator uses the sink's positional contract and active core IDs."""
    client = Mock(spec=Langfuse)
    telemetry, _ = otel
    live = LiveEvaluation([ExactMatch()], sink=Scorer(client).as_live_sink())
    with telemetry.agent("agent") as observation:
        await live.evaluate(output="ok", expected_output="ok")
    call = client.create_score.call_args.kwargs
    assert call["trace_id"] == observation.trace_id
    assert call["observation_id"] == observation.observation_id
    assert call["name"] == "exact_match"
    assert call["value"] == 1.0
