"""Exercise export transport, resources, and parent-based sampling."""

from base64 import b64encode
from dataclasses import replace
from unittest.mock import patch

from opentelemetry.context import Context
from opentelemetry.sdk.trace.export import (
    SimpleSpanProcessor,
    SpanExporter,
    SpanExportResult,
)
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.sdk.trace.sampling import Decision, ParentBased
from opentelemetry.trace import (
    NonRecordingSpan,
    SpanContext,
    TraceFlags,
    get_tracer_provider,
    set_span_in_context,
)
from pytest import MonkeyPatch, mark, raises
from requests import PreparedRequest, Response

from observability_ai import (
    LangfuseSettings,
    Telemetry,
    build_tracer_provider,
    langfuse_span_exporter,
)


def test_exported_http_request(
    settings: LangfuseSettings,
    otel: tuple[Telemetry, InMemorySpanExporter],
    monkeypatch: MonkeyPatch,
) -> None:
    """The wire request uses the Langfuse path, credentials, and v4 header."""
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT", "http://wrong.invalid")
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_TRACES_HEADERS", "Authorization=wrong")
    telemetry, capture = otel
    with telemetry.observe("transport test"):
        pass
    exporter: SpanExporter = langfuse_span_exporter(
        replace(settings, base_url="https://example.com/langfuse///")
    )
    response = Response()
    response.status_code = 200
    try:
        with patch(
            "requests.sessions.Session.send", autospec=True, return_value=response
        ) as send:
            result = exporter.export(capture.get_finished_spans())
        assert result is SpanExportResult.SUCCESS
        send.assert_called_once()
        request = send.call_args.args[1]
        assert isinstance(request, PreparedRequest)
        assert request.method == "POST"
        assert request.url == "https://example.com/langfuse/api/public/otel/v1/traces"
        credentials = b64encode(b"pk-lf-test:sk-lf-test").decode("ascii")
        assert request.headers["Authorization"] == f"Basic {credentials}"
        assert request.headers["x-langfuse-ingestion-version"] == "4"
        assert request.headers["Content-Type"] == "application/x-protobuf"
        assert isinstance(request.body, bytes) and request.body
    finally:
        exporter.shutdown()


def test_provider_resources_and_injected_processor(settings: LangfuseSettings) -> None:
    """Every raw span carries deployment identity without exporting to a network."""
    global_provider = get_tracer_provider()
    exporter = InMemorySpanExporter()
    with patch(
        "observability_ai.export.langfuse_span_exporter",
        side_effect=AssertionError("must not construct a network exporter"),
    ):
        provider = build_tracer_provider(
            replace(settings, environment="staging", release="release-abc"),
            service_name="service-test",
            service_version="2.3.4",
            span_processor=SimpleSpanProcessor(exporter),
        )
    try:
        with provider.get_tracer("test.raw").start_as_current_span("resource test"):
            pass
        (span,) = exporter.get_finished_spans()
        resource = span.resource.attributes
        assert resource["service.name"] == "service-test"
        assert resource["service.version"] == "2.3.4"
        assert resource["langfuse.environment"] == "staging"
        assert resource["langfuse.release"] == "release-abc"
        assert settings.secret_key not in str(resource)
        assert settings.public_key not in str(resource)
        assert get_tracer_provider() is global_provider
    finally:
        provider.shutdown()


def test_default_provider_batches_export(settings: LangfuseSettings) -> None:
    """Default export drains queued spans to the configured exporter on flush."""
    exporter = InMemorySpanExporter()
    with patch("observability_ai.export.langfuse_span_exporter", return_value=exporter):
        provider = build_tracer_provider(
            settings, service_name="batch-test", service_version="1"
        )
    try:
        with provider.get_tracer("test.batch").start_as_current_span("batched"):
            pass
        assert provider.force_flush()
        assert [span.name for span in exporter.get_finished_spans()] == ["batched"]
    finally:
        provider.shutdown()


@mark.parametrize("service_name,service_version", [("", "1"), ("app", " ")])
def test_service_identity_is_required(
    settings: LangfuseSettings, service_name: str, service_version: str
) -> None:
    """A missing application identity fails before starting exporter threads."""
    with raises(ValueError, match="service_"):
        build_tracer_provider(
            settings, service_name=service_name, service_version=service_version
        )


def test_root_sampler_uses_configured_ratio(
    settings: LangfuseSettings, monkeypatch: MonkeyPatch
) -> None:
    """Settings take priority over SDK sampler variables, including fractional rates."""
    monkeypatch.setenv("OTEL_TRACES_SAMPLER", "always_off")
    provider = build_tracer_provider(
        replace(settings, sample_ratio=0.25),
        service_name="sampling-test",
        service_version="1",
        span_processor=SimpleSpanProcessor(InMemorySpanExporter()),
    )
    try:
        assert isinstance(provider.sampler, ParentBased)
        assert (
            provider.sampler.should_sample(Context(), 1, "sampled").decision
            is Decision.RECORD_AND_SAMPLE
        )
        assert (
            provider.sampler.should_sample(Context(), (1 << 64) - 1, "dropped").decision
            is Decision.DROP
        )
    finally:
        provider.shutdown()


@mark.parametrize("ratio", [0.0, 1.0])
@mark.parametrize("sampled", [False, True])
@mark.parametrize("remote", [False, True])
def test_parent_sampling_decision_is_preserved(
    settings: LangfuseSettings, ratio: float, sampled: bool, remote: bool
) -> None:
    """Local and remote parents control descendants regardless of the root ratio."""
    exporter = InMemorySpanExporter()
    provider = build_tracer_provider(
        replace(settings, sample_ratio=ratio),
        service_name="parent-sampling-test",
        service_version="1",
        span_processor=SimpleSpanProcessor(exporter),
    )
    parent = SpanContext(
        trace_id=123,
        span_id=456,
        is_remote=remote,
        trace_flags=TraceFlags(TraceFlags.SAMPLED if sampled else TraceFlags.DEFAULT),
    )
    try:
        tracer = provider.get_tracer("test.sampling")
        with tracer.start_as_current_span("root", context=Context()) as root:
            assert root.is_recording() is bool(ratio)
        with tracer.start_as_current_span(
            "child", context=set_span_in_context(NonRecordingSpan(parent), Context())
        ) as child:
            assert child.is_recording() is sampled
            assert child.get_span_context().trace_id == parent.trace_id
        assert len(exporter.get_finished_spans()) == int(ratio) + int(sampled)
    finally:
        provider.shutdown()
