"""Lazy stream observations with OTel context confined to producer execution."""

from collections.abc import (
    AsyncGenerator,
    AsyncIterable,
    AsyncIterator,
    Callable,
    Generator,
    Iterable,
    Iterator,
)
from contextlib import contextmanager
from datetime import UTC, datetime
from typing import cast

from opentelemetry.context import attach, detach, get_current
from opentelemetry.trace import Status, StatusCode, set_span_in_context

from ._context import _trace_attributes
from .observation import Observation


class _StreamObservation:
    """Own one span and save producer context between iteration steps."""

    def __init__(self, observation: Observation) -> None:
        self.observation = observation
        self.context = set_span_in_context(observation.span)
        self.attributes = _trace_attributes.get()
        self.count = 0

    @contextmanager
    def active(self) -> Iterator[None]:
        attributes_token = _trace_attributes.set(self.attributes)
        token = attach(self.context)
        try:
            yield
        finally:
            self.context = get_current()
            detach(token)
            self.attributes = _trace_attributes.get()
            _trace_attributes.reset(attributes_token)

    def item(self) -> None:
        if self.count == 0:
            self.observation.set_attribute(
                "langfuse.observation.completion_start_time",
                datetime.now(UTC).isoformat(),
            )
        self.count += 1

    def error(self, error: BaseException) -> None:
        if not isinstance(error, GeneratorExit):
            self.observation.record_exception(error)
            self.observation.span.set_status(
                Status(StatusCode.ERROR, f"{type(error).__name__}: {error}")
            )

    def end(self) -> None:
        self.observation.set_metadata({"stream_item_count": self.count})
        self.observation.span.end()


def _stream[T, S, R](
    source: Iterable[T], start: Callable[[], Observation]
) -> Generator[T, S, R]:
    state = _StreamObservation(start())
    iterator: Iterator[T] | None = None
    failed = False
    try:
        try:
            with state.active():
                iterator = iter(source)
                item = next(iterator)
            while True:
                state.item()
                try:
                    sent = yield item
                except GeneratorExit:
                    raise
                except BaseException as error:
                    with state.active():
                        if not isinstance(iterator, Generator):
                            raise
                        item = iterator.throw(error)
                else:
                    with state.active():
                        if isinstance(iterator, Generator):
                            item = iterator.send(sent)
                        elif sent is None:
                            item = next(iterator)
                        else:
                            raise TypeError("cannot send a value to a plain iterator")
        except StopIteration as done:
            return cast(R, done.value)
    except BaseException as error:
        failed = not isinstance(error, GeneratorExit)
        state.error(error)
        raise
    finally:
        try:
            with state.active():
                close = getattr(iterator, "close", None)
                if close is not None:
                    close()
        except BaseException as error:
            if not failed:
                state.error(error)
                raise
        finally:
            state.end()


async def _async_stream[T, S](
    source: AsyncIterable[T], start: Callable[[], Observation]
) -> AsyncGenerator[T, S]:
    state = _StreamObservation(start())
    iterator: AsyncIterator[T] | None = None
    failed = False
    try:
        try:
            with state.active():
                iterator = aiter(source)
                item = await anext(iterator)
            while True:
                state.item()
                try:
                    sent = yield item
                except GeneratorExit:
                    raise
                except BaseException as error:
                    with state.active():
                        if not isinstance(iterator, AsyncGenerator):
                            raise
                        item = await iterator.athrow(error)
                else:
                    with state.active():
                        if isinstance(iterator, AsyncGenerator):
                            item = await iterator.asend(sent)
                        elif sent is None:
                            item = await anext(iterator)
                        else:
                            raise TypeError("cannot send a value to a plain iterator")
        except StopAsyncIteration:
            return
    except BaseException as error:
        failed = not isinstance(error, GeneratorExit)
        state.error(error)
        raise
    finally:
        try:
            with state.active():
                close = getattr(iterator, "aclose", None)
                if close is not None:
                    await close()
        except BaseException as error:
            if not failed:
                state.error(error)
                raise
        finally:
            state.end()
