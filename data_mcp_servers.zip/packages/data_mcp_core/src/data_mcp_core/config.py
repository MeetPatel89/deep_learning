"""TOML configuration with environment references and safe validation errors."""

import os
import re
import tomllib
from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field, ValidationError

from data_mcp_core.auth import AuthProfile, resolve_auth
from data_mcp_core.results import register_secret
from data_mcp_core.stores import StoreConfig

_env_ref = re.compile(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}")


class ConfigModel(BaseModel):
    model_config = ConfigDict(extra="forbid", hide_input_in_errors=True)


class DataConfig(ConfigModel):
    auth_profiles: dict[str, AuthProfile] = Field(default_factory=dict)
    stores: dict[str, StoreConfig] = Field(default_factory=dict)
    allowed_local_roots: list[str] = Field(default_factory=list)

    def auth_profile(self, auth: str | AuthProfile) -> AuthProfile:
        return resolve_auth(auth, self.auth_profiles)


def expand_env(value):
    if isinstance(value, dict):
        return {key: expand_env(item) for key, item in value.items()}
    if isinstance(value, list):
        return [expand_env(item) for item in value]
    if isinstance(value, str):

        def substitute(match):
            name = match[1]
            if name not in os.environ:
                raise ValueError(f"Configuration references unset environment variable {name}")
            replacement = os.environ[name]
            register_secret(replacement)
            return replacement

        return _env_ref.sub(substitute, value)
    return value


def load_config[T: BaseModel](env_var: str, model: type[T]) -> T:
    filename = os.environ.get(env_var)
    data = {}
    if filename:
        with Path(filename).expanduser().open("rb") as handle:
            data = expand_env(tomllib.load(handle))
    try:
        config = model.model_validate(data)
    except ValidationError as error:
        # Pydantic nested error contexts may include original secret input.
        locations = [".".join(str(part) for part in item["loc"]) for item in error.errors()]
        raise ValueError("Invalid configuration fields: " + ", ".join(locations)) from None
    if isinstance(config, DataConfig):
        for store in config.stores.values():
            config.auth_profile(store.auth)
    return config
