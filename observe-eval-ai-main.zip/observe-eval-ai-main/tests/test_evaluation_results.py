"""Verify score invariants without importing the optional SDK."""

from dataclasses import FrozenInstanceError
from typing import Any, cast

from pytest import mark, raises

from observability_ai.evaluation import EvaluationResult, ScoreDataType


@mark.parametrize(
    ("data_type", "value", "expected"),
    [
        ("NUMERIC", 0, 0.0),
        ("NUMERIC", -1.5, -1.5),
        ("CATEGORICAL", "good", "good"),
        ("TEXT", "x" * 500, "x" * 500),
        ("BOOLEAN", True, 1.0),
        ("BOOLEAN", False, 0.0),
        ("BOOLEAN", 1, 1.0),
    ],
)
def test_result_values(
    data_type: ScoreDataType, value: float | str, expected: float | str
) -> None:
    """Preserve the SDK score contract and normalize numeric values eagerly."""
    result = EvaluationResult("quality", value, data_type, "reviewed")
    assert result.value == expected
    assert type(result.value) is type(expected)
    assert result.comment == "reviewed"


@mark.parametrize(
    ("kwargs", "error"),
    [
        ({"name": " "}, ValueError),
        ({"name": 1}, TypeError),
        ({"data_type": "UNKNOWN"}, ValueError),
        ({"value": True}, TypeError),
        ({"value": "0.5"}, TypeError),
        ({"value": float("nan")}, ValueError),
        ({"value": float("inf")}, ValueError),
        ({"value": 10**400}, ValueError),
        ({"value": None}, TypeError),
        ({"data_type": "BOOLEAN", "value": "true"}, TypeError),
        ({"data_type": "BOOLEAN", "value": 0.5}, ValueError),
        ({"data_type": "BOOLEAN", "value": float("nan")}, ValueError),
        ({"data_type": "CATEGORICAL", "value": 1}, TypeError),
        ({"data_type": "CATEGORICAL", "value": ""}, ValueError),
        ({"data_type": "TEXT", "value": " "}, ValueError),
        ({"data_type": "TEXT", "value": "x" * 501}, ValueError),
        ({"comment": 1}, TypeError),
        ({"metadata": []}, TypeError),
        ({"metadata": {1: "bad"}}, TypeError),
        ({"metadata": {" ": "bad"}}, ValueError),
    ],
)
def test_invalid_results(kwargs: dict[str, Any], error: type[Exception]) -> None:
    """Reject malformed results before delivery, including invalid metadata keys."""
    arguments: dict[str, Any] = {"name": "quality", "value": 0.8} | kwargs
    with raises(error):
        EvaluationResult(**arguments)


def test_result_is_frozen_with_shallow_metadata_snapshot() -> None:
    """Top-level source edits cannot mutate results; nested data stays shared."""
    nested = ["label"]
    metadata: dict[str, object] = {"labels": nested}
    result = EvaluationResult("quality", 1, metadata=metadata)
    metadata["new"] = True
    assert dict(result.metadata) == {"labels": nested}
    assert result.metadata["labels"] is nested
    with raises(FrozenInstanceError):
        setattr(result, "value", 0)
    with raises(TypeError):
        cast(dict[str, object], result.metadata)["new"] = 1
