"""Validate settings before any telemetry infrastructure is constructed."""

from dataclasses import FrozenInstanceError, replace

from pytest import MonkeyPatch, mark, raises

from observability_ai import LangfuseSettings


def test_defaults_and_immutability(settings: LangfuseSettings) -> None:
    """Settings retain defaults, reject mutation, and hide the secret in repr."""
    assert settings.base_url == "http://localhost:3000"
    assert settings.environment is None
    assert settings.release is None
    assert settings.sample_ratio == 1.0
    assert settings.secret_key not in repr(settings)
    with raises(FrozenInstanceError):
        setattr(settings, "sample_ratio", 0.5)


@mark.parametrize(
    ("field", "value", "error"),
    [
        ("public_key", "", ValueError),
        ("public_key", "pk:invalid", ValueError),
        ("public_key", "pk with space", ValueError),
        ("public_key", 123, TypeError),
        ("secret_key", "\t", ValueError),
        ("secret_key", "sk\ninvalid", ValueError),
        ("secret_key", None, TypeError),
        ("base_url", "", ValueError),
        ("base_url", "localhost:3000", ValueError),
        ("base_url", "ftp://localhost", ValueError),
        ("base_url", "http:///path", ValueError),
        ("base_url", "https://user:password@example.com", ValueError),
        ("base_url", "https://example.com?query=1", ValueError),
        ("base_url", "https://example.com#fragment", ValueError),
        ("base_url", "https://example.com:invalid", ValueError),
        ("base_url", "https://example.com:99999", ValueError),
        ("base_url", "http://[::1", ValueError),
        ("base_url", " https://example.com", ValueError),
        ("base_url", "https://example.com/\n", ValueError),
        ("base_url", None, TypeError),
        ("environment", "", ValueError),
        ("environment", "Production", ValueError),
        ("environment", "langfuse-internal", ValueError),
        ("environment", "a" * 41, ValueError),
        ("environment", 1, TypeError),
        ("release", " ", ValueError),
        ("release", 1, TypeError),
        ("sample_ratio", -0.1, ValueError),
        ("sample_ratio", 1.1, ValueError),
        ("sample_ratio", float("nan"), ValueError),
        ("sample_ratio", float("inf"), ValueError),
        ("sample_ratio", "0.5", TypeError),
        ("sample_ratio", True, TypeError),
    ],
)
def test_invalid_settings(
    settings: LangfuseSettings, field: str, value: object, error: type[Exception]
) -> None:
    """Invalid input fails locally and identifies the field without credentials."""
    with raises(error, match=field) as caught:
        replace(settings, **{field: value})  # type: ignore[arg-type]
    assert settings.secret_key not in str(caught.value)


@mark.parametrize("base_url", ["https://example.com/prefix///", "http://[::1]:3000/"])
def test_base_url_preserves_path_and_normalizes_slashes(
    settings: LangfuseSettings, base_url: str
) -> None:
    """Reverse-proxy paths and IPv6 origins remain usable exporter destinations."""
    assert replace(settings, base_url=base_url).base_url == base_url.rstrip("/")


def test_from_env_defaults(monkeypatch: MonkeyPatch) -> None:
    """Only credentials are required when reading the process environment."""
    monkeypatch.setenv("LANGFUSE_PUBLIC_KEY", "pk-env")
    monkeypatch.setenv("LANGFUSE_SECRET_KEY", "sk-env")
    assert LangfuseSettings.from_env() == LangfuseSettings("pk-env", "sk-env")


@mark.parametrize("ratio", ["0", "0.25", "1"])
def test_from_env_all_fields(monkeypatch: MonkeyPatch, ratio: str) -> None:
    """All documented variables are parsed, including a disabled root sampler."""
    for name, value in {
        "LANGFUSE_PUBLIC_KEY": "pk-env",
        "LANGFUSE_SECRET_KEY": "sk-env",
        "LANGFUSE_BASE_URL": "https://example.com/langfuse/",
        "LANGFUSE_TRACING_ENVIRONMENT": "staging-1",
        "LANGFUSE_RELEASE": "release-123",
        "LANGFUSE_SAMPLE_RATE": ratio,
    }.items():
        monkeypatch.setenv(name, value)
    assert LangfuseSettings.from_env() == LangfuseSettings(
        public_key="pk-env",
        secret_key="sk-env",
        base_url="https://example.com/langfuse",
        environment="staging-1",
        release="release-123",
        sample_ratio=float(ratio),
    )


@mark.parametrize("name", ["LANGFUSE_PUBLIC_KEY", "LANGFUSE_SECRET_KEY"])
@mark.parametrize("value", [None, ""])
def test_missing_env_credentials(
    monkeypatch: MonkeyPatch, name: str, value: str | None
) -> None:
    """Missing and empty credentials name the required environment variable."""
    monkeypatch.setenv("LANGFUSE_PUBLIC_KEY", "pk-env")
    monkeypatch.setenv("LANGFUSE_SECRET_KEY", "sk-env")
    if value is None:
        monkeypatch.delenv(name)
    else:
        monkeypatch.setenv(name, value)
    with raises(ValueError, match=name):
        LangfuseSettings.from_env()


@mark.parametrize("value", ["", "many", "nan", "inf", "-0.1", "1.1"])
def test_invalid_env_sampling(monkeypatch: MonkeyPatch, value: str) -> None:
    """Malformed and out-of-range sampling variables cannot reach the SDK."""
    monkeypatch.setenv("LANGFUSE_PUBLIC_KEY", "pk-env")
    monkeypatch.setenv("LANGFUSE_SECRET_KEY", "sk-env")
    monkeypatch.setenv("LANGFUSE_SAMPLE_RATE", value)
    with raises(ValueError, match="LANGFUSE_SAMPLE_RATE|sample_ratio"):
        LangfuseSettings.from_env()
