"""Keep evaluation imports independent of model-runtime and the Langfuse SDK."""

from subprocess import run
from sys import executable

from pytest import mark


@mark.parametrize("failure", ["missing", "transitive"])
def test_judge_optional_imports(failure: str) -> None:
    """Only constructing a judge imports its extra; transitive errors stay intact."""
    result = run(
        [
            executable,
            "-c",
            f"""
from importlib.abc import MetaPathFinder
from sys import meta_path, modules

class BlockOptional(MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in ('model_runtime', 'vectorstore', 'langfuse'):
            missing = fullname if {failure!r} == 'missing' else 'broken_transitive'
            raise ModuleNotFoundError('dependency unavailable', name=missing)

meta_path.insert(0, BlockOptional())
from observability_ai.evaluation import (
    EvaluationResult, ExactMatch, JudgeRubric, LiveEvaluation, ModelRuntimeJudge,
    PrecisionAtK,
)
assert not any(name in modules for name in ('model_runtime', 'vectorstore', 'langfuse'))
assert ExactMatch()(output='a', expected_output='a').value == 1
assert PrecisionAtK(2)(output=['a'], expected_output=['a']).value == 0.5
rubric = JudgeRubric('quality', 'Check correctness')
try:
    ModelRuntimeJudge(object(), 'judge', rubric)
except ImportError as exc:
    if {failure!r} == 'missing':
        assert 'observe-eval-ai[model-runtime]' in str(exc), str(exc)
        assert isinstance(exc.__cause__, ModuleNotFoundError)
        assert exc.__cause__.name == 'model_runtime'
    else:
        assert isinstance(exc, ModuleNotFoundError)
        assert exc.name == 'broken_transitive'
else:
    raise AssertionError('judge unexpectedly constructed without its extra')
""",
        ],
        capture_output=True,
        text=True,
        check=False,
        timeout=20,
    )
    assert result.returncode == 0, result.stderr
