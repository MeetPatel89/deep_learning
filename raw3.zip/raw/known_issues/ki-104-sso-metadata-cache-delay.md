---
doc_id: KI-104
title: SSO Metadata Cache Delay After Certificate Rotation
doc_type: known_issue
service_id: svc_identity_gateway
owner_group: IAM Platform
visibility: internal
status: active
created_at: "2026-06-13T01:00:00"
updated_at: "2026-06-14T09:00:00"
related_records:
  - CHG-2407
  - INC-1104
  - PRB-202
  - RUNBOOK-SSO-003
source_facts:
  - KI-104
  - svc_identity_gateway
difficulty_tags:
  - known-issue
  - permission-boundary
  - similar-symptoms
servicenow:
  table: u_known_issue
  number: KI00104
  state: Active
  business_service: Employee Portal
  cmdb_ci: Identity Gateway
  assignment_group: IAM Platform
  related_change: CHG002407
  related_incident: INC001104
  related_problem: PRB000202
  workaround_available: true
  visibility: internal
  contains_customer_safe_wording: true
---

# SSO Metadata Cache Delay After Certificate Rotation

## Record details

| Field | Value |
| --- | --- |
| Table | u_known_issue |
| Number | KI00104 |
| State | Active |
| Business service | Employee Portal |
| Configuration item | Identity Gateway |
| Assignment group | IAM Platform |
| Related change | CHG002407 |
| Related incident | INC001104 |
| Related problem | PRB000202 |
| Workaround available | true |
| Visibility | internal |
| Contains customer-safe wording | true |

## Summary

KI-104 documents a known Identity Gateway issue observed after identity maintenance. Some Identity Gateway nodes may continue using stale IdP metadata after certificate rotation. The result is an inconsistent sign-in experience: some users can authenticate normally while others receive errors before reaching Employee Portal.

This issue is linked to CHG-2407 and incident INC-1104. It should be considered when SSO failures begin after certificate rotation or other identity maintenance.

## Affected service

Affected service:

- Identity Gateway, service ID svc_identity_gateway.

Owning and escalation group:

- IAM Platform.

Relevant dependencies:

- Okta.
- Employee Portal.
- Internal API Gateway.

## Symptoms

Symptoms include invalid SAML response errors and partial login failures.

Support should look for the following pattern:

- Users cannot log into Employee Portal.
- Error message mentions invalid SAML response.
- Issue starts after identity maintenance.
- Some users can log in while others cannot.
- Browser refresh or retry may appear to help one user but does not clear the broader condition.

The partial impact pattern is important. A full authentication outage may indicate a different failure mode, while this known issue is often seen as inconsistent failures across users or gateway paths.

## Root cause

The internal root cause is stale IdP metadata on some Identity Gateway nodes after certificate rotation. The certificate rotation can complete successfully while some nodes continue to use older identity provider metadata until the cache is refreshed.

Do not use this internal wording in customer-facing updates. Use the customer-safe summary below unless IAM Platform approves more detail.

## Workaround

Workaround is to refresh the Identity Gateway metadata cache and verify the active certificate thumbprint.

Recommended operational sequence:

1. Confirm the incident started after identity maintenance or certificate rotation.
2. Confirm the user-facing error mentions invalid SAML response.
3. Check whether some users can log in while others cannot.
4. Refresh the Identity Gateway metadata cache.
5. Verify the active certificate thumbprint.
6. Ask Service Desk L1 to retest with affected users.

If failures persist after cache refresh and thumbprint validation, keep the incident with IAM Platform for deeper review.

## Escalation guidance

Escalation group is IAM Platform. Service Desk L1 should escalate when the issue affects multiple users, when an identity-related change occurred in the last 24 hours, or when the documented workaround does not resolve the problem.

Release Management should be notified when symptoms follow CHG-2407 or another completed identity change.

## Customer-safe summary

Customer-safe summary is: We are validating the enterprise sign-in configuration after scheduled identity maintenance.

Support may add user-specific next steps such as retrying sign-in after support confirms remediation, but should not mention internal metadata cache behavior.

## Related records

- CHG-2407: Rotate Okta Signing Certificate for Identity Gateway.
- INC-1104: Employee Portal Login Failures After Okta Certificate Rotation.
- PRB-202: Identity Gateway Metadata Cache Inconsistency After IdP Certificate Rotation.
- RUNBOOK-SSO-003: Identity Gateway SSO Login Failure Runbook.

