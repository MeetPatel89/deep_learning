"""Spool batches only after the shared input budget is crossed."""

import math
from dataclasses import dataclass, field
from pathlib import Path

import polars as pl

from qa_mcp_server.engine.compare import ROW_INDEX, common_dtype
from qa_mcp_server.models import CompareOptions, DatasetSource
from qa_mcp_server.sources import iter_batches


@dataclass
class LoadedSide:
    frames: list[pl.DataFrame] = field(default_factory=list)
    paths: list[Path] = field(default_factory=list)
    types: dict[str, list[pl.DataType]] = field(default_factory=dict)
    row_count: int = 0
    size_bytes: int = 0

    def batches(self):
        yield from self.frames
        for path in self.paths:
            yield pl.read_parquet(path)


@dataclass
class Plan:
    expected: LoadedSide
    actual: LoadedSide
    schema: dict[str, pl.DataType]
    rename: dict[str, str]
    schema_difference: set[str]
    partitions: int
    partitioned: bool
    budget_bytes: int


def load_and_plan(
    expected: DatasetSource, actual: DatasetSource, options: CompareOptions, directory: Path
) -> Plan:
    sides = {"expected": LoadedSide(), "actual": LoadedSide()}
    budget = max(1, int(options.memory_budget_mb * 1024 * 1024))
    # Leave room for normalization, join indices and report generation.
    input_budget = max(1, budget // 4)
    spilling = options.num_partitions is not None
    resident = 0

    def spill(name: str, frame: pl.DataFrame):
        target = directory / name
        target.mkdir(parents=True, exist_ok=True)
        path = target / f"batch_{len(sides[name].paths):08d}.parquet"
        frame.write_parquet(path)
        sides[name].paths.append(path)

    for name, source in (("expected", expected), ("actual", actual)):
        side = sides[name]
        for frame in iter_batches(source):
            if any(column.startswith("__qa_") for column in frame.columns):
                raise ValueError("Input column names beginning with __qa_ are reserved")
            if frame.height and not frame.width:
                raise ValueError("Rows must contain at least one column")
            for column, dtype in frame.schema.items():
                side.types.setdefault(column, []).append(dtype)
            size = frame.estimated_size()
            frame = frame.with_columns(
                pl.int_range(side.row_count, side.row_count + frame.height, dtype=pl.UInt64).alias(
                    ROW_INDEX
                )
            )
            side.row_count += frame.height
            side.size_bytes += size
            if not spilling and resident + size > input_budget:
                spilling = True
                for previous_name, previous_side in sides.items():
                    for previous in previous_side.frames:
                        spill(previous_name, previous)
                    previous_side.frames.clear()
                resident = 0
            if spilling:
                spill(name, frame)
            else:
                side.frames.append(frame)
                resident += size

    rename = {actual: expected for expected, actual in options.column_mapping.items()}
    e_types = {c: t for c, t in sides["expected"].types.items() if c not in options.ignore_columns}
    a_types = {}
    for column, types in sides["actual"].types.items():
        target = rename.get(column, column)
        if target in options.ignore_columns or column in options.ignore_columns:
            continue
        if target in a_types:
            raise ValueError(f"Column mapping creates duplicate actual column: {target}")
        a_types[target] = types
    for e, a in options.column_mapping.items():
        if e in options.ignore_columns or a in options.ignore_columns:
            continue
        if e not in e_types and sides["expected"].row_count:
            raise ValueError(f"Mapped expected column does not exist: {e}")
        if a not in sides["actual"].types and sides["actual"].row_count:
            raise ValueError(f"Mapped actual column does not exist: {a}")
    columns = list(dict.fromkeys([*e_types, *a_types]))
    if not columns and (sides["expected"].row_count or sides["actual"].row_count):
        raise ValueError("No columns remain after ignoring columns")
    for key in options.primary_keys or []:
        for name, types in (("expected", e_types), ("actual", a_types)):
            if key not in types and (sides[name].row_count or sides[name].types):
                raise ValueError(f"Primary key {key!r} does not exist in {name}")
        if key not in columns:
            raise ValueError(f"Primary key {key!r} has no input schema")
    # Schemaless, empty inline inputs inherit the other side's schema.
    difference = set(e_types) ^ set(a_types)
    if not sides["expected"].types or not sides["actual"].types:
        difference = set()
    schema = {c: common_dtype(e_types.get(c, []) + a_types.get(c, [])) for c in columns}
    total = sum(side.size_bytes for side in sides.values())
    partitions = options.num_partitions or min(65536, max(2, math.ceil(total / input_budget)))
    return Plan(
        sides["expected"],
        sides["actual"],
        schema,
        rename,
        difference,
        partitions if spilling else 1,
        spilling,
        budget,
    )
