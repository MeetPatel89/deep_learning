---
doc_id: INC-1104
title: Employee Portal Login Failures After Okta Certificate Rotation
doc_type: incident
service_id: svc_identity_gateway
owner_group: IAM Platform
visibility: internal
status: resolved
created_at: "2026-06-12T23:18:00"
updated_at: "2026-06-13T03:45:00"
related_records:
  - CHG-2407
  - KI-104
  - PRB-202
  - RUNBOOK-SSO-003
  - KB-118
  - POL-ESC-001
  - WN-INC-1104
  - COMM-INC-1104
  - TASK-INC-1104
  - POL-SLA-001
source_facts:
  - CHG-2407
  - KI-104
  - svc_identity_gateway
difficulty_tags:
  - temporal-reasoning
  - multi-hop
  - escalation-routing
servicenow:
  table: incident
  number: INC001104
  state: Resolved
  impact: 2
  urgency: 1
  priority: 2
  priority_label: "2 - High"
  category: Software
  subcategory: Authentication
  business_service: Employee Portal
  cmdb_ci: Identity Gateway
  assignment_group: IAM Platform
  opened_by_group: Service Desk L1
  contact_type: Phone
  related_change: CHG002407
  related_known_issue: KI00104
  related_problem: PRB000202
  sla_policy: POL-SLA-001
  sla_target_response: "30 minutes"
  sla_target_resolution: "8 hours"
  sla_breached: false
  visibility: internal
  contains_customer_safe_wording: false
---

# Employee Portal Login Failures After Okta Certificate Rotation

## Record details

| Field | Value |
| --- | --- |
| Table | incident |
| Number | INC001104 |
| State | Resolved |
| Impact | 2 |
| Urgency | 1 |
| Priority | 2 - High |
| Category | Software |
| Subcategory | Authentication |
| Business service | Employee Portal |
| Configuration item | Identity Gateway |
| Assignment group | IAM Platform |
| Opened by group | Service Desk L1 |
| Contact type | Phone |
| Related change | CHG002407 |
| Related known issue | KI00104 |
| Related problem | PRB000202 |
| SLA policy | POL-SLA-001 |
| SLA target response | 30 minutes |
| SLA target resolution | 8 hours |
| SLA breached | false |
| Visibility | internal |
| Contains customer-safe wording | false |

## Incident summary

INC-1104 was opened after users reported Employee Portal sign-in failures following CHG-2407. The change rotated the Okta signing certificate used by Identity Gateway and completed at 2026-06-12T23:00:00. Incident began 18 minutes after CHG-2407 completed.

The incident matched KI-104: SSO metadata cache delay after certificate rotation. IAM Platform owned final remediation.

## Impact

Impact was partial but business-visible. Some users could log in while others could not. Affected users saw invalid SAML response errors before reaching Employee Portal.

Because Identity Gateway is a Tier 1 service and multiple users were affected, Service Desk L1 treated the incident as high priority under POL-ESC-001 and escalated to IAM Platform.

## Timeline

| Time | Event |
| --- | --- |
| 2026-06-12T22:00:00 | CHG-2407 maintenance window opened. |
| 2026-06-12T23:00:00 | CHG-2407 planned window ended with implementation marked successful. |
| 2026-06-12T23:18:00 | INC-1104 opened after first reports of Employee Portal login failure. |
| 2026-06-12T23:28:00 | Service Desk L1 confirmed users reported invalid SAML response errors. |
| 2026-06-12T23:42:00 | L1 noted that some users could log in while others could not. |
| 2026-06-13T00:05:00 | Incident escalated to IAM Platform with CHG-2407 and KI-104 candidates noted. |
| 2026-06-13T00:40:00 | IAM Platform refreshed the Identity Gateway metadata cache. |
| 2026-06-13T01:05:00 | Active certificate thumbprint verified by IAM Platform. |
| 2026-06-13T02:10:00 | Most affected users confirmed successful Employee Portal sign-in. |
| 2026-06-13T03:45:00 | Incident resolved and linked to PRB-202 for root-cause follow-up. |

## Observed symptoms

Observed symptoms were consistent with KI-104:

- Users reported invalid SAML response errors.
- Some users could log in while others could not.
- Failures began shortly after identity maintenance.
- Retrying did not reliably clear the issue for all affected users.

No evidence indicated that Employee Portal itself was unavailable after authenticated sessions were established.

## Investigation notes

Service Desk L1 first confirmed the impact pattern and checked the recent change calendar. CHG-2407 had completed at 2026-06-12T23:00:00, making the first incident report approximately 18 minutes after completion.

IAM Platform reviewed the Identity Gateway path and treated KI-104 as the matching known issue. The investigation focused on whether the active IdP certificate thumbprint was being honored consistently after certificate rotation.

The working diagnosis was that some gateway nodes still had stale IdP metadata even though the change implementation had completed successfully.

## Resolution

Refreshing the Identity Gateway metadata cache resolved most failures. IAM Platform then verified the active certificate thumbprint and monitored successful Employee Portal sign-in attempts.

Residual reports were handled as user-specific retry and session cleanup cases after the platform-level condition was cleared.

## Customer communication

Customer-facing updates used KI-104 safe wording:

"We are validating the enterprise sign-in configuration after scheduled identity maintenance."

Support did not expose internal metadata-cache implementation details in user-facing messages.

## Follow-up actions

- Link INC-1104 to KI-104 for future similar symptoms.
- Open PRB-202 to document the known error and permanent fix status.
- Keep RUNBOOK-SSO-003 updated with cache refresh and thumbprint validation steps.
- Notify Release Management because the incident appeared related to recently completed CHG-2407.

## Related records

- CHG-2407: Rotate Okta Signing Certificate for Identity Gateway.
- KI-104: SSO Metadata Cache Delay After Certificate Rotation.
- PRB-202: Identity Gateway Metadata Cache Inconsistency After IdP Certificate Rotation.
- RUNBOOK-SSO-003: Identity Gateway SSO Login Failure Runbook.
- KB-118: Employee Portal SSO Login Troubleshooting.
- POL-ESC-001: Incident Severity and Escalation Policy.
- WN-INC-1104: Internal work notes for INC-1104.
- COMM-INC-1104: Customer communications sent for INC-1104.
- TASK-INC-1104: Incident tasks opened under INC-1104.
- POL-SLA-001: SLA policy applied to INC-1104.

