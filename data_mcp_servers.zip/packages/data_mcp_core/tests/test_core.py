import json
import struct
import sys
from datetime import date
from decimal import Decimal
from unittest.mock import Mock

import pytest
from data_mcp_core import auth, sql
from data_mcp_core.config import DataConfig, load_config
from data_mcp_core.guards import local_path, require
from data_mcp_core.results import bounded_result, json_safe, paginate, redact
from data_mcp_core.stores import StoreConfig, resolve_path, resolve_store
from pydantic import SecretStr


def test_environment_secrets_and_safe_config_errors(tmp_path, monkeypatch):
    config = tmp_path / "config.toml"
    config.write_text(
        '[auth_profiles.app]\nmode="service_principal"\ntenant_id="tenant"\nclient_id="app"\nclient_secret="${CORE_TEST_SECRET}"\n'
    )
    monkeypatch.setenv("CORE_TEST_CONFIG", str(config))
    monkeypatch.setenv("CORE_TEST_SECRET", "super-secret-value")
    loaded = load_config("CORE_TEST_CONFIG", DataConfig)
    assert loaded.auth_profiles["app"].client_secret.get_secret_value() == "super-secret-value"
    assert "super-secret-value" not in json.dumps(redact(loaded))
    assert redact("error: super-secret-value") == "error: [REDACTED]"
    config.write_text('invalid="${CORE_TEST_SECRET}"\n')
    with pytest.raises(ValueError) as error:
        load_config("CORE_TEST_CONFIG", DataConfig)
    assert "super-secret-value" not in str(error.value)
    monkeypatch.delenv("CORE_TEST_SECRET")
    with pytest.raises(ValueError, match="unset environment"):
        load_config("CORE_TEST_CONFIG", DataConfig)


@pytest.mark.parametrize(
    "mode,constructor",
    [
        ("default", "DefaultAzureCredential"),
        ("cli", "AzureCliCredential"),
        ("interactive_browser", "InteractiveBrowserCredential"),
        ("device_code", "DeviceCodeCredential"),
        ("service_principal", "ClientSecretCredential"),
        ("managed_identity", "ManagedIdentityCredential"),
    ],
)
def test_credentials_are_cached_by_profile(monkeypatch, mode, constructor):
    auth.close_credentials()
    import azure.identity

    factory = Mock()
    monkeypatch.setattr(azure.identity, constructor, factory)
    options = {"mode": mode}
    if mode == "service_principal":
        options.update(tenant_id="tenant", client_id="app", client_secret="credential-secret")
    profile = auth.AuthProfile(**options)
    assert auth.get_credential(profile) is auth.get_credential(profile)
    assert factory.call_count == 1
    auth.close_credentials()
    factory.return_value.close.assert_called_once()


def test_odbc_token_is_utf16_and_connection_omits_interactive(monkeypatch):
    token = "a😀z"
    encoded = auth.pack_odbc_token(token)
    assert struct.unpack("<I", encoded[:4])[0] == len(token.encode("utf-16-le"))
    assert encoded[4:].decode("utf-16-le") == token
    settings = sql.SQLConnection(
        workspace="workspace", pool="serverless", database="db", auth="token"
    )
    assert settings.server == "workspace-ondemand.sql.azuresynapse.net"
    assert "Authentication=" not in sql.connection_string(settings)
    assert "UID=" not in sql.connection_string(settings)
    connect = Mock()
    monkeypatch.setitem(sys.modules, "pyodbc", Mock(connect=connect))
    monkeypatch.setattr(sql, "odbc_token_attributes", lambda profile: {1256: encoded})
    sql._open_connection(settings)
    assert connect.call_args.kwargs["attrs_before"] == {1256: encoded}


@pytest.mark.parametrize(
    "query",
    [
        "SELECT 1",
        "WITH t AS (SELECT 1 AS id) SELECT * FROM t",
        "SELECT 1 UNION SELECT 2",
        "/* leading */ SELECT 1;",
        "EXPLAIN SELECT 1",
        "SELECT 'DROP TABLE x; SELECT 2' AS v",
        "EXPLAIN WITH t AS (SELECT 1 v) SELECT * FROM t",
    ],
)
def test_read_only_sql_accepts_queries(query):
    sql.ensure_read_only(query)


@pytest.mark.parametrize(
    "query",
    [
        "DROP TABLE x",
        "SELECT * INTO new_table FROM old_table",
        "SELECT 1; DELETE FROM t",
        "WITH t AS (SELECT 1 AS id) DELETE FROM x",
        "EXEC dbo.proc",
        "UPDATE t SET x=1",
        "TRUNCATE TABLE t",
        "CREATE TABLE t (id int)",
        "EXPLAIN DELETE FROM t",
        "EXPLAIN SELECT 1; DROP TABLE t",
        "nonsense command",
    ],
)
def test_read_only_sql_fails_closed(query):
    with pytest.raises(PermissionError):
        sql.ensure_read_only(query)
    sql.ensure_read_only(query, allow_write=True)


@pytest.mark.parametrize(
    "path",
    [
        "../outside",
        "a/../../b",
        "/absolute",
        "abfss://raw/path",
        "a\\..\\secret",
        "%2e%2e/secret",
        "%252e%252e/secret",
    ],
)
def test_store_paths_block_traversal(tmp_path, path):
    with pytest.raises((PermissionError, ValueError)):
        resolve_store(StoreConfig(root=str(tmp_path)), path)


def test_symlinks_and_allowed_local_roots(tmp_path):
    root, outside = tmp_path / "root", tmp_path / "outside"
    root.mkdir()
    outside.mkdir()
    (root / "link").symlink_to(outside, target_is_directory=True)
    with pytest.raises(PermissionError):
        local_path(root, "link/secret")
    with pytest.raises(PermissionError):
        local_path(root, "file", [str(outside)])
    assert local_path(root, "file", [str(root)]) == root / "file"


def test_cloud_uri_resolution_reuses_matching_config_and_credentials():
    profile = auth.AuthProfile(mode="account_key", account_key="storage-key-value")
    store = StoreConfig(
        protocol="abfss", account_name="lake", container="raw", root="sales", auth="key"
    )
    resolved = resolve_path(
        "abfss://raw@lake.dfs.core.windows.net/sales/data.csv",
        stores={"raw": store},
        auth_profiles={"key": profile},
    )
    assert resolved.relative == "data.csv"
    assert resolved.fs_path == "raw/sales/data.csv"
    assert resolved.storage_options()["azure_storage_account_key"] == "storage-key-value"
    assert resolved.credential_provider == "auto"
    with pytest.raises(PermissionError):
        resolve_store(store, "../other")
    for protocol in ["s3", "gs"]:
        assert (
            resolve_store(StoreConfig(protocol=protocol, bucket="bucket", root="prefix"), "x").uri
            == f"{protocol}://bucket/prefix/x"
        )


def test_secret_redaction_and_pagination():
    value = {
        "password": "p",
        "nested": {"type": "SecureString", "value": "s"},
        "url": "https://x?sig=signature&sv=1",
        "number": Decimal("1.23"),
        "date": date(2026, 1, 2),
        "secret": SecretStr("hidden"),
    }
    safe = redact(value)
    assert safe["password"] == "[REDACTED]"
    assert safe["nested"]["value"] == "[REDACTED]"
    assert "signature" not in safe["url"]
    assert json_safe(value)["number"] == "1.23"
    first = paginate(list(range(5)), 2, context="request")
    second = paginate(list(range(5)), 2, first["continuation"], "request")
    assert first["items"] + second["items"] == [0, 1, 2, 3]
    with pytest.raises(ValueError):
        paginate(list(range(5)), 2, first["continuation"], "different")
    assert bounded_result({"v": "x" * 60_000})["truncated"]


def test_guards_require_actual_boolean():
    for flag in [
        "allow_write",
        "allow_delete",
        "allow_run",
        "allow_manage",
        "allow_sql_write",
        "allow_sas",
    ]:
        with pytest.raises(PermissionError):
            require({}, flag)
        with pytest.raises(PermissionError):
            require({flag: 1}, flag)
        require({flag: True}, flag)


def test_uri_cannot_escape_matching_configured_cloud_root():
    store = StoreConfig(protocol="s3", bucket="bucket", root="allowed")
    with pytest.raises(PermissionError, match="root"):
        resolve_path("s3://bucket/other/file.csv", stores={"restricted": store})


def test_character_caps_keep_pagination_and_json_envelope():
    items = [{"id": 1, "data": "x" * 40_000}, {"id": 2, "data": "x" * 40_000}]
    first = paginate(items, limit=2, context="large")
    assert len(json.dumps(first)) <= 50_000
    assert first["continuation"]
    second = paginate(items, limit=2, token=first["continuation"], context="large")
    assert second["items"][0]["id"] == 2
    assert len(json.dumps(bounded_result({"text": '"' * 60_000}))) <= 50_000
