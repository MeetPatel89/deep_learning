---
name: Dataset Comparison MCP Server
overview: Build a Python MCP server (FastMCP + Polars) that loads expected and actual datasets from SQL (Azure SQL, ActiveDirectoryInteractive MFA), CSV, Parquet, Excel, or inline JSON. It compares them by primary keys, or by all columns if no keys are given, and uses hash partitioning when the data is too large for memory so no row is skipped. Results go to color-coded Excel reports split by a row cap.
todos:
  - id: scaffold
    content: Set up src layout, pyproject dependencies and entry point, FastMCP server skeleton
    status: completed
  - id: models
    content: "Pydantic models: DatasetSource union, CompareOptions, OutputOptions"
    status: completed
  - id: sources
    content: "Loaders: SQL (ActiveDirectoryInteractive, cached connections, batched reads), CSV, Parquet, Excel, inline"
    status: completed
  - id: compare-core
    content: "Compare core: normalization, type coercion, duplicate keys, outer join, per-column null-safe mismatch flags, no-key multiset mode"
    status: completed
  - id: partition
    content: Planner and hash-partition spill to Parquet, per-bucket compare loop, completeness check
    status: completed
  - id: excel
    content: "Excel writer: summary, paired colored columns, missing/extra/duplicate sheets, split by max_rows_per_file"
    status: completed
  - id: tools
    content: Wire up the compare_datasets, inspect_dataset and test_sql_connection tools
    status: completed
  - id: tests
    content: pytest suite including a check that partitioned results equal in-memory results; README with MCP config
    status: completed
isProject: false
---

# Dataset Comparison MCP Server

## Tool design (3 tools rather than 1)

- **`compare_datasets`** is the main tool. It takes `expected`, `actual`, `primary_keys`, compare options and output options. It returns a JSON summary: counts, mismatches per column, report file paths and a small sample of mismatches.
- **`inspect_dataset`** takes one source and returns its schema, row count and a sample of rows. It lets the agent check a query, check key columns and trigger the MFA login before starting a long comparison.
- **`test_sql_connection`** takes server and database, runs `SELECT 1` and caches the connection, so the MFA prompt shows up once before the real run.

One tool would work, but the two helper tools cut down on failed long runs. Both reuse the same loader code.

## Project layout (src layout, uv)

- [pyproject.toml](pyproject.toml): dependencies are `mcp[cli]`, `polars`, `pyodbc`, `xlsxwriter`, `fastexcel` and `pydantic`; dev dependency is `pytest`. Script entry point: `qa-mcp-server = qa_mcp_server.server:main`.
- `src/qa_mcp_server/server.py`: FastMCP app, tool definitions, stdio transport. Replaces [main.py](main.py).
- `src/qa_mcp_server/models.py`: Pydantic models.
- `src/qa_mcp_server/sources/sql.py`, `files.py`, `inline.py`: loaders.
- `src/qa_mcp_server/engine/planner.py`, `partition.py`, `compare.py`: the comparison engine.
- `src/qa_mcp_server/report/excel.py`: Excel writer.
- `tests/`: unit tests on generated data. SQL is tested with a mocked connection.

## Models (`models.py`)

`DatasetSource` is a discriminated union on `type`:
- `sql`: `server`, `database`, `query` or `query_file` (path to a .sql script), optional `username` (UPN hint for the MFA prompt), `driver` (default `ODBC Driver 18 for SQL Server`), `timeout`.
- `csv` and `parquet`: `path`, plus options such as delimiter and encoding.
- `excel`: `path`, `sheet`.
- `inline`: `rows: list[dict]`.

`CompareOptions`:
- `primary_keys: list[str] | None`
- `column_mapping` (expected column name to actual column name) and `ignore_columns`
- `numeric_tolerance`, `trim_strings`, `case_insensitive`, `treat_null_as_equal` (default true)
- `memory_budget_mb` (default 1024) and `num_partitions` (default auto)

`OutputOptions`:
- `output_dir`
- `max_rows_per_file` (default 100k, capped at Excel's limit of 1,048,575 data rows)
- `include_matched_rows` (default false)
- `max_total_report_rows` (optional overall cap). A full mismatch dump to Parquet is always written so nothing is lost when the cap applies.

## SQL loading (Azure SQL MFA)

- Connection string: `Driver={ODBC Driver 18 for SQL Server};Server=tcp:<server>,1433;Database=<db>;Authentication=ActiveDirectoryInteractive;UID=<upn>;Encrypt=yes;TrustServerCertificate=no`.
- Open connections are cached per `(server, database, username)` for the life of the server process, so the MFA prompt appears once per session rather than once per query. The server runs on Windows, so the interactive popup works.
- Rows are streamed with `pl.read_database(query, conn, iter_batches=True, batch_size=N)`. Each batch is either appended in memory or sent to the partition writer.

## Comparison strategy

```mermaid
flowchart TD
    Load[Resolve sources] --> Estimate[Estimate size: rows x avg row bytes]
    Estimate -->|"fits memory_budget"| InMem[Single in-memory compare]
    Estimate -->|"too large"| Partition["Hash-partition both sides on keys into N Parquet spill files"]
    Partition --> Loop["For each partition i: compare expected_i vs actual_i"]
    InMem --> Collect[Accumulate results]
    Loop --> Collect
    Collect --> Excel[Write Excel reports split by max_rows_per_file]
```

- **Fits in memory:** for file sources, the size estimate comes from the lazy scan metadata (`scan_parquet` and `scan_csv`). For SQL, the first batch is read and then the stream continues; if the running size passes the budget partway through, the loader switches to spilling. If the data fits, one compare runs on the whole set.
- **Does not fit:** each row gets `bucket = hash(key columns) % N`. Expected and actual rows are written to `tmp/{side}/part_{i}.parquet`. Rows with the same key always land in the same bucket number on both sides, so comparing bucket `i` against bucket `i` for every `i` covers every row exactly once. There are no gaps and no overlap between chunks. N is chosen so that one pair of buckets fits in about half the memory budget.
- **Completeness check:** after the run, the summary asserts that matched + mismatched + missing in actual + extra in actual adds up to the row counts of both inputs. The run fails loudly if it does not.
- **Compare core (`compare.py`), per bucket:**
  1. Normalize column names using the mapping and ignore list, and cast both sides to a common type (for example Decimal vs Float becomes Float64, and mixed types become String).
  2. Detect duplicate keys on each side and report them separately.
  3. Run a full outer join on the keys with `_expected` and `_actual` suffixes.
  4. Per column, compute a mismatch flag with null-safe equality (`eq_missing`), applying the numeric tolerance and string options.
  5. Classify each row as `matched`, `mismatched`, `missing_in_actual` or `extra_in_actual`.
- **No primary keys given:** all columns become the key, which makes this a multiset compare. Rows are grouped by all columns with a count, then the join is on all columns plus the count difference. Only missing and extra rows are reported, along with occurrence counts.

## Excel report (`report/excel.py`, xlsxwriter with `constant_memory`)

- **Summary sheet:** the parameters used, row counts, the count for each status, mismatch counts per column, and a list of the other files.
- **Mismatches sheet:** key columns first. Then each compared column appears as two adjacent columns, `col_expected` and `col_actual`. Text is green when the pair matches and red (bold) when it does not, so each cell's format is chosen from that row's mismatch flag.
- **Missing_in_Actual, Extra_in_Actual and Duplicate_Keys sheets.**
- **File splitting:** a writer streams rows and starts a new `report_NNN.xlsx` whenever `max_rows_per_file` is reached, repeating the header row in each file. The Summary sheet only goes in file 001.

## Testing

- Generated Polars datasets covering: identical data, value mismatches, missing and extra rows, duplicate keys, the no-key mode, tolerance, and type coercion.
- A test that forces partitioning (a tiny `memory_budget_mb`) and checks the results match the in-memory run exactly.
- A test that Excel files split at `max_rows_per_file`, with a check of the cell formats via openpyxl (test-only dependency).
- A short README section with the Cursor or Claude Desktop MCP config for running on Windows (`uv run qa-mcp-server`) and a note on the ODBC Driver 18 prerequisite.
