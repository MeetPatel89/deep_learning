---
doc_id: KI-307
title: API Clients Receive Unexpected 429 Responses After Rate-Limit Policy Update
doc_type: known_issue
service_id: svc_internal_api_gateway
owner_group: Platform Engineering
visibility: internal
status: active
created_at: "2026-06-18T22:00:00"
updated_at: "2026-06-19T10:30:00"
related_records:
  - CHG-2420
  - INC-1302
  - PRB-411
  - RUNBOOK-API-005
source_facts:
  - KI-307
  - svc_internal_api_gateway
difficulty_tags:
  - known-issue
  - plan-specific-behavior
  - entitlement-check
---

# API Clients Receive Unexpected 429 Responses After Rate-Limit Policy Update

## Summary

KI-307 documents an Internal API Gateway known issue where API clients receive 429 Too Many Requests after a rate-limit policy deployment. The issue affects Business-tier clients more often than Enterprise clients.

Errors begin after rate-limit policy deployment, especially after CHG-2420. The issue is owned by Platform Engineering.

## Affected service

Affected service:

- Internal API Gateway, service ID svc_internal_api_gateway.

Owning and escalation group:

- Platform Engineering.

Relevant dependencies:

- Kong.
- Vault.
- Splunk.

## Symptoms

Symptoms include:

- API clients receive 429 Too Many Requests.
- Issue affects Business-tier clients more often than Enterprise clients.
- Errors begin after rate-limit policy deployment.
- 429 volume appears elevated for specific client groups in Splunk.
- Clients report throttling even when they believe traffic is within entitlement.

The issue may be reported as burst rejection, unexpected throttling, API traffic blocked, or Business-tier client rate-limit failure.

## Root cause

The internal root cause is that the new rate-limit policy applied stricter burst limits to some client groups. Some clients had applied gateway policy that did not match their entitlement.

This detail should remain internal. Customer-facing communication should not state that an internal policy mistake occurred.

## Workaround

Workaround is to confirm customer tier, check applied rate-limit policy, and escalate if policy does not match entitlement.

Operational sequence:

1. Confirm the client ID.
2. Confirm the customer tier.
3. Capture affected endpoint and approximate timestamp.
4. Inspect 429 volume in Splunk.
5. Compare applied rate-limit policy against customer entitlement.
6. Escalate to Platform Engineering if the policy does not match entitlement.

## Escalation guidance

Escalation group is Platform Engineering. Escalate when the applied rate-limit policy appears stricter than the customer's entitlement or when multiple clients report unexpected 429 errors after a rate-limit policy deployment.

Service Desk L1 should collect client ID, endpoint, approximate timestamp, and tier before escalation when possible.

## Customer-safe summary

Customer-safe summary is: We are reviewing the applied API traffic policy for the affected client.

Do not state that an internal policy misconfiguration or entitlement mistake occurred in customer-facing updates.

## Related records

- CHG-2420: Deploy New API Gateway Rate-Limit Policy.
- INC-1302: Business-Tier API Clients Receive 429 Errors After Rate-Limit Policy Deployment.
- PRB-411: API Rate-Limit Policy Entitlement Mismatch.
- RUNBOOK-API-005: API Gateway 429 Investigation Runbook.

