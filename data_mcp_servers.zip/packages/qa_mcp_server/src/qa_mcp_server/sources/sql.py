"""Compatibility imports; connection state lives in data_mcp_core.sql."""

from data_mcp_core.sql import (
    close_connections,
    connection_string,
    get_connection,
    iter_sql_batches,
    test_connection,
)

__all__ = [
    "close_connections",
    "connection_string",
    "get_connection",
    "iter_sql_batches",
    "test_connection",
]
