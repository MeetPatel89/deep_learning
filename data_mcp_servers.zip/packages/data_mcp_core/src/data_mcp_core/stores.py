"""Named, sandboxed fsspec stores and Polars cloud credentials."""

import json
import posixpath
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal
from urllib.parse import urlsplit

from pydantic import BaseModel, ConfigDict, Field, model_validator

from data_mcp_core.auth import (
    STORAGE_SCOPE,
    AuthProfile,
    azure_credential_provider,
    get_credential,
    get_token,
    resolve_auth,
)
from data_mcp_core.guards import local_path, relative_path


class StoreConfig(BaseModel):
    model_config = ConfigDict(extra="forbid", hide_input_in_errors=True)
    protocol: Literal["file", "abfss", "s3", "gs"] = "file"
    root: str = "."
    account_name: str | None = None
    container: str | None = None
    bucket: str | None = None
    auth: str | AuthProfile = "default"
    allow_write: bool = False
    allow_delete: bool = False
    allow_manage: bool = False
    allow_sas: bool = False
    options: dict[str, Any] = Field(default_factory=dict, exclude=True, repr=False)

    @model_validator(mode="after")
    def valid_location(self):
        if self.protocol == "abfss" and not (self.account_name and self.container):
            raise ValueError("abfss stores require account_name and container")
        if self.protocol in {"s3", "gs"} and not self.bucket:
            raise ValueError("Object stores require bucket")
        if self.protocol != "file":
            relative_path(self.root.strip("/"))
            for part in (self.account_name, self.container, self.bucket):
                if part and any(character in part for character in "/\\?#@"):
                    raise ValueError("Invalid account, container or bucket name")
        return self


@dataclass
class ResolvedPath:
    store: StoreConfig
    relative: str
    uri: str
    fs_path: str
    auth: AuthProfile
    allowed_local_roots: list[str] = field(default_factory=list)
    _filesystem: Any = field(default=None, repr=False)

    @property
    def fs(self):
        if self._filesystem is None:
            self._filesystem = filesystem(self.store, self.auth)
        return self._filesystem

    def child(self, path: str):
        return resolve_store(
            self.store,
            posixpath.join(self.relative, path),
            auth_profiles={"resolved": self.auth},
            allowed_local_roots=self.allowed_local_roots,
            profile=self.auth,
        )

    def storage_options(self, *, token: bool = False) -> dict[str, str]:
        options = {
            str(key): str(value) for key, value in self.store.options.get("polars", {}).items()
        }
        if self.store.protocol == "abfss":
            options["azure_storage_account_name"] = self.store.account_name
            if self.auth.mode == "account_key":
                options["azure_storage_account_key"] = self.auth.account_key.get_secret_value()
            elif self.auth.mode == "sas":
                options["azure_storage_sas_token"] = self.auth.sas_token.get_secret_value().lstrip(
                    "?"
                )
            elif token:
                options["azure_storage_token"] = get_token(self.auth, STORAGE_SCOPE).token
        elif self.store.protocol == "s3":
            source = self.store.options.get("fsspec", {})
            keys = {
                "key": "aws_access_key_id",
                "secret": "aws_secret_access_key",
                "token": "aws_session_token",
            }
            for key, target in keys.items():
                if source.get(key):
                    options.setdefault(target, source[key])
            for key, target in {
                "region_name": "aws_region",
                "endpoint_url": "aws_endpoint_url",
            }.items():
                value = source.get("client_kwargs", {}).get(key) or source.get(key)
                if value:
                    options.setdefault(target, value)
        elif self.store.protocol == "gs":
            credential = self.store.options.get("fsspec", {}).get("token")
            if isinstance(credential, dict):
                options.setdefault("google_service_account_key", json.dumps(credential))
            elif isinstance(credential, str) and Path(credential).is_file():
                options.setdefault("google_service_account", credential)
        return options

    @property
    def credential_provider(self):
        if self.store.protocol == "abfss" and self.auth.mode not in {"account_key", "sas"}:
            return azure_credential_provider(self.auth)
        return "auto"

    def exists(self) -> bool:
        return self.fs.exists(self.fs_path)

    def relative_name(self, fs_path: str) -> str:
        if self.store.protocol == "file":
            resolved = Path(fs_path).resolve()
            base = Path(self.store.root).expanduser().resolve()
            if not resolved.is_relative_to(base):
                raise PermissionError("Listed path escapes store root")
            result = resolved.relative_to(base).as_posix()
            local_path(base, result, self.allowed_local_roots)
            return result
        prefix = store_prefix(self.store)
        fs_path = self.fs._strip_protocol(fs_path).rstrip("/")
        if fs_path != prefix and not fs_path.startswith(prefix + "/"):
            raise PermissionError("Listed path escapes store root")
        return fs_path[len(prefix) :].lstrip("/")


def store_prefix(store: StoreConfig) -> str:
    base = store.container if store.protocol == "abfss" else store.bucket
    root = store.root.strip("/")
    return posixpath.join(base or "", "" if root == "." else root).rstrip("/")


def filesystem(store: StoreConfig, profile: AuthProfile):
    import fsspec

    options = dict(store.options.get("fsspec", {}))
    if store.protocol == "file":
        return fsspec.filesystem("file", **options)
    if store.protocol == "abfss":
        options["account_name"] = store.account_name
        if profile.mode == "account_key":
            options["account_key"] = profile.account_key.get_secret_value()
        elif profile.mode == "sas":
            options["sas_token"] = profile.sas_token.get_secret_value().lstrip("?")
        else:
            options["credential"] = get_credential(profile, asynchronous=True)
        return fsspec.filesystem("abfss", **options)
    try:
        return fsspec.filesystem(store.protocol, **options)
    except ImportError as error:
        extra = "s3" if store.protocol == "s3" else "gcs"
        raise RuntimeError(f"Install the [{extra}] extra to use this store") from error


def resolve_store(
    store: StoreConfig,
    path: str = "",
    *,
    auth_profiles: dict[str, AuthProfile] | None = None,
    allowed_local_roots: list[str] | None = None,
    profile: AuthProfile | None = None,
) -> ResolvedPath:
    relative = relative_path(path)
    auth = profile or resolve_auth(store.auth, auth_profiles or {})
    if store.protocol == "file":
        fs_path = str(local_path(store.root, relative, allowed_local_roots))
        uri = fs_path
    else:
        fs_path = posixpath.join(store_prefix(store), relative).rstrip("/")
        if store.protocol == "abfss":
            object_path = posixpath.join(store.root.strip("/"), relative)
            if store.root == ".":
                object_path = relative
            uri = (
                f"abfss://{store.container}@{store.account_name}.dfs.core.windows.net/{object_path}"
            )
        else:
            uri = f"{store.protocol}://{fs_path}"
    return ResolvedPath(store, relative, uri, fs_path, auth, allowed_local_roots or [])


def resolve_path(
    path: str,
    *,
    store: str | None = None,
    stores: dict[str, StoreConfig] | None = None,
    auth_profiles: dict[str, AuthProfile] | None = None,
    allowed_local_roots: list[str] | None = None,
) -> ResolvedPath:
    stores = stores or {}
    if store:
        if store not in stores:
            raise ValueError(f"Unknown store: {store}")
        return resolve_store(
            stores[store],
            path,
            auth_profiles=auth_profiles,
            allowed_local_roots=allowed_local_roots,
        )
    uri = urlsplit(path)
    if not uri.scheme or (len(uri.scheme) == 1 and len(path) >= 2 and path[1] == ":"):
        absolute = Path(path).expanduser().absolute()
        if ".." in absolute.parts:
            raise PermissionError("Parent traversal is forbidden")
        return resolve_store(
            StoreConfig(root=str(absolute.parent)),
            absolute.name,
            allowed_local_roots=allowed_local_roots,
        )
    if uri.query or uri.fragment:
        raise ValueError("Configure credentials in an auth profile rather than a URI")
    if uri.scheme == "file":
        if uri.netloc not in {"", "localhost"}:
            raise ValueError("Remote file:// authorities are unsupported")
        return resolve_path(uri.path, allowed_local_roots=allowed_local_roots)
    if uri.scheme not in {"abfss", "s3", "gs"}:
        raise ValueError(f"Unsupported store protocol: {uri.scheme}")
    object_path = uri.path.lstrip("/")
    if uri.scheme == "abfss":
        container, separator, host = uri.netloc.partition("@")
        suffix = ".dfs.core.windows.net"
        if not separator or not host.endswith(suffix):
            raise ValueError("Use abfss://container@account.dfs.core.windows.net/path")
        config = StoreConfig(
            protocol="abfss", root="", container=container, account_name=host[: -len(suffix)]
        )
    else:
        config = StoreConfig(protocol=uri.scheme, root="", bucket=uri.netloc)
    # Reuse a configured store when its authority and root contain the URI.
    candidates = []
    configured_authority = False
    for configured in stores.values():
        if (
            configured.protocol,
            configured.account_name,
            configured.container,
            configured.bucket,
        ) != (config.protocol, config.account_name, config.container, config.bucket):
            continue
        configured_authority = True
        root = configured.root.strip("/") if configured.root != "." else ""
        if not root or object_path == root or object_path.startswith(root + "/"):
            candidates.append((len(root), configured, object_path[len(root) :].lstrip("/")))
    if candidates:
        _, config, object_path = max(candidates, key=lambda item: item[0])
    elif configured_authority:
        raise PermissionError("URI is outside the configured store roots")
    return resolve_store(config, object_path, auth_profiles=auth_profiles)
