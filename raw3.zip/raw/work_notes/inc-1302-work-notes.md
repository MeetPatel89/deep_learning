---
doc_id: WN-INC-1302
title: INC-1302 Work Notes
doc_type: work_notes
service_id: svc_internal_api_gateway
owner_group: Platform Engineering
visibility: internal
status: closed
created_at: "2026-06-18T21:10:00"
updated_at: "2026-06-19T01:20:00"
related_records:
  - INC-1302
  - KI-307
  - RUNBOOK-API-005
  - CHG-2420
source_facts:
  - KI-307
  - svc_internal_api_gateway
difficulty_tags:
  - internal-only-detail
  - timeline-reconstruction
servicenow:
  table: sys_journal_field
  element: work_notes
  parent: INC001302
  parent_table: incident
  visibility: internal
  contains_customer_safe_wording: false
---

# INC-1302 Work Notes

## Record details

| Field | Value |
| --- | --- |
| Table | sys_journal_field |
| Element | work_notes |
| Parent | INC001302 |
| Parent table | incident |
| Visibility | internal |
| Contains customer-safe wording | false |

## Work notes

These are the internal work notes for INC001302. The notes contain internal policy names and applied burst-limit detail. This detail must not appear in customer communications. Customer-facing wording is tracked separately under COMM-INC-1302 and follows the KI-307 customer-safe summary.

### 2026-06-18T21:12:00 — Service Desk L1

Initial triage of Business-tier 429 reports. Collected client IDs, affected endpoints, approximate timestamps, and customer tier from the first reporting clients. All reporting clients confirmed as Business-tier. Errors are HTTP 429 Too Many Requests during burst traffic. No secrets, tokens, or credentials recorded in the ticket.

### 2026-06-18T21:25:00 — Service Desk L1

Checked the recent change calendar. CHG-2420 deployed a new API Gateway rate-limit policy with a window of 2026-06-18T20:00:00 to 2026-06-18T20:45:00. All reported 429 timestamps fall after the change window closed. Noting the change correlation and routing per RUNBOOK-API-005.

### 2026-06-18T21:40:00 — Platform Engineering

Reviewed Splunk for 429 volume. Elevated 429 counts confirmed for the reporting Business-tier client group beginning shortly after 20:45. Enterprise-tier client groups show no comparable increase in the same window. Symptoms consistent with a policy-side issue rather than client traffic growth.

### 2026-06-18T22:00:00 — Platform Engineering

Opened KI-307 for unexpected 429 responses after the rate-limit policy update. Symptom pattern on this incident matches KI-307: Business-tier clients affected more often than Enterprise clients, errors starting after the rate-limit policy deployment.

### 2026-06-18T22:20:00 — Service Desk L1

Escalated to Platform Engineering with the collected evidence set: client IDs, endpoints, timestamps, and confirmed Business-tier status for all affected clients. Customer-safe holding update sent using the KI-307 approved wording; internal detail withheld from the outbound message.

### 2026-06-18T22:35:00 — Platform Engineering

Began comparing the applied rate-limit policy against customer entitlement in the gateway configuration. Pulled the policy set deployed by CHG-2420 from the Kong-backed gateway configuration and lined it up against the tier entitlement records for the affected client group.

### 2026-06-18T23:20:00 — Platform Engineering

Mismatch identified. The new rate-limit policy applied a stricter burst limit to the Business-tier client group than that tier's entitlement allows. The applied burst ceiling for the affected client group is below the entitled burst level, so valid burst traffic within entitlement is being rejected with 429. Enterprise-tier policy assignments match entitlement, which explains the tier skew. Internal detail only — do not include policy names or burst values in customer updates.

### 2026-06-19T00:25:00 — Platform Engineering

Corrected the policy assignment for the affected Business-tier client group so the applied burst limit matches tier entitlement. Change applied to the gateway configuration and confirmed active. Full rollback of CHG-2420 not required; correction scoped to the mismatched client group.

### 2026-06-19T00:55:00 — Platform Engineering

Asked Service Desk L1 to have affected clients retest. Retest confirmed burst traffic within entitlement now succeeds without 429. Splunk shows 429 volume for the affected client group returning to expected baseline.

### 2026-06-19T01:20:00 — Platform Engineering

Resolving INC001302. 429 volume normalized for the affected clients and applied policy verified against entitlement. KI-307 remains active pending the permanent fix tracked under PRB-411. Post-incident follow-up handed to problem management.
