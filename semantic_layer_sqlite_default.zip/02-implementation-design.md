# Enterprise NL-to-SQL platform: implementation design

Version 2.1 • Revised 2026-09-26 • SQLite catalog by default • Business data: Azure SQL Database

Companions: [Constitution](01-semantic-layer-constitution.md), [worked producer examples](03-worked-examples.md), [schema reconciliation guide](04-constitution-to-catalog-schema-guide.md), [default SQLite catalog schema](catalog-schema.sql), [SQLite authority settings](catalog-sqlite-authority-settings.sql), [optional PostgreSQL schema](catalog-postgresql.sql).

## Contents

- [1. Scope and architecture decisions](#1-scope-and-architecture-decisions)
- [2. System architecture and responsibilities](#2-system-architecture-and-responsibilities)
- [3. Enterprise catalog model and onboarding](#3-enterprise-catalog-model-and-onboarding)
- [4. Catalog storage, projections and publication](#4-catalog-storage-projections-and-publication)
- [5. Enterprise retrieval and context assembly](#5-enterprise-retrieval-and-context-assembly)
- [6. Semantic graph and relationship planning](#6-semantic-graph-and-relationship-planning)
- [7. Value resolution, examples and domain procedures](#7-value-resolution-examples-and-domain-procedures)
- [8. General semantic query model and compiler](#8-general-semantic-query-model-and-compiler)
- [9. LangGraph workflow from the first production release](#9-langgraph-workflow-from-the-first-production-release)
- [10. Execution, security and trust boundaries](#10-execution-security-and-trust-boundaries)
- [11. Reliability, observability and capacity](#11-reliability-observability-and-capacity)
- [12. Production evaluation and release gates](#12-production-evaluation-and-release-gates)
- [13. Implementation contracts and repository organization](#13-implementation-contracts-and-repository-organization)
- [14. Phased delivery plan](#14-phased-delivery-plan)
- [15. Decision rationale and tradeoffs](#15-decision-rationale-and-tradeoffs)
- [16. Deliverables, remaining decisions and verification](#16-deliverables-remaining-decisions-and-verification)

## 1. Scope and architecture decisions

This design targets a production application across a large company database with many business domains, ambiguous terminology, overlapping datasets, complicated relationships and concurrent users. The four producer tables supplied earlier are a small teaching and regression fixture. They do not determine platform capacity, deployment topology or the complete query language.

The recommended first production release includes **hybrid lexical/vector retrieval with reranking, a typed relationship/dependency graph, durable LangGraph orchestration, a persistent SQLite catalog behind an authoring service, read-only in-memory SQLite readers loaded from immutable releases, and deterministic query planning/compilation**. The first rollout can cover a limited number of actual company domains while using this platform architecture. Domain coverage and operator coverage expand through explicit releases. PostgreSQL and Azure SQL are later catalog backend options selected by measured write, capacity and availability needs; neither is required for initial metadata storage.

Large schema size does not by itself make every additional database necessary. Each chosen component has a concrete responsibility and acceptance criteria. Azure AI Search supplies both lexical and vector indexes. The semantic graph is a required data structure; whether it also needs a dedicated graph server is a capacity and workflow decision made against the enterprise benchmark before production.

### 1.1 Confirmed constraints and open sizing inputs

| Item | Treatment |
|---|---|
| Operational query target | Azure SQL Database; T-SQL compiler/executor |
| Semantic catalog | User selected SQLite for persistent metadata and in-memory fetching; this supersedes the earlier PostgreSQL default |
| Default authority and read store | Durable local SQLite file owned by CatalogService; approved releases loaded into per-worker in-memory SQLite |
| Later backend choices | PostgreSQL or a separate Azure SQL metadata database behind the same catalog interfaces; migration requires adapter and operational validation |
| Catalog contents | Descriptions, field roles, business identity/grain, values, metrics, predicates, examples, relationships, policies and evidence |
| Supplied workbook | Header-only authoring template; its five categories are retained and expanded |
| Four supplied tables | Sample fixture only; see companion appendix |
| Deployment scale | Actual table/domain counts, traffic, concurrency, SLA, budget and team experience were not provided |
| Technology policy | Prefer supported production features; pin versions and deployment configuration after compatibility evaluation |

Use the following **provisional engineering envelope**, not a claim about company size: 1,000–10,000 tables/views, 20,000–300,000 fields, 10–100 domains, tens of thousands of approved relationship/dependency edges, 50 simultaneous workflow requests, and separate interactive/export queues. Generate larger stress catalogs as needed. Operational data rows can number millions or billions and are not copied into the semantic catalog. Replace the envelope with measured inventory and demand in Phase 0; it must guide capacity tests rather than silently set product limits.

### 1.2 Technology decision register

| Capability | Initial production recommendation | Rationale | Decision boundary |
|---|---|---|---|
| API and domain services | Python service modules with typed request/response schemas | Fits SQL, retrieval and LangGraph integration | API framework is replaceable; do not put rules in route handlers |
| Canonical metadata | SQLite on a durable local volume, accessed through CatalogService | Transactional authoring and publication with serialized short writes and optimistic revisions | Migrate authority to PostgreSQL or Azure SQL when measured contention or availability requirements demand it |
| Runtime metadata | Read-only in-memory SQLite per worker, loaded from immutable release files | Indexed exact reads from one coherent release | RAM copies are disposable; bound memory and retain a read-only file mode for large releases |
| Retrieval | Azure AI Search hybrid text/vector indexes, evaluated semantic reranking | Language matching and exact technical lookup in one retrieval service | A dedicated vector product is an alternative backend, not an additional mandatory component |
| Graph planning | Planner service with immutable typed multigraph per release, NetworkX initial backend | Parallel edges, roles, temporal paths, dependency closure | Benchmark memory/latency; choose Neo4j/shared graph backend before release if requirements demand it |
| Orchestration | LangGraph; separate persistent SQLite checkpoint file for the admitted initial single-host workload | Durable clarification and restart recovery with explicit concurrency limits | SQLite checkpoint support targets lightweight deployments; validate load/recovery and upgrade this backend independently if needed |
| Work dispatch | Durable queue and execution workers; Azure Service Bus is the proposed Azure deployment choice | Admission control, long-query isolation, explicit retries | Queue messages carry IDs, not full query results/secrets |
| Object storage | Versioned blob storage | Catalog exports, SQLite snapshots, graph artifacts, permitted result files | Encryption, retention and access scope configured |
| Business execution | Restricted Azure SQL adapter using parameterized driver APIs | Controlled query workload and source-side authorization | No model-supplied connection strings or executable SQL |
| Observability | OpenTelemetry-compatible traces/metrics exported to the approved enterprise platform | End-to-end request/definition/query correlation | Model traces must respect the same data retention rules |

These are design recommendations, not a claim that the services are deployed or configured in this workspace. A managed-service feature list does not establish application correctness or operational readiness.

### 1.3 What changes from the prior scope

The production baseline includes hybrid retrieval, LangGraph and a typed graph from the outset. The revised storage decision uses SQLite in two roles: a durable authority behind a catalog service, and disposable in-memory read models built from approved releases. Multiple authors use the service, which serializes database writes and detects conflicting edits. PostgreSQL/Azure SQL catalog adapters are later deployment choices. The query language remains a general typed relational plan with a capability registry; its scope is independent of the initial catalog engine.

## 2. System architecture and responsibilities

### 2.1 Control services and query services

```mermaid
flowchart TB
    subgraph Control[Metadata authoring and publication]
        DISC[Schema discovery and governed profiling] --> STAGE[Candidate metadata and evidence]
        OWN[Business stewards and engineers] --> STAGE
        STAGE --> CS[CatalogService and serialized writes]
        CS --> CAT[(Persistent SQLite authority)]
        CAT --> PUB[Release validation and publisher]
        PUB --> BLOB[Versioned release artifacts]
        PUB --> SEARCH[Hybrid lexical and vector indexes]
        PUB --> GRAPH[Typed graph projection]
        PUB --> MAN[Active release manifest]
    end
    subgraph Query[Production query services]
        API[Authenticated API] --> WF[LangGraph workflow workers]
        WF --> RET[Domain routing and hybrid retrieval]
        SEARCH --> RET
        GRAPH --> PLAN[Relationship and grain planner]
        RET --> CTX[Authorized context package]
        CTX --> LLM[Intent interpreter]
        LLM --> IR[Typed semantic query proposal]
        IR --> PLAN
        PLAN --> COMP[Deterministic compiler and validators]
        COMP --> QUEUE[Execution ledger and workload queue]
        QUEUE --> EXEC[Restricted Azure SQL executor]
        EXEC --> DATA[(Company Azure SQL database)]
        DATA --> RESULT[Result storage and answer assembly]
    end
    BLOB --> FILE[Immutable SQLite release file]
    FILE --> SNAP[(Per-worker in-memory SQLite)]
    MAN --> WF
    SNAP --> CTX
    SNAP --> PLAN
    WF --> CP[(Separate persistent workflow checkpoints)]
    POL[Live authorization service] --> API
    POL --> CTX
    POL --> EXEC
```

Metadata authoring and query execution have different write rates, permissions and availability requirements. Deploy them as separate roles even if they initially share a repository and some application code. Start with an API/workflow deployment, catalog/publisher workers and execution workers; split other modules only when independent scaling or isolation requires it. This provides enterprise boundaries without requiring one microservice per box.

### 2.2 Ownership of decisions

| Step | LLM judgment | Deterministic/service responsibility |
|---|---|---|
| Domain routing | Propose relevant business areas and alternate meanings | Enforce authorized domains; retrieve ranked alternatives; track coverage |
| Field/metric interpretation | Interpret wording using descriptions and approved examples | Resolve IDs/types, required dependencies and applicable versions |
| Value interpretation | Select candidate meaning or ask a focused question | Exact/alias lookup, indexed candidates, authoritative physical bindings |
| Relationship choice | Express intended role: holder, seller, approver, current owner, etc. | Find approved paths, apply role/time constraints and operation contracts |
| Output shape | Specify counted unit, grouping, detail expansion and time scope | Prove applicable grain constraints within supported algebra |
| SQL generation | No executable SQL authority in normal query path | Lower typed plan to T-SQL and bind parameters |
| Repair | Revise a mistaken intent or clarify missing scope | Bounded errors; no weakened permission or join policy |
| Answer | Explain executed scope and caveats in natural language | Supply exact results, lineage, completeness and execution metadata |

“Typed semantic query” means a schema-constrained proposal about entities, metrics, populations, relationships and operations. Retrieval happens **before and during** proposal construction. The plan is then bound and checked against authoritative definitions. A plan can be well-typed and still reflect a misunderstood request, which is why reviewed examples, clarification and semantic evaluations are also required.

### 2.3 End-to-end request flow

1. Authenticate the caller, establish server-owned access context and pin a compatible release manifest.
2. Interpret scope/history from the conversation and route to authorized domain candidates.
3. Retrieve domain/object/example candidates with exact, lexical and vector methods; rerank within the trusted retrieval boundary.
4. Expand the graph to include required bridge entities, predicates, metrics, identity/temporal facts and policy dependencies.
5. Rehydrate all selected objects from the release snapshot, reauthorize, and assemble a bounded context package.
6. Resolve business values and produce a typed semantic query. Clarify material ambiguity or retrieve additional evidence within budget.
7. Bind IDs/values, plan relationships and grain, apply source restrictions, compile T-SQL and validate its complete AST.
8. Seal a query artifact, admit it to a workload class, and execute with current access checks.
9. Return results with units, interpretation, completeness, versions and source freshness. Persist only the authorized audit/result data.

## 3. Enterprise catalog model and onboarding

### 3.1 Catalog object model

| Object | What it represents | Why it is separate |
|---|---|---|
| Business domain | An ownership and meaning boundary such as distribution or finance | A term such as active/revenue/customer can mean different things by domain |
| Data source and dataset | Connection reference, physical object or approved derived relation | Source binding can change without changing a business concept |
| Entity and field | Row subject, projected attributes, roles, semantic/physical types | Precise field use and lineage |
| Identity and grain | Physical row key, business identity, version/current population, output unit | Surrogate uniqueness alone does not establish business counts |
| Concept and value domain | Business term, canonical category/status, aliases and relationships | Labels and source codes differ across domains/systems |
| Value binding/provider | Typed source literals or authorized indexed lookup service | Large dynamic dictionaries cannot all be prompt content |
| Predicate and metric | Reusable conditions and measures with time/unit/additivity rules | Centralized meaning and dependency analysis |
| Relationship and operation | Correspondence facts plus permitted filtering/enrichment/expansion | Key equality, cardinality and population preservation are different facts |
| Query template | Approved reusable plan pattern | Supports complex frequently used questions without hardcoding source SQL in prompts |
| Evidence/assertion | Constraint, owner decision, profile, lineage and freshness | Makes assumptions explicit and invalidatable |
| Example/evaluation case | Question, expected intent, fixture/results and rejection behavior | Guides interpretation and supports release gates |
| Policy binding | References to current access rules and source restrictions | Authentication/authorization stay outside model control |

The existing workbook's tables, columns, enum mappings, joins and examples map into this model. Excel remains one optional authoring input. At enterprise scale the catalog service, bulk import API, review UI and metadata connectors are the primary onboarding path.

### 3.2 Discovery pipeline

Use Azure SQL catalog views to collect object names, columns/types, primary/foreign/unique constraints and dependency metadata within the allowed metadata scope. Physical catalog views provide structural evidence; they do not supply business definitions. [Microsoft catalog-view documentation](https://learn.microsoft.com/en-us/sql/relational-databases/system-catalog-views/catalog-views-transact-sql?view=sql-server-ver17)

Combine structural metadata with approved data dictionaries, owners' descriptions, existing semantic models, ETL lineage and reviewed query examples. Permissioned profiling can measure nulls, duplicates, code coverage and cardinality with strict sampling/full-scan declarations and workload limits. Never assume a table is safe to expose because a connector can discover it.

```mermaid
flowchart LR
    S[Source schemas and approved documentation] --> D[Discover and fingerprint]
    D --> C[Candidate definitions and inferred edges]
    C --> R[Owner and engineering review]
    R --> A[Approved catalog objects]
    A --> T[Contract and evaluation gates]
    T --> P[Published release]
    S --> DR[Drift detection]
    DR --> C
```

Lifecycle is discovered → proposed → reviewed → published → deprecated/withdrawn. Inferred joins, LLM-generated descriptions and query-log patterns remain proposed until reviewed. Existing foreign keys can support correspondence but cannot select a business role, time interval or mandatory LEFT behavior on their own.

### 3.3 Identity, grain and source history

Each entity declares row meaning, physical-row identity, business identity, version identity if relevant, current/as-of row-selection rule, nullable-key behavior, normalization and evidence scope. A surrogate primary key may identify an ingestion row or history version. Do not call `COUNT(*)` a business-entity count until the counted population is defined.

A logical business key can be a column combination or an authoritative stable entity ID that maps to the business thing. It need not always be a natural composite key. A surrogate that is proven to stay one-to-one with the business entity can serve that role; a surrogate whose only guarantee is physical row uniqueness cannot establish it. This distinction applies across every domain.

Physical source rows, distinct business entities, current versions, events and snapshots are different metric units. If a history table lacks sufficient version or effective-time fields, either expose an explicit source-row metric or mark the requested business/as-of metric unsupported. Do not choose an arbitrary latest row or deduplicate without an owner-approved rule.

### 3.4 Domain coverage and onboarding order

Inventory the whole relevant database, then prioritize domains by business demand, data readiness, ambiguity and risk. The first production rollout should include multiple real domains, overlapping terminology and at least one approved cross-domain path; the four-table fixture alone is insufficient. Declare unsupported question families visibly and route coverage gaps into a steward backlog.

Record coverage independently: discovered assets, reviewed entities, verified metrics, supported query families, unavailable history, unknown joins and resolved value coverage. Report both correctness on supported questions and the fraction of useful requests supported. A system that declines every difficult request must not receive a misleadingly high quality score.

## 4. Catalog storage, projections and publication

### 4.1 SQLite persistence and in-memory reads by default

The initial catalog authority is `catalog-authority.sqlite` on a durable volume attached to one catalog-service host. All editors, importers and publishers access it through CatalogService. The service owns transactions, write admission, review permissions and revision checks. A shared application service can serve multiple users while serializing short database writes. Operational data remains in Azure SQL.

The authority stores drafts, approved definitions, release records, projection state, manifests and a transactional outbox. Workers consume immutable published semantic releases. Each worker loads its selected release into a read-only in-memory SQLite database for exact metadata lookups, alongside the matching graph and search projection references. The RAM database is a disposable copy of the published file; authoring never happens in that copy.

| Storage role | Default representation | Writes and recovery |
|---|---|---|
| Catalog authority | Durable `catalog-authority.sqlite` | CatalogService writes; consistent backups preserve drafts and publication state |
| Published release | Immutable `catalog-r42.sqlite` plus external checksum/manifest | Publisher creates once; retained artifact rebuilds read copies |
| Worker lookup store | In-memory SQLite for release `r42` | Loaded once then query-only; discarded and reloaded after restart |
| Workflow checkpoints | Separate durable `workflow-checkpoints.sqlite` for the initial admitted deployment | Workflow persistence writes independently; never copied into semantic releases |

Multiple query workers can read their own release copies without contending for the authority's write lock. Only one host owns the writable authority file. Remote editors/workers use the service API; they do not mount the live database over a network filesystem. SQLite's deployment guidance supports an application server owning the database while identifying concurrent-write and distributed-access limits. [SQLite deployment guidance](https://www.sqlite.org/whentouse.html)

This is a production deployment option with an explicit workload and recovery envelope, rather than a promise of automatic failover. If the initial service's availability, write load or restore time fails the accepted requirements, adopt a server catalog backend before that requirement is released. Table count alone does not settle that choice.

`catalog-schema.sql` is the default bootstrap for authority and published read representations. `catalog-postgresql.sql` is an optional future adapter bootstrap. Both now include the outbox and `catalog_release.edit_revision`; their catalog schema version is 3. Azure SQL metadata storage has a defined adapter/migration contract in sections 4.8–4.10, but its DDL and adapter are future implementation work. These files do not create the full authoring audit, execution ledger or LangGraph checkpoint schema.

### 4.2 Projection contents

| Projection | Content | Rebuild source |
|---|---|---|
| SQLite release file and in-memory copy | Approved objects, bindings, predicates, metrics, contracts, capabilities and evidence references | Canonical release export, then file-to-memory load |
| Search index | Atomic semantic documents and embeddings with release/security/domain metadata | Canonical export plus approved text transforms/embedding model |
| Graph artifact | Typed nodes, executable relationships, dependencies and reviewed lineage | Same release's structured records |
| Example index | Approved questions/intent summaries and expected-plan references | Versioned example registry |
| Value index/provider | Authorized business dictionary entries; source bindings and freshness | Reference source or catalog domain, with separate lifecycle |

Store secrets only in the approved secret-management system. Catalog connection references identify configured providers without carrying passwords, tokens or full privileged connection strings.

Snapshot export copies only approved semantic records and canonical release identity. Projection-build, active-pointer, manifest and outbox rows remain in the persistent authority; their matching tables are empty in the published SQLite file and its RAM copy. Draft rows are excluded. Keep the snapshot's file checksum in the authority/external manifest, outside the file being checksummed. Canonical semantic hashes exclude audit timestamps, `edit_revision`, hashes themselves and build-control records. Specify canonical JSON and timestamp normalization identically across backend adapters.

### 4.3 Release manifest

```json
{
  "manifest_version": 1,
  "release_id": "enterprise-2026-09-26-r1",
  "catalog_schema_version": 3,
  "catalog_hash": "sha256-example",
  "sqlite_artifact": "catalog/r1/catalog.sqlite",
  "search_projection_id": "semantic-r1",
  "graph_projection_id": "graph-r1",
  "embedding_config_id": "embedding-config-v1",
  "retrieval_config_id": "hybrid-rerank-v1",
  "compiler_capability_set": "query-algebra-v1",
  "workflow_version": "workflow-v1",
  "prompt_version": "intent-v1",
  "model_config_id": "approved-model-v1",
  "compatible_policy_schema": 1
}
```

IDs are illustrative; choose actual approved model/deployment configurations during implementation. Pin dimensions, model identity, input-text transformation and index metric in the embedding configuration. Similarity scores from different configurations are not directly interchangeable. Authorization grants and emergency revocations are evaluated live rather than frozen by this manifest.

### 4.4 Publish atomically at the logical level

1. Commit draft edits with reviewer attribution and optimistic concurrency. Validate references, typed expressions, source bindings, grain/identity evidence and policy dependencies.
2. Freeze a candidate catalog release and canonical export. A transactional outbox records projection-build events in the same database transaction as the release state.
3. Build SQLite, search and graph projections under immutable IDs. Workers process outbox messages idempotently; retries cannot create another logical release.
4. Verify content/hash and referential coverage, run retrieval/graph/compiler evaluations, and mark each projection ready.
5. Activate the manifest only when all required projections and application versions are compatible. The active-manifest pointer changes in one catalog transaction.
6. New requests pin the new manifest. In-flight requests keep their old release unless access revocation, a critical semantic error or retirement policy invalidates it.

There is no distributed transaction spanning the catalog authority, search and object storage. SQLite commits the release transition and outbox event together; projection work occurs afterward. Immutable artifacts and the manifest activation gate provide coherent request behavior. Do not overwrite a live index while independently updating the catalog. Use versioned indexes where quotas permit or strict release filtering in a shared index with complete build verification; requests always specify their pinned release.

Rollback selects a previously validated complete manifest, subject to current policy and source compatibility. An urgent source change can invalidate old SQL even if the old catalog still exists. Retention and garbage collection must account for checkpoint references, active requests and audit policy.

### 4.5 Change impact and revocation

Traverse dependency edges to find metrics, predicates, contracts and examples affected by a changed field, code set or identity rule. Rebuild only content-addressed unchanged-safe artifacts where possible, but evaluate the affected closure. Alias-only changes still require retrieval checks; grain and scope changes require answer-impact review.

An access revocation immediately invalidates entitlement/cache/artifact checks and prevents affected content from reaching model context, even if an old search index contains the document. If the application cannot enforce current policy, it must not serve that protected context from a stale projection. Withdrawn definitions can be denied by ID immediately while a new complete release is built.

### 4.6 Persistent SQLite transactions, concurrency and recovery

Initialize the authority with [catalog-sqlite-authority-settings.sql](catalog-sqlite-authority-settings.sql): enable foreign keys, WAL journaling, `synchronous=FULL` and an initial bounded lock wait of 5,000 ms. Configure/check these settings before transactions; WAL mode persists on the database, while connection settings must be applied per connection. Use a supported SQLite build with current fixes and verify actual driver/runtime versions at deployment. [SQLite WAL](https://www.sqlite.org/wal.html), [SQLite configuration](https://www.sqlite.org/pragma.html)

CatalogService admits one write transaction at a time. Keep edits short; do retrieval, model calls, profiling, embedding generation and artifact uploads outside the transaction. Batch imports into bounded drafts and freeze a complete candidate before publication. A long read transaction can delay WAL checkpoint progress, so the publisher should materialize a frozen canonical export promptly rather than holding the authority transaction open during external builds.

Use `catalog_release.edit_revision` for optimistic concurrency. Within one SQLite `BEGIN IMMEDIATE` transaction, conditionally advance the revision only when the caller's expected revision matches and the release is still editable. If no row matches, roll back and return a conflict; perform no semantic writes. Otherwise apply all related metadata changes and commit together. Freeze transitions also compare the expected revision. Published semantic records are immutable through the service; editing them starts a new draft release. These lifecycle rules are application obligations, not a side effect of adding the integer column.

Independent author sessions can therefore submit concurrently, but conflicting edits cannot silently overwrite each other. Handle transient lock contention with a bounded deadline and explicit errors; a timeout never counts as a successful edit. SQLite serializes writes, and snapshot readers can coexist with a writer under WAL. [SQLite isolation](https://www.sqlite.org/isolation.html)

The authority and publication outbox share one database so the release transition and dispatch record commit atomically. The outbox consumer records retries and delivery only through the same owning service. Workflow checkpoints and the execution ledger have separate storage/lifecycles to avoid their frequent writes extending catalog transactions. Cross-store effects use durable IDs and reconciliation; they are not one atomic transaction.

Store the live file on a durable volume whose locking and flush behavior are supported by SQLite. Back up the complete authority using an online-backup procedure or a quiesced consistent backup, then retain protected copies off the host and rehearse restoration. Published semantic files are useful rebuild inputs but omit drafts, outbox progress and activation history; they are not full authority backups. Do not copy only the live main file while a WAL contains uncheckpointed commits. [SQLite backup API](https://www.sqlite.org/backup.html)

The initial service has one writable authority owner and a measured restore procedure. It does not provide automatic multi-host failover. A failover process must fence the old owner before admitting a new writer and establish the restored manifest/outbox state. When that operational requirement exceeds the accepted single-host envelope, use PostgreSQL or Azure SQL authority instead of improvising network-file sharing.

### 4.7 Loading published SQLite into memory

The default exact-lookup path is `published release file -> in-memory SQLite -> typed catalog objects`. It is not a write-through cache of drafts.

1. Resolve the request's manifest and obtain the matching immutable file. Verify its checksum, supported catalog schema version, release identity and semantic export completeness before using it.
2. The publisher finishes and closes a standalone release file without live WAL dependencies. It contains approved semantic records; authority-control tables are empty.
3. Open that file read-only. Create a fresh in-memory SQLite connection and copy the finished release using SQLite's backup API, exposed by Python's `Connection.backup`. Validate the loaded release ID and required contents.
4. Set the memory connection to query-only and expose a `CatalogReader` interface containing approved read operations. A connection pragma is a misuse guard; trusted service boundaries and authorization still provide security.
5. Build/load the matching graph and register the reader under its release/manifest identity. A worker marks the release ready only when all local components are compatible.
6. New requests acquire that reader. Existing requests retain their previously acquired release. Release references are counted; close an old reader only when no request holds it, subject to configured retention and retirement policy.
7. After a process restart, reconstruct memory from the persisted artifact. No approved edits or durable workflow state depend on the RAM copy surviving.

Each `:memory:` connection normally creates an independent database. Do not open a new connection per query expecting it to contain another connection's rows. The initial reader owns one connection on a designated execution thread/actor per loaded release, or explicitly creates separately loaded read connections with a measured memory budget. Named shared-memory connections are a possible later within-process adapter detail; they do not provide cross-host persistence. [SQLite in-memory databases](https://www.sqlite.org/inmemorydb.html), [Python SQLite backup support](https://docs.python.org/3/library/sqlite3.html#sqlite3.Connection.backup)

Budget total memory for every worker and simultaneously retained release, including the graph, decoded objects and query overhead. Atomic replacement may briefly require both old and new releases. Enforce a configurable upper bound on loaded releases; recover older pinned requests from retained artifacts or return an explicit retired/unavailable outcome. Never silently substitute a newer release for an old request.

Support `read_mode=immutable_file` through the same reader contract if the complete release exceeds the RAM allowance. Memory mode is the requested default, but its benefit should be measured against a read-only file with the operating system's cache. A file fallback must keep the same complete semantic contents and version checks. Avoid partial in-memory catalogs that omit bridge or policy dependencies merely to fit a budget.

Live authorization and emergency revocation checks remain outside this immutable read view. A ready RAM snapshot does not permit using withdrawn definitions or stale access grants.

### 4.8 Storage interfaces and backend portability

Keep backend choice below semantic services. Application modules use typed records and operations, not SQLite cursors or engine-specific JSON queries. The ports are:

| Interface | Required operations | Default implementation | Later implementation |
|---|---|---|---|
| `CatalogAuthoringStore` | Read/edit draft at expected revision; atomically freeze with outbox event; manage review records | Local SQLite transactions inside CatalogService | PostgreSQL or Azure SQL transaction adapter |
| `ReleaseStore` | Read manifest, record artifact readiness, conditionally activate expected prior manifest, record outbox progress | Persistent authority tables in SQLite | Same logical tables/operations in selected server backend |
| `CatalogReader` | Resolve objects, fields, values, contracts, capabilities and dependencies within one release | Query-only in-memory SQLite; optional immutable-file reader | The same SQLite read implementation can continue after authority migration |
| `CatalogExporter` | Export canonical approved records with stable IDs and deterministic hash rules | SQLite authority adapter | PostgreSQL/Azure SQL authority adapter |
| `ReleaseArtifactStore` | Put/get immutable snapshots and graph artifacts, verify checksums and retention | Versioned artifact storage plus local verified files | Same contract regardless of authority engine |

The runtime semantic planner and compiler must depend on `CatalogReader`, not the authoring backend. Search and graph builders consume canonical records through `CatalogExporter`. This allows the authority to migrate while workers retain the same release format and read path.

Normalize transaction outcomes into application errors such as `RevisionConflict`, `CatalogBusy`, `ReleaseNotReady`, `UnsupportedSchema` and `StorageUnavailable`. The adapter owns locking, isolation, placeholders, JSON serialization, timestamp conversion, upsert strategy and driver retries. An ORM can reduce repetition but cannot make those semantics identical automatically.

Preserve stable semantic IDs and exact ID comparison across all backends. Use portable typed JSON payload contracts; define canonical timestamp, decimal and null encodings. Validate string lengths explicitly before introducing a backend with bounded indexed strings. Separate semantic content hashes from backend-specific file hashes.

| Storage detail | SQLite default | PostgreSQL option | Azure SQL option |
|---|---|---|---|
| Metadata text and IDs | Text; application enforces ID rules | Text with exact ID comparison | Bounded identifier columns with deliberate case/binary collation and index-width design |
| JSON payload storage | JSON text with syntax checks plus typed validation | JSONB with typed validation | JSON text in `nvarchar(max)` with appropriate validation, or evaluated compatible native representation |
| Binding literals | JSON may contain scalars such as `"PET"` | Preserve scalar JSON and exact type rules | Preserve scalar JSON semantics; default object/array-only validation is insufficient |
| UTC times | Canonical sortable text | Native timestamp conversion with canonical export | Chosen UTC `datetime2`/`datetimeoffset` conversion with canonical export |
| Edit concurrency | Serialized short transactions plus expected `edit_revision` | Expected-revision update and appropriate transaction isolation | Expected-revision update and appropriate transaction isolation |
| Publication | Atomic authority/outbox transaction and conditional activation | Equivalent atomic transaction/activation | Equivalent atomic transaction/activation |
| Published reads | SQLite release files and RAM copies | Retain the same read format | Retain the same read format |

Azure SQL supports storing and querying JSON text, but payload validation must preserve this catalog's scalar bindings as well as objects and arrays. A future adapter must test that behavior; do not mechanically replace every JSON check with an object-only check. [Azure SQL JSON features](https://learn.microsoft.com/en-us/azure/azure-sql/database/json-features?view=azuresql)

An Azure SQL metadata backend should use an explicitly managed metadata database/schema and credentials, separated from operational query access. Choosing the same engine does not imply merging metadata with the company's business tables. No future adapter is considered implemented merely because it appears in this table.

### 4.9 Measured triggers for a server catalog

SQLite can remain the authority as long as it satisfies the accepted requirements. There is no scheduled mandatory migration and no universal table-count cutoff.

| Observation or requirement | Action |
|---|---|
| Many catalog reads or query users, with infrequent metadata edits | Scale read workers/caches and measure memory; this alone does not require an authority migration |
| Large catalogs but acceptable imports, publication time, disk use and backup/restore time | Continue SQLite; measure release load and in-memory capacity |
| Sustained write queue growth, lock timeouts or edit/publication latency above the agreed SLO after sensible batching | Benchmark PostgreSQL and Azure SQL using the same workload |
| Concurrent independently scaled catalog writers across hosts are required | Move authority to a server backend |
| Required automatic failover, recovery time or central database operations cannot be met by the single-owner deployment | Choose an appropriate managed server topology before accepting that requirement |
| Workflow checkpoint writes exceed their separate envelope | Upgrade checkpoint storage independently; this does not automatically require moving the metadata catalog |

Phase 0 sets measured thresholds for author count/write bursts, commit and publication latency, maximum accepted queue wait, disk/WAL growth, release RAM use, startup time, backup duration and restore objectives. The large-schema test envelope in section 1 is input to those measurements, not proof that SQLite meets them. Record actual evidence before rollout.

### 4.10 Migration to PostgreSQL or Azure SQL

1. Implement the selected authority adapter and versioned schema migrations. Verify identical typed payload, ID, null, collation, transaction and canonical-export behavior with a backend conformance suite.
2. Provision the target with the needed permissions, backup/recovery and availability configuration. Validate representative authoring/publication loads and failure behavior.
3. Pause authoring and publication dispatch, drain or reconcile in-progress writes/builds, and take a consistent authority backup. Existing query requests can use retained releases only while current authorization remains enforceable.
4. Export and import all authority state: drafts, approved releases, object IDs, `edit_revision`, evidence/review records, artifact references, manifests, active pointer and outbox progress. Treat transient job ownership as expired and reconcile work rather than duplicating it.
5. Verify row/reference coverage, normalized semantic hashes, active-manifest identity and compatible artifact access. Build a trial release through the new backend and check that its logical content matches the expected export.
6. Switch the authority backend configuration once, with the old authority fenced against writes. Resume authoring/builds on the new store; retain existing immutable release files and workers' valid pinned readers.
7. Validate service behavior and retain the old consistent backup for the agreed rollback window. A rollback after new writes requires quiescing and transferring/reconciling those writes; pointing back to an old file would lose them.

This is a controlled data migration with limited catalog-write downtime. It avoids dual writable authorities and does not claim that SQL dialects are interchangeable. Semantic object identities, query-plan contracts, search/graph release linkage and the in-memory SQLite reader remain stable across the migration.

## 5. Enterprise retrieval and context assembly

### 5.1 Retrieval is a pipeline

```mermaid
flowchart TB
    Q[Question and authorized conversation scope] --> D[Domain candidates]
    D --> E[Exact identifiers and curated aliases]
    D --> L[Lexical retrieval]
    D --> V[Vector retrieval]
    E --> F[Candidate fusion]
    L --> F
    V --> F
    F --> R[Relevance reranking]
    R --> G[Graph bridge and dependency expansion]
    G --> A[Rehydrate and reauthorize exact definitions]
    A --> C[Context completeness and token budget]
    C --> P[Typed query interpretation]
    C --> X[Bounded wider retrieval or clarification]
```

Hybrid retrieval is justified here because schema names, business descriptions and user wording may differ across a large catalog. Azure AI Search combines full-text and vector retrieval and merges their rankings; exact technical codes still benefit from lexical lookup. [Azure hybrid-search behavior](https://learn.microsoft.com/en-us/azure/search/hybrid-search-overview)

Domain routing is a candidate-generating step, not a hard single-domain classifier. Retain several authorized domains when wording overlaps. Cross-domain intent can intentionally require entities from different domains. If no complete valid plan emerges, widen retrieval within the allowed scope before declaring the request unsupported. Log widening and clarification separately from a successful first-pass route.

### 5.2 What to embed

Create documents by semantic object, not arbitrary pages of all schema text. Entity documents include meaning, grain, business aliases and a concise field summary. Field documents include parent/domain context, data meaning, permitted use and value-domain references. Metric/predicate documents include business definition, unit, time basis and applicable population. Relationship documents describe role and purpose; their executable conditions remain structured catalog records. Example documents contain reviewed questions and intent summaries with definition dependencies.

Embed labels, descriptions, aliases and concise examples. Keep exact IDs, physical names and code-like aliases in searchable/filterable fields as appropriate. Do not embed unapproved sensitive rows, raw customer dictionaries or raw query logs by default. Examples containing sensitive literals need redaction or a separately authorized retrieval scope.

Illustrative search document:

```json
{
  "document_id": "r1__finance.net_revenue",
  "object_id": "finance.net_revenue",
  "object_kind": "metric",
  "release_id": "enterprise-2026-09-26-r1",
  "domain_ids": ["finance"],
  "label": "Net revenue",
  "aliases": ["revenue after adjustments"],
  "description": "Owner-approved definition is stored in the catalog.",
  "dependency_ids": ["finance.revenue_base"],
  "policy_scope_ids": ["finance-analytics"],
  "content_hash": "sha256-example",
  "embedding_config_id": "embedding-config-v1"
}
```

The vector field is omitted here for readability. Serialize a configured dimension count; never mix vectors from incompatible models in one field. A physical column rename can update binding metadata without forcing a new business definition, but any affected search text/projection still needs a compatible release.

### 5.3 Authorization and reranking

The trusted retrieval service applies release/domain/policy filters before returning candidates. On vector queries choose a tested prefilter strategy when needed for restricted recall; post-filtering can miss valid authorized neighbors when initial candidates are removed. [Azure vector-filter modes](https://learn.microsoft.com/en-us/azure/search/vector-search-filters)

Index ACL/security fields are an optimization and defense layer, not the authentication system. Build filters from trusted identity, never user-supplied group strings. Microsoft's security-filter pattern explicitly relies on application-managed filtering rather than authenticating a principal through the filter. Recheck selected objects against current policy before an external reranker or model sees text. Built-in search reranking may process indexed content inside the approved search trust boundary; deploying it requires accepting that service's data-processing boundary. For stronger isolation, separate indexes or services by policy zone. [Security filter pattern](https://learn.microsoft.com/en-us/azure/search/search-security-trimming-for-azure-search)

Use semantic reranking for candidate relevance where domain evaluation shows benefit. It reranks an initial candidate set and cannot recover required objects absent from that set; therefore candidate recall and graph expansion remain critical. [Azure semantic ranker](https://learn.microsoft.com/en-us/azure/search/semantic-search-overview)

### 5.4 Candidate and context budgets

Starting configuration for evaluation: keep up to 3–5 plausible domain candidates, retrieve tens of entity/metric/example candidates per channel, rerank a bounded union, then include only a small relevant entity set plus mandatory dependency closure. These are tunable starting values, not fixed correctness thresholds or vendor guarantees. Reserve model context space for actual fields, grain, relationships, filters and value resolutions rather than hundreds of decorative examples.

A context package contains exact versioned definitions, selected roles, required bridges, verified keys, metric/predicate dependencies, value handles, approved examples, unresolved alternatives and evidence provenance. Summary text may help readability, but a summary cannot replace the exact executable contract fetched by the planner.

If the dependency closure exceeds the context budget, decompose the question into approved subplans or perform staged tool retrieval. Mandatory policies and join/temporal conditions are loaded by services regardless of what fits in the prompt. Do not drop required constraints to meet a token target.

### 5.5 Retrieval completeness and repair

For each evaluation question, annotate the required entities, fields, metrics, relationships, values and time semantics. Measure **complete-set recall**: whether all necessary items reached the planner, not merely whether one relevant table ranked first. Include low-similarity bridge tables, competing domains, deprecated copies, homonyms, abbreviations and misspellings.

A failed plan may signal incomplete retrieval. Allow bounded follow-up retrieval targeted to the missing concept or relationship. Differentiate `no approved path`, `required object not retrieved`, `unauthorized dependency`, and `conflicting business definitions`. Avoid automatically enlarging the schema context indefinitely or interpreting access denial as evidence that a different unapproved path should be used.

## 6. Semantic graph and relationship planning

### 6.1 Required graph model

Use a typed directed multigraph from the first production release. Multiple edges between the same entities capture different business roles, time rules or operations. Distinguish these edge kinds:

| Edge kind | Permitted use |
|---|---|
| Approved executable correspondence | Candidate for query planning under its operation contract |
| Metric/predicate/field dependency | Context completion, compilation and impact analysis |
| Derived dataset lineage | Provenance, dependency invalidation and source traceability |
| Concept equivalence or taxonomy | Retrieval expansion with provenance and scope |
| Inferred association | Stewardship suggestion only; never a query join |

A language-generated knowledge-graph summary is not an executable relationship contract. The graph backend must preserve typed nodes/edges and exact referenced definitions. NetworkX's `MultiDiGraph` supports directed parallel edges and is a viable initial projection representation; validate its footprint and algorithms with the full enterprise benchmark. [NetworkX MultiDiGraph](https://networkx.org/documentation/stable/reference/classes/multidigraph.html)

### 6.2 Relationship correspondence versus operation

A correspondence states endpoint roles, namespace-qualified composite key pairs, temporal predicates, directional multiplicity, null-key semantics and evidence. Operations state intended use: existence, absence, one-record enrichment, child expansion, membership bridge or approved allocation. A mandatory left enrichment must preserve its source population, including after target filtering. An existence condition can use a many-to-many correspondence without multiplying the outer rows.

```json
{
  "id": "orders.customer_as_of_order_time",
  "source_entity": "sales.order",
  "target_entity": "customer.history",
  "source_role": "order",
  "target_role": "customer_at_order",
  "key_pairs": [
    {"source": "order.customer_key", "target": "customer.customer_key"},
    {"source": "order.identity_namespace", "target": "customer.identity_namespace"}
  ],
  "temporal_rule_id": "order_time_inside_customer_valid_interval",
  "source_to_target": "zero_or_one_after_temporal_filter",
  "required_assertions": ["customer_intervals_nonoverlapping"],
  "operations": [
    {"purpose": "enrich", "operator": "left_lookup", "preserve_source": true},
    {"purpose": "qualify", "operator": "exists"}
  ],
  "status": "illustrative_requires_approval"
}
```

These sales/customer names illustrate a broader enterprise case, not discovered company tables. Missing fields or temporal evidence make that particular operation unavailable; the platform is designed to represent it.

### 6.3 General relationship cases

Support composite and namespace-scoped keys, role-playing dimensions, temporal joins, slowly changing dimensions, self-relationships and explicit bridge datasets in the model. Reversing an edge does not inherit its preservation rule or multiplicity. For a many-to-many bridge, pure eligibility can use existence; attributing a measure through the bridge needs an allocation/deduplication rule. No default equal allocation may be invented.

Temporal uniqueness requires nonoverlapping valid intervals for the matched key and time basis, not just uniqueness of a version ID. Define boundary conventions, open-ended intervals, timezone and current-vs-as-of semantics. A matching row's technical restriction belongs inside the target relation or ON clause for preserving enrichment; a user-requested base qualification is modeled separately.

### 6.4 Bounded multi-target planning

Input: selected metrics/base entity, desired dimensions and roles, population predicates, output grain, time context, pinned graph and current authorization. Output: an approved relational plan or typed ambiguity/coverage error.

Algorithm:

1. Remove unpublished, revoked and unauthorized executable edges; load required dependencies separately.
2. Resolve endpoint roles and available operation contracts for each requested semantic object.
3. Enumerate a bounded candidate set using allowed path templates plus guided graph search. Keep independent alternatives; do not choose solely by shortest path.
4. Reject namespace/type/time incompatibilities, unsupported cycles, invalid fanout and required-evidence failures.
5. Combine candidate paths into a bounded plan search across all requested targets. Reusing a relation under incompatible roles requires separate aliases/subplans.
6. Rank remaining plans by semantic role match, approved preferred path, simplicity and estimated work, in that order. Performance cannot override business meaning.
7. Clarify materially different valid meanings. If search bounds are exhausted, return that distinct reason or route to an approved template; it is not proof that no path exists.

A shortest-path algorithm alone is inadequate for multiple targets and grain constraints. General path/plan search can grow combinatorially. Cap candidate counts, depth and runtime; instrument pruned paths and search exhaustion. Domain templates and curated preferred paths keep common queries predictable without hardcoding physical SQL into the interpreter.

### 6.5 Graph database decision before production

Default to an immutable per-release graph served by horizontally replicated planner workers. The size of the operational database does not determine the graph's size: this graph contains metadata nodes and contracts, not every operational record. Provisional planner objective is p95 under 250 ms for supported bounded searches at the benchmark envelope, with worker memory leaving at least 40% headroom. These are design targets to validate, not measured results.

Choose a dedicated graph service such as Neo4j in Phase 0/1 if the benchmark fails, if interactive lineage/impact exploration requires large shared traversals, or if independent graph consumers and operational query needs justify it. Store graph data as a release projection keyed by semantic IDs; the configured catalog backend remains authoritative, initially SQLite. Validate licensing, managed/private deployment and HA requirements for the selected edition. Neo4j documents clustered topology options; a database label alone is not a reliability design. [Neo4j clustering](https://neo4j.com/docs/operations-manual/current/clustering/)

This decision is intentionally about the graph backend. **Graph modeling, graph traversal and graph-based planning are already mandatory in the initial architecture.**

## 7. Value resolution, examples and domain procedures

### 7.1 Values need their own resolver

Metadata search identifies a field or metric. Value resolution identifies a canonical member and its exact physical encoding for each source binding. For a small domain, use exact code, normalized label and curated alias matching first. For large dictionaries, an authorized lexical/vector index can generate candidates; fetch the authoritative record before issuing a resolved handle.

The same concept can bind to several codes in one source and different codes in another. Return a typed set per field, including mapping validity and provider revision. A product-category concept can be one-to-many in stored codes without being ambiguous. Ambiguity means multiple competing meanings, not simply several approved encodings.

```json
{
  "status": "resolved",
  "resolution_id": "opaque-example-handle",
  "value_id": "product_category.pet",
  "catalog_release_id": "enterprise-2026-09-26-r1",
  "provider_revision": "catalog-r1",
  "bindings": [
    {"field_id": "agent_contract.product_category", "binding_ids": ["pet_agent_example"]},
    {"field_id": "agency_contract.product_category", "binding_ids": ["pet_agency_example"]}
  ],
  "match_method": "curated_alias"
}
```

Real handles bind principal/access scope, requested fields, effective time and expiry on the server. Outcomes are resolved, ambiguous, not_found, binding_missing, stale or not_authorized. A missing source binding must not silently remove a branch of an either-source condition. Sensitive candidate labels may themselves require access checks.

### 7.2 Large and changing dictionaries

For customers, products or accounts, use a provider contract: search candidates, read authoritative member, obtain source-specific typed binding, check visibility, and pin revision/freshness. Avoid live `SELECT DISTINCT` scans over large operational tables for every question. Build authorized reference projections or query indexed lookup tables with bounded results.

Invalidation includes code reassignment, merges/splits, deprecation, source-sync lag and access changes. Define whether historical queries use historical value bindings. Mapping a current label onto old data is a business rule that must be explicit. Embeddings propose candidate meanings; they never manufacture product/customer keys.

### 7.3 Examples and Agent Skills

A verified example stores question, disambiguated intent, expected semantic plan, definition dependencies, data fixture/reference result, reviewer and applicable capability set. Retrieve relevant examples from the enterprise index. Promote recurring business rules into predicates, metrics or templates so copied SQL does not compete with current catalog definitions.

Domain procedures can use Agent Skills packaging: explain vocabulary discovery, evidence retrieval, clarification, query submission and answer presentation; load domain resources only as needed. The skill is distributed as versioned procedural context and cannot authorize SQL or override policy. The [Agent Skills specification](https://agentskills.io/specification) describes that instruction/resource format; the runtime enforcement in this design is application code.

## 8. General semantic query model and compiler

### 8.1 Three representations

| Representation | Author | Contents and purpose |
|---|---|---|
| Proposed semantic query | LLM/interpreter | Typed business intent, selected IDs, roles, filters, metrics, time and output shape |
| Validated logical plan | Deterministic semantic services | Fully bound relation/operation DAG, values, grain, policies, lineage and assertions |
| Compiled execution artifact | Compiler | T-SQL AST/text, ordered typed parameters, manifest, access binding, expiry and immutable hash |

Do not require a separately hardcoded query kind for every business question. Model a general algebra from the beginning and enable supported operators through a versioned capability registry. A friendly proposal format can use detail/aggregate/cohort shorthand, such as the sample appendix, but it lowers into the same logical operators. Old proposal versions have explicit adapters; arbitrary unknown fields are rejected.

### 8.2 Operator model

| Operator family | Contract required | Rollout treatment |
|---|---|---|
| Scan physical/derived dataset | Authorized binding, source restrictions, row semantics | Initial production |
| Project, typed filter, sort, page | Allowed fields/operators; output identity and completeness | Initial production |
| Semi/anti qualification | Approved correlation, scoped target predicates | Initial production |
| One-record enrichment | Role/key/time contract; right-side uniqueness; preservation | Initial production |
| Child expansion/collection | Parent preservation, changed output grain, complete-child paging rule | Initial production for selected shapes |
| Aggregate and group | Measure unit, counted identity, additivity and allowed dimensions | Initial production for approved metrics |
| Union/intersection/cohort operations | Compatible schema and identity; explicit duplicate semantics | Initial production for required domain templates, broaden later |
| Temporal as-of join | Valid intervals, nonoverlap, timezone and boundary rules | Represented now; enable in domains with verified history |
| Window/ranking/period comparison | Partition grain, ordering, frame and time/calendar semantics | Phase 2 capability releases unless initial demand requires them |
| Multiple-fact combination | Independent aggregates to conformed dimensions; compatible filters | Phase 2 by default; earlier for required production use cases |
| Many-to-many measure attribution | Explicit bridge and allocation/deduplication definition | Governed capability; no implicit allocation |

Capability phases are planning defaults. Phase 0 demand analysis can move an operator into the first release. Safety is attached to the operator contract; product scope should not be frozen to a minimal demonstration.

### 8.3 Illustrative general proposal

```json
{
  "proposal_version": 2,
  "catalog_release_id": "enterprise-2026-09-26-r1",
  "requested_measures": ["finance.net_revenue"],
  "group_by": ["calendar.month", "customer.segment"],
  "population": {
    "entity_id": "sales.order",
    "filters": [{"field_id": "sales.order_date", "op": "in_period", "period_id": "resolved-last-quarter"}]
  },
  "relationship_roles": [
    {"target": "customer", "role": "customer_at_order_time", "purpose": "enrich"}
  ],
  "time_context": {"calendar_id": "approved-business-calendar", "timezone_id": "approved-business-timezone"},
  "output": {"shape": "table", "order_by": [{"field_id": "calendar.month", "direction": "asc"}]}
}
```

This sales example is illustrative, not a claim about actual company tables or definitions. The server resolves the period using an explicit request timestamp/calendar and validates the metric's actual base grain. A request combining an order-level amount with line-level product categories needs a reviewed attribution definition, even if all named fields exist.

### 8.4 Grain propagation

Each logical node carries input/output identity, row unit, multiplicity, population restriction, time basis and field lineage. Existence changes population while preserving the remaining base rows' multiplicity. One-to-many expansion changes output grain and prevents unsafe downstream base-measure sums. An aggregate produces one row per grouping tuple; ratio metrics carry numerator/denominator semantics and cannot generally be summed across groups.

For multiple fact tables, aggregate each fact at a common approved dimensional grain, then combine. Example: invoice revenue and payment amounts are separate fact measures; joining raw invoices to raw payments on customer can multiply both. A combined result requires compatible date/population definitions and a conformed customer/calendar mapping. Reaggregation must respect additive, semi-additive and nonadditive measures.

For business distinct counts, specify the complete identity and null policy. A distinct count over a composite tuple may require a grouped subquery in T-SQL; do not concatenate keys with a delimiter and risk collisions. If multiple source rows represent one entity, first apply the approved current/as-of or version rule. Declared grain plus a surrogate key is not sufficient evidence.

### 8.5 Compiler pipeline

```mermaid
flowchart LR
    I[Typed proposal] --> B[Bind IDs values and time]
    B --> P[Plan approved relationships]
    P --> G[Propagate grain and population]
    G --> S[Apply source and access restrictions]
    S --> L[Validated logical DAG]
    L --> T[T-SQL AST compiler]
    T --> V[Independent AST and manifest checks]
    V --> A[Sealed execution artifact]
```

Validate schema shape, known IDs, kind/type compatibility, domain capabilities, value bindings, role/time paths, required evidence, source authorization and query budget. Build only supported AST nodes. Deterministically generate aliases and parameter order. Identify every physical scan and approved derived relation in the manifest.

Identifiers come from validated bindings and are quoted component by component. Values use the driver's parameter interface, with approved type/length mappings. Multi-value mappings expand to separate placeholders or an explicitly supported large-set binding strategy. The agent cannot pass raw SQL snippets, arbitrary identifiers, credentials, policy claims or proof flags.

Validate the final AST against expected structure and obligations. This is tractable because the compiler emits a closed algebra. It is not a claim to prove arbitrary SQL equivalent to a business question. SQL parsers such as SQLGlot provide AST/dialect infrastructure; application policy and target-engine tests remain necessary. [SQLGlot documentation](https://sqlglot.com/sqlglot.html)

### 8.6 Advanced questions and escape-hatch policy

Add an approved derived dataset, reusable typed template or compiler operator when a needed business question exceeds current capabilities. An engineer may author reviewed SQL behind a secured database view with declared grain and lineage. That source becomes a governed binding.

Do not silently fall back to arbitrary LLM-authored SQL when semantic compilation fails. If an organization later chooses an expert SQL workbench, treat it as a separate permissioned product path with its own review, provenance and guarantees. It must not inherit the promise that normal agent answers satisfy all semantic contracts.

## 9. LangGraph workflow from the first production release

### 9.1 Why it belongs in this scope

The production workflow needs multi-domain retrieval, parallel evidence gathering, bounded repair, clarification across sessions and recovery after worker restart. Adopt LangGraph now to manage that control flow, with deterministic services implementing the business rules. Its runtime supports stateful orchestration and deterministic/agentic nodes. [LangGraph overview](https://docs.langchain.com/oss/python/langgraph/overview)

LangGraph is not responsible for business identity, joins, source permissions or SQL correctness. Those services remain directly callable and separately evaluated. A retrieval branch is usually a tool/service node, not necessarily another autonomous agent. Add specialist agents only where they demonstrate quality or throughput gains.

### 9.2 Workflow graph

```mermaid
flowchart TB
    START[Authenticate and pin release: code] --> ROUTE[Interpret domain candidates: LLM plus code]
    ROUTE --> RET[Parallel lexical vector and example retrieval: code]
    RET --> EXP[Graph expansion and context validation: code]
    EXP --> INT[Propose business query: LLM]
    INT --> RES[Resolve values roles and dates: code]
    RES --> DEC{Meaning complete?}
    DEC -->|Clarify| ASK[Ask user and checkpoint]
    ASK -->|Resume with access recheck| ROUTE
    DEC -->|More evidence within budget| RET
    DEC -->|Yes| PLAN[Plan compile and validate: code]
    PLAN -->|Recoverable intent error| INT
    PLAN -->|Valid| ADMIT[Workload admission and execution ledger: code]
    ADMIT --> EXEC[Execute bounded Azure SQL query: code]
    EXEC --> RESULT[Verify result envelope: code]
    RESULT --> ANSWER[Explain executed result: LLM plus code]
    PLAN -->|Unsafe or unsupported| STOP[Typed failure]
```

All backward transitions share a global attempt/tool/token/time budget. Define maximum retrieval expansions and interpretation repairs centrally; an error cannot reset the budget. A reasonable initial evaluation profile is two intent repairs and two targeted retrieval expansions, adjusted by measured task complexity and latency.

### 9.3 Durable state and access binding

State includes request ID, caller scope reference, conversation scope, pinned manifest, explicit interpretations/clarifications, context-object IDs, resolution handles, proposal/plan versions, typed errors, budget usage, artifact handle and execution/result IDs. Prefer references over full schema/result payloads. Encrypt and expire checkpoints according to classification; stored text may contain sensitive information.

Use persistent workflow storage separately from semantic metadata. The default initial deployment uses the supported asynchronous SQLite checkpoint integration with a dedicated `workflow-checkpoints.sqlite` file, one owning workflow-service host, bounded concurrent runs and serialized access as required by the selected adapter. Never use an in-memory saver for work that must survive restart. Checkpointer tables/setup are managed by that integration, outside `catalog-schema.sql`.

LangGraph positions its SQLite checkpoint package for local development, testing and lightweight deployments. Selecting it here is conditional on the admitted workflow load and recovery tests, not a claim that every enterprise workload fits it. The synchronous SqliteSaver has additional scaling limits; do not assume switching to async removes SQLite's write constraints. If the required workflow concurrency, multi-host operation or availability exceeds the measured envelope, use a supported server checkpointer such as PostgreSQL independently of the metadata backend. [SQLite checkpoint package](https://reference.langchain.com/python/langgraph.checkpoint.sqlite), [SqliteSaver scope](https://reference.langchain.com/python/langgraph.checkpoint.sqlite/SqliteSaver), [production persistence guidance](https://docs.langchain.com/oss/python/langgraph/add-memory)

An Azure SQL **catalog** adapter does not imply an Azure SQL LangGraph checkpointer exists or is compatible. That is a separate integration decision. Workflow and catalog stores may migrate at different times. Choose safe checkpoint deserialization, retention, backup and resume-compatibility settings for the selected package version.

The public API maps authenticated users to permitted workflow IDs. Possession of a LangGraph thread ID does not grant access. Resume checks current entitlement, catalog retirement, value-handle freshness and workflow-state compatibility. A conversation's earlier assumptions must be visible in the explicit plan and may be revised by the user; hidden free-form memory cannot override catalog rules.

### 9.4 Side effects, retries and cancellation

Keep clarification nodes separate from database submission. Interrupt/resume can rerun code in a node, so code before an interrupt must be safe to repeat. Persist an execution request in a durable ledger before dispatch; queue consumers use an idempotency key derived from request, accepted artifact version and intended execution instance. [LangGraph interrupt behavior](https://docs.langchain.com/oss/python/langgraph/interrupts)

Ledger states: prepared → queued → running → succeeded/failed/cancelled/unknown. Worker ownership uses a lease/fencing token so an expired worker cannot publish over a replacement's result. After a network loss, a SELECT may still be running on the database; do not claim exactly-once execution or blindly submit again. Attempt driver/server cancellation and reconcile the execution record. If outcome remains unknown, report it and apply the defined bounded retry policy.

Cancellation propagates from API to workflow, queue and execution worker. It stops new work and attempts to cancel current work, but database cancellation may not be instantaneous. Redelivery must not restart a cancelled request. Long exports return a job ID and expose status/result retrieval under the original access scope.

### 9.5 Recovery and model behavior

Transient provider failures can retry within budget with backoff. Semantic ambiguity asks the user; permission failures terminate; source drift disables affected capabilities; malformed output can receive one bounded schema-repair attempt. SQL syntax/policy defects from the deterministic compiler are engineering errors, not a request for the model to rewrite executable SQL.

Pin workflow/prompt/model configurations and support checkpoint migration or draining on deployment. Model changes require held-out evaluation. Resume a previous checkpoint only with a compatible state schema or a deliberate restart that explains any changed interpretation.

## 10. Execution, security and trust boundaries

### 10.1 Access applies before context and at execution

Authenticate through the organization's identity provider. The API constructs trusted caller/domain/policy context. Enforce metadata visibility, value visibility, eligible relationships, selectable fields and source-row access. Check authorization before sensitive text enters an LLM, reranker outside the approved boundary, trace exporter, checkpoint or cache.

Use least-privilege database roles, approved secured views and applicable Azure SQL row-level security. RLS is available through security policies and predicates; implementation depends on actual company identity/schema, which was not supplied. The model cannot invent tenant fields or select a tenant/group claim. [Microsoft RLS documentation](https://learn.microsoft.com/en-us/sql/relational-databases/security/row-level-security?view=sql-server-ver17)

For pooled shared database connections, set and validate trusted session context on acquisition and ensure it cannot leak between users. For separate user/delegated identities, test entitlement propagation. Read-intent connection settings alone do not enforce a read-only or least-privilege role.

Every relation used by a query, including an EXISTS subquery, receives its required access restrictions. “Has a contract” can reveal sensitive eligibility information even when no contract column is projected. If the organization wants broader eligibility access than raw contract access, publish a deliberately authorized eligibility view/service with that definition.

### 10.2 Closed execution interface

The executor accepts a sealed artifact ID plus trusted context. It rechecks principal, policy revision, expiry, withdrawn definitions and source compatibility. It does not accept SQL text, credentials or arbitrary connection references from the agent. Displaying SQL in a preview does not make edited SQL executable through the same handle.

Inspect all AST scopes. Allow only compiler-supported SELECT/CTE/operators and approved functions/bindings. Reject dynamic SQL, multiple statements, DML/DDL, SELECT INTO, external/linked sources, unapproved table functions/hints and hidden operations inside nested queries. Source permissions still protect against parser/compiler defects; neither SQL parsing nor a prompt is a sufficient access boundary.

Approved derived sources and UDFs require review of their underlying behavior and privileges. A syntactically read-only SELECT can still cause costly or externally visible behavior through an unapproved function, so function allowlisting is part of the execution contract.

### 10.3 Workload admission and Azure SQL

Separate interactive, scheduled/reporting and export classes. Per-class limits include workflow concurrency, per-user/tenant fairness, SQL concurrency, command timeout, result rows/bytes, tool/model cost and daily consumption where required. The scheduler queues or rejects work with a clear reason; it does not silently sample an exact count.

The Azure SQL adapter quotes bound object names, maps semantic types to driver types, uses parameter APIs, streams permitted rows and handles cancellation/resource cleanup. Keep a database command timeout distinct from the total workflow deadline. Configure the pool so API replicas cannot collectively overwhelm the database.

Optional estimated-plan preflight uses a capability such as SHOWPLAN_XML on an isolated, correctly permissioned connection. It does not execute the statement while enabled, and it must follow the driver's session/batch rules. It is not a correctness proof or a firm resource estimate. If the role lacks SHOWPLAN permission, record that capability as unavailable rather than granting broad access by default. [Microsoft SHOWPLAN_XML](https://learn.microsoft.com/en-us/sql/t-sql/statements/set-showplan-xml-transact-sql?view=sql-server-ver17)

Production rollout needs actual target-engine results, collation/null/date behavior, index/query-plan analysis and load testing. Use supported isolation appropriate to the data; avoid NOLOCK for correctness-sensitive analytical answers. Offloading to a read replica or curated reporting copy is a DBA architecture choice with an explicit freshness contract, not an agent decision.

### 10.4 Result integrity, paging and exports

Counts operate over the entire authorized requested population. Do not place TOP/page limits before aggregate computation. Detail results have stable ordering based on verified output identity and explicit `has_more`/completeness. A table with a synthetic row ID but unresolved business duplication still needs an honest source-row description.

For nested child details, paging flat rows can split a parent across pages. Select an approved shape: page parents and return bounded complete children, or page flat pairs and state the grain. An unmatched LEFT child is an empty child set, not one invented all-null business record. Child limits must be reported explicitly.

For multi-query result assembly, use a tested snapshot/transaction strategy or disclose potentially different read times. Retain source data version/watermark when available. Pinning the catalog guarantees rule reproducibility, not identical results after business data changes.

### 10.5 Data residency, model and prompt boundaries

Select model/embedding/reranker deployments through the enterprise approval process for residency, retention, data processing and access. This document intentionally does not pick a model name or size without workload evaluation and organizational constraints. Record model identity/version and configuration in the manifest; benchmark stronger/smaller models on semantic accuracy and latency rather than assuming one is sufficient.

Retrieved descriptions, examples and SQL comments are data, not executable instructions. Test prompt-injection attempts in catalog text and user requests. Keep tool schemas strict, authenticate service calls and apply authorization regardless of a model's explanation. Result summarization receives only the fields needed and must preserve exact numbers/units; never execute model-authored code over sensitive result sets without a separately approved runtime.

## 11. Reliability, observability and capacity

### 11.1 Initial operating objectives

These are **proposed acceptance targets for capacity planning**, to confirm with stakeholders and measurement. They are not current performance claims or guaranteed provider SLAs.

| Measure | Initial target | Scope |
|---|---|---|
| Interactive API availability | 99.9% monthly | Request/status service; report correctness/coverage separately |
| Context retrieval latency | p95 ≤ 2 seconds | Authorized domain+hybrid+graph context on benchmark catalog; excludes model/database execution |
| Bounded graph planning | p95 ≤ 250 ms | Supported planner workload, excluding LLM interpretation |
| Interactive complete response | p95 ≤ 15 seconds | Agreed common-query class; expensive jobs become asynchronous |
| Interactive SQL timeout | Initial 10 seconds, workload-specific | Engineering default to tune with DBA; does not change requested semantics |
| Authoring recovery | RPO ≤ 15 minutes, RTO ≤ 1 hour | Provisional objectives; validate SQLite backup/restore and artifact recovery; migrate if the accepted availability requirement cannot be met |
| Published release recovery | Restore last known-good complete manifest | Snapshot/index rebuild or standby projection; measured runbook |
| Authorization revocation | Live recheck before context delivery and execution | No new entitlement inferred from pinned release; measure propagation delay |

Long analytical queries and exports have separate deadlines/queues. If the common-query class cannot meet the target without data modeling/index work, revise scope or infrastructure explicitly. Do not hide database delays by returning estimated or sampled answers as exact.

### 11.2 Deployment and failure domains

The initial SQLite deployment has one catalog-service owner and one workflow-service owner of their respective durable files; they may share a host with separate files and resource budgets. Stateless API instances and independent query/execution workers may scale through service APIs and the queue, while their metadata readers use local release copies. They must not mount writable catalog/checkpoint files across hosts. A durable execution ledger can also start with a separately owned SQLite store behind its service; admission, claims and state transitions use that service, with load/recovery gates independent of the catalog. Its schema is separate implementation work.

Multiple active workflow-owner hosts require a compatible shared checkpoint backend and request-ownership strategy. Multiple active catalog writers require the server authority adapter. These decisions are independent of read-worker scaling. Use approved networking and identities and choose availability configurations to meet measured requirements. Azure AI Search reliability depends on its configured replicas and workload. [Azure AI Search reliability](https://learn.microsoft.com/en-us/azure/reliability/reliability-ai-search)

Separate data-ingestion/index-build resource budgets from interactive serving. Cache immutable catalog/graph projections by hash. Avoid global mutable in-process catalog state that can change halfway through compilation. A replica becomes ready only after it can serve a supported manifest and policy checks.

### 11.3 Failure behavior

| Failure | Required response |
|---|---|
| Search projection unavailable | Use an explicitly evaluated exact/template path if sufficient; otherwise report retrieval unavailable. Do not pretend full-schema understanding. |
| Reranker unavailable | Fall back only to a validated retrieval configuration with its own gates; preserve authorization and disclose service degradation operationally |
| Graph projection missing/incompatible | Load the pinned artifact or stop affected planning; no unapproved join fallback |
| Catalog publisher unavailable | Existing immutable releases may continue if current policy/source checks work; authoring/publication pauses |
| SQLite authority host/storage unavailable | Pause catalog edits/activation; retained authorized releases may serve under the manifest/revocation policy; restore the full authority with one fenced owner |
| RAM catalog lost or over budget | Rebuild from the verified release artifact or use the configured immutable-file reader; do not substitute another release |
| Policy service unavailable | Deny affected protected requests unless a formally approved time-bounded policy cache applies |
| Checkpointer unavailable | Stop starting/resuming durable work; do not run an untracked production workflow |
| Azure SQL timeout/network loss | Cancel/reconcile, return typed failure/unknown outcome, preserve execution ledger |
| Source schema/identity drift | Withdraw affected objects/operations, block dependent artifacts, notify owners |
| New model/index degrades quality | Canary stop and rollback complete compatible manifest/configuration |

### 11.4 Observability

Trace request → workflow stage → retrieval query → selected object IDs → graph path → semantic plan → compiler artifact → database execution → response. Include versions and timings, not hidden model reasoning. Redact sensitive literals, SQL parameters and result content by policy. Record why a path or value was rejected in structured diagnostics accessible to appropriate engineers.

Dashboards track domain coverage, complete retrieval recall on replay sets, ambiguity rate, repair rate, incorrect accepted answers from reviews, unsupported requests, query timeouts, queue delay, database load, token/cost distribution, projection lag, revoked-access attempts and snapshot/hash mismatches. Assign ownership and alert thresholds per failure class; a generic model-error counter is insufficient.

### 11.5 Cache, cost and retention

Context caches key by release, normalized query, domain scope, policy scope and retrieval configuration. Resolution caches additionally include provider version/time/field set. Compiled artifacts key by canonical plan plus catalog/policy/compiler/dialect configuration. Results need principal/access scope, parameter values, source watermark or TTL and time context. A matching question string is never a sufficient cache key.

Budget model calls, embedding changes, ranker calls, search capacity, graph memory, database time and exported bytes separately. Measure marginal cost per successful supported answer and wasted work from failed retrieval/repair. Re-embed only changed semantic text when configuration remains compatible; a model/dimension change requires a new vector projection and evaluation.

Checkpoint, result, trace and catalog retention differ. Deleting a user conversation does not automatically delete immutable business definitions, and retaining a catalog release does not authorize indefinite retention of a sensitive query result. Document deletion/retention behavior and verify it operationally.

## 12. Production evaluation and release gates

### 12.1 Evaluation corpus

Construct reviewed questions from real business demand across domains, plus synthetic adversarial/edge cases. Keep the four producer examples as a small baseline. Include large-schema distractors, duplicate table names, deprecated copies, competing definitions, bridge tables, composite keys, surrogate IDs, historical versions, multi-fact metrics, role-playing dimensions and access-scope variations.

Separate training/prompt-tuning examples from held-out evaluation. Include domain-disjoint or newly onboarded-domain evaluation to test generalization. Store gold intent and result expectations independently of generated SQL; text equality of SQL is not the success criterion.

| Layer | Measurements and acceptance |
|---|---|
| Discovery/catalog | Reference integrity, owner approval, physical bindings, identity evidence, policy coverage, drift behavior |
| Domain routing | Recall of all required authorized domains; avoid forced single-domain classification |
| Retrieval | Complete required-object-set recall, bridge recall, ranking quality, prompt size, latency and no unauthorized context |
| Value resolution | Exact/alias accuracy, ambiguity calibration, binding coverage, stale/reassigned-code behavior |
| Intent | Correct metric/entity/time/scope/grain, useful clarification and explicit abstention |
| Planning/compiler | Correct cardinality/temporal/role decisions, AST obligations, parameter binding and result equivalence |
| Azure SQL | Executed expected results, data types/collation, resource consumption, timeout/cancellation/isolation |
| Orchestration | Restart during every stage, resume compatibility, bounded retries, queue redelivery, unknown execution handling |
| Security | Negative entitlements, revoked policy, forged handle/thread ID, pooled connections, cache/checkpoint/result isolation |
| Operations | Load/soak tests, search/catalog outage, partial release failure, backup restore and manifest rollback |

### 12.2 Initial quality gates

For required regression cases, tolerate zero unauthorized context/execution and zero incorrect accepted results in the deterministic/compiler suite. Track large-schema retrieval complete-set recall with a proposed initial target of at least 98% on the agreed supported corpus; a failure should lead to repair/clarification rather than fabricated SQL. That target is an engineering proposal, not a guarantee about an unmeasured model.

For end-to-end evaluation, separately report supported-answer coverage, answer correctness, clarification burden and incorrect accepted-answer rate. Define severity thresholds with business owners before rollout; a high average score must not conceal material wrong counts. Stratify by domain, query complexity, language and permission scope.

Require target-engine and operational gates before calling a release production-ready. Passing these Markdown examples or SQLite fixtures cannot establish Azure SQL integration, large-catalog retrieval or LangGraph recovery.

### 12.3 Change-specific gates

- Catalog semantics: rerun affected dependency closure, expected results and relevant retrieval cases.
- Embedding/ranker configuration: rebuild required index; compare complete-set recall, latency, cost and domain fairness.
- Prompt/model: held-out intent/clarification/security evaluations plus end-to-end answers.
- Compiler/operator: unit/property tests, SQL mutation negatives, target-engine results and performance cases.
- Workflow/checkpointer: state migration, restart, retries, cancellation and security tests.
- Access policy: pre-context and source-result restrictions, cache invalidation and old-handle rejection.

Use shadow evaluation without executing extra production queries unless that workload is explicitly authorized and bounded. Canary releases route a controlled cohort and retain a tested rollback manifest. Automatically collected feedback becomes review evidence; it does not automatically rewrite metrics or join policy.

## 13. Implementation contracts and repository organization

### 13.1 Service interfaces

| Service | Input | Output/invariant |
|---|---|---|
| `CatalogPublisher` | Reviewed revision | Immutable release and projection jobs |
| `ReleaseResolver` | Trusted user/workload context | Compatible manifest and access scope |
| `DomainRouter` | Question and authorized domain summaries | Multiple candidate domains with explicit uncertainty |
| `HybridRetriever` | Question, domain candidates, manifest, trusted filters | Ranked versioned candidates with source-channel evidence |
| `ContextAssembler` | Candidates + graph + policy | Exact authorized dependency-complete context package or missing evidence |
| `ValueResolver` | Domain/text/fields/time | Resolved handle or explicit ambiguity/coverage error |
| `SemanticPlanner` | Typed proposal, graph, snapshot, capabilities | Bound logical DAG with grain and policy obligations |
| `SqlCompiler` | Validated plan/dialect | Immutable AST/text/parameters/manifest |
| `ArtifactValidator` | Artifact and expected plan | Checked execution eligibility or structured error |
| `ExecutionService` | Sealed handle and trusted context | Durable job/typed result; no caller SQL |
| `AnswerAssembler` | Result and executed manifest | Exact units/scope/completeness with readable explanation |

All deterministic services are usable outside LangGraph and independently evaluated. The workflow invokes them; it does not duplicate their rules. A REST/gRPC or in-process adapter can expose the same typed contracts. MCP can be added for approved external agent consumers without changing semantic authority.

### 13.2 Repository layout

```text
services/
  api/                  identity, request/status/results, preview
  workflow/             LangGraph state, nodes, routing, budgets
  catalog/              discovery, stewardship, migrations, publisher
  retrieval/            index builders, hybrid search, context assembly
  planning/             graph projection, relationship search, grain algebra
  compiler/             typed IR, expressions, T-SQL AST, manifest validation
  execution/            ledger, queue consumers, Azure SQL, exports
packages/
  semantic_contracts/   versioned object/IR/tool/error schemas
  policy_adapters/      current authorization and source-policy bindings
  telemetry/            redacted common trace/metric conventions
evals/
  enterprise_domains/  held-out reviewed questions and target-engine fixtures
  producer_baseline/   supplied examples and adversarial cases
  retrieval_scale/     large catalog distractors and bridge-recall cases
  operations/          failure/load/recovery scenarios
infrastructure/        approved deployment configurations and runbooks
```

Separate deployable roles where needed, while sharing versioned types and code. The folder layout does not mandate a large microservice fleet. Make ownership and dependency direction explicit: source adapters depend on contracts; contracts must not import a particular workflow or vector backend.

## 14. Phased delivery plan

### 14.1 Phase 0: enterprise foundation and architecture validation

**Deliverables:** inventory sources/domains and policies; establish data-owner roles; select representative production question families; define grain/business identities for pilot domains; benchmark schema scale; evaluate model/embedding/reranker configurations; confirm deployment regions, HA, residency and cost limits. Build an offline retrieval/planner harness with a realistically large catalog and distractors, not just the producer fixture.

**Decisions before first production:** SQLite authority host/volume, write admission and revision handling, backup/restore, release-to-memory loading and memory budget, Azure search configuration, graph capacity, independently measured workflow checkpoint limits, Azure SQL execution identity/isolation, queue/admission policy and provisional SLOs. Validate metadata backend interfaces for later PostgreSQL/Azure SQL adapters. If initial requirements already exceed the SQLite or graph envelope, adopt the justified backend before release.

**Exit gate:** reviewed architecture/contract schemas, accepted workload envelope, initial held-out evaluation corpus, privacy/access model and measured backend/model comparison. These gates require representative enterprise metadata; synthetic numbers in this document do not satisfy them.

### 14.2 Phase 1: first production platform and controlled domain rollout

**Platform included:** catalog/stewardship service over persistent SQLite, discovery pipeline, atomic manifest publication, immutable release files and in-memory SQLite readers, hybrid lexical/vector retrieval, reranking, graph context expansion/planning, LangGraph durable workflows with separately measured persistence, value resolution, deterministic T-SQL compilation, source authorization, execution ledger/queue, observability and rollback.

**Business coverage:** a selected set of actual company domains, including ambiguous terms and approved cross-domain relationships. Support detail queries, typed filters, approved groupings and sums/counts, composite business counts where defined, membership/absence, one-record enrichment, controlled child expansion, simple date periods and required governed templates. Move temporal or multi-fact capabilities into this phase if the selected production use cases require them; do not ship a supposedly production domain that cannot answer its agreed core questions.

**Exit gate:** correct target-engine golden results, no authorization failures, accepted retrieval/intent/coverage gates, measured load/latency, restart/clarification recovery, backup/restore and rollback exercise, named support owners. A narrow domain rollout can be production-grade only when these platform controls exist.

### 14.3 Phase 2: broader semantics and domain coverage

Add more domains through the same onboarding path. Enable reviewed temporal joins, richer time/calendar logic, windows/ranking, ratios, multiple-fact aggregation, reusable cohort algebra and governed many-to-many attribution. Expand high-cardinality value providers and domain-specific clarification. Add cost-aware plan alternatives without changing business meaning.

**Exit gate per capability/domain:** result identity/measure tests, ambiguous-path and fanout negatives, retrieval coverage on the wider catalog, target-engine performance, updated stewardship docs and no regression in existing domains. No blanket release of every discovered table.

### 14.4 Phase 3: organizational and operational scale

Scale publisher, search partitions/replicas, planning workers and execution capacity based on observed load. Retain SQLite authority while its requirements are met; migrate to PostgreSQL or Azure SQL through the adapter and cutover process when measured contention, capacity or availability demands it. Upgrade workflow storage independently. Introduce a dedicated graph backend if its measured/shared workload criteria are met. Add richer lineage/impact UIs, delegated domain stewardship, regional recovery improvements, asynchronous report workflows and workload-specific model routing after evaluation.

**Exit gate:** higher-envelope soak/failure tests, confirmed recovery objectives, sustainable cost per successful answer and tested multi-domain ownership workflows. Cross-source federation or additional SQL engines require new execution/identity/consistency contracts; they are not assumed to work because source records can be listed in the catalog.

### 14.5 What is designed now versus deferred implementation

| Concern | Required in first production | Later expansion |
|---|---|---|
| Catalog | SQLite persistence, revision/outbox publication, RAM reads, portable interfaces, domain/source identity and grain | PostgreSQL/Azure SQL adapters when justified; broader connectors/authoring |
| Retrieval | Hybrid lexical/vector, reranking, graph expansion, evaluation | Advanced domain-tuned retrieval/model routing |
| Graph | Typed executable/dependency graph and planner | Backend scaling and broader lineage use |
| Orchestration | LangGraph durable state, budgets, clarification and recovery | More complex workflows and justified specialists |
| Query language | Extensible typed algebra and capability gating | Additional operators and domain templates |
| Security | Pre-context checks, source restrictions, artifact/result isolation | Additional regulated workflows as required |
| Operations | Metrics, redacted traces, queue limits, deployment/rollback, DR exercise | Higher capacity and regional objectives |

The intended simplification is **limited initial business coverage on the intended production platform**. It is not a plan to implement a toy tool and replace its central architecture later.

## 15. Decision rationale and tradeoffs

| Decision | Why it fits the stated scope | Cost/tradeoff | Stable interface |
|---|---|---|---|
| Hybrid retrieval in first release | Large, heterogeneous terminology already requires robust candidate discovery | Embedding/index lifecycle, evaluation and service cost | `HybridRetriever` + versioned context objects |
| Graph model in first release | Safe paths, bridge dependencies and change impact are structural | Owner-reviewed edges and bounded search complexity | `SemanticPlanner` + typed edge contracts |
| LangGraph in first release | Durable enterprise workflows require branching, clarification and recovery | Checkpointer operations, state versions and replay discipline | Deterministic services + workflow state schema |
| SQLite authority + in-memory SQLite reads | Fits modest metadata writes while supporting coherent indexed reads and multiple authors through one service | Single write owner, memory budget, consistent backups and measured availability | `CatalogAuthoringStore`, `CatalogReader`, exporter and release manifest |
| Optional PostgreSQL/Azure SQL authority | Accommodates requirements exceeding the SQLite deployment envelope | Adapter validation, provisioned infrastructure and controlled migration | Same semantic IDs, payload contracts and worker release format |
| Managed search instead of a separate standalone vector DB | One selected service provides lexical/vector search for metadata | Vendor/service constraints and trust boundary | Search document/retrieval APIs |
| Graph backend chosen by enterprise benchmark | Graph structures are mandatory; server benefits depend on actual traversals/consumers | A dedicated graph DB adds operations and consistency work | Graph projection and planner interfaces |
| Deterministic SQL compilation | Makes join/grain/value enforcement explicit across many domains | Building and maintaining a query algebra | Typed proposal/logical plan/compiled artifact |
| Capability-gated rollout | Allows broad future semantics while controlling released guarantees | Unsupported requests need useful feedback and prioritization | Versioned operator registry |

These choices intentionally preserve the earlier good boundary between LLM interpretation and deterministic execution while correcting the earlier assumption that a four-table-sized workflow was the production starting point. Requirements may cause ordinary schema migrations and new operators; the goal is to avoid replacing the core model of meaning, identity, authorization and execution.

## 16. Deliverables, remaining decisions and verification

### 16.1 Document package

- [Constitution](01-semantic-layer-constitution.md): required semantic components, why they exist, authority and enforcement.
- This design: enterprise target architecture, technology choices, retrieval/graph/workflow implementation contracts and phased rollout.
- [Producer worked examples](03-worked-examples.md): original schemas, detailed grain correction, contract/IR illustrations, three requested SQL patterns and synthetic expected results.
- [Default catalog bootstrap DDL](catalog-schema.sql): SQLite authority and published-read schema, including revision counter and transactional outbox.
- [SQLite authority settings](catalog-sqlite-authority-settings.sql): persistent writer connection configuration; RAM readers use separate settings.
- [Optional PostgreSQL bootstrap DDL](catalog-postgresql.sql): future server-backend representation of the same metadata. Azure SQL adapter/migrations are specified in section 4.8 but not implemented here.
- [Constitution/schema guide](04-constitution-to-catalog-schema-guide.md): detailed component-to-table mapping, updated for persistent authority and memory reader roles.

The schema files illustrate the persistence contract. Release lifecycle transitions, specialization/type validation, payload JSON schemas, authoring permissions, outbox consumers and application migrations are implementation work; valid DDL alone does not enforce every constitutional rule. LangGraph/checkpointer migrations are managed through the selected backend's supported setup, not these catalog files.

### 16.2 Decisions still requiring actual company input

Inventory and workload measurements must establish domain/table scale, concurrency, required question families, historical data availability, business identity rules, existing catalog/tooling, hosting/security policy, recovery targets, budget and data-owner responsibilities. The architecture proceeds without treating the sample data as a substitute for that discovery. The default technologies above are concrete recommendations that Phase 0 should validate against those requirements.

### 16.3 Verification scope

This task revises design artifacts and bootstrap DDL. Local package checks cover the retained synthetic SQL answers/counterexamples, SQLite schema/reference integrity, table-set parity with the optional PostgreSQL representation, JSON payload examples and Markdown links. Focused SQLite storage checks cover authority persistence/reopen, conflicting edit revisions, atomic release/outbox rollback, semantic export excluding control rows, and file-to-memory loading with a query-only reader. The machine-readable reports distinguish these checks from a deployed catalog service. Mermaid diagrams are supplied as source; no visual rendering check is claimed. The business SQL examples run in SQLite after documented dialect substitutions; PostgreSQL syntax is not checked by a native PostgreSQL engine.

These checks cannot demonstrate enterprise retrieval quality, model accuracy, Azure SQL execution, PostgreSQL deployment, LangGraph recovery, permissions or throughput without deployed services and representative data. Those are explicit Phase 0/1 acceptance activities.

The sample appendix records the original fixture checks, including correct license/appointment counts and join-inflation counterexamples. They remain useful regressions and must not be presented as evidence that the enterprise application is implemented or production-ready.

### 16.4 Primary documentation checked

Technology claims are linked where used. These additional references support integration work: [Azure SQL overview](https://learn.microsoft.com/en-us/azure/azure-sql/database/sql-database-paas-overview?view=azuresql), [T-SQL EXISTS](https://learn.microsoft.com/en-us/sql/t-sql/language-elements/exists-transact-sql?view=sql-server-ver17), [T-SQL joins](https://learn.microsoft.com/en-us/sql/t-sql/queries/from-transact-sql?view=sql-server-ver17), [SQLite foreign keys](https://www.sqlite.org/foreignkeys.html), [SQLite WAL](https://www.sqlite.org/wal.html), and [LangGraph persistence](https://docs.langchain.com/oss/python/langgraph/persistence).

The workbook hash and exact inspected header ranges remain in the constitution. Its source file was not modified. Product-specific features and service configurations must be rechecked when implementation pins versions; the recommendations here do not depend on preview-only capabilities.
