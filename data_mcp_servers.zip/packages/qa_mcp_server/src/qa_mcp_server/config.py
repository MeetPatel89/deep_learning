"""Optional QA named stores and Synapse SQL authentication profiles."""

from data_mcp_core.config import ConfigModel, DataConfig, load_config
from data_mcp_core.sql import SQLConnection
from pydantic import Field


class SQLWorkspace(ConfigModel):
    name: str
    auth: str = "default"
    serverless_database: str = "master"
    dedicated_pools: dict[str, str] = Field(default_factory=dict)


class QAConfig(DataConfig):
    workspaces: dict[str, SQLWorkspace] = Field(default_factory=dict)


def get_config() -> QAConfig:
    return load_config("QA_MCP_CONFIG", QAConfig)


def resolve_sql_source(source: SQLConnection) -> SQLConnection:
    config = get_config()
    workspace = config.workspaces.get(source.workspace or "")
    updates = {}
    if workspace:
        updates.update(workspace=workspace.name, server=None)
        if source.auth == "token":
            updates["auth_profile"] = config.auth_profile(workspace.auth)
    elif source.auth == "token":
        updates["auth_profile"] = source.auth_profile
    return type(source).model_validate(
        {**source.model_dump(), "auth_profile": source.auth_profile, **updates}
    )
