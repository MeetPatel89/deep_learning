"""Constant-memory Excel shards and a complete Parquet difference dataset."""

import json
from pathlib import Path

import polars as pl
import xlsxwriter
from data_mcp_core.results import json_safe

from qa_mcp_server.engine.compare import Record
from qa_mcp_server.models import OutputOptions

SHEETS = {
    "mismatched": "Mismatches",
    "missing_in_actual": "Missing_in_Actual",
    "extra_in_actual": "Extra_in_Actual",
    "duplicate_key": "Duplicate_Keys",
    "matched": "Matched",
}


class ExcelWriter:
    def __init__(
        self, directory: Path, columns: list[str], keys: list[str], options: OutputOptions
    ):
        self.directory, self.columns, self.keys, self.options = directory, columns, keys, options
        self.paths: list[Path] = []
        self.total_rows = 0
        self.omitted_rows = 0
        self.file_rows = 0
        self.workbook = None
        self.sheets = {}
        self.summary_sheet = None
        self.summary_workbook = None
        self._open()

    def _open(self):
        path = self.directory / f"report_{len(self.paths) + 1:03d}.xlsx"
        self.paths.append(path)
        self.workbook = xlsxwriter.Workbook(
            path,
            {
                "constant_memory": True,
                "strings_to_formulas": False,
                "strings_to_urls": False,
            },
        )
        self.formats = {
            "header": self.workbook.add_format({"bold": True, "bg_color": "#D9E2F3"}),
            "equal": self.workbook.add_format({"font_color": "#008000"}),
            "different": self.workbook.add_format({"font_color": "#FF0000", "bold": True}),
        }
        if len(self.paths) == 1:
            self.summary_workbook = self.workbook
            self.summary_sheet = self.workbook.add_worksheet("Summary")
            self.summary_sheet.set_column(0, 0, 35)
            self.summary_sheet.set_column(1, 1, 90)
        self.sheets = {}
        self.file_rows = 0

    def _headers(self, status: str):
        if status in ("matched", "mismatched"):
            headers = [f"{key}_expected" for key in self.keys]
            headers += [f"{key}_actual" for key in self.keys]
            for column in self.columns:
                if column not in self.keys:
                    headers.extend([f"{column}_expected", f"{column}_actual"])
            return headers + ["occurrences"]
        if status == "duplicate_key":
            return ["side", "duplicate_count", *self.columns]
        return [*self.columns, "occurrences"]

    def _sheet(self, status):
        if status not in self.sheets:
            sheet = self.workbook.add_worksheet(SHEETS[status])
            headers = self._headers(status)
            if len(headers) > 16384:
                raise ValueError("Report exceeds Excel's 16,384-column limit")
            sheet.write_row(0, 0, headers, self.formats["header"])
            sheet.freeze_panes(1, 0)
            sheet.set_column(0, len(headers) - 1, 22)
            self.sheets[status] = (sheet, 1)
        return self.sheets[status]

    @staticmethod
    def _cell(value):
        value = json_safe(value)
        if isinstance(value, (dict, list)):
            return json.dumps(value, ensure_ascii=False)
        # Excel stores numeric cells as IEEE doubles; preserve large integers as text.
        if isinstance(value, int) and abs(value) > 2**53:
            return str(value)
        return value

    def write(self, record: Record):
        if record.status == "matched" and not self.options.include_matched_rows:
            return
        if (
            self.options.max_total_report_rows is not None
            and self.total_rows >= self.options.max_total_report_rows
        ):
            self.omitted_rows += 1
            return
        if self.file_rows >= self.options.max_rows_per_file:
            if self.workbook is not self.summary_workbook:
                self.workbook.close()
            self._open()
        sheet, row = self._sheet(record.status)
        cells = []
        if record.status in ("matched", "mismatched"):
            for values in (record.expected, record.actual):
                cells.extend((values[key], None) for key in self.keys)
            for column in self.columns:
                if column not in self.keys:
                    fmt = self.formats[
                        "different" if column in record.mismatch_columns else "equal"
                    ]
                    cells.extend([(record.expected[column], fmt), (record.actual[column], fmt)])
            cells.append((record.occurrences, None))
        elif record.status == "duplicate_key":
            values = record.expected if record.expected is not None else record.actual
            cells = [(record.side, None), (record.duplicate_count, None)]
            cells.extend((values[column], None) for column in self.columns)
        else:
            values = record.expected if record.expected is not None else record.actual
            cells = [(values[column], None) for column in self.columns]
            cells.append((record.occurrences, None))
        for index, (value, fmt) in enumerate(cells):
            sheet.write(row, index, self._cell(value), fmt)
        self.sheets[record.status] = (sheet, row + 1)
        self.total_rows += 1
        self.file_rows += 1

    def finish(self, summary: dict):
        self.summary_sheet.write_row(0, 0, ["Parameter / measure", "Value"])
        row = 1
        for key, value in summary.items():
            if key == "sample_mismatches":
                continue
            if isinstance(value, dict):
                entries = [(f"{key}.{subkey}", subvalue) for subkey, subvalue in value.items()]
            else:
                entries = [(key, value)]
            for label, entry in entries:
                if isinstance(entry, (list, dict)):
                    entry = json.dumps(json_safe(entry), ensure_ascii=False)
                self.summary_sheet.write_row(row, 0, [label, self._cell(entry)])
                row += 1
        if self.workbook is not self.summary_workbook:
            self.workbook.close()
        self.summary_workbook.close()
        self.workbook = self.summary_workbook = None

    def close(self):
        if self.workbook is not None and self.workbook is not self.summary_workbook:
            self.workbook.close()
        if self.summary_workbook is not None:
            self.summary_workbook.close()
        self.workbook = self.summary_workbook = None


class ParquetWriter:
    """Each shard has the same typed paired columns, even when a side is absent."""

    def __init__(self, directory: Path, schema: dict[str, pl.DataType], batch_size: int = 4096):
        self.directory = directory / "mismatches.parquet"
        self.directory.mkdir()
        self.input_columns = list(schema)
        self.schema = {
            "status": pl.String,
            "occurrences": pl.UInt64,
            "mismatch_columns": pl.List(pl.String),
            "side": pl.String,
            "duplicate_count": pl.UInt64,
        }
        # Prefixes prevent collisions between source names and report metadata.
        for column, dtype in schema.items():
            self.schema[f"expected.{column}"] = dtype
            self.schema[f"actual.{column}"] = dtype
        self.rows = []
        self.batch_size = batch_size
        self.parts = 0

    def write(self, record: Record):
        if record.status == "matched":
            return
        row = {
            "status": record.status,
            "occurrences": record.occurrences,
            "mismatch_columns": record.mismatch_columns,
            "side": record.side,
            "duplicate_count": record.duplicate_count,
        }
        for side in ("expected", "actual"):
            values = getattr(record, side)
            row.update(
                {
                    f"{side}.{column}": values[column] if values is not None else None
                    for column in self.input_columns
                }
            )
        self.rows.append(row)
        if len(self.rows) >= self.batch_size:
            self.flush()

    def flush(self):
        if not self.rows and self.parts:
            return
        frame = pl.from_dicts(self.rows, schema=self.schema)
        frame.write_parquet(self.directory / f"part_{self.parts:06d}.parquet")
        self.parts += 1
        self.rows.clear()

    def finish(self):
        self.flush()
