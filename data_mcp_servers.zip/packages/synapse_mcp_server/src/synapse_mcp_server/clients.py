"""Lazy, cached SDK clients; constructing the MCP server never authenticates."""

from threading import RLock

import httpx
from data_mcp_core.auth import SYNAPSE_SCOPE, get_credential, get_token
from data_mcp_core.guards import require

from synapse_mcp_server.config import SynapseConfig


class ClientRegistry:
    def __init__(self, config: SynapseConfig):
        self.config = config
        self._clients = {}
        self._lock = RLock()

    def get(self, workspace: str, kind: str, pool: str | None = None):
        # Recheck even for cached clients, before credential construction.
        require(self.config.workspaces[workspace], "allow_live_env")
        key = (workspace, kind, pool)
        with self._lock:
            if key in self._clients:
                return self._clients[key]
            settings = self.config.workspaces[workspace]
            credential = get_credential(self.config.auth_profile(settings.auth))
            if kind == "artifacts":
                from azure.synapse.artifacts import ArtifactsClient

                client = ArtifactsClient(settings.endpoint, credential)
            elif kind == "spark":
                from azure.synapse.spark import SparkClient

                if not pool:
                    raise ValueError("Specify a Spark pool")
                client = SparkClient(settings.endpoint, pool, credential)
            elif kind == "arm":
                from azure.mgmt.synapse import SynapseManagementClient

                if not settings.subscription_id or not settings.resource_group:
                    raise ValueError("ARM tools require subscription_id and resource_group")
                client = SynapseManagementClient(credential, settings.subscription_id)
            elif kind == "accesscontrol":
                from azure.synapse.accesscontrol import AccessControlClient

                client = AccessControlClient(settings.endpoint, credential)
            elif kind == "http":
                client = httpx.Client(
                    base_url=settings.endpoint, timeout=30, follow_redirects=False
                )
            else:
                raise ValueError(f"Unknown client kind: {kind}")
            self._clients[key] = client
            return client

    def http_get(self, workspace: str, path: str, params: dict | None = None):
        require(self.config.workspaces[workspace], "allow_live_env")
        if not path.startswith("/") or path.startswith("//") or "://" in path:
            raise ValueError("Monitoring endpoints must be relative to the configured workspace")
        settings = self.config.workspaces[workspace]
        token = get_token(self.config.auth_profile(settings.auth), SYNAPSE_SCOPE)
        response = self.get(workspace, "http").get(
            path,
            params=params,
            headers={"Authorization": f"Bearer {token.token}"},
        )
        response.raise_for_status()
        return response

    def close(self):
        with self._lock:
            for client in self._clients.values():
                client.close()
            self._clients.clear()
