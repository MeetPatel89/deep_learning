"""Construct an explicit SDK client without registering a global provider."""

from langfuse import Langfuse
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SpanExporter
from opentelemetry.sdk.trace.sampling import ParentBased, TraceIdRatioBased

from .. import __version__
from ..config import LangfuseSettings


def build_langfuse_client(
    settings: LangfuseSettings,
    *,
    tracer_provider: TracerProvider | None = None,
    span_exporter: SpanExporter | None = None,
) -> Langfuse:
    """Build a native client with project credentials and deployment dimensions.

    The default provider is local, with parent-based sampling from ``settings``.
    The SDK installs its processor on that provider. An injected provider keeps
    its own resource and sampler; its owner is responsible for shutting it down.
    Inject ``span_exporter`` for network-free observation tests. Scores and prompt
    retrieval still use the SDK's API client.

    Call the returned client's ``shutdown()`` to drain its queues. The SDK shares
    resources by public key, so configure one client per project at startup.
    """
    if tracer_provider is None:
        tracer_provider = TracerProvider(
            resource=Resource.create(
                {
                    "service.name": "observability-ai.langfuse",
                    "service.version": __version__,
                }
            ),
            sampler=ParentBased(TraceIdRatioBased(settings.sample_ratio)),
        )
    return Langfuse(
        public_key=settings.public_key,
        secret_key=settings.secret_key,
        base_url=settings.base_url,
        release=settings.release,
        environment=settings.environment,
        sample_rate=settings.sample_ratio,
        tracer_provider=tracer_provider,
        span_exporter=span_exporter,
    )
