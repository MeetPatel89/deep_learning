"""File readers. CSV/Parquet stream; the Excel reader materializes its selected sheet."""

import codecs
import tempfile
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

import polars as pl

from qa_mcp_server.models import CSVSource, ExcelSource, ParquetSource


@contextmanager
def _utf8_path(source: CSVSource):
    encoding = codecs.lookup(source.encoding).name
    if encoding == "utf-8":
        yield source.path
        return
    with tempfile.TemporaryDirectory(prefix="qa_csv_") as directory:
        path = Path(directory) / "decoded.csv"
        with source.path.open("r", encoding=source.encoding, newline="") as src:
            with path.open("w", encoding="utf-8", newline="") as dst:
                while chunk := src.read(1024 * 1024):
                    dst.write(chunk)
        yield path


def iter_file_batches(
    source: CSVSource | ParquetSource | ExcelSource, batch_size: int
) -> Iterator[pl.DataFrame]:
    if not source.path.is_file():
        raise FileNotFoundError(f"Dataset file does not exist: {source.path}")
    if isinstance(source, CSVSource):
        with _utf8_path(source) as path:
            # Scan the entire schema so later values cannot invalidate a batch's dtype.
            scan = pl.scan_csv(
                path,
                separator=source.delimiter,
                has_header=source.has_header,
                null_values=source.null_values,
                infer_schema_length=None,
                raise_if_empty=False,
            )
            yield from scan.collect_batches(chunk_size=batch_size, engine="streaming")
            # Preserve schema for a header-only file.
            if scan.collect_schema():
                yield pl.DataFrame(schema=scan.collect_schema())
    elif isinstance(source, ParquetSource):
        scan = pl.scan_parquet(source.path)
        yield from scan.collect_batches(chunk_size=batch_size, engine="streaming")
        yield pl.DataFrame(schema=scan.collect_schema())
    else:
        kwargs = {"sheet_name": source.sheet} if isinstance(source.sheet, str) else {}
        if isinstance(source.sheet, int):
            if source.sheet < 1:
                raise ValueError("Excel sheet index must be at least 1")
            kwargs["sheet_id"] = source.sheet
        frame = pl.read_excel(source.path, engine="calamine", raise_if_empty=False, **kwargs)
        if frame.is_empty():
            yield frame
        else:
            yield from frame.iter_slices(batch_size)
