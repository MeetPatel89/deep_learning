# How the semantic-layer constitution maps to the catalog schema

Companion guide to the enterprise design, version 2.1. Default metadata storage: persistent SQLite authority plus in-memory SQLite readers. Catalog schema version: 3.

Read alongside the [constitution](01-semantic-layer-constitution.md), the [default SQLite catalog schema](catalog-schema.sql), the [SQLite authority connection settings](catalog-sqlite-authority-settings.sql), the [optional PostgreSQL schema](catalog-postgresql.sql), the [implementation design](02-implementation-design.md), and the [producer worked examples](03-worked-examples.md).

This guide explains the **existing SQL files**. It identifies what they represent directly, what they leave inside JSON payloads, and what the application must implement. Examples use the producer domain to make the connections concrete; the storage model supports other domains in the same way. Codes, source types, identity rules and approval states in examples are illustrative unless explicitly identified as user-confirmed.

## Contents

- [1. The connection between the constitution and the SQL](#1-the-connection-between-the-constitution-and-the-sql)
- [2. How to read the recurring SQL patterns](#2-how-to-read-the-recurring-sql-patterns)
- [3. Every constitutional component and its storage location](#3-every-constitutional-component-and-its-storage-location)
- [4. The common foundation: releases, objects and sources](#4-the-common-foundation-releases-objects-and-sources)
- [5. Entities and fields: meaning, identity and physical bindings](#5-entities-and-fields-meaning-identity-and-physical-bindings)
- [6. Domains, glossary concepts and membership](#6-domains-glossary-concepts-and-membership)
- [7. Values and mappings: from Pet to stored codes](#7-values-and-mappings-from-pet-to-stored-codes)
- [8. Predicates, metrics and reusable populations](#8-predicates-metrics-and-reusable-populations)
- [9. Relationships, operation contracts and the graph](#9-relationships-operation-contracts-and-the-graph)
- [10. Examples and assertions: definitions need evidence](#10-examples-and-assertions-definitions-need-evidence)
- [11. Templates, capabilities and typed validation](#11-templates-capabilities-and-typed-validation)
- [12. Publication, projections and the request manifest](#12-publication-projections-and-the-request-manifest)
- [13. Trace one question through the catalog](#13-trace-one-question-through-the-catalog)
- [14. Where the fourteen foundational commitments are implemented](#14-where-the-fourteen-foundational-commitments-are-implemented)
- [15. What the SQL file still leaves to implementation](#15-what-the-sql-file-still-leaves-to-implementation)
- [16. Mapping the original workbook into this schema](#16-mapping-the-original-workbook-into-this-schema)
- [17. Practical reading and implementation order](#17-practical-reading-and-implementation-order)

## 1. The connection between the constitution and the SQL

**The constitution defines the obligations. The catalog stores definitions and evidence needed to meet those obligations. Application services read those records and enforce the obligations.**

For example, the constitution requires a relationship operation to preserve the base population when its purpose is left enrichment. The catalog stores the operation and its contract. The planner and compiler use that contract to produce the appropriate relational operation. The SQL validator checks the generated query. Merely storing `enrich_left` in a metadata row does not implement a SQL compiler.

There are three separate things to recognize:

| Item | Concrete example | What it accomplishes |
|---|---|---|
| Requirement in the constitution | A business label must resolve to approved physical values | States the behavior the platform must provide |
| Definition stored in the catalog | `product_category.pet` binds to `PET` in one source field | Supplies the exact metadata needed for that behavior |
| Implemented service | A value resolver loads the binding, validates scope and returns a typed value handle | Applies the definition to a particular request |

```mermaid
flowchart TB
    C[Constitution requirements] --> S[Catalog tables and typed JSON definitions]
    C --> R[Required application behavior]
    S --> P[Publisher validates and releases metadata]
    P --> SNAP[SQLite snapshot]
    SNAP --> MEM[Read-only in-memory SQLite]
    MEM --> V[Resolver planner compiler and validators]
    R --> V
    V --> Q[Authorized query against Azure SQL]
```

The SQL file is a **bootstrap schema**: it creates empty metadata tables, indexes and database constraints. It contains no populated definitions for your license tables. It also contains no implementation of retrieval, graph traversal, query planning, model interaction or execution.

Some difficulty reconciling the documents comes from a real difference in detail: the constitution describes required contents such as metric additivity, but the SQL sometimes provides one `definition_json` column to hold several of those contents. The precise JSON payload schemas still need to be defined in application types. This guide makes those implicit locations explicit.

### 1.1 Which database is this script for?

| File or system | Purpose |
|---|---|
| `catalog-schema.sql` | Default SQLite schema for persistent authority; also used to build published semantic read copies |
| `catalog-sqlite-authority-settings.sql` | Connection settings for the persistent authority; excluded from in-memory reader setup |
| `catalog-postgresql.sql` | Optional future PostgreSQL authority representation when server storage is justified |
| Azure SQL metadata adapter | Planned alternative server backend through the same interfaces; adapter and migration DDL remain implementation work |
| Company Azure SQL database | Operational tables such as `Producer_Licenses`; queried by the execution service |
| Azure AI Search | Derived searchable documents and vectors used to find relevant metadata |
| In-memory graph | Derived relationship and dependency structures used by planning services |

SQLite is the initial authority and reader engine. The optional PostgreSQL schema uses the same semantic model. A later PostgreSQL or Azure SQL adapter exports the same published SQLite read format, converting engine representations into canonical records. The compiler and business definitions do not need to depend on that engine choice.

Authoring occurs in a durable SQLite authority file through CatalogService. The service admits multiple authors, serializes short write transactions and checks expected edit revisions. A publisher creates a separate immutable SQLite release file containing approved semantic records. Each worker loads that file into in-memory SQLite and uses a query-only reader for fast lookups. Losing the memory copy loses no approved edits; the copy is rebuilt from the published artifact. Applying `catalog-schema.sql` creates empty tables; authoring/import and export processes supply their appropriate records.

These are separate database instances even though they use the same SQLite engine and schema. The persistent authority includes drafts and publication-control records. The release file and RAM reader contain approved semantic data. Only the authority is writable by the authoring service. The implementation design's sections 4.6–4.10 define transaction settings, memory loading, backend interfaces, migration triggers and a PostgreSQL/Azure SQL cutover procedure.

### 1.2 The schema has 26 tables, grouped by responsibility

| Responsibility | Tables in `catalog-schema.sql` |
|---|---|
| Common identity and source binding | `catalog_release`, `catalog_object`, `data_source` |
| Datasets and attributes | `entity`, `field` |
| Value meaning and source encodings | `value_domain`, `canonical_value`, `value_alias`, `value_binding` |
| Permitted relationships | `relationship`, `relationship_operation` |
| Reusable rules and measures | `predicate`, `metric` |
| Reviewed examples and evidence | `verified_example`, `assertion` |
| Domain organization and semantic context | `business_domain`, `domain_membership`, `semantic_concept`, `semantic_edge` |
| Reusable plans and supported operators | `query_template`, `capability`, `domain_capability` |
| Publication coordination | `projection_artifact`, `release_manifest`, `active_manifest`, `publication_outbox` |

The four publication-control tables are populated in the persistent SQLite authority. Their **rows are excluded from the published release file and its RAM copy**, where those tables remain empty. Section 12 explains the authority/read-copy boundary.

## 2. How to read the recurring SQL patterns

### 2.1 A row usually describes a definition, rather than a business transaction

An `entity` row describes the license dataset. A `field` row describes its status column. A `canonical_value` row describes the meaning of active status. These metadata tables do not contain individual licenses, their holders or their current status.

There may be millions of operational license rows while the catalog contains one entity definition and a small number of field definitions for that dataset.

### 2.2 Composite metadata keys include the release

This declaration occurs throughout the schema:

```sql
PRIMARY KEY (release_id, field_id)
```

It means a field definition is identified by **its release and its stable semantic ID together**. For example:

| `release_id` | `field_id` | `physical_column` |
|---|---|---|
| `r41` | `license.termination_date` | `Termination_Date` |
| `r42` | `license.termination_date` | `License_End_Date` |

This is an illustrative column rename. Both definitions refer to the same business concept, but different release-specific physical bindings. The request chooses a release first, then resolves the ID within that release. Application lookups must consistently include `release_id`.

These are **metadata keys**. They do not establish the business key or grain of operational license records.

### 2.3 Foreign keys connect definitions within a release

For example, `field` has:

```sql
FOREIGN KEY (release_id, entity_id)
  REFERENCES entity(release_id, entity_id)
```

This prevents a field definition from referring to an entity absent from the same release, when SQLite foreign-key enforcement is enabled. It does not prove that the physical source column actually exists in Azure SQL. The publisher checks that separately using source metadata.

The script starts with `PRAGMA foreign_keys = ON`. Each connection used to write or validate SQLite metadata must enable foreign keys before its transaction; this is a connection setting. [SQLite foreign-key documentation](https://www.sqlite.org/foreignkeys.html)

### 2.4 `CHECK` constraints validate a limited set of stored facts

Examples in this schema include:

- `field.nullable` must be `0` or `1`.
- `relationship_operation.operator` must belong to the listed operation names.
- A physical `entity` requires source/schema/object bindings and excludes a derived plan.
- A projection marked `ready` must have a non-null content hash.

A valid hash string does not prove the file matches it. A permitted operator name does not prove its implementation is installed. Those checks require application code.

### 2.5 JSON columns hold structured definitions whose full schemas are still required

The declaration:

```sql
definition_json TEXT NOT NULL CHECK (json_valid(definition_json))
```

checks JSON syntax. It does not require keys such as `aggregation`, `unit` or `required_predicate_ids`. `{}` and `"hello"` are valid JSON but unsuitable metric definitions. [SQLite JSON validation documentation](https://www.sqlite.org/json1.html#the_json_valid_function)

The implementation must define a versioned type for each payload family, such as a metric definition or relationship contract, and validate it during authoring/publication and deserialization. Pydantic models can supply that structural validation. References inside JSON also require explicit catalog lookup; SQLite foreign keys do not inspect them.

**Convention used below:** JSON payloads are proposed explanatory shapes compatible with the intended column purpose. They are not a claim that the existing SQL file specifies those exact keys or that a compiler implementing them already exists. Existing worked-example expressions are retained where possible.

### 2.6 Indexes support lookups

| Index | Typical use |
|---|---|
| `value_alias_lookup` | Find canonical-value candidates for a normalized label within a release and locale |
| `value_binding_lookup` | Fetch source literals for a value, field and effective time |
| `relationship_outgoing` | Load approved relationship candidates originating from an entity |
| `semantic_edge_outgoing` / `semantic_edge_incoming` | Expand dependencies or find definitions affected by a change |

These are relational database indexes. The file does not create a vector index or a graph database. Whether additional indexes are needed depends on actual lookup workloads.

## 3. Every constitutional component and its storage location

The section numbers below refer to the [constitution](01-semantic-layer-constitution.md). “Application responsibility” identifies what storing records cannot accomplish on its own.

| Constitution component | Direct storage in this schema | Application responsibility |
|---|---|---|
| **4.1 Domain and business glossary** | `business_domain`, `domain_membership`, `semantic_concept`; common labels/descriptions in `catalog_object`; associations in `semantic_edge` | Interpret scoped terms, detect ambiguity, authorize domain context |
| **4.2 Entities, bindings and grain** | `entity`, `data_source`; row meaning, keys, versioning and evidence in entity JSON columns | Verify physical bindings and business identity; propagate grain through the plan |
| **4.3 Fields and dimensions** | `field`; field descriptions in `catalog_object` | Enforce field permissions, semantic types, operators and null behavior |
| **4.4 Values, aliases and bindings** | `value_domain`, `canonical_value`, `value_alias`, `value_binding` | Resolve ambiguity, verify field/domain compatibility, fetch complete binding sets and live provider data |
| **4.5 Predicates and temporal semantics** | `predicate.expression_json`, `predicate.purpose`; temporal and binding-validity metadata | Interpret typed expressions, apply mandatory restrictions, resolve calendars/time consistently |
| **4.6 Relationships and operation contracts** | `relationship`, `relationship_operation`, related `assertion` records | Select permitted paths; enforce join form, filter scope, preservation and multiplicity |
| **4.7 Populations and cohorts** | `predicate`, `query_template.plan_json`, optionally `entity.derived_plan_json` | Construct each request's qualifying population; verify derived keys and duplicate semantics |
| **4.8 Metrics and aggregation** | `metric.definition_json`, base entity, required predicate references | Validate counted unit, additivity, grouping, temporal rules and fanout |
| **4.9 Query intent and intermediate representation** | Schemas may be described by `capability.schema_json`; plans appear in examples/templates | Define Pydantic/JSON schemas and maintain each live proposal/validated plan in request state |
| **4.10 Retrieval, paths and examples** | `verified_example`, domain/description records, `relationship`, `semantic_edge`, projection references | Build/search indexes, rerank, traverse the graph and assemble complete authorized context |
| **4.11 Compiler and validators** | Capability declarations, contracts and definitions are inputs | Implement the compiler, type binding, parameter generation, SQL validation and structured errors |
| **4.12 Security and execution** | Policy references, `field.sensitivity`, `predicate.purpose`; some contract restrictions | Resolve current policy, authenticate, enforce source access and execution/result limits |
| **4.13 Provenance and answers** | `catalog_object.provenance_json`, `data_source.freshness_json`, assertions and release IDs | Create per-answer provenance/completeness records using actual execution details |
| **4.14 Ownership and publication** | `catalog_release`, object ownership/status, assertions, examples and publication tables | Enforce review transitions, concurrency, immutable releases, compatibility and activation |
| **4.15 Discovery and stewardship** | `data_source.schema_fingerprint`, domain steward/coverage, object provenance/status | Implement connectors, staging, drift detection, profiling and review workflow |
| **4.16 Search and graph projections** | `projection_artifact`; source definitions in the semantic tables | Build/rebuild actual search and graph representations and validate their release consistency |
| **4.17 Durable workflows and workload control** | Release/capability references can inform request state; no checkpoint or execution-ledger tables here | Implement LangGraph persistence, budgets, queues, cancellation and execution reconciliation |
| **4.18 Production quality and operations** | Examples, assertions, capability evidence, evaluation projection references | Run evaluation suites, monitor workloads, operate services and exercise recovery |

There is intentionally no one-to-one relationship between constitutional sections and SQL tables. One business definition spans several tables, and one table can support several requirements.

## 4. The common foundation: releases, objects and sources

### 4.1 `catalog_release`: which set of definitions is this?

**Connects to constitution 4.14 and commitments C07/C12.**

| Column | Meaning |
|---|---|
| `release_id` | Identity of the catalog release, for example `r42` |
| `schema_version` | Version of the catalog representation expected by readers; distinct from the release ID |
| `status` | `draft`, `reviewed`, `published` or `retired` |
| `content_sha256` | Hash of canonical semantic content using a defined serialization procedure |
| `created_at`, `published_at` | Release creation and publication times |
| `edit_revision` | Nonnegative edit counter used by CatalogService to detect stale edits and coordinate a freeze |

The constraint requires a published release to have a content hash and publication time. It does not verify the hash, enforce permissible state transitions or prevent later edits. The publisher and service permissions enforce those behaviors. SQLite file access is restricted to the service; it has no per-user database-role system. An edit compares the expected `edit_revision` and changes definitions plus revision within one transaction. A mismatch rejects the edit. The integer column alone does not implement that concurrency protocol.

Do not equate a catalog content hash with the SQLite file hash. A catalog content hash describes canonical metadata; a file hash describes bytes of a particular generated snapshot. Publication-control rows, `edit_revision`, audit timestamps selected for exclusion, and hashes themselves are excluded from canonical semantic hashing by an explicit procedure. Hashes must retain the same meaning when the authority later uses a different engine.

### 4.2 `catalog_object`: the common description of a semantic object

**Connects to meaning, ownership, provenance, security and stable IDs throughout the constitution.**

Many definitions need the same fields: a name, description, owner, policy reference, status and provenance. `catalog_object` stores those fields once per object/release. Specialized tables store the details particular to an entity, field, metric or other object kind.

| Column | Meaning |
|---|---|
| `release_id`, `object_id` | Versioned identity shared with a specialized table |
| `object_kind` | One of the permitted semantic object categories |
| `label` | Human-readable display name |
| `description` | Business description available to retrieval and interpretation |
| `owner` | Responsible owner reference |
| `access_policy_ref` | Reference to the policy governing access to the object |
| `status` | `draft`, `reviewed`, `published` or `deprecated` |
| `provenance_json` | Where the definition came from and its review/evidence references |

For example, the field `license.termination_date` is represented by two associated records:

| Table | Illustrative values |
|---|---|
| `catalog_object` | `object_id = license.termination_date`, `object_kind = field`, `label = License termination date`, `description = Date recorded as ending the license` |
| `field` | `field_id = license.termination_date`, `entity_id = license`, `physical_column = Termination_Date`, plus types/null/alias rules |

They share the same `release_id` and ID. **The description is in `catalog_object.description`; it is not missing because `field` has no `description` column.** The same pattern applies to entities, metrics, predicates and canonical values.

These specialized tables reference `catalog_object`:

| Specialized table | Its ID column | Expected `catalog_object.object_kind` |
|---|---|---|
| `entity` | `entity_id` | `entity` |
| `field` | `field_id` | `field` |
| `value_domain` | `domain_id` | `value_domain` |
| `canonical_value` | `value_id` | `canonical_value` |
| `relationship` | `relationship_id` | `relationship` |
| `predicate` | `predicate_id` | `predicate` |
| `metric` | `metric_id` | `metric` |
| `business_domain` | `domain_id` | `business_domain` |
| `semantic_concept` | `concept_id` | `concept` |
| `query_template` | `template_id` | `query_template` |

The existing foreign keys verify that a parent object exists. They **do not check that its kind matches the specialized table** or that it has exactly one appropriate specialization. The publisher must check those conditions. Tables such as `relationship_operation`, `verified_example`, `assertion` and `capability` have their own identity arrangements and do not use this parent pattern.

Object IDs must be unique across these object categories within a release. Prefixes such as `domain.distribution`, `license`, `license.status` and `license_status.active` help make their roles visible. An ID string's appearance is a convention; the declared object kind is the type.

### 4.3 `data_source`: where physical data comes from

**Connects to constitution 4.2, 4.12, 4.13 and 4.15.**

| Column | Meaning |
|---|---|
| `source_id` | Stable source reference within the release |
| `provider_kind`, `dialect` | Provider and SQL dialect used by the adapter |
| `connection_config_ref` | Reference to trusted connection configuration; credentials stay outside catalog records |
| `schema_fingerprint` | Recorded structural fingerprint used for drift comparison |
| `auth_policy_ref` | Applicable source access policy reference |
| `freshness_json` | Freshness expectations or evidence about the source |

`entity.connection_ref` is a foreign key to this table's `source_id`. The names differ, but the SQL explicitly connects them. Resolving it provides a source configuration reference, not permission for the model to choose credentials.

`schema_fingerprint` does not run drift detection. A discovery/drift service computes and compares fingerprints and decides which definitions or capabilities are affected.

## 5. Entities and fields: meaning, identity and physical bindings

### 5.1 `entity`: what dataset is available and what its rows mean

**Connects primarily to constitution 4.2; also 4.7, 4.12 and 4.13.**

| Column or group | Constitutional requirement represented |
|---|---|
| `entity_id` and corresponding `catalog_object` record | Stable identity, label, business description, ownership and lifecycle |
| `binding_kind` | Whether this entity binds to a physical source object or a reviewed derived relation |
| `connection_ref`, `physical_schema`, `physical_object` | Exact source location for a physical entity |
| `derived_plan_json` | Typed definition of a derived relation |
| `row_semantics_json` | Business sentence describing what a row represents |
| `physical_row_key_json` | How a physical row is identified; null/scope details and evidence references |
| `business_identity_json` | Which fields or authoritative identifier distinguish business entities |
| `versioning_json` | Current/history/version selection rules |
| `uniqueness_evidence_json` | References to evidence for required uniqueness claims |
| `identity_namespace` | Scope of the entity's identity; relationships must separately establish correspondence between their endpoint keys |
| `temporal_json` | Relevant temporal fields, interval/timezone semantics and supported time interpretations |
| `access_policy_ref` | Entity-specific policy reference, overlapping with the common object policy field |

For the sample physical entity, the binding chain is:

```text
semantic entity ID: license
  -> entity.connection_ref: company_operational
  -> data_source.connection_config_ref: approved configuration reference
  -> entity.physical_schema: dbo
  -> entity.physical_object: Producer_Licenses
```

The `CHECK` constraint requires physical bindings and derived bindings to use their respective columns exclusively. A derived relation's plan identifies its dependencies. The runtime must validate all of those dependencies and permissions before compiling it.

### 5.2 How grain appears in the columns

There is no single `grain` text column. The schema decomposes the requirement into row meaning, identity, versioning and evidence. This addresses your concern that “one row per license” is insufficient.

| Question | Relevant entity column |
|---|---|
| Does a row represent a current license, a history version or an ingestion record? | `row_semantics_json` |
| Which fields uniquely locate a physical source row? | `physical_row_key_json` |
| Which combination identifies one business license? | `business_identity_json` |
| Which version belongs in a current or historical answer? | `versioning_json`, `temporal_json` |
| Who confirmed the definition, and what supports uniqueness? | `catalog_object.provenance_json`, `uniqueness_evidence_json`, `assertion` |

A proposed `business_identity_json` payload during onboarding might be:

```json
{
  "payload_version": 1,
  "status": "unverified",
  "candidates": [
    {
      "field_ids": [
        "license.producer_key",
        "license.state",
        "license.license_number"
      ],
      "scope": "Requires owner confirmation and version-population definition"
    }
  ]
}
```

This records a hypothesis. It does not authorize a business-license count. The sample column list does not establish the correct combination or current/history behavior. A business metric requiring that identity stays unavailable until the claim is resolved. An explicitly defined physical source-row count has a different requirement.

A stable surrogate can be the business identity if evidence establishes its meaning and persistence. Its physical uniqueness alone is insufficient.

### 5.3 `field`: which attribute may be used and how?

**Connects to constitution 4.3.**

| Column or group | Meaning |
|---|---|
| `field_id`, `entity_id` | Stable field identity and its owning entity |
| `physical_column` / `expression_json` | A physical column binding or a typed derived expression, exclusively |
| `physical_type` | Actual source type, including details the adapter needs |
| `semantic_type` | Business/application type used to validate operations |
| `nullable` | Whether the source field can be null; stored as `0` or `1` |
| `null_meaning` | What a missing value means in this domain |
| `roles_json` | Identifier, dimension, temporal field, measure input or other supported roles |
| `operators_json` | Permitted operations on this field |
| `aliases_json` | Alternative business names used to retrieve the field |
| `sensitivity` | Classification information consumed by policy |
| `domain_id` | Optional reference to a **value domain**, such as `license_status` |

The label and description come from the matching `catalog_object` record. A dimension is represented by a field with the appropriate role; this schema has no separate dimension table.

For `license.termination_date`, the user-confirmed alias “term date” can be stored in `aliases_json`. `physical_column` contains `Termination_Date`. `null_meaning` should explain missing-date semantics without silently declaring the license active. The actual source type/nullability must be discovered before publication.

The source name is assembled through `field -> entity -> data_source`. A representative **metadata read against the in-memory SQLite copy of a published release** is:

```sql
SELECT
    o.label,
    o.description,
    f.field_id,
    f.physical_column,
    f.physical_type,
    f.semantic_type,
    f.null_meaning,
    f.aliases_json,
    e.physical_schema,
    e.physical_object,
    s.connection_config_ref
FROM field AS f
JOIN catalog_object AS o
  ON o.release_id = f.release_id AND o.object_id = f.field_id
JOIN entity AS e
  ON e.release_id = f.release_id AND e.entity_id = f.entity_id
JOIN data_source AS s
  ON s.release_id = e.release_id AND s.source_id = e.connection_ref
WHERE f.release_id = :release_id
  AND f.field_id = :field_id;
```

With `field_id = license.termination_date`, this loads the meaning and physical binding together. The example handles a physical entity; a derived entity requires interpretation of its reviewed plan. Authorization is a separate service check before the definition enters model context or execution.

The unique constraint on `(release_id, entity_id, physical_column)` allows one directly bound semantic field for a physical column within an entity. Additional labels should normally be aliases. Multiple intentional interpretations would require an explicit derived field/entity design or a reviewed schema extension.

### 5.4 Two policy references need an explicit rule

Both `catalog_object` and `entity` contain `access_policy_ref`. The SQL does not define their precedence. A practical initial publisher rule is to require them to match for an entity, with the common object record as the authoring source. If the product needs separate policies, define their combination explicitly and validate it. The compiler must never infer that one reference silently overrides the other.

## 6. Domains, glossary concepts and membership

**Connects to constitution 4.1, 4.10 and 4.15.**

### 6.1 A business domain and a value domain are different

| Name | Example | Purpose |
|---|---|---|
| `business_domain` | `domain.distribution` | Groups meaning, ownership and supported questions |
| `value_domain` | `product_category` | Defines a vocabulary of permitted business values |

Both tables name their key `domain_id`, but the foreign key determines which kind is intended. `field.domain_id` points to `value_domain`. `domain_membership.domain_id` and `domain_capability.domain_id` point to `business_domain`.

### 6.2 `business_domain`

The common object record supplies its name, description, owner and policy. Specialized columns add:

- `routing_summary`: a concise description used to select candidate domains for a question.
- `vocabulary_json`: domain terms and scoped vocabulary information.
- `coverage_json`: which datasets/question families are available and where gaps remain.
- `steward`: the person/team responsible for business stewardship.

The field `coverage_json` records coverage declarations. It cannot prove that the system correctly answers those questions; evaluation evidence supplies that support.

### 6.3 `domain_membership`

This table associates an object with one or more business domains. Its keys are `release_id`, `domain_id` and `object_id`; `membership_role` describes the relationship.

For example, `license` and `license.active_record_count` can both belong to `domain.distribution`. The same object may be shared with another domain. This association supports routing and ownership; access authorization still applies independently.

### 6.4 `semantic_concept`

A glossary concept can exist even when it is not itself a column or dataset. `concept_id` links to the common object record, and `definition_json` holds additional scoped meaning, aliases and associations required by the chosen payload schema.

For example, “individual” may have a glossary definition distinguishing a legal person from an unaggregated detail record. A concept association can help interpretation find relevant entities. It does not create a classification field absent from the source.

### 6.5 `semantic_edge`

This table links semantic objects using `from_object_id`, `to_object_id`, `edge_kind`, `review_status` and `properties_json`. The allowed edge kinds are `depends_on`, `lineage`, `concept_association`, `equivalence` and `taxonomy`.

Examples include a metric depending on a predicate, or a business concept associated with a field. These edges support context expansion and change-impact analysis. Proposed edges can support review workflows; they must not acquire execution authority merely because they exist in the table. Runtime projections apply the release's approval policy.

An executable SQL correspondence is represented by `relationship` and `relationship_operation`. Section 9 explains how both edge families feed a graph while preserving this distinction.

## 7. Values and mappings: from Pet to stored codes

**Connects to constitution 4.4 and commitment C03.**

This family explains the earlier phrase “resolve labels to authoritative records and bindings.” Four tables divide that work, and `catalog_object` supplies their common descriptions where applicable.

```mermaid
flowchart LR
    T[User label: Pet] --> A[value_alias]
    A --> V[canonical_value: product_category.pet]
    V --> D[value_domain: product_category]
    V --> B[value_binding]
    B --> F1[agent_contract.product_category: PET]
    B --> F2[agency_contract.product_category: P]
    O[catalog_object labels and descriptions] --> V
```

### 7.1 `value_domain`: the vocabulary and its resolution rules

`domain_id` identifies the vocabulary, such as `product_category` or `license_status`.

- `normalization_json` describes approved text normalization, such as case handling, whitespace handling and locale policy.
- `resolution_policy_json` describes exact/alias/fuzzy resolution behavior and ambiguity handling.
- Its `catalog_object` record supplies the business label, description, ownership, approval status and policy reference.

Normalization must preserve distinctions meaningful in that domain. A status code and an account identifier may need different rules. A global lowercase-and-strip-punctuation rule would be an implementation decision requiring evidence, not a consequence of this schema.

### 7.2 `canonical_value`: one business meaning

`canonical_value` contains only `release_id`, `value_id` and `domain_id` because its label/description/status are stored in `catalog_object`.

| Table | Illustrative record |
|---|---|
| `catalog_object` | `object_id = product_category.pet`, `object_kind = canonical_value`, `label = Pet`, business description of the category |
| `canonical_value` | `value_id = product_category.pet`, `domain_id = product_category` |

The canonical ID is the value referred to by semantic plans. It is independent of whether a particular source stores `PET`, `P` or another encoding.

### 7.3 `value_alias`: ways a user might name that meaning

The row contains `value_id`, `locale` and `normalized_alias` within a release. For example, `pet` in `en-US` can point to `product_category.pet`.

The key includes `value_id`, so the same alias may point to multiple candidate values. The schema intentionally permits ambiguity. The resolver examines domain/context and either selects a justified interpretation or asks the user. It must not arbitrarily take the first matching row.

There is no `domain_id` on `value_alias`. Join through `canonical_value` to restrict an alias lookup to a value domain. The normalization procedure must agree with the selected domain's policy.

### 7.4 `value_binding`: exact values for a particular field

| Column | Meaning |
|---|---|
| `binding_id` | Identity of this source-field encoding |
| `value_id` | Canonical business meaning being encoded |
| `field_id` | Exact source field to which this encoding applies |
| `literal_type` | Type tag such as string, integer, decimal or date |
| `literal_json` | Stored literal encoded as JSON |
| `valid_from`, `valid_to` | Effective interval for the mapping |

Illustrative records, using the synthetic encodings from the worked examples:

| `binding_id` | `value_id` | `field_id` | `literal_type` | `literal_json` |
|---|---|---|---|---|
| `pet_agent_example` | `product_category.pet` | `agent_contract.product_category` | `string` | `"PET"` |
| `pet_agency_example` | `product_category.pet` | `agency_contract.product_category` | `string` | `"P"` |
| `license_active_example` | `license_status.active` | `license.status` | `string` | `"ACTIVE"` |
| `appointment_active_example` | `appointment_status.active` | `appointment.status` | `string` | `"A"` |

The quotes in `"PET"` show that `literal_json` contains a JSON string. The resolver decodes it to the typed value `PET`, and the executor binds that value as a query parameter. It is not pasted into SQL text.

Multiple approved encodings for one value/field are represented by multiple binding rows. For example, if two reviewed source codes both mean active, the resulting membership predicate may use two bound parameters. The resolver must return the complete applicable set.

The script checks that the referenced value and field exist. It does **not** check that the value's domain matches `field.domain_id`, the JSON value agrees with `literal_type`, or validity intervals obey the intended mapping policy. Publisher/resolver validation supplies those checks.

### 7.5 What an exact metadata lookup looks like

After the resolver has selected a value domain and normalized the input, it can retrieve candidate mappings with a query shaped like this:

```sql
SELECT
    cv.value_id,
    co.label,
    co.description,
    vb.binding_id,
    vb.field_id,
    vb.literal_type,
    vb.literal_json
FROM value_alias AS va
JOIN canonical_value AS cv
  ON cv.release_id = va.release_id AND cv.value_id = va.value_id
JOIN catalog_object AS co
  ON co.release_id = cv.release_id AND co.object_id = cv.value_id
JOIN value_binding AS vb
  ON vb.release_id = cv.release_id AND vb.value_id = cv.value_id
WHERE va.release_id = :release_id
  AND cv.domain_id = :value_domain_id
  AND va.locale = :locale
  AND va.normalized_alias = :normalized_label
  AND vb.field_id = :field_id
  AND vb.valid_from <= :effective_at
  AND (vb.valid_to IS NULL OR :effective_at < vb.valid_to);
```

This example uses half-open intervals: the start is included and the end is excluded. That is an explicit proposed validity convention; the publisher must adopt and validate it. Because SQLite stores these timestamps as text, the exporter and caller must use a consistent sortable representation, such as fixed-format UTC timestamps. `CHECK (valid_from < valid_to)` alone does not validate timezone or date formatting.

This query is one metadata lookup, not a complete resolver. An empty result must be diagnosed: the alias could be absent, the field binding missing, or the time interval unsupported. The service also checks authorization, canonical-name matches, ambiguity and required coverage across all requested fields.

### 7.6 How this relates to vector search

Search may suggest that the user's wording matches `product_category.pet`. Its hit should return stable object IDs and release identity. The application reloads the canonical record and binding rows before accepting the value. The source code comes from `value_binding`, regardless of how the candidate was discovered.

For large live dictionaries, the design also permits authorized value providers. This DDL does not yet define a dedicated provider-configuration/version table. That is a genuine extension to implement, rather than a hidden capability of `value_binding`.

## 8. Predicates, metrics and reusable populations

### 8.1 `predicate`: a reusable business condition

**Connects to constitution 4.5 and C09.**

The common object record supplies the predicate's name, description, owner and status. `predicate` adds:

| Column | Meaning |
|---|---|
| `predicate_id` | Stable rule ID, for example `license.active` |
| `entity_id` | Entity on which the condition applies |
| `expression_json` | Typed expression defining the condition |
| `purpose` | `business`, `source_restriction` or `security_restriction` |

For a reviewed status-only active definition, the stored `expression_json` could be:

```json
{
  "op": "in_value_set",
  "field": "license.status",
  "value_id": "license_status.active"
}
```

The expression refers to the canonical active value. The resolver follows the mapping tables to obtain the relevant status literals. This keeps the active condition and physical status codes connected without copying those codes into every metric or example.

For a no-termination-date rule, the expression can use `is_null` on `license.termination_date`. This is a separate condition. Whether active status also requires a date condition is a business decision, not something `purpose = business` implies.

The `purpose` enum distinguishes broad rule categories. It does not fully specify whether a business rule is a default, user-requested condition, metric requirement or overridable preference. The application payload/context must make those distinctions explicit. Merely storing a `security_restriction` predicate does not attach it to every relevant scan; trusted planning/policy code must do that.

### 8.2 How a worked-example JSON object becomes rows

The worked examples show readable composite objects with keys such as `id`, `expression` and `explanation`. Those are explanatory representations, not a literal list of SQL column names. For the active predicate:

| Worked-example key | Persistence location |
|---|---|
| `id = license.active` | Both `catalog_object.object_id` and `predicate.predicate_id` |
| `entity_id = license` | `predicate.entity_id` |
| `definition_status = draft` | `catalog_object.status` |
| `expression = {...}` | Contents of `predicate.expression_json` |
| `explanation` | Appropriate business text in `catalog_object.description` |

The importer supplies other required common fields, such as owner and provenance. You do not place the entire explanatory wrapper inside `expression_json`; that column holds the expression itself.

### 8.3 `metric`: the meaning of a count, sum or other measure

**Connects to constitution 4.8.**

`metric` has `metric_id`, `base_entity_id` and `definition_json`, plus release identity. Its common object row supplies the business label/description, ownership and lifecycle.

The constitution's richer metric requirements are expected inside `definition_json`:

| Required meaning | Proposed payload content |
|---|---|
| What is measured | Unit and business definition |
| Which records contribute | Required predicates and applicable population rules |
| How records are counted | Aggregation operator and counted identity/row-selection rule |
| Permitted grouping | Approved dimensions and their relationship roles |
| Whether totals can be combined | Additivity/overlap rules |
| Time behavior | Time basis, period and current/as-of rules |
| Null/empty-set behavior | Explicit aggregation semantics |
| Output representation | Result type and precision |
| Supporting proof | Required assertion IDs |

For illustration, a definition for `license.active_record_count` might contain:

```json
{
  "payload_version": 1,
  "aggregation": "count_rows",
  "unit": "business_license",
  "population_rule": "one_approved_row_per_business_license",
  "required_predicate_ids": ["license.active"],
  "required_assertion_ids": ["license.business_population_verified"],
  "allowed_group_field_ids": [],
  "allowed_population_operation_ids": [
    "license.has_agent_contract",
    "license.has_agency_contract"
  ],
  "null_input_behavior": "count_qualifying_rows",
  "empty_population_result": 0,
  "output_type": "int64",
  "additivity": "requires_disjoint_populations"
}
```

Here the population-rule name is an explanatory proposal requiring a formally defined, validated payload contract. The assertion must refer to actual evidence and row-selection semantics before this metric can be enabled. Declaring the assertion name or setting a JSON flag cannot make an unverified business identity valid.

The metric chooses the base entity and required active predicate. A request adds Pet-contract qualification through approved operations. Therefore changing Pet to another approved category does not require a new count metric.

### 8.4 Where a cohort is stored

**Connects to constitution 4.7.** There is no `cohort` table in the current schema. Three supported representation choices have different purposes:

| Case | Representation |
|---|---|
| A condition reused on an entity | Named `predicate` and approved relationship qualification |
| A reusable pattern that constructs a qualifying population | `query_template.plan_json` with typed parameters |
| A named dataset whose rows represent cohort members | `entity` with `binding_kind = derived` and `derived_plan_json` |

A one-time cohort formed for a question can also exist solely in that request's logical plan. It need not become a persistent catalog object.

For the sample “qualifying producers, then all their active licenses” interpretation, the plan derives qualifying producer keys and expands licenses. The four supplied physical tables do not include an authoritative producer master. A derived cohort must declare its resulting key and classification limits; it cannot imply a legal-individual classification that the source does not establish.

## 9. Relationships, operation contracts and the graph

**Connects to constitution 4.6 and 4.10.**

### 9.1 `relationship`: which entity roles can correspond?

| Column | Meaning |
|---|---|
| `relationship_id` | Stable correspondence identity |
| `source_entity_id`, `target_entity_id` | Directed endpoint entities |
| `source_role`, `target_role` | Business roles of those endpoints in this relationship |
| `key_pairs_json` | Typed field pairs used to correlate records |
| `cardinality_json` | Possible matches in each direction and relevant qualifications |
| `required_predicates_json` | Conditions intrinsic to the relationship |
| `identity_json` | Identity-namespace/crosswalk meaning and null-key handling |
| `temporal_json` | Required time/interval correspondence |

The common object row supplies its description, approval status, owner, policy and provenance. Evidence can be attached through assertions and typed references in its payloads.

Illustrative source and target:

```text
relationship_id: license.agent_contract_by_producer
source_entity_id: license
target_entity_id: agent_contract
source_role: base_license
target_role: qualifying_contract
```

The proposed `key_pairs_json` contents are:

```json
[
  {
    "source_field": "license.producer_key",
    "target_field": "agent_contract.producer_key"
  }
]
```

The endpoints have SQL foreign keys. The field IDs inside this JSON do not. The publisher must confirm that each field exists, belongs to the stated endpoint and is compatible with the key semantics. A shared column name or data type cannot establish that producer identities have the same meaning across sources.

### 9.2 Cardinality belongs to the relationship; multiplicity belongs to the operation

The license-to-contract correspondence by producer may be many-to-many: a producer may hold several licenses and several contracts. A contract-existence operation can still qualify each license without multiplying it.

| Statement | Where represented |
|---|---|
| A license may correspond to several contracts | `relationship.cardinality_json` |
| This operation keeps a license when at least one contract qualifies | `relationship_operation.operator = exists` |
| This use preserves the multiplicity of surviving license rows | `relationship_operation.contract_json` and planner validation |

This is why neither `CARDINALITY` nor a single universal `JOIN_TYPE` can express all the required semantics.

### 9.3 `relationship_operation`: how may the relationship be used?

The row identifies `operation_id`, its `relationship_id`, an `operator`, and `contract_json` within a release.

For `license.has_agent_contract`, the operator is `exists`. A proposed contract can contain:

```json
{
  "payload_version": 1,
  "purpose": "qualify_base",
  "required_sql_form": "correlated_exists",
  "output_grain": "unchanged",
  "output_multiplicity_per_base_row": "zero_or_one",
  "can_project_target_fields": false,
  "target_filters_scope": "inside_exists",
  "permitted_target_filters": [
    "agent_contract.product_category",
    "agent_contract.status",
    "agent_contract.contract_type"
  ]
}
```

The SQL constraint limits `operator` to `exists`, `not_exists`, `enrich_left`, `expand_left`, `enrich_inner`, `expand_inner`, `temporal_lookup`, `bridge_membership` or `bridge_allocate`. These are permitted metadata values. A listed value still needs an implemented, enabled capability before execution.

One relationship can have several approved operation records. The operation chooses population/output behavior; the relationship supplies key, role and temporal facts.

### 9.4 Exactly where a mandatory LEFT rule lives

Suppose an approved relationship supports left-preserving enrichment. Its operation row has `operator = enrich_left`, and `contract_json` describes preservation, right-side uniqueness, allowed projections and target-filter placement.

1. The planner selects that operation and verifies its required uniqueness evidence.
2. The compiler emits a logical left join with the correct predicates.
3. The validator checks the operation's shape, lineage and obligations in the generated query.
4. A target filter used to choose included children stays in the join condition or target subquery when needed to preserve the base population.

For a one-to-many detail result, `expand_left` declares the changed grain instead. Preserving the parent population does not imply one output row per parent.

The SQL schema does not itself inspect or reject an `INNER JOIN` generated by a faulty compiler. It stores the contract that the planner/compiler/validator must enforce. Similarly, it contains no trigger that rewrites target filters into the correct clause.

### 9.5 Reading a relationship and its operations from the snapshot

```sql
SELECT
    r.relationship_id,
    r.source_entity_id,
    r.target_entity_id,
    r.source_role,
    r.target_role,
    r.key_pairs_json,
    r.cardinality_json,
    r.identity_json,
    r.temporal_json,
    r.required_predicates_json,
    ro.operation_id,
    ro.operator,
    ro.contract_json
FROM relationship AS r
JOIN relationship_operation AS ro
  ON ro.release_id = r.release_id
 AND ro.relationship_id = r.relationship_id
WHERE r.release_id = :release_id
  AND ro.operation_id = :operation_id;
```

This loads the contract. The planner still verifies capability enablement, current authorization, evidence and applicability to the request.

### 9.6 How rows turn into a NetworkX graph

The graph builder loads entities as typed nodes and approved relationship/operation definitions as executable edge metadata. It preserves edge identity, direction, endpoint roles and parallel relationships. It also loads appropriate `semantic_edge` records for dependency/context analysis, preserving their separate edge kinds.

```mermaid
flowchart TB
    E[entity and field records] --> G[Typed graph projection]
    R[relationship and operation records] --> G
    S[semantic_edge dependency records] --> G
    G --> P[Planner traverses permitted relationship paths]
    G --> C[Context assembler expands dependencies]
    G --> I[Publisher finds affected definitions]
```

The canonical records remain in the persistent catalog authority, initially SQLite, and the selected published release. NetworkX provides an in-memory graph while the separate in-memory SQLite reader provides relational metadata lookups. The graph is reconstructed from those records or from a serialized, verified graph projection. A future server authority changes where edits persist; it need not change either read representation.

Even if an approved dependency path connects two objects, that path alone does not authorize a SQL join. Only the executable relationship contracts provide that permission. A later graph-database backend must preserve these same distinctions.

## 10. Examples and assertions: definitions need evidence

### 10.1 `verified_example`: a reviewed question and expected behavior

**Connects to constitution 4.10, 4.14 and 4.18.**

| Column | Meaning |
|---|---|
| `example_id` | Example identity within a release |
| `question` | User wording |
| `semantic_query_json` | Expected interpreted intent/plan representation |
| `reference_sql` | Optional reviewed SQL for comparison and explanation |
| `fixture_id` | Reference to controlled example data or an evaluation fixture |
| `expected_json` | Expected results, identities or rejection/clarification outcome |
| `review_status`, `reviewer` | Review state and attribution |

For the sample license count, the example can state that category membership means either contract source, that active means the reviewed license-status rule, and that contract status is unrestricted unless an approved default says otherwise.

The table does not store fixture rows or run assertions. The evaluation system owns those activities. The name `verified_example` also does not make every row verified: the schema permits `draft` and `rejected`. The publisher must choose appropriate approved records. It should require a reviewer for approved examples, although the present DDL does not enforce that condition.

This table lacks a direct `catalog_object` parent and a dedicated policy-reference column. Examples may contain sensitive wording or literals. Publication/retrieval must use an explicit access classification, whether through an implementation extension or a restrictive inherited scope. Lack of a policy column cannot mean universal visibility.

### 10.2 `assertion`: a required claim and its supporting evidence

**Connects to constitution 4.2, 4.6, 4.14 and 4.18.**

| Column | Meaning |
|---|---|
| `assertion_id` | Identity of a required claim |
| `subject_id` | Object, operation or identity namespace to which it applies |
| `requirement_json` | Typed claim and subject kind |
| `evidence_json` | Constraint, owner decision, profile or other evidence, including scope and time |
| `valid_until` | Optional expiry of the evidence/claim's applicability |
| `failure_action_json` | What to do when evidence fails, expires or becomes inapplicable |

For example, an enrichment operation might require at most one applicable target row per source key at the chosen time. Its assertion can reference a maintained source constraint or a reviewed temporal uniqueness mechanism.

A profile over a sample is weaker evidence than a maintained constraint and says nothing about unseen or subsequently changed data. The evidence payload must identify that limitation. A stored assertion cannot guarantee future source rows will continue to obey it; drift/health checks and runtime guards are needed where the operation relies on a condition that can change.

`subject_id` deliberately has no SQL foreign key because subjects can belong to different kinds. The publisher reads the typed subject declaration in `requirement_json` and resolves it. This is another place where database integrity and semantic integrity differ.

## 11. Templates, capabilities and typed validation

**Connects to constitution 4.7, 4.9, 4.11 and C10.**

### 11.1 `query_template`: a reusable parameterized semantic plan

The common object row supplies the template's label, description, owner and policy. Its specialized fields are:

- `parameter_schema_json`: allowed parameters and their types.
- `plan_json`: reviewed logical plan pattern.
- `capability_requirements_json`: operator capabilities required to instantiate it.

A template can express “count active licenses having contracts in a requested category.” The category parameter resolves to an approved canonical value and source bindings. The plan uses IDs for the metric, predicates and relationship operations.

The template is useful for repeatable complex shapes and controlled coverage. Ordinary supported combinations can also be represented directly by the general plan language; they do not all need separate template rows.

### 11.2 `capability`: what an operator means in a particular implementation contract

| Column | Meaning |
|---|---|
| `capability_id` | Stable capability identifier |
| `operator_name`, `operator_version` | Operation family and its semantic/version contract |
| `dialect` | Target dialect supported by this capability |
| `schema_json` | Versioned schema for the operator's payload or a defined representation of it |
| `requirements_json` | Preconditions such as field types, evidence or supported workload characteristics |

For example, a semi-qualification capability can describe an existence operator over an approved relationship. The compiler's installed operator registry must contain a compatible implementation.

**Inserting a capability row does not add executable behavior.** The publisher/runtime verifies that the installed code supports the declared operator version and target dialect. The catalog stores declarations; deployment supplies implementations.

### 11.3 `domain_capability`: where that capability is enabled

This links a capability to a business domain, with `status` set to `disabled`, `evaluation` or `enabled`, and `evidence_json` recording the basis for enablement.

For example, an as-of relationship capability may be enabled for one domain with reliable history and unavailable for another domain that lacks effective dates. Both domains use the same general query language; the enabled operations differ.

The current table does not have explicit workload-class or role columns. If rollout varies by workload class, the requirements payload and runtime configuration must define that policy, or the schema must be extended. Do not assume domain enablement grants every user access.

### 11.4 Where Pydantic fits

Two related type families are needed:

| Type family | Examples | Validation role |
|---|---|---|
| Catalog payload types | Metric definition, relationship contract, field roles, capability requirements | Validate metadata entering and leaving JSON columns |
| Query/plan types | Filter, aggregate, relation reference, proposed query, validated plan | Validate requests and intermediate representations |

Pydantic can enforce configured structural rules, type checks and rejection of unexpected properties. Strictness must be configured deliberately; it should not be assumed from simply inheriting a base model. [Pydantic strict-mode documentation](https://docs.pydantic.dev/latest/concepts/strict_mode/)

Further semantic validation loads the pinned catalog to verify that referenced fields exist, operators apply to their types, values bind to the right domains, paths are approved, capability versions are supported and requested access is allowed.

Example:

```text
Proposed filter:
  field_id = license.termination_date
  operator = is_null

Structural validation:
  The filter has the correct shape and accepted operator name.

Semantic validation:
  That field exists in the selected release.
  Its owning entity is available in this plan role.
  Its operators_json permits the operation.
  Its type and meaning support the condition.
  The request is authorized to use it.
  The compiler supports the required operator capability.
```

The actual request proposal and validated plan are runtime artifacts. This SQL file contains no `request_plan` or `compiled_query` table. Template/example plans are reusable/reference metadata and should not be confused with live request storage.

## 12. Publication, projections and the request manifest

**Connects to constitution 4.14, 4.16 and commitments C07/C12.**

### 12.1 `projection_artifact`: what was built from a release?

| Column | Meaning |
|---|---|
| `projection_id` | Identity of the generated representation within the release |
| `projection_kind` | `sqlite`, `search`, `graph`, `examples` or `evaluation` |
| `state` | `building`, `ready`, `failed` or `retired` |
| `locator` | Where the file, index, graph artifact or evaluation result can be obtained |
| `content_hash` | Digest established using the artifact's defined verification procedure |
| `configuration_json` | Build configuration, such as embedding settings, text transformation, graph format or evaluation version |

The persistent SQLite authority stores each projection's identity and location. Search vectors stay in the search service. Serialized graphs and immutable SQLite release files live in artifact storage. Workers load the selected SQLite release and graph into memory within a measured budget; a read-only file mode supports larger catalogs through the same reader interface.

For a file, `content_hash` can describe exact file bytes. For a managed search index, the system needs a defined content/build verification procedure rather than pretending the service exposes a stable downloadable file. Record the meaning of the digest in projection configuration.

The SQL checks that `ready` projections have non-null hashes. The publisher must verify actual content, readiness and configuration compatibility.

### 12.2 `release_manifest`: a compatible bundle for requests

| Column | Meaning |
|---|---|
| `manifest_id` | Identity of the bundle |
| `release_id` | Semantic catalog release |
| `manifest_version` | Manifest format version |
| `snapshot_projection_id` | Chosen SQLite representation |
| `search_projection_id` | Chosen search representation |
| `graph_projection_id` | Chosen graph representation |
| `application_config_json` | Compatible application/model/compiler/workflow configuration references |
| `manifest_hash` | Digest of the manifest's canonical content, excluding its own hash field |
| `created_at` | Creation time |

The compound foreign keys ensure that the referenced projections belong to the manifest's release. They do not verify that `snapshot_projection_id` points to a projection whose kind is `sqlite`, or that any projection is actually ready. Those checks belong to the publisher.

A proposed `application_config_json` might be:

```json
{
  "payload_version": 1,
  "model_config_id": "approved-model-config-6",
  "prompt_version": "intent-4",
  "compiler_version": "compiler-3",
  "compiler_capability_set": "query-algebra-2",
  "workflow_version": "workflow-5",
  "retrieval_config_id": "hybrid-rerank-3",
  "compatible_policy_schema": 1
}
```

This identifies compatible configurations. The model/runtime configurations live in their deployment/configuration systems; a catalog JSON record does not install or pin a provider deployment by itself. The release process must resolve the references and record what was actually used.

Catalog-resident mappings are versioned through `value_binding.release_id`; they need not each have an unrelated global mapping-version field. External value providers require their own revision/freshness records in resolved handles and request provenance.

### 12.3 `active_manifest`: the default for new requests

This small table contains `singleton` and `manifest_id`. The primary key and `CHECK (singleton = 1)` allow at most one active-pointer row. Application initialization/publication must ensure an appropriate pointer exists; the DDL does not require one row to be present.

Changing the pointer makes new requests select a different complete bundle. Requests already running retain the selected manifest unless a retirement, revocation or source-compatibility rule requires interruption or replanning.

The provided table represents one global active pointer. Multiple independent environment/domain rollout channels would need a scoped activation model or separate deployments. That is a future schema extension, not an existing feature of the singleton key.

### 12.4 Why control tables are populated in authority but empty in readers

The DDL includes `projection_artifact`, `release_manifest`, `active_manifest` and `publication_outbox`. The persistent authority uses these tables for real publication work. The exporter copies approved semantic definitions and canonical release identity into a separate release file; its control tables stay empty. This rule applies whether the authority uses SQLite now or a server engine later. It does not mean that all SQLite databases lack control records.

The reason is practical: the publisher must finish creating the SQLite file before it can calculate that file's hash. Writing the file's hash back inside the file would change the file being hashed. The external manifest stores the snapshot's location and checksum.

```mermaid
flowchart TB
    A[Authors use CatalogService] --> DB[Persistent SQLite authority]
    DB --> R[Review and freeze release]
    R --> B[Publisher builds projections]
    B --> S[Immutable SQLite file]
    B --> X[Search index for the release]
    B --> G[Graph projection for the release]
    S --> V[Verify complete artifact set]
    X --> V
    G --> V
    V --> M[Store manifest in authority]
    M --> P[Update active_manifest]
    P --> W[New request pins manifest]
    W --> L[Worker loads SQLite release into RAM and graph into memory]
```

SQLite now serves two roles: durable authority and published read model. The earlier statement that it serves only as a published read model is superseded. Workers consume approved releases through in-memory SQLite; authoring and global activation occur in the persistent authority through CatalogService.

### 12.5 The transactional outbox in the authority

`publication_outbox` is present in both the default SQLite schema and optional PostgreSQL schema. It stores release events with `event_id`, `release_id`, `topic`, `idempotency_key`, `payload_json`, `created_at`, `delivered_at` and `attempt_count`. Those rows persist in the authority and are excluded from published read copies.

A catalog transaction records both the intended publication change and the event describing work to perform. Consumers build projections and handle retries. The table supports reliable dispatch; consumer code must implement idempotency, acknowledgments and error handling.

The non-null, unique `idempotency_key` prevents duplicate event identities. `attempt_count` must be nonnegative. The pending index supports finding undelivered events. These constraints do not prevent every duplicated external side effect; the worker must reuse durable operation IDs and reconcile retries. Backup and migration must preserve pending events and their status along with definitions and manifests.

### 12.6 Version pinning and current authorization work together

A request stores the selected manifest ID and references to the definitions used. Its RAM reader is acquired by that release identity and retained for the request lifetime. It records the model/compiler configurations and any mapping-provider revisions. The request's execution/audit artifact also records the policy decision/version actually evaluated.

Current access is rechecked before protected metadata use, execution and result retrieval as applicable. A manifest's `compatible_policy_schema` describes format compatibility; it does not freeze access grants. This catalog DDL has no per-request policy-decision, compiled-artifact or answer-audit table. Those stores are separate implementation work.

## 13. Trace one question through the catalog

Consider the original question:

> What is the count of all license records that are active and have Pet contracts?

For this walkthrough only, assume an owner has approved the license business identity and counted-row population, confirmed producer identity correspondence, supplied real mappings, and enabled the required operations. Those approvals remain unresolved for the actual sample schema. Without them, the application stops at the relevant missing definition instead of asserting a valid business count.

### 13.1 The minimum relevant definition set

| Metadata | Illustrative IDs | What the request needs it for |
|---|---|---|
| Catalog/manifest | `r42` and its selected manifest | Consistent interpretation and implementation configuration |
| Business domain | `domain.distribution` | Routing and scoped vocabulary |
| Entities | `license`, `agent_contract`, `agency_contract` | Base records and qualifying contract sources |
| Fields | License status/producer key; contract product categories/producer keys; identity/version fields as required | Filtering, correlation and counted population |
| Value domains | `license_status`, `product_category` | Meaning of active and Pet |
| Canonical values | `license_status.active`, `product_category.pet` | Source-independent values |
| Bindings | Active codes and Pet codes for both contract fields | Exact typed query parameters |
| Predicate | `license.active` | Approved active-license rule |
| Metric | `license.active_record_count` | Counted unit, base population and required predicates |
| Relationships/operations | `license.has_agent_contract`, `license.has_agency_contract` and their correspondence rows | Approved producer-scoped qualification without fanout |
| Assertions | Business-population, identity and other required evidence | Justification for the selected operations |
| Capabilities | Enabled count/filter/existence support for the domain and dialect | Implemented and released operator set |
| Example | Reviewed form of this question | Clarify either-source eligibility and contract-status treatment |

Each specialized entity/field/value/predicate/metric/relationship also has its common `catalog_object` row. The table above is a dependency list, not a count of individual SQL records.

### 13.2 Execution trace

| Step | Catalog records or other state consulted | Result |
|---|---|---|
| 1. Select release | Persistent authority `active_manifest`, `release_manifest`, projection records | Request pins one compatible bundle and acquires its in-memory SQLite reader |
| 2. Find relevant business area | Domain summaries, descriptions and search documents | Authorized domain/entity/metric candidates |
| 3. Load exact definitions | `catalog_object`, `entity`, `field`, `metric` | Meaning, source bindings and metric requirements |
| 4. Interpret active | `predicate`, status domain/value/binding rows | Approved active condition and typed status parameter set |
| 5. Interpret Pet | Category alias/value/binding rows | Canonical Pet meaning with bindings for each contract field |
| 6. Interpret “have contracts” | Relationship records, operation contracts, reviewed example | Existence through either approved contract source |
| 7. Check counted population | Entity identity/version metadata, metric definition, assertions | Established business unit and required row selection |
| 8. Validate request | Capability/domain capability records, policies and installed implementations | A validated semantic plan or a specific unresolved requirement |
| 9. Compile | Exact physical bindings and typed parameters | Parameterized T-SQL with approved population and relationship semantics |
| 10. Execute | Current authorization, sealed artifact and workload controls | Azure SQL computes the result |
| 11. Explain | Executed interpretation, manifest and result envelope | Count with its unit, scope, versions and completeness |

Under the worked example's approved one-row-per-counted-license assumption, the resulting logical shape is:

```text
Start with the approved license population.
Keep rows satisfying license.active.
Keep a row if either:
  an approved agent-contract correspondence has the Pet category, or
  an approved agency-contract correspondence has the Pet category.
Count the surviving license rows.
```

Contract multiplicity does not multiply licenses because qualification uses existence. No appointment relation participates. The question does not add a contract-active or license-no-termination-date condition automatically; those require explicit wording or a disclosed approved rule.

### 13.3 How the other two sample questions reuse the catalog

For the appointment count, select the appointment entity, its own active predicate and mappings, its metric, and the appointment-to-contract operations. The same canonical Pet value can be reused with the contract source bindings.

For the detail question, retrieve the description and aliases for `license.termination_date` to interpret “no term date.” The agent then proposes the filter. A reviewed example or clarification decides whether all conditions apply to the same license rows, or whether qualifying producers form a cohort and all active licenses are expanded afterward. The output grain and operation contract differ between those interpretations.

The catalog supplies precise definitions and available operations. Interpreting the user's intended scope remains part of the agentic workflow, with clarification when necessary.

## 14. Where the fourteen foundational commitments are implemented

This table reconciles the short constitutional statements discussed in the conversation with concrete storage and code responsibilities.

| Commitment | Concrete catalog connection | Enforcement that must be implemented |
|---|---|---|
| **C01 Meaning precedes SQL** | Entity grain/identity, predicates and metric definitions | Build and validate semantic intent before SQL compilation |
| **C02 IDs precede names** | `catalog_object.object_id`; specialized IDs; separate entity/field physical bindings | Resolve semantic IDs within the pinned release |
| **C03 Facts precede similarity** | Canonical values, aliases and field-specific literal bindings | Rehydrate search candidates and resolve approved typed values |
| **C04 Contracts precede join syntax** | `relationship_operation.operator` and `contract_json` | Planner/compiler/validator enforce each selected operation |
| **C05 Unknown stays unknown** | Draft statuses, coverage gaps, assertions and missing mappings | Return ambiguity/unsupported errors instead of inventing metadata |
| **C06 Authorization covers every stage** | Policy references, sensitivity and restriction predicates | Live policy decisions across retrieval, source access, caches and results |
| **C07 Versions travel together** | Release IDs, manifest configuration and provider revisions where applicable | Bind actual versions to each compiled artifact and answer audit record |
| **C08 Tests prove specific guarantees** | `verified_example`, `assertion`, capability evidence | Execute relevant evaluations and interpret the limits of the evidence |
| **C09 One implementation of a business rule** | Named `predicate` and `metric` records | Resolve their IDs consistently and compile centrally |
| **C10 Versioned expressiveness** | `capability`, `domain_capability`, template requirements | Match declared operators with installed compatible implementations |
| **C11 Enterprise retrieval** | Domain/object metadata, examples, typed edges and search projection configuration | Build hybrid retrieval, reranking and dependency expansion |
| **C12 Coherent publication** | Projection records, `release_manifest`, `active_manifest` | Verify/build a compatible bundle and pin it per request |
| **C13 Durable execution** | Release and capability references consumed by workflow state | Durable LangGraph checkpoints, execution ledger, limits and recovery |
| **C14 Measured rollout** | Domain coverage, enabled capabilities and evaluation evidence | Enforce release gates and measure production behavior |

## 15. What the SQL file still leaves to implementation

The bootstrap DDL supplies a storage foundation. The following are actual boundaries or gaps visible in the file, not merely optional improvements.

### 15.1 Definitions require formal payload contracts

Every JSON family needs a versioned schema covering required properties, allowed values, field types, nested references and migration rules. The document examples illustrate those payloads but do not form a complete machine-readable schema package.

Important payload families include entity identity/versioning, field operations, normalization and resolution policy, relationship cardinality and identity, operation contracts, predicate expressions, metric definitions, template plans, capability requirements, evidence and release configuration.

Long-lived semantics must not depend on each engineer independently deciding what arbitrary JSON keys mean.

### 15.2 Database constraints and application checks have different coverage

| Condition | Current DDL coverage | Additional required check |
|---|---|---|
| A field references an entity in the same release | Composite foreign key | Physical source binding, ownership/type semantics and publication eligibility |
| Specialized record matches its common object kind | Parent existence only | Kind matches and exactly one appropriate specialization |
| A JSON payload is structurally valid for its purpose | JSON syntax only | Versioned payload schema and cross-reference validation |
| A value binding matches the field's vocabulary and type | Value/field existence and literal-type enum | Domain compatibility, literal decoding/type compatibility, interval and coverage checks |
| A relationship's key fields belong to its endpoints | Endpoints have foreign keys; JSON field refs do not | Resolve every field and validate identity/correlation semantics |
| A left enrichment has one applicable target per base | Contract/evidence can be stored | Verify required uniqueness and enforce the operation in generated SQL |
| A release is genuinely reviewed and immutable | Status values and a published-hash requirement | Review workflow, permissions, audit and immutability controls |
| A ready projection matches its claimed contents | Non-null hash required | Compute/verify hash and validate complete contents |
| A manifest references the right projection kinds | Same-release foreign keys | Kind, readiness, configuration and code compatibility |
| A capability is executable | Versioned declaration and domain enablement | Installed implementation and passed relevant evaluations |
| A user is entitled to the requested data now | Policy references | Live identity/policy checks and source-side controls |

### 15.3 Several production stores are intentionally outside this file

| Required system responsibility | Status relative to this DDL |
|---|---|
| Workflow checkpoints | Separate persistent SQLite store for the admitted initial workflow workload; chosen LangGraph integration manages it, with independent scaling/recovery gates |
| Execution ledger, workload queue and cancellation | Separate operational persistence/services to implement |
| Live proposals, compiled artifacts, result handles and answer audit records | Separate request/execution storage to implement |
| Identity provider, authorization rules and live revocation | External policy/identity integration referenced by catalog IDs |
| Search documents and vectors | Built in the search service from approved definitions |
| Graph representation | Built in the planner or loaded from a graph artifact |
| Discovery staging, authoring revisions and detailed approval audit | Shared-authority workflow schema still to implement |
| High-cardinality value providers and their revisions | Provider contracts/configuration still to implement |
| Evaluation fixtures, run results and performance telemetry | Evaluation and observability systems; catalog stores references/evidence |

The default SQLite bootstrap now includes `edit_revision` and a transactional outbox. It does not provide the authoring/audit application itself. CatalogService must implement revision comparison and atomic edits, reviewer permissions and audit history. The optional PostgreSQL adapter carries the same fields; an Azure SQL adapter must preserve their behavior through its own transaction and migration implementation.

### 15.4 Specific modeling choices must be resolved before implementation

- **Lifecycle vocabulary:** discovery uses states such as discovered/proposed, while `catalog_object.status` currently permits draft/reviewed/published/deprecated. Use a separate staging lifecycle or a reviewed schema migration; do not insert unsupported statuses.
- **Policy duplication and inheritance:** define how common-object, entity, source and derived-dependency policies combine. Resolve the duplicate entity policy fields explicitly.
- **Example security:** add or formally inherit classification/access rules for examples; the table does not currently carry them directly.
- **Owner/reviewer detail:** one `owner` string and one domain `steward` field are insufficient for every organizational workflow. Define technical/business ownership and approval evidence in a typed model or normalized extension.
- **Dynamic dictionary providers:** design provider identity, authorization, freshness and revision binding for values outside the catalog.
- **Activation scope:** the existing singleton supports one active manifest pointer per authority instance. Broader rollout channels need a deliberate extension.
- **Reference consistency:** materialized `semantic_edge` dependencies must agree with references inside metric/predicate/template JSON. Prefer deriving dependency edges from validated definitions where possible; review descriptive associations separately.

These details should become concrete types, publisher rules, service contracts and schema migrations. They can be added while retaining the central separation of semantic IDs, physical bindings, governed definitions and deterministic execution.

## 16. Mapping the original workbook into this schema

The original workbook categories remain recognizable, but several normalized tables represent what was previously one spreadsheet row.

| Workbook input | Destination | Additional information needed |
|---|---|---|
| `meta_tables.TABLE_NAME` | `entity.physical_object`, with schema/source references | Stable entity ID, source configuration, binding kind |
| `meta_tables.BUSINESS_DESCRIPTION` | Entity's `catalog_object.description` | Ownership, status, provenance, row identity/versioning |
| `meta_columns.TABLE_NAME` / `COLUMN_NAME` | `field.entity_id` / `physical_column` after resolving the entity | Stable field ID and release |
| `meta_columns.DATA_TYPE` | `field.physical_type` | Semantic type, exact source metadata verification |
| `meta_columns.BUSINESS_COLUMN_NAME` / `BUSINESS_DESCRIPTION` | Field's `catalog_object.label` / `description` | Aliases, null meaning, roles and operators |
| `meta_columns.ENUM_MAPPING` | `field.domain_id` referring to `value_domain` | Mapping ID normalization and reviewed domain meaning |
| `meta_enum_mappings.ENUM_MAPPING` | `value_domain.domain_id` | Normalization and resolution policy |
| `meta_enum_mappings.CANONICAL_NAME` / `BUSINESS_DESCRIPTION` | Canonical value's `catalog_object.label` / `description` | Stable `canonical_value.value_id` and its domain |
| `meta_enum_mappings.ALIASES` | One or more `value_alias` rows | Locale and domain-specific normalization |
| `meta_enum_mappings.LITERAL_VALUE` | One or more `value_binding` rows | Exact target field, literal type and validity interval |
| `meta_joins.JOIN_NAME` / endpoint table names | Relationship common object plus resolved endpoint entity IDs | Direction, roles, namespace and evidence |
| `meta_joins.ON` | Reviewed typed `key_pairs_json` plus other required conditions | Structured parsing/review; raw ON text is not a trusted executable definition |
| `meta_joins.CARDINALITY` | `relationship.cardinality_json` | Directional multiplicity, scope and supporting evidence |
| `meta_joins.TYPE` | An appropriate `relationship_operation.operator` and `contract_json` | Purpose, preservation, target-filter placement and output grain |
| `meta_examples` name/description/SQL | Example identity/question/reference SQL where semantically appropriate | Explicit question wording, expected semantic plan, fixture, outcome and reviewer |

The source workbook contains headers only, so this mapping describes the importer to build. There are no populated workbook business rules to import yet. In particular, a human must establish how each canonical value applies to each source field; an enum-mapping name alone does not settle all source-specific encodings.

## 17. Practical reading and implementation order

To understand one field end to end, follow this order:

1. Read its `catalog_object` record for meaning, owner, status and policy.
2. Read its `field` record for physical binding, type, aliases and allowed use.
3. Follow `entity_id` to the dataset's source and row/identity rules.
4. If it has a value domain, read canonical values, aliases and field-specific bindings.
5. Find predicates and metrics referencing it; load their full dependencies.
6. Find permitted relationship operations needed by the question and their evidence.
7. Check capabilities and the selected release before compiling.

For implementation, build typed catalog models and validators first, then the SQLite authoring/import/publication path and file-to-memory reader, then resolver/planner/compiler services consuming published definitions. Retrieval and graph builders project those same definitions into their own access structures. Keep `CatalogAuthoringStore`, `ReleaseStore`, `CatalogExporter` and `CatalogReader` separate so later PostgreSQL/Azure SQL authority adapters preserve the semantic model and worker read format. Query workflow and execution persistence have their own interfaces and migration needs.

The three schema levels should remain visible in code reviews:

| Level | Review question |
|---|---|
| Storage schema | Can we persist and connect the required definition correctly? |
| Typed semantic model | Is the definition complete, valid and meaningful within its release? |
| Runtime behavior | Does the application apply that definition correctly to this authorized request? |

This is how a requirement such as “count the correct business records using only approved relationships” becomes a complete implementation: the catalog represents the meaning, the publisher establishes its validity, and the runtime applies it to the selected question and data.
