"""Test the SDK import guard in a process where optional dependencies are hidden."""

from subprocess import run
from sys import executable

from pytest import mark


@mark.parametrize(
    "module",
    [
        "langfuse",
        "langfuse.client",
        "langfuse.scores",
        "langfuse.prompts",
        "langfuse.datasets",
        "langfuse.experiments",
        "langfuse.batch",
    ],
)
@mark.parametrize("failure", ["missing", "transitive"])
def test_sdk_import_guard(module: str, failure: str) -> None:
    """Core imports remain lazy and only missing SDK modules get install hints."""
    result = run(
        [
            executable,
            "-c",
            f"""
from importlib import import_module
from importlib.abc import MetaPathFinder
from sys import meta_path, modules

class BlockSDK(MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] == 'langfuse':
            missing = fullname if {failure!r} == 'missing' else 'broken_transitive'
            raise ModuleNotFoundError('dependency unavailable', name=missing)

meta_path.insert(0, BlockSDK())
from observability_ai import LangfuseSettings, Telemetry
from observability_ai.adapters import model_runtime_observer, retrieval_observer
from observability_ai.genai import langfuse_usage_details
assert 'langfuse' not in modules
try:
    import_module('observability_ai.' + {module!r})
except ImportError as exc:
    if {failure!r} == 'missing':
        assert 'observe-eval-ai[langfuse]' in str(exc), str(exc)
        assert isinstance(exc.__cause__, ModuleNotFoundError)
        assert exc.__cause__.name == 'langfuse'
    else:
        assert isinstance(exc, ModuleNotFoundError)
        assert exc.name == 'broken_transitive'
else:
    raise AssertionError('SDK import unexpectedly succeeded')
usage = langfuse_usage_details(input_tokens=7, output_tokens=3, cached_tokens=2)
assert usage['input'] == 5
""",
        ],
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stdout + result.stderr
