"""Durable execution journal. Ownership intents are saved before external mutations."""

import json
import os
import sqlite3
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from threading import RLock

from synapse_mcp_server.locking import file_lock


def now():
    return datetime.now(UTC).isoformat()


class ExecutionStore:
    def __init__(self, path):
        self.path = Path(path).expanduser().resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        descriptor = os.open(self.path, os.O_CREAT | os.O_RDWR, 0o600)
        os.close(descriptor)
        os.chmod(self.path, 0o600)
        self.db = sqlite3.connect(self.path, timeout=30, check_same_thread=False)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS executions "
            "(id TEXT PRIMARY KEY, workspace TEXT NOT NULL, document TEXT NOT NULL)"
        )
        self.db.commit()
        self.mutex = RLock()

    def save(self, record):
        record["updated_at"] = now()
        with self.mutex, self.db:
            self.db.execute(
                "INSERT INTO executions VALUES (?, ?, ?) "
                "ON CONFLICT(id) DO UPDATE SET document=excluded.document",
                (record["execution_id"], record["workspace"], json.dumps(record)),
            )

    def create(self, record):
        record["updated_at"] = now()
        with self.mutex, self.db:
            self.db.execute(
                "INSERT INTO executions VALUES (?, ?, ?)",
                (record["execution_id"], record["workspace"], json.dumps(record)),
            )

    def get(self, workspace, execution_id):
        with self.mutex:
            row = self.db.execute(
                "SELECT document FROM executions WHERE id=? AND workspace=?",
                (execution_id, workspace),
            ).fetchone()
        if row is None:
            raise ValueError("Unknown branch execution for this workspace")
        return json.loads(row[0])

    def list(self, workspace=None):
        with self.mutex:
            rows = self.db.execute(
                "SELECT document FROM executions" + (" WHERE workspace=?" if workspace else ""),
                (workspace,) if workspace else (),
            ).fetchall()
        return [json.loads(row[0]) for row in rows]

    @contextmanager
    def lock(self, execution_id):
        if len(execution_id) != 32 or any(c not in "0123456789abcdef" for c in execution_id):
            raise ValueError("Invalid branch execution ID")
        directory = self.path.parent / (self.path.name + ".locks")
        directory.mkdir(exist_ok=True, mode=0o700)
        with file_lock(directory / execution_id):
            yield

    def close(self):
        with self.mutex:
            self.db.close()
