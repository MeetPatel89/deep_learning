"""ADLS Gen2 ACL, properties, deleted paths and scoped SAS tools."""

from datetime import UTC, datetime, timedelta
from typing import Any

from data_mcp_core.auth import get_credential
from data_mcp_core.guards import planned_action, require
from data_mcp_core.results import bounded_result, paginate


def service_client(resolved):
    from azure.storage.filedatalake import DataLakeServiceClient

    profile = resolved.auth
    if profile.mode == "account_key":
        credential = profile.account_key.get_secret_value()
    elif profile.mode == "sas":
        credential = profile.sas_token.get_secret_value()
    else:
        credential = get_credential(profile)
    options = resolved.store.options.get("adls", {})
    return DataLakeServiceClient(
        account_url=options.get(
            "account_url", f"https://{resolved.store.account_name}.dfs.core.windows.net"
        ),
        credential=credential,
    )


def object_name(resolved):
    return resolved.fs_path[len(resolved.store.container) :].lstrip("/")


def path_client(resolved, *, directory=False):
    # Path clients share their parent's transport. The caller closes the path client.
    filesystem = service_client(resolved).get_file_system_client(resolved.store.container)
    return (filesystem.get_directory_client if directory else filesystem.get_file_client)(
        object_name(resolved)
    )


class ADLSTools:
    def _adls(self, store, path=""):
        resolved = self.resolve(store, path)
        if resolved.store.protocol != "abfss":
            raise ValueError("This tool requires an abfss store")
        return resolved

    def get_acl(self, store: str, path: str) -> dict[str, Any]:
        """Read an ADLS file or directory access control list."""
        resolved = self._adls(store, path)
        with path_client(resolved) as client:
            return bounded_result(client.get_access_control())

    def set_acl(
        self, store: str, path: str, acl: str, recursive: bool = False, dry_run: bool = False
    ) -> dict[str, Any]:
        """Set ADLS ACLs, optionally recursively (requires allow_manage)."""
        resolved = self._adls(store, path)
        require(resolved.store, "allow_manage")
        plan = planned_action(
            "set_acl", dry_run, store=store, path=path, acl=acl, recursive=recursive
        )
        if plan:
            return plan
        with path_client(resolved, directory=recursive) as client:
            result = (
                client.set_access_control_recursive(acl=acl)
                if recursive
                else client.set_access_control(acl=acl)
            )
            return bounded_result(result)

    def get_properties(self, store: str, path: str) -> dict[str, Any]:
        """Read ADLS metadata and path properties."""
        resolved = self._adls(store, path)
        with path_client(resolved) as client:
            return bounded_result(dict(client.get_file_properties()))

    def set_metadata(
        self, store: str, path: str, metadata: dict[str, str], dry_run: bool = False
    ) -> dict[str, Any]:
        """Replace ADLS metadata (requires allow_write)."""
        resolved = self._adls(store, path)
        require(resolved.store, "allow_write")
        plan = planned_action("set_metadata", dry_run, store=store, path=path, metadata=metadata)
        if plan:
            return plan
        with path_client(resolved) as client:
            return bounded_result(client.set_metadata(metadata))

    def list_deleted_paths(
        self, store: str, path: str = "", limit: int = 100, continuation: str | None = None
    ) -> dict[str, Any]:
        """List soft-deleted paths under the configured root (requires allow_manage)."""
        resolved = self._adls(store, path)
        require(resolved.store, "allow_manage")
        with service_client(resolved) as service:
            filesystem = service.get_file_system_client(resolved.store.container)
            root = object_name(resolved).rstrip("/")
            entries = []
            for item in filesystem.list_deleted_paths():
                name = item.name
                if root and name != root and not name.startswith(root + "/"):
                    continue
                entries.append(
                    {
                        **dict(item),
                        "name": resolved.relative_name(f"{resolved.store.container}/{name}"),
                    }
                )
        return paginate(entries, limit, continuation, f"deleted:{store}:{path}")

    def undelete_path(
        self, store: str, path: str, deletion_id: str, dry_run: bool = False
    ) -> dict[str, Any]:
        """Restore an ADLS soft-deleted path (requires allow_write)."""
        resolved = self._adls(store, path)
        require(resolved.store, "allow_write")
        plan = planned_action(
            "undelete_path", dry_run, store=store, path=path, deletion_id=deletion_id
        )
        if plan:
            return plan
        with service_client(resolved) as service:
            filesystem = service.get_file_system_client(resolved.store.container)
            # The current Azure SDK exposes the HNS restore operation under this name.
            filesystem._undelete_path(object_name(resolved), deletion_id)
        return {"restored": True, "path": path}

    def generate_sas(
        self, store: str, path: str, permissions: str = "r", expiry_minutes: int = 15
    ) -> dict[str, Any]:
        """Generate an explicitly authorized file SAS; this tool intentionally returns a secret."""
        resolved = self._adls(store, path)
        require(resolved.store, "allow_sas")
        if (
            not 1 <= expiry_minutes <= 60
            or not permissions
            or any(letter not in "racwd" for letter in permissions)
        ):
            raise ValueError("SAS expiry must be 1–60 minutes and permissions must use r,a,c,w,d")
        if set(permissions) & set("acw"):
            require(resolved.store, "allow_write")
        if "d" in permissions:
            require(resolved.store, "allow_delete")
        from azure.storage.filedatalake import FileSasPermissions, generate_file_sas

        now = datetime.now(UTC)
        expiry = now + timedelta(minutes=expiry_minutes)
        if resolved.auth.mode == "account_key":
            credential = resolved.auth.account_key.get_secret_value()
        elif resolved.auth.mode == "sas":
            raise ValueError("A SAS credential cannot sign another SAS")
        else:
            with service_client(resolved) as service:
                credential = service.get_user_delegation_key(now - timedelta(minutes=5), expiry)
        token = generate_file_sas(
            account_name=resolved.store.account_name,
            file_system_name=resolved.store.container,
            directory_name=object_name(resolved).rpartition("/")[0],
            file_name=object_name(resolved).rpartition("/")[2],
            credential=credential,
            permission=FileSasPermissions.from_string(permissions),
            expiry=expiry,
            start=now - timedelta(minutes=5),
            protocol="https",
        )
        return {"sas": token, "expires_at": expiry.isoformat()}
