---
doc_id: TASK-INC-1104
title: Incident Tasks for INC-1104 Employee Portal Login Failures
doc_type: incident_task
service_id: svc_identity_gateway
owner_group: IAM Platform
visibility: internal
status: closed
created_at: "2026-06-12T23:20:00"
updated_at: "2026-06-13T02:15:00"
related_records:
  - INC-1104
  - KI-104
  - RUNBOOK-SSO-003
source_facts:
  - KI-104
  - svc_identity_gateway
difficulty_tags:
  - action-sequencing
  - task-decomposition
servicenow:
  table: incident_task
  parent: INC001104
  task_numbers:
    - INCT0001001
    - INCT0001002
    - INCT0001003
  visibility: internal
  contains_customer_safe_wording: false
---

# Incident Tasks for INC-1104 Employee Portal Login Failures

## Record details

| Field | Value |
| --- | --- |
| Table | incident_task |
| Parent | INC001104 |
| Task numbers | INCT0001001, INCT0001002, INCT0001003 |
| Visibility | internal |
| Contains customer-safe wording | false |

## Overview

Three incident tasks were opened under INC001104 to structure the recovery work. The task sequence follows RUNBOOK-SSO-003: confirm scope and change correlation first, then apply the KI-104 workaround, then verify and coordinate user retest.

## INCT0001001 — Confirm impact scope and change correlation

| Field | Value |
| --- | --- |
| Number | INCT0001001 |
| Short description | Confirm impact scope and change correlation |
| Assignment group | Service Desk L1 |
| State | Closed Complete |
| Opened at | 2026-06-12T23:20:00 |
| Closed at | 2026-06-13T00:05:00 |

Service Desk L1 confirmed the impact pattern: multiple users reporting invalid SAML response errors while other users could sign in normally. The task included capturing exact error text, confirming the affected application was Employee Portal, and checking the change calendar for identity-related activity in the last 24 hours.

The change-calendar check found CHG-2407, which completed at 2026-06-12T23:00:00, about 18 minutes before the first incident report. The symptoms were matched to KI-104. The task closed when the incident was escalated to IAM Platform per POL-ESC-001 at 2026-06-13T00:05:00.

## INCT0001002 — Refresh Identity Gateway metadata cache

| Field | Value |
| --- | --- |
| Number | INCT0001002 |
| Short description | Refresh Identity Gateway metadata cache |
| Assignment group | IAM Platform |
| State | Closed Complete |
| Opened at | 2026-06-13T00:10:00 |
| Closed at | 2026-06-13T00:45:00 |

IAM Platform applied the approved KI-104 workaround by refreshing the Identity Gateway metadata cache across gateway nodes. The working diagnosis was that some nodes were still using stale IdP metadata cached before the CHG-2407 certificate rotation.

The cache refresh completed at 2026-06-13T00:40:00 and the task closed after IAM Platform confirmed nodes were pulling current identity provider metadata. Error monitoring showed invalid SAML response reports declining after the refresh.

## INCT0001003 — Verify active certificate thumbprint and coordinate user retest

| Field | Value |
| --- | --- |
| Number | INCT0001003 |
| Short description | Verify active certificate thumbprint and coordinate user retest |
| Assignment group | IAM Platform |
| State | Closed Complete |
| Opened at | 2026-06-13T00:45:00 |
| Closed at | 2026-06-13T02:15:00 |

IAM Platform verified the active IdP certificate thumbprint at 2026-06-13T01:05:00 and confirmed it matched the certificate rotated in CHG-2407. Service Desk L1 then coordinated a retest with previously affected users.

By 2026-06-13T02:10:00 most affected users confirmed successful Employee Portal sign-in. The task closed with remaining reports transferred into user-specific retry and session cleanup handling. INC-1104 was resolved at 2026-06-13T03:45:00.

## Related records

- INC-1104: Employee Portal Login Failures After Okta Certificate Rotation.
- KI-104: SSO Metadata Cache Delay After Certificate Rotation.
- RUNBOOK-SSO-003: Identity Gateway SSO Login Failure Runbook.
