---
doc_id: PRB-411
title: API Rate-Limit Policy Entitlement Mismatch
doc_type: problem_record
service_id: svc_internal_api_gateway
owner_group: Platform Engineering
visibility: internal
status: known_error
created_at: "2026-06-19T09:00:00"
updated_at: "2026-06-20T11:00:00"
related_records:
  - KI-307
  - INC-1302
  - RUNBOOK-API-005
source_facts:
  - KI-307
  - svc_internal_api_gateway
difficulty_tags:
  - root-cause
  - entitlement-check
  - internal-only-detail
---

# API Rate-Limit Policy Entitlement Mismatch

## Problem summary

PRB-411 tracks the known error where Internal API Gateway applies rate-limit behavior that does not match customer entitlement after a rate-limit policy deployment. The problem is owned by Platform Engineering.

Root cause is stricter burst limits applied to some client groups after rate-limit policy deployment. Business-tier clients are more likely to hit the mismatch.

## Related incidents

Primary related incident:

- INC-1302: Business-Tier API Clients Receive 429 Errors After Rate-Limit Policy Deployment.

Related known issue:

- KI-307: API Clients Receive Unexpected 429 Responses After Rate-Limit Policy Update.

INC-1302 began after CHG-2420 and was resolved when Platform Engineering adjusted the applied rate-limit policy.

## Root cause analysis

The rate-limit policy deployment changed burst handling for Internal API Gateway clients. For some client groups, the applied policy was stricter than the entitlement expected for that customer tier. The issue appeared most often for Business-tier clients and less often for Enterprise clients.

The gateway was still routing traffic and enforcing limits. The known error is not a general gateway outage. It is an entitlement-to-policy mismatch that can cause valid client traffic bursts to receive HTTP 429 Too Many Requests.

Corrective action is to compare customer entitlement with applied gateway policy.

## Known error

Known error indicators:

- Client reports 429 Too Many Requests shortly after rate-limit policy deployment.
- Client is Business-tier.
- Splunk shows increased 429 volume for the client or client group.
- Applied gateway policy is stricter than customer entitlement.
- Enterprise-tier clients are less affected or unaffected during the same window.

## Workaround

Use RUNBOOK-API-005. The operational workaround is:

1. Confirm the client ID and customer tier.
2. Check recent API Gateway policy changes.
3. Inspect 429 volume in Splunk.
4. Compare applied rate-limit policy against customer entitlement.
5. Escalate to Platform Engineering if applied policy does not match entitlement.
6. Adjust the applied policy after Platform Engineering confirms the mismatch.

## Permanent fix status

Status is known error. Platform Engineering owns permanent remediation for policy deployment validation and entitlement alignment.

Until a permanent fix is recorded, support should use KI-307 and RUNBOOK-API-005 for matching reports after rate-limit policy changes.

## Communication guidance

Customer-facing communication should not state that an internal policy mistake occurred. Use the KI-307 customer-safe summary:

"We are reviewing the applied API traffic policy for the affected client."

Internal work notes may mention entitlement mismatch, applied gateway policy, and stricter burst limits. Customer-facing updates should stay focused on review and remediation of the affected client's API traffic policy.

## Related records

- KI-307: API Clients Receive Unexpected 429 Responses After Rate-Limit Policy Update.
- INC-1302: Business-Tier API Clients Receive 429 Errors After Rate-Limit Policy Deployment.
- RUNBOOK-API-005: API Gateway 429 Investigation Runbook.

