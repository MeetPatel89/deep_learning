# observe-eval-ai

`observe-eval-ai` exports application-owned OpenTelemetry traces and evaluations to Langfuse,
with optional SDK support for scores, managed prompts, datasets, and experiments.

The core provides task-local trace propagation, observation and generation
handles, sync/async stream tracing, and opt-in payload capture with redaction.
Its evaluation package adds deterministic checks, retrieval metrics, validated
score results, and sampled live evaluation with application-provided sinks.
The optional Langfuse integration adds score sinks, datasets, experiments with
regression gates, and batch evaluation of historical traces and observations.
The core includes validated settings, immutable trace attributes, OTLP/HTTP export,
parent-based sampling, and protection against processor and shutdown failures
without requiring the SDK. Optional integrations connect `model-runtime`
(including model judging), `vectorstore-ai`, and Langfuse scoring and managed
prompts. This repository also owns the local
Langfuse Docker stack.

## Consumers: fieldguide-ai

[Fieldguide AI](../fieldguide-ai/README.md) uses the v0.6.0 tracing adapters and
Langfuse integration for direct/contextual/agentic RAG, golden dataset sync,
scored experiments, and regression gates. Its
[observability playbook](../fieldguide-ai/docs/OBSERVABILITY.md) covers this
repository's backend, application setup, baseline matrices, trace inspection,
and one-variable iteration. These relative links assume sibling checkouts.
Langfuse's Postgres uses host port 5432; Fieldguide's example configuration uses
5433 for its separate catalog. Live verification and measured baseline evidence
are tracked in Fieldguide's [evaluation record](../fieldguide-ai/artefacts/eval/README.md).

## Quickstart

Python 3.14 and [`uv`](https://docs.astral.sh/uv/) are required. Run commands from
this repository root:

```bash
uv sync
```

Follow the [backend guide](observability/README.md) to start local Langfuse with
Docker Compose and put project API keys in the ignored `observability/.env`.
Then run the example:

```bash
uv run examples/raw_otel_example.py
```

It creates `parent` with concurrent `child-0` and `child-1` tool observations, each
containing a raw OTel `raw-step-*` span. It prints the trace ID to locate in
Langfuse. It loads `observability/.env`, with exported variables taking precedence,
and makes no model-provider calls.

The same facade works in an application with Langfuse variables in its process
environment:

```python
from observability_ai import LangfuseSettings, Telemetry, TraceAttributes

trace = TraceAttributes(
    session_id="session-123",
    user_id="user-456",
    tags=("example", "raw-otel"),
    metadata={"tenant": "docs"},
)

with Telemetry(
    LangfuseSettings.from_env(),
    service_name="my-app",
    service_version="1.0.0",
) as telemetry:
    with telemetry.observe("parent", attributes=trace):
        with telemetry.observe("child", type="tool", attributes=trace) as span:
            span.set_attribute("app.result.count", 3)
```

The distribution is `observe-eval-ai`; the import package remains
`observability_ai` for source compatibility with existing applications.
Importing it does not construct a provider, load credentials, or send spans.
`python-dotenv` is a development dependency for the example and backend smoke
test; library users choose how to populate their environment.

## Settings

`LangfuseSettings` is a frozen dataclass. Construct it directly or read the current
process environment with `LangfuseSettings.from_env()`:

| Field | Environment variable | Default |
| --- | --- | --- |
| `public_key` | `LANGFUSE_PUBLIC_KEY` | Required |
| `secret_key` | `LANGFUSE_SECRET_KEY` | Required; excluded from `repr` |
| `base_url` | `LANGFUSE_BASE_URL` | `http://localhost:3000` |
| `environment` | `LANGFUSE_TRACING_ENVIRONMENT` | `None` (omitted) |
| `release` | `LANGFUSE_RELEASE` | `None` (omitted) |
| `sample_ratio` | `LANGFUSE_SAMPLE_RATE` | `1.0` |

Credentials must be nonempty strings without whitespace; the public key cannot
contain a colon. The base URL must be an absolute HTTP(S) URL without embedded
credentials, whitespace, query parameters, or fragments. Reverse-proxy path
prefixes are supported, and trailing slashes are removed.

When supplied, `environment` has 1–40 lowercase letters, digits, hyphens, or
underscores and cannot start with `langfuse`, following Langfuse's
[environment constraints](https://langfuse.com/docs/observability/features/environments).
`release` must be nonblank. `sample_ratio` must be a finite number from `0.0` to
`1.0`, inclusive. Invalid settings raise `TypeError` or `ValueError` before export
is configured. `from_env()` never loads a dotenv file automatically.

The provider uses `ParentBased(TraceIdRatioBased(sample_ratio))`: the ratio applies
to new root spans, and children honor their local or remote parent's sampling
decision. These explicit settings take precedence over `OTEL_TRACES_SAMPLER`
and `OTEL_TRACES_SAMPLER_ARG`; use `LANGFUSE_SAMPLE_RATE` with this package.

## Observations and raw OpenTelemetry

`Telemetry.observe(name, *, type="span", attributes=None, input=None, output=None)`
yields an `Observation` handle. Its `.span` exposes the ordinary OTel `Span`.
Supported `ObservationType` values are `span`, `generation`, `agent`,
`tool`, `chain`, `retriever`, `embedding`, `evaluator`, `guardrail`, and `event`.
Each observation gets `langfuse.observation.type`. Application exceptions are
recorded on the span and re-raised.

Use a regular `with telemetry.observe(...)` inside either synchronous or async
functions. Active span context follows nested calls and `asyncio.TaskGroup`
children. Finish those tasks before leaving their parent observation and before
shutting down telemetry.

Use `telemetry.propagate(TraceAttributes(...))` to apply trace dimensions to
facade observations created in the scope, including decorated calls and child
asyncio tasks. Nested propagation scopes merge dimensions and restore the prior
values on exit, including after exceptions. Per-observation `attributes` override
propagated values for that observation only: nonempty tags replace inherited
tags, metadata merges by key, and supplied IDs replace inherited IDs. `None`
and empty collections mean unspecified; they do not clear inherited values.
Propagation is task-local and shared by facade instances in that context.

```python
from observability_ai import current_observation_id, current_trace_id

with telemetry.propagate(trace):
    with telemetry.agent("request") as observation:
        trace_id = current_trace_id()
        observation_id = current_observation_id()
        with telemetry.tool("search", call_id="call-123"):
            pass
```

Both ID functions return lowercase hex strings (32 and 16 digits respectively),
or `None` when there is no active recording span. They also work with raw OTel
spans. Handle properties `.trace_id` and `.observation_id` remain available after
completion and for valid unsampled spans; invalid contexts return `None`.

Raw tracers and third-party adapters share OTel parent context but do not consume
the facade's propagated dimensions. Pass explicit attributes to those integrations.
Langfuse filters observations using
[attributes on each span](https://langfuse.com/integrations/native/opentelemetry#propagating-trace-attributes-to-all-spans).

`TraceAttributes` copies tags to a tuple and metadata to an immutable mapping.
Session IDs, user IDs, tags, metadata keys, and metadata values must be nonempty
strings of at most 200 characters. IDs and metadata keys must be US-ASCII; tag
and metadata values may contain Unicode. Metadata values are strings. Unset IDs
and empty collections are omitted. `as_otel_attributes()` returns a fresh mutable
dictionary for raw instrumentation:

```python
tracer = telemetry.tracer("my_app.worker")
with tracer.start_as_current_span(
    "raw child", attributes=trace.as_otel_attributes()
) as span:
    span.set_attribute("langfuse.observation.type", "tool")
```

Run this inside the application's `Telemetry` lifetime. Raw spans and facade
observations share the standard OTel context, so either can parent the other.
Settings for environment and release are attached to the provider's Resource as
`langfuse.environment` and `langfuse.release`, alongside `service.name` and
`service.version`, and accompany every exported span.

Handles expose `set_attribute`, `set_attributes`, `add_event`, and
`record_exception`. Use `set_input` and `set_output` for payloads governed by the
capture policy. `set_metadata(mapping)` maps flat OTel attribute values to
`langfuse.observation.metadata.*`; `set_level(level, status_message=None)` accepts
`DEBUG`, `DEFAULT`, `WARNING`, or `ERROR`. Level is independent of OTel span status.
The handle is frozen, while these methods update its underlying span.

Breaking change in `0.6.0`: `observe` and typed context helpers now return
handles. Replace raw calls such as `handle.get_span_context()` or
`handle.is_recording()` with `handle.span.get_span_context()` or
`handle.span.is_recording()`. OTel's `get_current_span()` returns `handle.span`.
Existing raw `telemetry.tracer(...)` APIs are unchanged. `traced` now accepts
generator functions: their observation starts on iteration, not on function call,
and must be closed when iteration stops early. See [the changelog](CHANGELOG.md)
for the complete `0.6.0` changes.

For direct provider ownership, use
`build_tracer_provider(settings, *, service_name, service_version, span_processor=None)`
and call its `shutdown()` when finished. `langfuse_span_exporter(settings)` builds
the underlying exporter at `{base_url}/api/public/otel/v1/traces` using Basic auth
and `x-langfuse-ingestion-version: 4`, as described in the
[Langfuse OTel setup](https://langfuse.com/integrations/native/opentelemetry).

## Agent and tool instrumentation

`telemetry.agent(name, ...)`, `telemetry.tool(name, ...)`, `telemetry.chain(name, ...)`,
`telemetry.retriever(name, ...)`, `telemetry.embedding(name, ...)`,
`telemetry.guardrail(name, ...)`, and `telemetry.evaluator(name, ...)`
are convenience context managers selecting the
corresponding observation type. Each accepts `attributes`, `input`, and `output`
with the same behavior as `observe`:

```python
with telemetry.agent("answer question", attributes=trace):
    with telemetry.chain("research", attributes=trace):
        with telemetry.tool("search", attributes=trace) as span:
            span.set_attribute("app.result.count", 3)
```

`tool` additionally accepts `call_id` and `description`, setting `gen_ai.tool.name`,
`gen_ai.tool.call.id`, and `gen_ai.tool.description` as supplied.
`telemetry.event(name, ...)` immediately records an event observation with equal
start/end timestamps, preserves the current parent, and returns its ended handle.
This differs from `handle.add_event`, which adds an OTel event inside a span.

For functions and methods, use `@telemetry.traced(name=None, *, type="span")`.
Define and call the decorated functions during the application's telemetry
lifetime:

```python
from asyncio import sleep


@telemetry.traced(type="tool")
def normalize(question: str) -> str:
    return question.strip()


@telemetry.traced("answer question", type="agent")
async def answer(question: str) -> str:
    question = normalize(question)
    await sleep(0)
    return question


# Inside your async entry point:
# result = await answer(" What is a vector space? ")
```

Each invocation creates a fresh observation. The default name is the function's
qualified name, or its class's qualified name for a callable instance. Sync
functions remain sync; async functions and async callable instances keep the
observation current through their awaits. Signatures, function metadata, return
values, application exceptions, and cancellation are preserved. Concurrent
tasks inherit their own parent context.

Decorators capture no arguments or return values automatically, including when
content capture is enabled. They inherit dimensions from `telemetry.propagate`.
Generator and async-generator functions, methods, and callable instances are
supported: the span starts when iteration begins and ends on exhaustion, error,
or explicit close. Arguments still follow the original callable signature.

## Generations and streaming

`telemetry.generation(name, *, model, provider_name, operation_name="chat", ...)`
accepts the same trace attributes and input/output options as `observe` and yields
a `Generation`, which extends `Observation`:

```python
with telemetry.generation(
    "answer", model="requested-model", provider_name="my-provider"
) as generation:
    generation.set_model("requested-model", response_model="returned-model")
    generation.set_model_parameters({"temperature": 0.2})
    generation.link_prompt("answer-question", version=1)
    generation.mark_completion_start()
    generation.set_usage(input_tokens=7, output_tokens=3, cached_tokens=2)
    generation.set_cost(input_cost=0.001, output_cost=0.002, total_cost=0.003)
    generation.set_output("computed answer")
```

Model parameters are snapshotted as JSON. Usage keeps cache reads within the
inclusive input total; each `set_usage` replaces all counts, including zero cache
reads. Costs are explicit nonnegative finite USD values; omitted
costs remain unknown. Prompt linking sets name/version attributes without fetching
the prompt or importing the SDK. Completion start is an ISO 8601 UTC timestamp.

`telemetry.stream(name, source, *, type="generation", attributes=None, input=None,
output=None)` wraps a sync iterable or async iterable, preserving yielded objects.
It creates one observation lazily on first iteration using the then-current parent
and propagated dimensions. The span stays open until exhaustion or close. Producer
execution runs in that span's context; between chunks, the consumer's OTel context
and propagated trace dimensions are restored. `traced` uses this same wrapper for
generator callables.

```python
from contextlib import closing

with closing(telemetry.stream("answer stream", iter(["Hello", " world"]))) as chunks:
    for chunk in chunks:
        print(chunk, end="")
```

For async sources use `async for`, with `contextlib.aclosing` when iteration may
stop early. Merely breaking a loop does not close its iterator; use `closing` /
`aclosing` or explicitly call `close()` / `aclose()` to end partial streams and run
producer cleanup. Generator `send`, `throw`, and return values, and async-generator
`asend` and `athrow`, are forwarded. Errors and cancellation end the span and
propagate. Ordinary early close does not mark an error.

The first yielded item sets `langfuse.observation.completion_start_time`; the final
count is stored in `langfuse.observation.metadata.stream_item_count`. Empty streams
have count zero and no completion-start timestamp. Chunk contents are never
automatically captured or accumulated, even with capture enabled. Streams default
to `generation`; generator decorators retain their selected type (default `span`).

## Content capture

`ContentCapturePolicy` is a frozen value. `ContentCapturePolicy()` snapshots
`OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT` when constructed; only
case-insensitive `true` enables it. Missing and other values disable capture.
`ContentCapturePolicy(enabled=True)` or `enabled=False` overrides the environment;
other override types raise `TypeError`.

`Telemetry(..., content_capture=None)` constructs the default policy once.
Inject a policy to choose explicitly; `telemetry.content_capture` exposes that
immutable policy for use with model adapters or computed outputs:

```python
from observability_ai import ContentCapturePolicy, LangfuseSettings, Telemetry

with Telemetry(
    LangfuseSettings.from_env(),
    service_name="my-app",
    service_version="1.0.0",
    content_capture=ContentCapturePolicy(enabled=True),
) as telemetry:
    with telemetry.tool("normalize", input={"question": " Hello "}) as observation:
        result = " Hello ".strip()
        observation.set_output(result)
```

`observe(..., input=..., output=...)` and the typed convenience helpers serialize
supplied values at context entry when the span is recording and capture is
enabled. Later changes to mutable values do not change the captured snapshot.
For output computed inside the block, use `observation.set_output` as above.
The policy's `as_otel_attributes` is also available for explicit serialization.
`None` omits a value; empty strings, empty collections, zero, and `False`
are retained. JSON-serializable values, including strings, become JSON strings
in `langfuse.observation.input` and `langfuse.observation.output`.

Disabled capture does not inspect or serialize payloads. An unsupported value,
circular structure, or non-finite number is omitted with a warning through
`observability_ai.content`; a failure in one value does not drop the other.
Warnings omit the payload and serialization exception text. There is no fallback
to an object's string representation.

`ContentCapturePolicy(enabled=True, redactor=redact, max_characters=2000)` can
transform each payload before JSON serialization and limit the resulting text.
`redactor` must be callable or `None`; it receives each supplied object and returns
the replacement object. Use a redactor that returns safe values without mutating
application data. Redaction failures omit only the failed payload with the same
content-free warning behavior. Disabled capture and non-recording spans never
invoke the redactor. An omitted payload (`None`) is not passed to it.

`max_characters` must be a positive integer or `None` (unlimited). Long serialized
values retain that many Unicode characters, followed by `...[truncated]`; the
marker is additional to the limit. Truncated values may no longer be valid JSON.
Redaction runs before truncation; truncation alone does not remove sensitive data.

This policy covers values supplied through these capture APIs. Raw span
attributes, OTel exception details, native SDK input/output, and score comments
retain their own behavior. The model-runtime adapter has its own capture option;
pass `capture_message_content=telemetry.content_capture.enabled` to keep it
aligned with an explicit facade override. Retrieval captures no query or document
text.

### Run the agent example

Install the two required extras and configure local Langfuse as in Quickstart:

```bash
uv sync --locked --extra model-runtime --extra langfuse
uv run --no-sync examples/agent_example.py --no-capture-content
```

The example uses deterministic model responses and illustrative token counts,
with no model-provider API keys or calls. It prints a trace ID for this structure:

```text
example agent (agent)
├── research (chain)
│   ├── definition (tool)
│   │   └── chat demo-model (generation)
│   └── example (tool)
│       └── chat demo-model (generation)
└── answer stream (chain)
```

The tools call model-runtime concurrently. `telemetry.propagate` supplies the
session, user, tags, and metadata to all seven observations, including child
tasks. Explicit `generation` handles record models, illustrative token usage,
and gated input/output; no runtime observer is added, avoiding duplicate
generations. `telemetry.stream` traces simulated incremental delivery of the
already-computed answer, recording first-chunk timing and item count. It is not
a provider token stream and does not automatically capture chunks.

The agent saves `current_trace_id()` before ending, then awaits `LiveEvaluation`
using `Scorer.as_live_sink()`. Boolean `mentions_topic` and `length_within` scores
attach to that completed trace, without an observation ID. A failed tool preserves
the TaskGroup's exception group and skips evaluation; cancellation closes the
response stream and agent. An unsampled agent returns its answer without scores.
Evaluation or score-delivery errors propagate to the caller.

`--capture-content` enables the agent, tool, and generation payloads;
`--no-capture-content` disables them. Omit both to use the
environment default. The example loads an optional root `.env`, then
`observability/.env`, with already-exported variables taking precedence.
`Telemetry` exports the observations and a separate SDK client sends scores using
the saved trace ID. The SDK creates no extra observations in this example.

## Use with model-runtime

Install the optional integration from this checkout:

```bash
uv sync --locked --extra model-runtime
```

`model_runtime_observer(telemetry, *, provider_name, trace=None,
capture_message_content=None)` returns model-runtime's `OTelTraceObserver` using
the application's tracer. It creates no additional wrapper span. Each logical
completion or stream produces one generation, even when `trace` is omitted;
retries remain events on that generation.

Inside an async application function, with an existing `Telemetry`,
`TraceAttributes`, and `ModelRouter` named `router` whose `chat` route uses OpenAI:

```python
from model_runtime import ModelRequest, ModelRuntime
from observability_ai.adapters import model_runtime_observer

runtime = ModelRuntime(
    router,
    observer=model_runtime_observer(
        telemetry, provider_name="openai", trace=trace, capture_message_content=False
    ),
)
with telemetry.observe("request", attributes=trace):
    response = await runtime.complete("chat", ModelRequest.from_text("Hello"))
```

Session, user, tags, and metadata are copied to every model generation.
The observer has a fixed provider name and fixed dimensions: use an appropriately
configured observer for each provider or request context that needs different
dimensions. Active spans remain isolated across concurrent tasks.

Message content follows model-runtime's policy. `None` reads
`OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT` at observer construction
(only case-insensitive `true` enables capture); `True` or `False` overrides it.
By default, the observer records model, token usage, latency, and error metadata
without messages. Capture is limited to the text supported by the native observer.

## Use with vectorstore-ai

```bash
uv sync --locked --extra vectorstore
```

`retrieval_observer(telemetry, *, trace=None)` returns vectorstore-ai's native
`OTelRetrievalObserver`. Supply it when constructing a `Retriever`. Inside the
application's `Telemetry` lifetime, this SQLite example performs lexical
retrieval without embedding-provider calls:

```python
from vectorstore import (
    CatalogChunk,
    CatalogDocument,
    Retriever,
    RetrieverConfig,
    SqliteDocumentCatalog,
)
from observability_ai.adapters import retrieval_observer

with SqliteDocumentCatalog() as catalog:
    catalog.upsert_documents([CatalogDocument("doc-1")])
    catalog.upsert_chunks([CatalogChunk("chunk-1", "doc-1", "Telemetry setup guide")])
    retriever = Retriever(
        catalog,
        observer=retrieval_observer(telemetry, trace=trace),
        config=RetrieverConfig(dense_enabled=False),
    )
    with telemetry.observe("request", attributes=trace):
        result = retriever.retrieve("telemetry")
```

The observer reconstructs a `retrieve` span and its timed phase children from the
completed result, under the current application span. The root receives
`langfuse.observation.type=retriever` and all supplied trace dimensions. The native
observer attaches custom attributes only to this root: embedding, search, and
fusion children keep their upstream attributes and do not receive those trace
dimensions or the retriever type. The adapter preserves that behavior.
Query and document text are not captured; operational IDs, counts, timings,
embedding usage, and fallback/degradation events follow vectorstore's observer.

### Optional dependency sources

Both factories can be imported from `observability_ai.adapters` or their
individual modules (`adapters.model_runtime` and `adapters.vectorstore`) with only
the core installed. Calling a factory without its library raises `ImportError`
with the corresponding `observe-eval-ai[extra]` install hint. Neither factory
creates an exporter, sets a global provider, nor shuts down `Telemetry`.

`uv sync --locked --all-extras` installs both adapters and the Langfuse SDK.
The project pins
vectorstore-ai to `v0.1.0`. Model-runtime's latest tag, `v0.2.1`, lacks the OTel
observer and `otel` extra, so this release pins its published commit
`1d050b4902421de28f57b24777f056ea1b19a75d`, which includes them.

When consuming this checkout in another uv project, add
`observe-eval-ai[model-runtime,vectorstore]>=0.7.0` to that project's dependencies
and configure these sources there (adjust the local path):

```toml
[tool.uv.sources]
observe-eval-ai = { path = "../observe-eval-ai", editable = true }
model-runtime = { git = "https://github.com/MeetPatel89/model-runtime.git", rev = "1d050b4902421de28f57b24777f056ea1b19a75d" }
vectorstore-ai = { git = "https://github.com/MeetPatel89/vectorstore-ai.git", tag = "v0.1.0" }
```

Source overrides are uv project configuration, not published distribution
requirements. Wheel/sdist consumers must also arrange compatible dependency
sources when installing the adapter extras; installing the base package needs
only OTel. The `langfuse` extra comes from PyPI and needs no source override.

## Evaluation core

Import evaluation APIs from `observability_ai.evaluation`. Deterministic checks,
retrieval metrics, result values, rubric configuration, and live evaluation work
without Langfuse, model-runtime, or vectorstore installed. Importing the package
does not load those optional libraries or construct clients.

```python
from observability_ai.evaluation import ExactMatch, NumericTolerance, PrecisionAtK

match = ExactMatch()(output="Paris", expected_output="Paris")
# EvaluationResult(name="exact_match", value=1.0, data_type="BOOLEAN", ...)
close = NumericTolerance(abs_tolerance=0.1)(output=3.14, expected_output=3.14159)
precision = PrecisionAtK(3)(output=["a", "a", "b"], expected_output=["a", "b"])
# precision.value == 2 / 3: duplicate IDs occupy positions without extra credit.
```

`EvaluationResult(name, value, data_type="NUMERIC", comment=None, metadata=...)`
is frozen. Names and categorical/text values must be nonblank. Numeric values
must be finite and cannot be booleans; boolean scores accept booleans or numeric
0/1. Numeric and boolean values become floats. Text scores allow at most 500
characters, while comments may be any string or `None`. The existing SDK `Scorer`
uses the same validation rules and retains its `ScoreDataType` export.
Metadata requires nonblank string keys and is copied into a read-only mapping;
nested values remain shared and are not serialized or deeply frozen.

An `Evaluator` accepts keyword arguments `input`, `output`, `expected_output`,
and `metadata`, and returns an `EvaluationResult`, a sequence of results, or an
awaitable producing either. Built-in evaluators require only `output`; unused
arguments default to `None`. Custom evaluators should accept all four arguments.
Input metadata is available to evaluators but is not automatically copied into
their results.

| Evaluator | Behavior |
| --- | --- |
| `ExactMatch()` | Python equality with `expected_output`; no normalization or string conversion |
| `Contains()` | Case-sensitive substring check: `expected_output` within string `output`; an empty expected string matches |
| `RegexMatch(pattern, flags=0)` | Regex search in string `output`; use anchors for a full match |
| `NumericTolerance(abs_tolerance=0.0, rel_tolerance=0.0)` | `math.isclose` comparison of finite numbers; numeric strings and booleans are rejected |
| `JsonParsable()` | One JSON value, including scalars; rejects code fences, duplicate keys, non-finite numbers, and trailing content |
| `LengthWithin(min_length=0, max_length=None)` | Inclusive `len(output)` bounds; characters for strings, items for collections |

These checks return `BOOLEAN` scores with snake-case names such as `exact_match`
and `json_parsable`. Pass `name=` to override any name. Invalid configuration or
input types raise `TypeError`/`ValueError`; a valid input that fails a check scores
zero. Malformed JSON text scores zero; a non-string JSON input is a type error.
Checks do not export scores or capture payloads by themselves.

### Retrieval metrics

`HitAtK(k)`, `RecallAtK(k)`, `PrecisionAtK(k)`, and `ReciprocalRank(k=None)` take
ordered string document IDs as `output` and nonempty relevance labels as
`expected_output`. A cutoff must be a positive, nonboolean integer. IDs must be
nonblank strings. Empty retrievals score zero; empty relevance labels raise.

Metrics follow the original returned positions, including repeated document IDs:

- Hit is 1 if any expected ID occurs in the first `k` positions, otherwise 0.
- Recall divides distinct matched IDs by distinct expected IDs.
- Precision divides distinct matched IDs by `k`, even for fewer than `k` results.
- Reciprocal rank is `1 / first_matching_position`, or zero for a miss. Omit `k`
  to use the whole list; supply it for truncated reciprocal rank.

All return `NUMERIC` scores. Default names include the cutoff: `hit_at_3`,
`recall_at_3`, `precision_at_3`, and `reciprocal_rank_at_3`; the unbounded rank
metric is `reciprocal_rank`. Each accepts `name=`. Recall measures coverage of
the supplied labels, not relevance of unlabeled documents in the corpus.

### Model-runtime judge

`ModelRuntimeJudge` requires `observe-eval-ai[model-runtime]` only when
constructed. Supply an existing runtime and a configured route; the judge does
not own the runtime, configure providers, or change retry policy. Inside an async
application with `runtime` and optional `telemetry` already configured:

```python
from observability_ai.evaluation import JudgeRubric, ModelRuntimeJudge

judge = ModelRuntimeJudge(
    runtime,
    "judge",  # A route configured on this runtime.
    JudgeRubric("correctness", "Assess correctness against the reference answer."),
    telemetry=telemetry,
)
result = await judge(
    input="What is the capital of France?",
    output="Paris",
    expected_output="Paris",
)
```

A default rubric requires a finite numeric score from 0 through 1. For categories,
use `JudgeRubric("quality", "Grade the answer.", data_type="CATEGORICAL",
labels=("pass", "fail"))`; labels must be unique, nonblank strings. Optional
`prompt=` is additional instruction text, not a template or SDK prompt object.
The judge always appends the rubric, JSON response contract, and application data.

The runtime receives `ModelRequest.from_text(...)` containing JSON-serializable
`input`, `output`, `expected_output`, and `metadata`. Unsupported values and
non-finite numbers raise before a model call. A response must be exactly a JSON
object with `score` and nonblank string `reasoning`; reasoning becomes the result's
comment. There is no extraction from prose or code fences, score coercion, or
automatic repair. Invalid responses raise `JudgeResponseError`; model errors and
cancellation propagate unchanged. Retry behavior remains the runtime's policy.

With `telemetry=`, the request and parsing occur inside an `evaluator` observation
named for the rubric. Its input/output follow the telemetry content capture and
redaction policy. The supplied application data is still sent to the judge model
when trace capture is disabled. A runtime observer can create a generation nested
inside that evaluator; its own message-capture settings remain independent.

### Sampled live evaluation

`LiveEvaluation(evaluators, sink=..., sample_ratio=1.0)` runs sync and async
evaluators sequentially in an awaited `evaluate(...)` call. Its sink is a
synchronous callable receiving `(result, trace_id, observation_id)` positionally.
For example, an application can collect results without any SDK:

```python
from observability_ai.evaluation import EvaluationResult, ExactMatch, LiveEvaluation

scores: list[tuple[EvaluationResult, str, str | None]] = []


def collect(
    result: EvaluationResult, trace_id: str, observation_id: str | None
) -> None:
    scores.append((result, trace_id, observation_id))


live = LiveEvaluation([ExactMatch()], sink=collect, sample_ratio=1.0)
with telemetry.agent("answer"):
    results = await live.evaluate(output="Paris", expected_output="Paris")
```

Sampling happens once for the whole call. Ratios must be finite numbers in
`[0, 1]`, excluding booleans; skipped calls return an empty tuple without running
evaluators or requiring target IDs. For reproducible tests, inject
`random_source=`, a callable returning a uniform float in `[0, 1)`.

By default, a sampled call captures the active recording span's IDs before running
evaluators. Without one, pass `trace_id=` explicitly. An explicit trace with no
`observation_id=` targets the trace alone, even inside another active span. To
score an ended observation, pass both IDs from its handle. No target is inferred
from any nested evaluator span, and unsampled tracing contexts provide no current
IDs. All result sequences are flattened in evaluator order and returned as a tuple.

All evaluators must succeed and return valid result objects before sink delivery
begins. Exceptions and cancellation propagate to the caller; there are no
background tasks or automatic retries. Sink delivery is sequential and is not
transactional: a sink error can leave earlier scores delivered. The application
owns failure handling and persistence. The optional `observability_ai.langfuse`
subpackage supplies a live sink, datasets, experiments, and batch evaluation;
these integrations do not add SDK dependencies to the evaluation core.

## Use with the Langfuse SDK

Install `observe-eval-ai[langfuse]` in an application, or from this checkout:

```bash
uv sync --locked --extra langfuse
```

The extra supports `langfuse>=4.7,<5`. Import SDK integration APIs from
`observability_ai.langfuse`; this subpackage raises `ImportError` with an install
hint if the SDK is missing. Core and adapter imports do not load it.

```python
from observability_ai import LangfuseSettings
from observability_ai.langfuse import (
    Scorer,
    build_langfuse_client,
    propagate_attributes,
    start_as_current_observation,
)

client = build_langfuse_client(LangfuseSettings.from_env())
scorer = Scorer(client)
try:
    with start_as_current_observation(client, name="answer request"):
        with propagate_attributes(
            session_id="session-123", user_id="user-456", tags=["my-app"]
        ):
            with start_as_current_observation(
                client, name="answer", as_type="generation", model="my-model"
            ):
                # Run the application's model call and compute its evaluation.
                scorer.score_current(name="quality", value=0.9)
finally:
    client.shutdown()
```

`build_langfuse_client(settings, *, tracer_provider=None, span_exporter=None)`
returns a native `Langfuse` client. It passes credentials, base URL, release,
environment, and sample rate from the settings. When environment or release is
`None`, the SDK retains its own environment-variable fallback behavior.

The factory supplies a local OTel provider with service name
`observability-ai.langfuse`, the package version, and
`ParentBased(TraceIdRatioBased(settings.sample_ratio))`. It does not register a
global provider. The SDK adds its own processor and exporter. An injected
`tracer_provider` keeps its resource and sampler; its owner should shut it down
after the client. Inject `span_exporter=InMemorySpanExporter()` for offline
observation tests; this does not replace the SDK's scores or prompts HTTP client.

Create one client per Langfuse project at application startup: the SDK shares
resources by public key, so the first client's resource configuration is reused.
`client.flush()` drains pending observations and scores; `client.shutdown()`
drains queues and stops SDK ingestion workers. The default OTel provider also
registers its normal process-exit cleanup. For explicit provider cleanup before
process exit, inject an application-owned provider and call its `shutdown()`.
Flushing does not confirm backend acceptance; SDK export failures follow its
logging and queue behavior. Scores use the SDK's own sampling behavior.

`propagate_attributes` is the original SDK function. The exported
`start_as_current_observation` is the unbound SDK method: pass the explicit
client as its first argument, or call `client.start_as_current_observation(...)`
directly. Both forms preserve SDK observation types and overloads. Regular
`with` blocks also work in async functions; context propagates to `TaskGroup`
descendants.

### Scores

`Scorer(client).score(name=..., value=..., trace_id=..., observation_id=None,
data_type="NUMERIC", comment=None, metadata=None)` queues a trace score or, when
an observation ID is supplied, a score for that observation. Names and target IDs must be
nonblank strings. Both IDs are required for an observation score; legacy trace
IDs are accepted without imposing an OTel hex format. Comments may be strings
or `None`.

| `data_type` | Accepted `value` |
| --- | --- |
| `NUMERIC` (default) | Finite integer or float; booleans are rejected |
| `BOOLEAN` | `True`/`False` or numeric `0`/`1`, sent as `0.0`/`1.0` |
| `CATEGORICAL` | Nonblank string |
| `TEXT` | Nonblank string of at most 500 characters |

`score_current(...)` takes the same score fields without IDs and delegates to
the SDK's `score_current_span()`. It targets the currently active observation,
including an OTel span from `Telemetry`; use a client for the same Langfuse
project. Without an active observation, the SDK logs a warning and sends no
score. Invalid arguments raise `TypeError` or `ValueError` before queueing.
The scorer does not flush or close the supplied client. See Langfuse's
[score API documentation](https://langfuse.com/docs/evaluation/evaluation-methods/scores-via-sdk)
for backend score behavior.

`score_current_trace(...)` accepts the same fields as `score_current(...)` and
targets the active trace, without an observation ID. It also validates before
delegating to the SDK and is a warning/no-op without an active span.
`score_evaluation(result, *, trace_id, observation_id=None)` preserves a core
`EvaluationResult`'s type, comment, and metadata. `score_many(results, *, trace_id,
observation_id=None)` snapshots and validates all results before submitting in
order. SDK delivery is not transactional; a client error can follow previously
queued scores. `feedback(trace_id, value, comment=None)` records the binary
`user-feedback` trace score (`True`/`False` or numeric `0`/`1`).

To persist sampled live results, pass `Scorer(client).as_live_sink()` as the sink:

```python
from observability_ai.evaluation import ExactMatch, LiveEvaluation
from observability_ai.langfuse import Scorer

live = LiveEvaluation([ExactMatch()], sink=Scorer(client).as_live_sink())
# In an async request handler, with an active core or SDK recording observation:
# await live.evaluate(input=question, output=answer, expected_output=reference)
# Or supply trace_id=... explicitly to score a trace without an active span.
```

### Datasets and local JSONL

`DatasetRepository(client)` provides `get(name, version=None)`, `create(name,
description=None, metadata=None)`, and `add_items(name, items)`. Fetches return the
native SDK dataset with `.items`; `version` is a `datetime` timestamp, not an
integer. Creation returns the native SDK dataset value; uploads return a tuple
of SDK dataset items in input order. SDK/API errors propagate to the caller.

`DatasetItemRecord(input, expected_output=None, metadata=..., id=None,
source_trace_id=None, source_observation_id=None)` is frozen with a shallow,
read-only metadata snapshot. Nested values remain application-owned. A source
observation requires its source trace. Explicit item IDs update existing remote
items when uploaded. Uploads validate the complete iterable first, but remote
writes are not transactional and are not retried by this wrapper.

`load_jsonl(path)` reads UTF-8 data locally and returns a tuple of records; it
does not create a client or upload anything. The SDK extra is required to import
this subpackage, but a hosted dataset is not required. Each nonblank line must
be a JSON object with `input` and any optional record fields, for example:

```json
{"input": "Paris", "expected_output": "Paris", "metadata": {"split": "test"}}
```

Blank lines are skipped. Unknown fields, duplicate keys, invalid records, and
non-finite numbers raise `ValueError` with the file path and line number. File
access errors retain their native types. JSON `null` inputs can be loaded, but
the SDK experiment runner treats missing/null input as a failed item.

### Experiments and regression gates

`ExperimentRunner(client).run(name, *, data, task, evaluators, run_evaluators=(),
run_name=None, description=None, metadata=None, max_concurrency=50)` accepts
local records, SDK local dictionaries, SDK dataset items, or a fetched dataset
object. Passing the dataset object preserves its version timestamp as well as
its remote item identities. Local record IDs and source IDs are upload fields;
they do not turn local experiment data into hosted dataset items.

Tasks follow the SDK's `task(*, item, **kwargs)` contract and can be sync or
async. For local data, `item` is a dictionary; hosted data uses SDK objects.
Item evaluators use the core `Evaluator` contract. Run evaluators follow the
exported `RunEvaluator` protocol: `evaluator(*, item_results)` receives completed
SDK item results and returns one or several core `EvaluationResult` values,
synchronously or asynchronously. Experiment metadata values must be strings.

```python
from langfuse.api import DatasetItem
from langfuse.experiment import ExperimentItem

from observability_ai import LangfuseSettings
from observability_ai.evaluation import ExactMatch
from observability_ai.langfuse import (
    DatasetItemRecord,
    ExperimentRunner,
    RegressionGate,
    build_langfuse_client,
)


def echo(*, item: ExperimentItem, **kwargs: object) -> object:
    return item.input if isinstance(item, DatasetItem) else item.get("input")


client = build_langfuse_client(LangfuseSettings.from_env())
try:
    report = ExperimentRunner(client).run(
        "echo-check",
        data=[DatasetItemRecord("Paris", "Paris")],  # Or load_jsonl(path).
        task=echo,
        evaluators=[ExactMatch()],
        max_concurrency=4,
    )
    print(dict(report.metric_means))
    RegressionGate({"exact_match": 1.0}).check(report)
finally:
    client.shutdown()
```

The frozen `ExperimentReport` snapshots `total_count`, `completed_count`,
`failed_count`, `evaluation_count`, `evaluator_failures`, `metric_means`,
`metric_counts`, and `run_evaluations`. Means/counts cover numeric and boolean
item scores; categorical scores count toward `evaluation_count` but are not
averaged. Run scores remain separate and do not affect item means. `sdk_result`
retains the original mutable SDK result, including its run URL when available.

The SDK logs and omits failed tasks. Evaluator exceptions are captured by the
wrapper before the SDK handles them, so they remain visible in the report.
`RegressionGate(thresholds).check(report)` raises `RegressionDetected` for a
mean below its minimum, a missing metric, an empty experiment, failed items, or
evaluator failures. Equality passes. Thresholds apply to item means only, over
the scores actually returned; evaluators may intentionally return no scores.
No baseline lookup or statistical significance test is performed.

The SDK owns experiment concurrency, automatic tracing, score delivery, and
flushing. These SDK workflows capture inputs/outputs under SDK settings;
`Telemetry`'s content policy does not govern them. A report or passing gate does
not confirm backend ingestion. Experiments and batches accept `NUMERIC`,
`BOOLEAN`, and `CATEGORICAL` results. `TEXT` is rejected at this SDK adapter
boundary; direct `Scorer` APIs still support it. See the
[SDK experiment reference](https://python.reference.langfuse.com/langfuse/experiment).

### Run the experiment example

Configure Langfuse credentials as in Quickstart, then run:

```bash
uv sync --locked --extra langfuse
uv run --no-sync examples/experiment_example.py
# Or supply your own local dataset and run label:
uv run --no-sync examples/experiment_example.py examples/normalization.jsonl \
  --run-name candidate
```

The bundled UTF-8 JSONL has three whitespace-normalization cases, including tabs,
newlines, and Unicode. The task collapses whitespace in `input`; it never reads
the reference to produce its answer. Each item requires string `input` and
`expected_output`. Local file errors, malformed/empty datasets, and invalid item
types fail before constructing a client. The default run needs no model provider
or model-runtime extra, but sends experiment inputs, outputs, and scores to
Langfuse through the SDK. It does not create a hosted dataset.

The CLI prints completed/failed counts and metric means. `ExactMatch` and
`LengthWithin(min_length=1)` must both average `1.0`. A failed task or evaluator
also fails the regression gate, causing a nonzero exit; the SDK client is shut
down on success and failure. A passing gate does not confirm backend ingestion.

For an optional live judge, install the model-runtime extra and set
`ANTHROPIC_API_KEY` and `ANTHROPIC_MODEL` in your environment or ignored root
`.env`. Choose a model supported by your provider account; no model is selected
by default:

```bash
uv sync --locked --extra langfuse --extra model-runtime
uv run --no-sync examples/experiment_example.py --judge
```

`--judge` makes paid Anthropic calls through `ModelRuntimeJudge`, sending each
input, output, reference, and metadata. The rubric requests strict JSON grading
whitespace normalization; its `normalization_quality` mean must be at least
`0.9`. Model output is nondeterministic: low scores, malformed responses, and
provider errors fail the gate. The example uses at most four concurrent items,
one runtime attempt per judgment, a provider HTTP timeout of 30 seconds, and
closes each provider client on its evaluator's event loop. It creates no additional
core `Telemetry`; the SDK owns experiment tracing and capture. Neither this
example nor the optional live judge is run against a live service by CI.

### Historical batch evaluation

`BatchEvaluation(client).run(mapper=..., evaluators=..., scope="traces", ...)`
adapts the same core evaluators to the SDK's `run_batched_evaluation`. Choose
`scope="observations"` for observation scoring. The SDK mapper accepts keyword
`item` (a `TraceWithFullDetails` or `ObservationsView`) and returns SDK
`EvaluatorInputs`, synchronously or asynchronously.

The wrapper forwards `filter` (the SDK's JSON filter string),
`fetch_batch_size=50`, `fetch_trace_fields=None`, `max_items=None`,
`max_retries=3`, `max_concurrency=5`, `metadata=None`, `resume_from=None`, and
`verbose=False`. Concurrency, batch size, and a supplied maximum item count must
be positive integers; retries may be zero. The SDK owns fetching, retries,
score delivery, and resume behavior. The native `BatchEvaluationResult` is
returned unchanged; inspect its statistics and resume token for partial
failures. Invocation errors propagate, and the wrapper never shuts down the
client. See the [SDK batch API](https://python.reference.langfuse.com/langfuse/batch_evaluation).

### Managed prompts

Within the client's lifetime, retrieve an existing text prompt named
`answer-question` containing a `{{question}}` variable:

```python
from observability_ai.langfuse import PromptRepository

prompts = PromptRepository(client)
prompt = prompts.get("answer-question", label="production")
text = prompt.compile(question="What is a vector space?")
with client.start_as_current_observation(
    name="answer", as_type="generation", model="my-model", prompt=prompt
) as generation:
    # Supply text to the application's model and update the generation with usage.
    generation.update(metadata={"compiled_characters": len(text)})
```

`get(name, *, label=None, version=None, type="text")` returns the original
`TextPromptClient` or, with `type="chat"`, `ChatPromptClient`. Use either a
nonblank label or a positive integer version; omitting both selects the SDK's
`production` label. Boolean versions and combined label/version selectors are
rejected. Call `compile(**variables)` on the returned object; the SDK controls
variable and chat-placeholder behavior. Pass that object as `prompt=` to link a
generation to its managed version. Compiled content is a separate value.

The repository retains SDK caching, refresh, retries, and fetch-error behavior;
it does not create prompts or invent fallback content. Unhandled SDK exceptions
propagate to the application. See
[prompt version control](https://langfuse.com/docs/prompt-management/features/prompt-version-control).

### SDK example

The [SDK example](examples/langfuse_sdk_example.py) ports model-runtime's
concurrent generation example and adds scoring and optional managed prompts:

```bash
uv sync --locked --extra langfuse --extra model-runtime
uv run --no-sync python examples/langfuse_sdk_example.py
```

The default makes two deterministic model-runtime completions, exports one parent
and two generation observations, and attaches a boolean `completed` score to the
parent. It prints the trace ID. Token counts are demonstration values; no model
provider is called and no model API keys are needed. The example loads an
optional repository-root `.env`, then `observability/.env` as a fallback;
exported environment variables take precedence over both.

To use an existing managed text prompt with a `{{question}}` variable:

```bash
uv run --no-sync python examples/langfuse_sdk_example.py \
  --prompt answer-question --prompt-label production
# Or choose --prompt-version 1 instead of --prompt-label.
```

`--live-models` runs OpenAI and Anthropic completions instead. It requires
`OPENAI_API_KEY`, `OPENAI_MODEL`, `ANTHROPIC_API_KEY`, and `ANTHROPIC_MODEL` in the
environment or the optional root `.env`. It uses the configured provider models
and their reported token usage.

The example only captures normalized message text and response text when
`OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT=true` (case-insensitive).
It always reports model parameters, route, usage, and managed prompt references
when supplied. Flat SDK token buckets use `langfuse_usage_details` below. The
SDK does not apply this example's capture switch to arbitrary application calls:
any input, output, score text, or comment explicitly supplied to it may be sent.

### Raw OTel compared with the SDK

| Concern | OTel core and adapters | Langfuse SDK extra |
| --- | --- | --- |
| Dependency | Core OTel plus the relevant adapter extra | `observe-eval-ai[langfuse]` |
| Export setup | `Telemetry` owns its provider and OTLP processor | Factory supplies a local provider; SDK adds its processor/exporter |
| Runtime lifecycle | Native observer covers retries, streams, errors, and usage | Application opens and updates each generation |
| Session/user/tags/metadata | `Telemetry.propagate` for facade calls; explicit attributes for raw spans/adapters | `propagate_attributes` covers current and descendant observations |
| Token usage | Inclusive GenAI input counts with separate cache reads | Exclusive `usage_details` buckets |
| Scores and managed prompts | Add the SDK extra when needed | `Scorer` and `PromptRepository` use an explicit client |
| Portability | Standard OTel spans and GenAI attributes | Native SDK objects and Langfuse prompt attribution |

Use the core and adapters for library instrumentation; use SDK features where the
application needs scoring, managed prompts, or native observation APIs. Both
share OTel context. Choose one generation-instrumentation path per model call
to avoid duplicate generations. Passing an already-exporting `Telemetry` provider
to the SDK would add another export processor; the factory's separate local
provider avoids that duplication by default.

## Model and token attributes

`observability_ai.genai` contains pure functions; it does not require either
adapter or the Langfuse SDK:

```python
from observability_ai.genai import (
    langfuse_usage_details,
    model_attributes,
    usage_attributes,
)

attributes = model_attributes(
    provider_name="my-provider",
    request_model="requested-model",
    response_model="returned-model",
)
attributes.update(usage_attributes(input_tokens=7, output_tokens=3, cached_tokens=2))
# Attach attributes with span.set_attributes(attributes).

details = langfuse_usage_details(input_tokens=7, output_tokens=3, cached_tokens=2)
# {"input": 5, "output": 3, "cache_read_input_tokens": 2}
```

`model_attributes` sets `gen_ai.provider.name`, `gen_ai.request.model`, and
`gen_ai.operation.name` (default `chat`); it includes `gen_ai.response.model` only
when supplied. Names must be nonblank strings. Set `operation_name="embeddings"`
for embedding calls or supply a custom operation name.

`usage_attributes` retains the inclusive input total in `gen_ai.usage.input_tokens`
and separately reports cache reads in `gen_ai.usage.cache_read.input_tokens`,
following the [OTel GenAI convention](https://opentelemetry.io/docs/specs/semconv/registry/attributes/gen-ai/).
`langfuse_usage_details` subtracts cache reads from `input` for flat SDK
`usage_details`, following Langfuse's
[exclusive usage buckets](https://langfuse.com/docs/observability/features/token-and-cost-tracking#usage-types-are-mutually-exclusive-buckets).
Use the appropriate representation once: Langfuse already normalizes inclusive
OTel usage during ingestion. The factories leave native observer usage unchanged.

Both usage helpers require nonnegative integer counts, reject booleans and cache
counts greater than input, preserve zero input/output, and omit zero cache reads.
All helpers return fresh dictionaries and capture no message content.

The same module also exports `tool_attributes(name=..., call_id=None,
description=None)`, `agent_attributes(name=..., agent_id=None, description=None)`,
`prompt_attributes(name=..., version=...)`, and `cost_details(input_cost=None,
output_cost=None, total_cost=None)`. Tool/agent identity uses `gen_ai.tool.*` /
`gen_ai.agent.*`; prompt references use `langfuse.observation.prompt.*`; costs use
`langfuse.observation.cost_details.*`. Names must be nonblank, prompt versions must
be positive integers, and costs must be finite and nonnegative; booleans are
rejected for numeric fields. These helpers require no optional dependencies.

## Export lifecycle and testing

By default, `Telemetry` batches completed spans for HTTP export. Its context
manager calls `shutdown()` to drain queued spans and close the provider. For a
long-running service, create one instance at startup and shut it down after all
request work has finished. `force_flush(timeout_millis=30_000)` returns whether
the processor finished flushing within the deadline. OTel flush completion does
not confirm that Langfuse accepted the data; inspect export logs or use the
standalone ingestion smoke test when checking connectivity.

OTel's standard simple and batch processors log exporter failures and allow
application work to continue. The default or injected processor attached by
`Telemetry` or `build_tracer_provider` is also guarded at start, pre-end, end,
flush, and shutdown. Callback exceptions are logged through
`opentelemetry.sdk.trace`, using the application's existing logging handlers,
and do not interrupt application work or replace application exceptions.
`force_flush()` returns `False` on a processor exception or after shutdown.

`shutdown()` attempts to close the owned processor at most once, including when
called concurrently or when that attempt fails. It does not retry failed cleanup.
Finish all request work before shutdown; later callbacks on that processor are
ignored. Invalid configuration still raises at construction, and process-control
exceptions such as `KeyboardInterrupt` are preserved. The guard covers callbacks
on the factory-attached processor, not direct exporter calls or extra processors
registered separately on a returned provider. Processors must still avoid blocking
their callers; the guard does not impose a timeout on arbitrary custom code.

No global tracer provider is installed by default. Set `set_global=True` on
`Telemetry` only when the application owns process-wide OTel configuration.
OTel permits global registration once; it logs a warning and keeps the existing
provider if one is already installed. Closing `Telemetry` does not reset that
global registration.

Both `Telemetry` and `build_tracer_provider` accept a `span_processor` to replace
the default network export path. They own the supplied processor's lifecycle.
For tests, inject `SimpleSpanProcessor(InMemorySpanExporter())`; this avoids
constructing an HTTP exporter. The suite covers settings and environment parsing,
attribute validation and immutability, HTTP request authentication, resources,
sampling, nesting, TaskGroup context, error recording, and provider ownership.
It also covers decorator signatures and cancellation, typed helpers, capture
gating, redaction and truncation, serialization failures, processor failures, and
concurrent shutdown. Core tracing tests cover propagated dimension isolation,
recording-only current IDs, generation updates, zero-duration events, and sync/async
stream protocol forwarding, partial close, first-chunk timing, and producer context.
Adapter tests use real runtime and retrieval APIs without live provider calls.
Evaluation tests cover shared score validation, deterministic boundaries,
document-rank semantics, lazy optional imports, strict judge responses, nested
runtime generations, capture policies, cancellation, and sampled sink delivery.
SDK tests inject fake clients for scores, prompts, datasets, and historical
batch evaluation. Experiment tests execute the SDK locally with intercepted
score delivery, covering async and multiple results, run evaluators, failures,
summary snapshots, and regression gates. Local providers and in-memory
exporters cover native observations and examples. Agent example tests verify
propagated generation/stream dimensions, capture overrides, cancellation, and
ended-trace scoring. Experiment example tests execute the real SDK locally with
intercepted delivery, covering bundled JSONL, optional judge wiring with fake model
responses, configuration errors, regression exits, and client cleanup.

The core facade does not automatically capture model messages, inputs, or
outputs. Explicit input/output use the content policy described above. Values
set directly on spans, including exception details recorded by OTel, are exported.

## Local Langfuse backend

The [backend guide](observability/README.md) documents Compose services,
credentials, startup, and the independent OTLP ingestion check:

```bash
uv run observability/smoke_test.py
```

The smoke test has inline dependencies and reads the `.env` beside it. Backend
credentials stay in `observability/.env`; applications configure their own
environment. The `model-runtime` examples remain in that repository and read its
root `.env`.

## Provisioning apps

The installed `observability-ai` command gives each application its own Langfuse
project and API key pair on the shared local stack. Start the backend from this
repository as documented above. From a consuming app's directory, with
`observe-eval-ai` installed in that app's environment, run:

```bash
uv run observability-ai provision --app my-app --app-env .env \
  --stack-dir ../observe-eval-ai/observability --user-email me@example.com
```

The optional `--user-email` creates a login if missing and grants OWNER membership
in the organization. The generated password is printed once per invocation; it
only applies to a newly created user. Existing users retain their passwords.
Use `--user-name` to name a new user. Save the password if you need that login;
neither the app file nor the registry stores it.

For subsequent commands, set the stack location in the app's `.env`:

```dotenv
OBSERVABILITY_AI_STACK_DIR=../observe-eval-ai/observability
```

`--stack-dir` takes precedence over this variable; an exported variable takes
precedence over the app file. Relative paths resolve against the invoking
directory, even when read from `.env`. The stack directory must contain
`compose.yaml` and `.env`. The CLI uses its directory name as the Compose project
name (normally `observability`); provisioning does not support a custom Compose
project name.

```bash
uv run observability-ai provision --app my-app --dry-run
uv run observability-ai verify --app my-app
uv run observability-ai apps list
uv run observability-ai where
```

Provisioning uses Langfuse's
[headless initialization](https://langfuse.com/self-hosting/administration/headless-initialization)
and recreates only `langfuse-web`; the worker and datastores stay running. Other
apps may experience an ingestion interruption, typically 10–30 seconds. The
command asks for confirmation; `--yes` runs unattended. `--dry-run` displays the
Compose command and redacted INIT values without Docker, HTTP, or file changes.
The stack `.env` is never edited. All ten INIT values are supplied through the
Compose process environment, including empty optional fields that override old
bootstrap values in the stack file.

After health and project/organization verification succeed, the command upserts
`LANGFUSE_PUBLIC_KEY`, `LANGFUSE_SECRET_KEY`, and `LANGFUSE_BASE_URL` in the app's
`.env`, preserving unrelated settings and comments. New files have mode 0600;
existing permissions remain. A failed health or credential check leaves the app
file untouched and prints a startup logs command. `--timeout` changes the default
120-second health wait. `verify` checks exported credentials before app-file
credentials, so clear stale exports if they still target another project.

The gitignored `observability/provisioned.json` registry stores public app IDs,
organization/project IDs, public keys, optional user emails, and timestamps.
It contains no secret keys or passwords. `apps list` shows those local records.
The web container retains its INIT credentials in Docker's container configuration
until recreated. A normal Compose `up -d` then restores the stack file's INIT
settings: empty values skip initialization; nonempty bootstrap values apply again.
Created entities persist across these restarts.

Repeated provisioning reuses the registered app's saved keys. To generate another
pair, run:

```bash
uv run observability-ai provision --app my-app --rotate-keys --yes
```

The previous pair remains valid until retired in the Langfuse UI. If credentials
are missing or disagree with the registry, restore the app file or rotate. After
a deliberate stack reset, re-provisioning can recreate the project with its old
keys when the registry and app file survive; it does not restore deleted data.
Traces, datasets, and experiments already written to another project remain there.

App slugs accept 1–40 lowercase letters, digits, or hyphens and become project IDs.
The default organization is `observability-ai` / `Observability AI`. On creation,
use `--org`, `--org-name`, and `--project-name` to choose other IDs/display names.
Headless initialization does not update existing names or retention, move a
project between organizations, or reset an existing password. `--retention-days`
must be an integer of at least 3 and requires Langfuse's data-retention entitlement;
OSS ignores it. The CLI does not use licensed organization, project, key, or
user-role administration APIs. Use the UI for management beyond creating entities
and adding an owner.

`observability_ai.provisioning` exposes the standard-library core independently:
frozen `AppProvision` and `ProvisionedApp` values, generated credentials, all ten
INIT mappings, atomic dotenv/registry writes, and stack resolution. It performs
no Docker or HTTP calls. Its dotenv reader supports single-line quoted/unquoted
values, optional `export`, and comments; variable expansion, shell execution, and
multiline values are unsupported. The CLI serializes writes with a stack-local
`.provision.lock` directory. See the
[backend provisioning guide](observability/README.md#provisioning-apps) for
startup details, reset/rotation behavior, and missing-stack, Docker/WSL, timeout,
verification, and stale-lock troubleshooting.

The [v0.7.0 provisioning verification record](observability/PROVISIONING_VERIFICATION.md)
records the live scratch-project check and project-isolation evidence.

## Development and release checks

```bash
uv sync --locked --all-extras
uv run --no-sync ruff format --check .
uv run --no-sync ruff check .
uv run --no-sync ty check
uv run --no-sync mypy
uv run --no-sync pytest
uv build --clear --no-sources
uv run --isolated --no-project --no-cache --python 3.14 \
  --with ./dist/*.whl tests/package_smoke.py "$(uv version --short)"
uv run --isolated --no-project --no-cache --python 3.14 \
  --with ./dist/*.tar.gz tests/package_smoke.py "$(uv version --short)"
```

CI runs the same quality and distribution checks, including in-memory observation
and generation handles, sync streaming and partial async-generator close,
propagation and capture APIs, attribute helpers, deterministic/retrieval evaluation,
live sink targeting, packaged SDK modules, and missing-extra behavior from each
installed base artifact.
The artifact smoke commands bypass uv's cache so repeated builds with the same
version test the newly built files.
Adapter and SDK test modules use `importorskip` when their optional library is
absent; the CI quality job installs all extras so every integration runs.
Stable `vMAJOR.MINOR.PATCH` tags must match the
project version; tag builds upload distributions and checksums as workflow
artifacts. Live Langfuse examples and smoke tests are separate from CI.
The GitHub remote remains a user setup step.

## Project structure

```text
src/observability_ai/
  __init__.py            public API and package version
  config.py              validated frozen Langfuse settings
  provisioning.py        headless init values, dotenv persistence, public app registry
  cli.py                 per-app provisioning, verification, and stack discovery
  attributes.py          immutable trace dimensions and observation types
  _context.py            task-local dimensions and active recording-span IDs
  observation.py         observation and generation update handles
  content.py             gated JSON payloads, redaction, and truncation
  export.py              authenticated exporter and tracer provider construction
  _processors.py         private fail-open processor and close-once guard
  telemetry.py           observation helpers, decorators, provider lifecycle
  _stream.py             lazy stream lifetime and producer context isolation
  genai.py               model, usage, tool, agent, prompt, and cost attributes
  evaluation/            SDK-free score results, checks, retrieval metrics, judge, live
  adapters/              lazy model-runtime and vectorstore observer factories
  langfuse/              optional SDK client, scores, prompts, datasets, experiments, batch
  py.typed               installed type information marker
examples/                raw OTel, Langfuse SDK, agent/streaming, and experiment examples
  normalization.jsonl    local UTF-8 dataset for the experiment CLI
observability/           local Langfuse Compose stack, template, smoke test, guide
tests/                   unit tests and installed-distribution checks
pyproject.toml           dependencies, packaging, and quality configuration
uv.lock                  locked dependency graph
.github/workflows/ci.yml quality and distribution validation
.vscode/                 Python editor settings and extension recommendations
AGENTS.md                Codex repository instructions
.cursor/rules/           Cursor repository instructions
CHANGELOG.md             release history
```
