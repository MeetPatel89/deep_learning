"""FastMCP stdio server exposing comparison, inspection and MFA preflight."""

from contextlib import asynccontextmanager
from typing import Any

from data_mcp_core.sql import close_connections, test_connection
from mcp.server.fastmcp import FastMCP

from qa_mcp_server.config import resolve_sql_source
from qa_mcp_server.models import CompareOptions, DatasetSource, OutputOptions, SQLConnection
from qa_mcp_server.service import compare, inspect


@asynccontextmanager
async def lifespan(app: FastMCP):
    try:
        yield {}
    finally:
        close_connections()


mcp = FastMCP("Dataset Comparison", lifespan=lifespan)


@mcp.tool()
def compare_datasets(
    expected: DatasetSource,
    actual: DatasetSource,
    primary_keys: list[str] | None = None,
    compare_options: CompareOptions | None = None,
    output_options: OutputOptions | None = None,
) -> dict[str, Any]:
    """Compare every row and write colored Excel files plus a complete Parquet dump.

    Source types: sql, csv, parquet, excel, file, inline. File paths can use named cloud stores.
    Omit primary_keys for a normalized multiset comparison with occurrence counts.
    Duplicate keys pair in source order and are also reported separately.
    """
    options = compare_options or CompareOptions()
    if primary_keys is not None:
        if options.primary_keys is not None and options.primary_keys != primary_keys:
            raise ValueError("primary_keys conflicts with compare_options.primary_keys")
        options = CompareOptions.model_validate(
            {**options.model_dump(), "primary_keys": primary_keys}
        )
    return compare(expected, actual, options, output_options)


@mcp.tool()
def inspect_dataset(source: DatasetSource, sample_size: int = 5) -> dict[str, Any]:
    """Read a dataset's full row count, schema and up to 100 sample rows.

    SQL inspection may trigger the interactive MFA login; the connection is cached.
    """
    return inspect(source, sample_size)


@mcp.tool()
def test_sql_connection(
    server: str | None,
    database: str,
    username: str | None = None,
    driver: str = "ODBC Driver 18 for SQL Server",
    timeout: int = 30,
    auth: str = "interactive",
    workspace: str | None = None,
    pool: str | None = None,
) -> dict[str, Any]:
    """Run SELECT 1 and cache an Azure SQL ActiveDirectoryInteractive MFA connection."""
    return test_connection(
        resolve_sql_source(
            SQLConnection(
                server=server,
                database=database,
                username=username,
                driver=driver,
                timeout=timeout,
                auth=auth,
                workspace=workspace,
                pool=pool,
            )
        )
    )


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
