---
doc_id: POL-SLA-001
title: Incident Service Level Agreement Policy
doc_type: policy
service_id: null
owner_group: Service Desk L1
visibility: internal
status: active
created_at: "2026-05-12T09:00:00"
updated_at: "2026-06-20T09:00:00"
related_records:
  - POL-ESC-001
  - REF-PRI-001
  - INC-1104
  - INC-1217
  - INC-1302
source_facts:
  - support_groups
difficulty_tags:
  - sla-policy
  - temporal-reasoning
  - severity-classification
servicenow:
  table: kb_knowledge
  number: KB0000903
  kb_category: Policy
  workflow_state: Published
  assignment_group: Service Desk L1
  visibility: internal
  contains_customer_safe_wording: false
---

# Incident Service Level Agreement Policy

## Record details

| Field | Value |
| --- | --- |
| Table | kb_knowledge |
| Number | KB0000903 |
| KB category | Policy |
| Workflow state | Published |
| Assignment group | Service Desk L1 |
| Visibility | internal |
| Contains customer-safe wording | false |

## Purpose

POL-SLA-001 defines the response and resolution service level agreements for incidents handled by the Nautilus Financial Systems internal ITSM support organization. SLA targets are driven by the incident priority assigned under REF-PRI-001, the incident priority matrix.

The SLA clock starts when the incident record is created. The response SLA is met when the incident is assigned to an analyst in the correct assignment group and the first meaningful triage note is recorded. The resolution SLA is met when the incident state is set to Resolved.

## SLA targets by priority

| Priority | Label | Response target | Resolution target | Update cadence |
| --- | --- | --- | --- | --- |
| 1 | Critical | 15 minutes | 4 hours | Every 30 minutes |
| 2 | High | 30 minutes | 8 hours | Every hour |
| 3 | Moderate | 2 hours | 24 hours | Every 4 hours |
| 4 | Low | 8 business hours | 5 business days | Daily |

Priority 1 and Priority 2 incidents on Tier 1 services are measured on a 24x7 clock. Priority 3 and Priority 4 incidents are measured against business hours, defined as 08:00 to 18:00 Eastern, Monday through Friday.

## Clock rules

The SLA clock pauses only in these states:

- Awaiting Caller: support is waiting on information that only the reporting user can provide.
- Awaiting Change: remediation requires a scheduled change and the owning group has recorded the change reference on the incident.

Reassignment between groups does not pause the clock. Time spent in the wrong assignment group counts against the SLA, which is why POL-ESC-001 requires Service Desk L1 to escalate quickly rather than exhaust diagnosis at L1.

## Breach handling

When a response or resolution SLA reaches 75 percent of its target, the platform issues a warning to the current assignment group manager. At 100 percent the SLA is marked breached and the incident is flagged for review.

Breached Priority 1 and Priority 2 incidents require a short SLA breach note on the incident explaining the cause of the delay. Repeat breaches on the same service should be raised to the service owner group and considered as input to problem management.

## Worked examples

- INC001104 (Priority 2, Identity Gateway): opened 2026-06-12T23:18:00, resolved 2026-06-13T03:45:00. Elapsed resolution time was 4 hours 27 minutes against an 8-hour target, so the resolution SLA was met and sla_breached is false.
- INC001217 (Priority 2, Payments Reporting Service): opened 2026-06-15T23:05:00, resolved 2026-06-16T04:15:00. Elapsed resolution time was 5 hours 10 minutes against an 8-hour target, so the resolution SLA was met.
- INC001302 (Priority 2, Internal API Gateway): opened 2026-06-18T21:05:00, resolved 2026-06-19T01:20:00. Elapsed resolution time was 4 hours 15 minutes against an 8-hour target, so the resolution SLA was met.

## Related records

- POL-ESC-001: Incident Severity and Escalation Policy.
- REF-PRI-001: Incident Priority Matrix.
- INC-1104, INC-1217, INC-1302: Priority 2 incidents measured under this policy.
