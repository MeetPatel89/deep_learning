"""Run concurrent SDK generations and scores, with optional managed prompts.

The default uses deterministic model-runtime adapters and needs only Langfuse
credentials. ``--live-models`` uses the OpenAI and Anthropic providers instead.
"""

from argparse import ArgumentParser
from asyncio import TaskGroup, run, sleep
from collections.abc import AsyncIterator
from os import environ, getenv
from pathlib import Path

from dotenv import load_dotenv
from langfuse import Langfuse
from langfuse.model import TextPromptClient
from model_runtime import (
    AnthropicAdapter,
    AnthropicProviderOptions,
    FinishReason,
    Message,
    ModelCapabilities,
    ModelRequest,
    ModelResponse,
    ModelRouter,
    ModelRuntime,
    OpenAIAdapter,
    OpenAIProviderOptions,
    StreamEvent,
    Usage,
)

from observability_ai import LangfuseSettings
from observability_ai.genai import langfuse_usage_details
from observability_ai.langfuse import (
    PromptRepository,
    Scorer,
    build_langfuse_client,
    propagate_attributes,
    start_as_current_observation,
)

_CAPTURE_MESSAGE_CONTENT_ENV = "OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT"


class _DemoModel:
    """Supply deterministic responses so local SDK verification needs no LLM key."""

    capabilities = ModelCapabilities(streaming=False)

    async def complete(self, model_id: str, request: ModelRequest) -> ModelResponse:
        """Yield once to exercise concurrent context and report sample usage."""
        await sleep(0)
        return ModelResponse(
            message=Message.assistant("A vector space supports addition and scaling."),
            usage=Usage(input_tokens=7, output_tokens=3, cached_tokens=2),
            finish_reason=FinishReason.STOP,
            model=model_id,
        )

    async def stream(
        self, model_id: str, request: ModelRequest
    ) -> AsyncIterator[StreamEvent]:
        """Reject streaming, which this completion-only example does not use."""
        raise NotImplementedError
        yield


def _captured_messages(request: ModelRequest) -> list[dict[str, str]] | None:
    """Return normalized text only when the shared capture flag opts in."""
    if getenv(_CAPTURE_MESSAGE_CONTENT_ENV, "").casefold() != "true":
        return None
    return [
        {"role": message.role.value, "content": message.text}
        for message in request.messages
    ]


async def _complete_generation(
    client: Langfuse,
    runtime: ModelRuntime,
    route: str,
    request: ModelRequest,
    *,
    prompt: TextPromptClient | None = None,
) -> ModelResponse:
    """Wrap one runtime call with a native generation and exclusive token usage."""
    model_id = runtime.router.resolve(route, request).model_id
    parameters: dict[str, str | int | float | bool | list[str] | None] = {}
    if request.temperature is not None:
        parameters["temperature"] = request.temperature
    if request.max_output_tokens is not None:
        parameters["max_tokens"] = request.max_output_tokens

    with start_as_current_observation(
        client,
        as_type="generation",
        name=f"chat {model_id}",
        model=model_id,
        input=_captured_messages(request),
        model_parameters=parameters,
        metadata={"route": route},
        prompt=prompt,
    ) as generation:
        response = await runtime.complete(route, request)
        generation.update(
            model=response.model or model_id,
            output=(
                response.text
                if getenv(_CAPTURE_MESSAGE_CONTENT_ENV, "").casefold() == "true"
                else None
            ),
            usage_details=langfuse_usage_details(
                input_tokens=response.usage.input_tokens,
                output_tokens=response.usage.output_tokens,
                cached_tokens=response.usage.cached_tokens,
            ),
        )
        return response


async def main() -> None:
    """Send concurrent generations and a completion score to local Langfuse."""
    parser = ArgumentParser(description=__doc__)
    parser.add_argument(
        "--live-models", action="store_true", help="call OpenAI and Anthropic providers"
    )
    parser.add_argument(
        "--prompt", help="existing Langfuse text prompt with {{question}}"
    )
    selector = parser.add_mutually_exclusive_group()
    selector.add_argument("--prompt-label", help="prompt label (default: production)")
    selector.add_argument("--prompt-version", type=int, help="positive prompt version")
    args = parser.parse_args()
    if (args.prompt_label or args.prompt_version is not None) and not args.prompt:
        parser.error("--prompt-label and --prompt-version require --prompt")

    root = Path(__file__).resolve().parents[1]
    load_dotenv(root / ".env")
    load_dotenv(root / "observability" / ".env")
    client = build_langfuse_client(LangfuseSettings.from_env())
    try:
        question = "What is a vector space?"
        prompt = (
            PromptRepository(client).get(
                args.prompt, label=args.prompt_label, version=args.prompt_version
            )
            if args.prompt
            else None
        )
        messages = (
            Message.system("Answer clearly and briefly."),
            Message.user(prompt.compile(question=question) if prompt else question),
        )
        requests: tuple[tuple[str, ModelRequest], ...]
        if args.live_models:
            router = (
                ModelRouter()
                .register("gpt", OpenAIAdapter(), environ["OPENAI_MODEL"])
                .register("claude", AnthropicAdapter(), environ["ANTHROPIC_MODEL"])
            )
            requests = (
                (
                    "gpt",
                    ModelRequest(
                        messages=messages,
                        timeout=30,
                        provider_options=OpenAIProviderOptions(),
                    ),
                ),
                (
                    "claude",
                    ModelRequest(
                        messages=messages,
                        timeout=30,
                        provider_options=AnthropicProviderOptions(),
                    ),
                ),
            )
        else:
            router = ModelRouter({"demo": (_DemoModel(), "demo-model")})
            requests = tuple(
                ("demo", ModelRequest(messages=messages)) for _ in range(2)
            )
        # SDK observations own these generations; no OTel runtime observer is added.
        runtime = ModelRuntime(router)
        with start_as_current_observation(
            client, as_type="span", name="example concurrent chat"
        ) as parent:
            trace_id = parent.trace_id
            with propagate_attributes(
                session_id="observability-ai-phase-3",
                user_id="example-user",
                tags=["observability-ai", "langfuse-sdk"],
                metadata={"approach": "langfuse-sdk", "phase": "3"},
                trace_name="example concurrent chat",
            ):
                async with TaskGroup() as tasks:
                    completions = [
                        tasks.create_task(
                            _complete_generation(
                                client, runtime, route, request, prompt=prompt
                            )
                        )
                        for route, request in requests
                    ]
                Scorer(client).score_current(
                    name="completed",
                    value=all(task.result().text for task in completions),
                    data_type="BOOLEAN",
                    comment="Both model-runtime completions returned text.",
                )
        client.flush()
        print(f"trace {trace_id}; inspect 'example concurrent chat' and its score")
    finally:
        client.shutdown()


if __name__ == "__main__":
    run(main())
