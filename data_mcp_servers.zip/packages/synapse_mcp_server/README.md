# synapse-mcp-server

Develop Synapse artifacts in Git, test branch snapshots in a configured development
workspace, prepare draft PRs, and operate published artifacts when live access is
explicitly enabled. Set `SYNAPSE_MCP_CONFIG` to a TOML file defining named workspaces.
SQL requires ODBC Driver 18.

From the workspace: `uv run --package synapse-mcp-server synapse-mcp-server`.

See the [workspace guide](../../README.md),
[example config](../../examples/synapse.toml) and
[MCP configuration](../../examples/mcp.json) for setup. Spark history/monitoring
HTTP endpoints remain best-effort.

## Permissions and migration

**Existing installations must set `allow_live_env = true` to retain previous live
behavior.** Artifact tools now default to `source="git"`. Live artifact operations
also require explicit `source="live"`. Missing Git artifacts never fall back to
published definitions.

| Operation | Required permissions/access |
| --- | --- |
| Git reads, analysis, diff, PR preparation | Repository read access |
| Feature-branch edits, commits, pushes, draft PR creation | `allow_git_write` |
| Studio HTTP branch debugging and associated results | `allow_run` |
| SDK branch staging, execution, monitoring, cleanup | `allow_live_env`, `allow_run`, `allow_manage` |
| Run a published pipeline (`run_pipeline`) | `allow_live_env`, `allow_run` |
| Live reads, monitoring, ARM, SQL reads, Spark inspection | `allow_live_env` |
| Live artifact writes / pool management | `allow_live_env`, `allow_manage` |
| Trigger, Spark, standalone data-flow debugging | `allow_live_env`, `allow_run` |
| Direct SQL writes | `allow_live_env`, `allow_sql_write` |

Flags default to false; backend selection grants no permissions. Toolset settings
apply too. Guards run before authentication/client access, including cached clients.
`list_workspaces` and the local execution journal require no Azure access. Branch
tests require a configured named profile and execute real activities against its
development connections. `allow_sql_write` separately governs direct SQL tools.

The collaboration branch, configured publish branch and `workspace_publish` are
protected from repository mutations. No tool merges PRs, publishes through Studio,
generates publish-branch templates, or stages/activates triggers.

## Configuration and repositories

Configure each workspace's `repository`: `local_path`, `github_repository`
(`owner/repository`), `github_token`, `artifact_root`, `collaboration_branch`,
`publish_branch` (default `workspace_publish`), `remote` (default `origin`), and
`default_backend` (`local` or `github`). No Azure discovery is required. Use
environment references such as `${SYNAPSE_GITHUB_TOKEN}` for credentials.

`local_path` is the checkout root; `artifact_root` is relative to it. Local reads
default to the current branch, GitHub reads to the collaboration branch. Writes
require an explicit feature branch. Other local branches use managed worktrees
under the Git common directory, retaining edits across restarts. An existing
checkout elsewhere is not taken over, and the user's branch is never switched.
Commits use Git identity configuration, bypass hooks and use a private index to
preserve unrelated staged changes. Supply `paths` to commit only selected artifacts.

GitHub uses authenticated REST for reads, branches and PRs and GraphQL
`createCommitOnBranch` with `expectedHeadOid` for atomic commits. GitHub edits
commit immediately to the selected feature branch. Its `commit_git_branch` accepts
a `changes` map of repository-relative artifact paths to JSON objects (null deletes).
Its push operation verifies that the commit is already remote. Configure repository
contents and PR permissions appropriate to the operations you enable.

Supported JSON directories: `pipeline`, `dataset`, `linkedService`, `notebook`,
`dataflow`, `sparkJobDefinition`, `sqlscript`, `trigger`, `integrationRuntime`,
`credential`. Tool type names use snake case. Libraries/unknown types, traversal,
symlinks, revision expressions and truncated GitHub trees are rejected. JSON is
retained, while tool results/diffs redact secrets. Snapshots are capped at 50 MiB.
Diffs and test claims cover Synapse artifact JSON, not unrelated repository files.

## Feature branch workflow

1. `list_git_branches` discovers heads; use `include_remote=true` for local remote
   heads. `create_git_branch` requires the inspected base `expected_revision`.
2. Read/search/analyze with `branch` and optional `repository_backend`.
   `upsert_artifact` / `delete_artifact` default to dry-run; apply with an explicit
   feature branch, `expected_revision` and `dry_run=false`.
3. `run_branch_pipeline` accepts `workspace`, `pipeline`, `branch`, optional
   `repository_backend`, `parameters`, `test_profile`, and `dry_run` (default true).
   `default_test_profile` can supply the profile. Local tests include uncommitted
   artifact files; GitHub tests read all blobs from one resolved commit.
4. Keep `execution_id`. Inspect with `get_branch_pipeline_run`,
   `get_branch_activity_results`, `wait_for_branch_pipeline_run`, and
   `diagnose_branch_pipeline_run`. Cancellation/explicit cleanup tools are
   `cancel_branch_pipeline_run` / `cleanup_branch_pipeline_run` (default dry-run).
   `list_branch_pipeline_runs` reads the journal. Debug IDs always use debug APIs.
5. Review `diff_git_branch`, then `commit_git_branch` and `push_git_branch`.
   Commits/pushes require `expected_revision`; pushes also require
   `expected_remote_revision` (empty string for a new branch). Stale heads and
   non-fast-forward pushes are rejected. Mutation tools default to dry-run.
6. `prepare_git_pr` generates a title/body targeting the collaboration branch.
   Recorded passes must match current artifact contents and the current test
   profile. Later edits invalidate the claim; committing identical tested contents
   preserves it. A separate `create_draft_pr` call requires an unchanged revision
   and committed/pushed contents. It creates a draft immediately when invoked.

Profiles contain `parameters`, `artifact_overrides` keyed by `artifact_type/name`,
`spark_pools`, and `integration_runtimes`. Overrides merge into artifact **properties**
in memory; lists/scalars replace the previous value. Repository files are unchanged.
Allow `AutoResolveIntegrationRuntime` explicitly for linked services using the
default runtime. Only listed existing pool/runtime bindings are permitted; those
runtime definitions are never staged. Provenance records the commit, repository
content hash, effective execution hash, parameters and profile hash.

Packages resolve child pipelines, datasets, linked services, notebooks and data
flows from that same snapshot. Missing, cyclic, dynamic and unsupported references
fail before deployment. Child invocations currently require `waitOnCompletion=true`.
Notebook source invoking other notebooks (`%run` / notebook utility `run` methods)
is rejected; use typed pipeline notebook activities. Unpublished notebooks require
an explicit pool. Parameterized notebook names are rejected under the
[documented Synapse restriction](https://learn.microsoft.com/en-us/azure/synapse-analytics/synapse-notebook-activity#known-issues).

## Studio HTTP: rollout prerequisite

`branch_execution_backend="studio_http"` is the default. The Python `httpx` adapter
uses existing Azure credential profiles and the Synapse token scope, without CLI
scripts or browser automation during execution.

**Authenticated integration validation remains outstanding. No real Studio protocol
capture ships with this implementation.** Transport tests use synthetic fixtures;
these do not establish compatibility with Studio. Without a sanitized authenticated
capture for the configured dev workspace, the adapter fails before authentication.
It never switches backends. The public
[create-pipeline-run API](https://learn.microsoft.com/en-us/rest/api/synapse/data-plane/pipeline/create-pipeline-run)
runs deployed pipelines by name and is not used for unpublished debugging.

Set `studio_http.contract_path` and `studio_http.contract_sha256`. The JSON contract
uses version `studio-debug-capture-v1` and contains:

- `validation.workspace` (actual name), `validation.authenticated_at` (ISO timestamp),
  and `supported_artifacts` (the types validated by the capture).
- `operations.submit`, `.status`, `.activities`, `.cancel`, each with `method`,
  captured relative `path`, optional `query` and JSON `body`, and sanitized
  `fixture.request` / `fixture.response`. Only dedicated debug paths are allowed.
  Run operations require `{run_id}` in the path; `{pipeline}` is also supported.
- Response mappings: submit `run_id_field`, status `status_field`, activities
  `items_field` and optional `continuation_field`. Dotted JSON field paths work.
- Optional `package_template` matching the captured layout. Whole-value placeholders:
  `$pipeline` (name), `$pipeline_definition`, `$parameters`, `$artifacts` (full
  type/name map), `$pipelines`, `$datasets`, `$linked_services`, `$notebooks`,
  `$data_flows`. Submission embeds it as `$package`. All dependency kinds and
  parameters must be included. Request bodies/queries also support `$run_id`,
  `$continuation`, `$recursive`.

Use actual captured routes/layout, not synthetic test routes. Changed digests,
missing response fields, unknown statuses and broken pagination fail explicitly.
Remove credentials, tokens, connection strings, business data and activity secrets
from captures before storing them. Existing executions retain their contract digest.

## SDK staging and recovery

Opt into `branch_execution_backend="sdk_staging"` and its three required permissions.
The complete package is validated before deployment, including SDK serialization.
Unique execution-specific names and consistently rewritten references isolate tests.
Name preflight, conditional creates, ownership annotations and conditional deletes
protect existing artifacts. Triggers are never staged.

`execution_store` defaults to `~/.local/state/synapse-mcp/executions.sqlite3`.
This owner-readable SQLite journal contains provenance, native IDs, ownership,
deployment intents, LRO continuation tokens and cleanup state. It can contain
unredacted inputs/staged definitions needed for recovery: keep it outside Git and
retain it until cleanup finishes. Tool responses redact secure parameters.

The lifespan monitor resumes recorded runs and pending cleanup after restart under
current permissions, without replaying submissions. Changed workspace endpoints
block access to old executions. Status/wait tools also clean up in reverse dependency
order once parent/child runs finish. Incomplete child results, unknown submissions,
missing ETags, uncertain creation outcomes and ownership changes retain artifacts
and report the reason. Cleanup stops at a failed dependent. A crash between Azure
accepting a request and recording its identifier requires operator reconciliation;
the server never guesses run IDs or force-deletes artifacts.

## Verification

`uv run --package synapse-mcp-server pytest packages/synapse_mcp_server/tests` uses
real temporary Git repositories, mocked GitHub HTTP, synthetic Studio contracts,
SDK mocks and regression tests. MCP stdio tests check tool schemas. Run
`uv run ruff check .` and `uv build --all-packages` for lint and builds.

Authenticated tests are marked `live` and excluded by default. Set
`SYNAPSE_MCP_CONFIG` and `SYNAPSE_MCP_LIVE_WORKSPACE` for the read-only smoke test.
Branch integration additionally requires `SYNAPSE_MCP_LIVE_BRANCH_TESTS=1`,
`SYNAPSE_MCP_LIVE_BRANCH`, `SYNAPSE_MCP_LIVE_PIPELINE`, and optionally
`SYNAPSE_MCP_LIVE_TEST_PROFILE`. Configure a pipeline/profile with a child pipeline,
notebook and data flow, an authenticated Studio contract, and the required
permissions. These opt-in tests execute both backends and verify protected heads
and existing published definitions. Run
`pytest -m live packages/synapse_mcp_server/tests/test_live.py`.
