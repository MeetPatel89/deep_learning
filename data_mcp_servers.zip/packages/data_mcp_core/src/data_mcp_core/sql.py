"""Azure SQL / Synapse interactive and token connections, serialized per connection."""

import atexit
import re
from collections.abc import Iterator
from dataclasses import dataclass, field
from datetime import date, datetime, time
from decimal import Decimal
from pathlib import Path
from threading import RLock
from typing import Any, Literal

import polars as pl
import sqlglot
from pydantic import BaseModel, ConfigDict, Field, model_validator
from sqlglot import exp

from data_mcp_core.auth import AuthProfile, odbc_token_attributes, profile_key


class SQLConnection(BaseModel):
    model_config = ConfigDict(extra="forbid", hide_input_in_errors=True)
    server: str | None = Field(default=None, min_length=1)
    database: str = Field(min_length=1)
    username: str | None = None
    driver: str = Field(default="ODBC Driver 18 for SQL Server", min_length=1)
    timeout: int = Field(default=30, gt=0)
    auth: Literal["interactive", "token"] = "interactive"
    auth_profile: AuthProfile = Field(default_factory=AuthProfile, exclude=True, repr=False)
    workspace: str | None = None
    pool: str | None = None

    @model_validator(mode="after")
    def resolve_server(self):
        if self.workspace:
            # QA can resolve a configured alias (including underscores) to the Azure name.
            if not re.fullmatch(r"[A-Za-z0-9_-]+", self.workspace):
                raise ValueError("Invalid Synapse workspace name")
            derived = (
                f"{self.workspace}-ondemand.sql.azuresynapse.net"
                if self.pool in {"serverless", "ondemand"}
                else f"{self.workspace}.sql.azuresynapse.net"
            )
            if self.server and self.server != derived:
                raise ValueError("server conflicts with workspace/pool endpoint")
            self.server = derived
        if not self.server:
            raise ValueError("Specify server or workspace")
        return self


class SQLSource(SQLConnection):
    type: Literal["sql"] = "sql"
    query: str | None = Field(default=None, min_length=1)
    query_file: Path | None = None

    @model_validator(mode="after")
    def exactly_one_query(self):
        if (self.query is None) == (self.query_file is None):
            raise ValueError("Specify exactly one of query or query_file")
        if self.query is not None and not self.query.strip():
            raise ValueError("query must not be blank")
        return self


@dataclass
class CachedConnection:
    connection: Any
    lock: RLock = field(default_factory=RLock)


_connections: dict[tuple, CachedConnection] = {}
_cache_lock = RLock()


def _open_connection(source: SQLConnection):
    try:
        import pyodbc
    except ImportError as error:
        raise RuntimeError(
            "SQL requires the ODBC runtime and Microsoft ODBC Driver 18 for SQL Server"
        ) from error
    options = {"timeout": source.timeout, "autocommit": True}
    if source.auth == "token":
        options["attrs_before"] = odbc_token_attributes(source.auth_profile)
    return pyodbc.connect(connection_string(source), **options)


def _escape(value: str) -> str:
    return "{" + value.replace("}", "}}") + "}"


def connection_string(source: SQLConnection) -> str:
    server = source.server
    if not server.lower().startswith("tcp:"):
        server = "tcp:" + server
    if "," not in server:
        server += ",1433"
    fields = [
        f"Driver={_escape(source.driver)}",
        f"Server={_escape(server)}",
        f"Database={_escape(source.database)}",
        "Encrypt=yes",
        "TrustServerCertificate=no",
    ]
    if source.auth == "interactive":
        fields.insert(3, "Authentication=ActiveDirectoryInteractive")
        if source.username:
            fields.append(f"UID={_escape(source.username)}")
    return ";".join(fields) + ";"


def get_connection(source: SQLConnection) -> CachedConnection:
    key = (
        source.server,
        source.database,
        source.username,
        source.driver,
        source.auth,
        profile_key(source.auth_profile) if source.auth == "token" else None,
    )
    with _cache_lock:
        if key not in _connections:
            connection = _open_connection(source)
            _connections[key] = CachedConnection(connection)
        return _connections[key]


def test_connection(source: SQLConnection) -> dict[str, Any]:
    cached = get_connection(source)
    with cached.lock:
        cached.connection.timeout = source.timeout
        cursor = cached.connection.cursor()
        try:
            result = cursor.execute("SELECT 1").fetchone()
            if result is None or result[0] != 1:
                raise RuntimeError("SQL connection did not return 1 for SELECT 1")
        finally:
            cursor.close()
    return {"connected": True, "server": source.server, "database": source.database}


def iter_sql_batches(source: SQLSource, batch_size: int) -> Iterator[pl.DataFrame]:
    if batch_size < 1:
        raise ValueError("batch_size must be positive")
    query = source.query
    if source.query_file is not None:
        query = source.query_file.read_text(encoding="utf-8-sig")
    if not query or not query.strip():
        raise ValueError("SQL query is empty")
    cached = get_connection(source)
    with cached.lock:
        cached.connection.timeout = source.timeout
        # Own the cursor so it is closed on completion or generator cancellation.
        cursor = cached.connection.cursor()
        try:
            emitted = False
            for frame in pl.read_database(
                query, cursor, iter_batches=True, batch_size=batch_size, infer_schema_length=None
            ):
                emitted = True
                yield frame
            if not emitted:
                if cursor.description is None:
                    raise ValueError("SQL query must return a tabular result set")
                dtype_map = {
                    bool: pl.Boolean,
                    int: pl.Int64,
                    float: pl.Float64,
                    str: pl.String,
                    bytes: pl.Binary,
                    date: pl.Date,
                    datetime: pl.Datetime("us"),
                    time: pl.Time,
                }
                schema = {}
                for description in cursor.description:
                    name, code = description[:2]
                    schema[name] = (
                        pl.Decimal(description[4] or 38, description[5] or 0)
                        if code is Decimal
                        else dtype_map.get(code, pl.Null)
                    )
                yield pl.DataFrame(schema=schema)
        finally:
            cursor.close()


def close_connections() -> None:
    with _cache_lock:
        for cached in _connections.values():
            with cached.lock:
                cached.connection.close()
        _connections.clear()


atexit.register(close_connections)


def ensure_read_only(query: str, allow_write: bool = False) -> None:
    """Fail closed on unparsed T-SQL, multiple statements, SELECT INTO and nested writes."""
    if not query.strip():
        raise ValueError("SQL query is empty")
    if allow_write:
        return
    explain = re.fullmatch(r"\s*EXPLAIN\s+(?:WITH_RECOMMENDATIONS\s+)?(.+)", query, re.I | re.S)
    if explain:
        ensure_read_only(explain[1])
        return
    try:
        statements = [node for node in sqlglot.parse(query, read="tsql") if node is not None]
    except sqlglot.errors.ParseError as error:
        raise PermissionError("SQL could not be classified as read-only") from error
    if len(statements) != 1 or not isinstance(
        statements[0], (exp.Select, exp.Union, exp.Intersect, exp.Except)
    ):
        raise PermissionError("Only a single read-only SELECT/WITH query is allowed")
    prohibited = (exp.DDL, exp.DML, exp.Command, exp.Into)
    if any(isinstance(node, prohibited) for node in statements[0].walk()):
        raise PermissionError("SQL writes are disabled (including SELECT INTO)")


def execute_sql(source: SQLConnection, query: str) -> dict[str, Any]:
    """Execute an explicitly authorized non-tabular SQL statement."""
    cached = get_connection(source)
    with cached.lock:
        cached.connection.timeout = source.timeout
        cursor = cached.connection.cursor()
        try:
            cursor.execute(query)
            if cursor.description is not None:
                return {
                    "rows": [
                        dict(zip([column[0] for column in cursor.description], row, strict=True))
                        for row in cursor.fetchmany(1000)
                    ]
                }
            return {"affected_rows": cursor.rowcount}
        finally:
            cursor.close()
