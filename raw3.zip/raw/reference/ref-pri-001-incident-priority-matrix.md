---
doc_id: REF-PRI-001
title: Incident Priority Matrix
doc_type: reference
service_id: null
owner_group: Service Desk L1
visibility: internal
status: active
created_at: "2026-05-12T09:00:00"
updated_at: "2026-06-20T09:00:00"
related_records:
  - POL-ESC-001
  - POL-SLA-001
  - INC-1104
  - INC-1217
  - INC-1302
source_facts:
  - support_groups
difficulty_tags:
  - severity-classification
  - reference-data
servicenow:
  table: kb_knowledge
  number: KB0000906
  kb_category: Reference
  workflow_state: Published
  assignment_group: Service Desk L1
  visibility: internal
  contains_customer_safe_wording: false
---

# Incident Priority Matrix

## Record details

| Field | Value |
| --- | --- |
| Table | kb_knowledge |
| Number | KB0000906 |
| KB category | Reference |
| Workflow state | Published |
| Assignment group | Service Desk L1 |
| Visibility | internal |
| Contains customer-safe wording | false |

## Purpose

REF-PRI-001 defines how incident priority is derived from impact and urgency. Priority is calculated, not chosen directly. Service Desk L1 sets impact and urgency during intake, and the platform derives priority from this matrix. SLA targets for each priority are defined in POL-SLA-001.

## Impact definitions

| Impact | Label | Definition |
| --- | --- | --- |
| 1 | High | An entire Tier 1 service is unusable for all users, or a regulatory or financial-close deadline is at risk. |
| 2 | Medium | A Tier 1 service is degraded or unavailable for a subset of users, business locations, or client tiers. |
| 3 | Low | A single user or a non-critical service is affected, or a documented workaround fully restores function. |

## Urgency definitions

| Urgency | Label | Definition |
| --- | --- | --- |
| 1 | High | Business work is blocked now, or the issue is actively visible to clients or many employees. |
| 2 | Medium | Business work is degraded but can continue with delay or manual effort. |
| 3 | Low | The issue can wait for scheduled handling without business harm. |

## Priority matrix

| Impact \ Urgency | 1 - High | 2 - Medium | 3 - Low |
| --- | --- | --- | --- |
| 1 - High | 1 - Critical | 2 - High | 3 - Moderate |
| 2 - Medium | 2 - High | 3 - Moderate | 4 - Low |
| 3 - Low | 3 - Moderate | 4 - Low | 4 - Low |

## Classification rules

- Tier 1 service incidents affecting multiple users must be classified with at least impact 2 and urgency 1, which yields at least priority 2 - High. This restates the rule in POL-ESC-001.
- Partial impact still counts. If some users can work and others cannot on a Tier 1 service, impact is 2, not 3.
- Urgency reflects timing, not scope. Client-visible errors and blocked business operations are urgency 1 even while scope is still being confirmed.
- Priority may be recalculated as scope evidence changes, but downgrades on Tier 1 services require agreement from the owning support group.

## Worked examples

- INC001104: Employee Portal login failures affected a subset of users on a Tier 1 service (impact 2) and blocked sign-in immediately (urgency 1), so priority is 2 - High.
- INC001217: Payments dashboard staleness affected payment operations reporting on a Tier 1 service (impact 2) with business users actively blocked on reconciliation (urgency 1), so priority is 2 - High.
- INC001302: Unexpected 429 errors affected Business-tier API clients on a Tier 1 service (impact 2) and were client-visible (urgency 1), so priority is 2 - High.
- INC008830: A follow-on ticket for one branch after remediation was underway was classified impact 2, urgency 2, priority 3 - Moderate.

## Related records

- POL-ESC-001: Incident Severity and Escalation Policy.
- POL-SLA-001: Incident Service Level Agreement Policy.
