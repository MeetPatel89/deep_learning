# Semantic-layer constitution for an enterprise NL-to-SQL application

Version 3.1 • 2026-09-27 • Catalog schema version 4 • Schema-independent planning edition

Companions: [implementation design](02-implementation-design.md) and [catalog schema](catalog-schema.sql). These three artifacts form the complete planning input; no earlier conversation, example database or separate guide is required.

## 1. Purpose, scope and authority

The semantic layer is the governed interface between business questions and executable queries. It defines meaning, populations, identity, grain, values, relationships, metrics and permitted operations. The application discovers and onboards actual source schemas after development begins. No particular company table, field, code, key, relationship or business definition is assumed here.

**Architecture:** React + TypeScript, HTTP/Python consumers and MCP hosts access the same modular Python application services. In managed mode, a durable LangGraph workflow retrieves authorized definitions using exact lookup, hybrid lexical/vector retrieval, reranking and a typed graph. The LLM proposes a typed semantic query. Deterministic resolvers, planners, validators and a compiler bind that proposal to approved definitions and produce parameterized SQL. Restricted source adapters execute sealed artifacts under current authorization. A catalog service owns persistent SQLite metadata and publishes immutable releases to read-only in-memory SQLite, retrieval projections and NetworkX graph projections. Catalog storage can later use PostgreSQL or Azure SQL without replacing the semantic model or runtime read format. A separate host-orchestrated mode lets an external MCP host compose semantic tools with its own agent loop; it requires neither React nor LangGraph, while shared deterministic services retain all execution safeguards.

Vector backend choices are **NumPy, Chroma, FAISS and Azure AI Search** behind one adapter contract. NumPy provides an in-memory exact-vector implementation for an admitted catalog size; FAISS is an index library; Chroma and Azure AI Search offer different deployment/service choices. They are alternative vector backends, not four mandatory running services. Lexical retrieval, embedding generation and reranking are separately configured. Azure SQL remains the initial business-query adapter; the model and source-adapter interfaces support subsequent systems through explicit implementation and testing.

`MUST` denotes an execution or release requirement. `SHOULD` denotes a recommendation whose exception requires a recorded rationale and evidence. `MAY` denotes an optional extension. These are requirements for the application to be built, not claims that an application is already deployed. Ordinary versioned schema migrations and new adapters/operators are expected as it matures.

## 2. Starting without a known company schema

Build platform contracts before concrete domain definitions. Source discovery collects names, types, constraints and dependencies into staging. Stewards then establish meanings, business keys, code mappings, relationship operations and expected answers for selected domains. Structural discovery and LLM suggestions provide evidence; neither automatically approves a business rule.

The catalog may inventory thousands of tables while only a small reviewed subset is queryable. Discover broadly only within authorized scope, then prioritize, model, evaluate, pilot and enable one domain or a small domain group at a time. Runtime coverage is the dependency-complete, approved content of a published release plus enabled capabilities and current access policy. Inventory size is not coverage.

Use neutral synthetic relations to test general properties such as duplicate identities, history versions, absent matches, ambiguous paths and fanout. These are test fixtures, never default production definitions. Actual identities, thresholds, deployment limits and business rules remain explicit discovery inputs. An unapproved or unavailable definition produces a coverage gap or clarification, never a guessed SQL rule.

## 3. Foundational commitments

| ID | What is required | Why |
|---|---|---|
| C01 | Establish population, identity, output grain and metric before compilation. | Valid SQL can answer a different question. |
| C02 | Reference stable semantic IDs; bind physical names separately. | Renames and source migrations should not rewrite meaning. |
| C03 | Resolve labels to authoritative records and typed bindings. | Similarity scores do not establish a stored value. |
| C04 | Select approved relationship operations; the compiler owns SQL form. | A plausible join can remove records or multiply measures. |
| C05 | Treat missing definitions and ambiguous meaning explicitly. | Unknown assumptions cannot support trustworthy answers. |
| C06 | Enforce access before retrieval/context, during resolution, and at execution/result delivery. | Metadata and candidate values can disclose protected information. |
| C07 | Record exact service-owned catalog, mapping, model, retrieval and compiler versions; mark unavailable external-host model/prompt provenance as unknown. | Answers must be attributable without claiming control over an external harness. |
| C08 | Test population, grain, null, duplicate, temporal and policy behavior. | Parsing success alone proves little. |
| C09 | Reference centrally implemented predicates and metrics by ID. | Reconstructing the same rule repeatedly permits drift. |
| C10 | Use a typed relational plan and versioned capability registry. | Expressiveness can expand while guarantees remain explicit. |
| C11 | Support hybrid retrieval, reranking and graph dependency expansion in the production platform. | Business wording and physical structure often differ. |
| C12 | Pin a complete compatible manifest; evaluate authorization live. | Independent projections must not mix releases; revocations must take effect. |
| C13 | Persist service-owned production request/workflow state and bound retries, cost and execution. | Clarifications, restarts and long queries require durable service state; external host history has a separate owner. |
| C14 | Release domains and operators through measured acceptance gates. | Broad discovery does not establish useful, correct coverage. |
| C15 | Author metadata through authenticated, reviewed service transactions. | A hidden UI control cannot enforce stewardship authority. |
| C16 | Keep storage and retrieval providers behind tested interfaces. | Capacity changes should not require replacing business meaning or the compiler. |
| C17 | Separate semantic contracts/services from presentation, transport, models and agent harnesses; expose reusable HTTP/Python/MCP interfaces. | The same governed capabilities must work in the full application and compatible external hosts without copying or bypassing rules. |

## 4. Components: what, why, contents and enforcement

### 4.1 Domains and business concepts

**What:** a business domain owns a scope of meaning and stewardship. A concept supplies a stable definition, label, synonyms and links to relevant semantic objects.

**Why:** the same term can denote different populations or conditions in different domains. A global alias must not collapse those meanings.

**Contents:** semantic ID, definition, owner, domain memberships, aliases/vocabulary, access policy reference, provenance, lifecycle and coverage. Domains may share objects through explicit memberships and ownership rules.

**Enforcement:** publication detects ambiguous vocabulary; runtime routing retains plausible authorized alternatives. A label alone cannot establish a predicate, metric or physical code. `business_domain`, `semantic_concept`, `domain_membership` and `catalog_object` persist these records.

### 4.2 Entities, bindings, business identity and grain

**What:** an entity is a semantic relation bound to an approved source object or typed derived plan. Grain describes precisely what distinguishes one represented unit from another. Physical row identity, business identity and version identity are separate declarations.

**Why:** a surrogate primary key can distinguish ingestion rows while several rows represent the same business entity. “One row per record” is insufficient to justify a business count.

**Contents:** physical-row key fields; business identity fields or an authoritative business-ID mapping; identity namespace; version/effective-time fields; current/as-of selection; normalization and null-key rules; uniqueness and nonoverlap evidence; source binding, owner and policy. Keys may be composite. A surrogate may serve as business identity only when its one-to-one business meaning is established.

**Enforcement:** source-row counts, distinct business counts, current entities, events and historical versions are separately named units. The planner propagates unit and multiplicity at each operation. Required uniqueness must have sufficient current evidence; a sampled profile is not a universal uniqueness proof. Missing identity/history rules disable affected operations. The compiler cannot repair uncertainty with arbitrary `DISTINCT`, key concatenation or “latest row” selection. Persist through `entity`, `field`, `data_source` and `assertion`.

### 4.3 Fields, dimensions and null semantics

**What:** a field binds a semantic attribute to an allowed physical column or typed expression; dimensions support filtering, grouping and description.

**Why:** physical data types alone do not explain units, sensitivity, business synonyms, valid comparisons or the meaning of missing values.

**Contents:** parent entity, physical and semantic types, roles, label/description, aliases, permitted operators, optional value domain, null meaning, normalization, lineage and sensitivity.

**Enforcement:** comparisons and projections must respect types and policy. Null, empty string, unknown code and absent fact are distinct unless an approved rule equates them. SQL identifiers are selected from approved bindings and quoted, never accepted as arbitrary text from a model. `field` plus `catalog_object` supplies these facts.

### 4.4 Canonical values, aliases and bindings

**What:** a value domain owns canonical members. Each member can map to one or more typed literals per source field and validity interval. Large dynamic domains may resolve through authorized indexed providers.

**Why:** one label can have different encodings across systems; a source encoding can also change over time. Retrieving a plausible word does not establish a database literal.

**Contents:** canonical ID and meaning, domain, curated aliases, source field, literal type/value, completeness requirements, effective intervals, provider revision/freshness and visibility.

**Enforcement:** try exact code, normalized name and curated alias lookup first. Lexical/vector search and reranking supply candidates when needed. Fetch authoritative records before issuing an opaque, access-bound resolved-value handle. Missing coverage for any required source is an error, not permission to omit that branch. An LLM-generated literal cannot replace resolution. Record ambiguous/not-found/stale/not-authorized outcomes explicitly. `value_domain`, `canonical_value`, `value_alias` and `value_binding` persist small governed domains; provider contracts govern larger ones.

### 4.5 Named predicates and time rules

**What:** a predicate is a reusable typed condition, optionally parameterized, with a precise business meaning and applicable entity. It can combine field comparisons, value handles, time rules and approved subqueries.

**Why:** asking the model to reconstruct status, dates and exceptions on each request creates opportunities for different implementations of the same meaning. Central ownership allows consistent execution and review.

**Contents:** ID, discoverable definition/aliases, parameter schema within the expression contract, typed expression, dependencies, entity scope, timezone/calendar/effective-time policy, exceptions and tests. Distinguish business conditions from mandatory source/security restrictions.

**Enforcement:** `predicate.expression_json` uses a versioned typed expression language, not arbitrary SQL. Retrieval helps select the right predicate; deterministic code expands its approved definition. Similar names do not imply identical rules. A definition using OR has different meaning from one using AND; only an owner-approved expression can decide. Source/security restrictions are injected by trusted services and cannot be removed by a proposal.

### 4.6 Relationship correspondence and operation contracts

**What:** a relationship records how two semantic relations correspond. An operation states how that correspondence may be used: existence, absence, preserving enrichment, expansion, temporal lookup or governed bridge allocation.

**Why:** matching keys, cardinality and mandatory join behavior are different facts. Preserving every qualifying parent does not imply one output row per parent when children expand.

**Contents:** directed endpoint roles, namespace-qualified composite key pairs, directional cardinality, null handling, temporal conditions, required predicates, evidence, operation purpose, preservation, filter placement, output grain and allowed aggregation consequences.

**Enforcement:** `relationship` persists correspondence; `relationship_operation.contract_json` defines each permitted use. Preserving enrichment MUST retain unmatched base rows and cannot be rewritten to an inner join or defeated by a null-rejecting target WHERE filter. Existence qualifies the outer population without multiplying it. Enrichment requires at-most-one matching target under the complete key/time/filter condition; expansion changes grain explicitly. Reversing a relationship does not inherit its operation rules. Many-to-many attribution needs a reviewed allocation rule. Neither matching names nor shortest graph paths authorize a join.

### 4.7 Populations, cohorts and derived relations

**What:** a population defines eligible base units; a cohort is a reusable population definition. A derived entity or query template can express approved combinations.

**Why:** eligibility evidence and output detail are different operations. Joining qualifying evidence directly into a count can multiply the counted units.

**Contents:** base identity/unit, predicates, related existence/absence conditions, time scope, set/duplicate semantics and dependencies.

**Enforcement:** represent membership and nonmembership explicitly in the typed plan. Define union/intersection compatibility and deduplication by approved identity. Cohorts use `predicate`, `entity.derived_plan_json` or `query_template`; no separate arbitrary-SQL escape hatch is implied.

### 4.8 Metrics and aggregation

**What:** a metric defines what is counted or measured, at which population and grain, in which unit and time frame.

**Why:** row count, non-null field count and distinct business-identity count differ. Joining multiple raw fact relations can inflate independent measures.

**Contents:** base entity, aggregate expression, counted identity, null treatment, unit, population, allowed dimensions, additivity, attribution and time/calendar semantics. Ratios carry numerator/denominator definitions; distinct composite keys have explicit equality/null rules.

**Enforcement:** `metric.definition_json` is typed and dependency-checked. The planner prevents unsafe fanout and reaggregation. Independent facts generally aggregate to a common approved grain before combination. A faster plan cannot change the metric definition. Required attribution/history operators must be enabled and tested for the domain.

### 4.9 Typed query intent and capability registry

**What:** a semantic query is a structured proposal referencing semantic IDs, typed operations, values, relationships, time and desired output. A validated logical plan binds it to authoritative definitions; a compiled artifact carries executable SQL and parameters.

**Why:** an intermediate contract makes errors explicit and permits deterministic enforcement without constraining the product to a few hardcoded question templates.

**Contents:** versioned discriminated-union schemas, node IDs/references, operator inputs/outputs, capability requirements, requested grain, resolved value handles and lineage. Pydantic is the Python validation implementation; OpenAPI/JSON Schema supplies matching frontend contracts.

**Enforcement:** reject unknown fields, arbitrary SQL fragments, incompatible types, unknown IDs, unavailable capabilities and unresolved ambiguity. Strict structural typing does not prove business correctness; semantic validation, clarification and evaluation remain necessary. `capability` and `domain_capability` declare tested support; they do not dynamically load executable code from metadata.

### 4.10 Retrieval, examples and procedural context

**What:** exact lookup, lexical search, vectors and reranking identify candidate definitions. Graph expansion includes necessary bridges and dependencies. Approved examples explain intent; skills can package how to use tools.

**Why:** a large schema cannot all fit in a prompt, and the most relevant-looking table may omit a required relationship or policy dependency.

**Contents:** authorized, release-scoped object documents, aliases, concise meaning/grain, required IDs, approved example plans and results, bounded retrieval budgets and explicit ambiguity handling.

**Enforcement:** rehydrate exact records from `CatalogReader` before planning. Search scores are not semantic proof or permission. Measure complete-set recall and downstream answer correctness. `verified_example` includes an access policy and review state; reference SQL is evaluation material, not executable user input. Skills and retrieved documents cannot override service policy or authorize SQL. Repeated business rules belong in predicates/metrics/templates rather than copied example SQL.

### 4.11 Deterministic planning, compilation and validation

**What:** trusted services bind values/IDs/time, choose permitted operations, propagate grain, apply restrictions, compile a closed relational algebra and verify its SQL AST.

**Why:** instructions to an LLM cannot guarantee population preservation, join policy, value correctness or source access.

**Contents:** operator contracts, source/dialect adapters, parameter typing, identifier allowlists, evidence requirements, query budgets and sealed artifact identity.

**Enforcement:** the normal executor accepts only an authorized sealed artifact. Models cannot submit raw executable SQL. Every physical scan, relationship and predicate must be accounted for. A parser checks structure; actual target-engine tests establish dialect/runtime behavior. Unsupported semantics produce a clear capability gap or reviewed extension, never a fallback to unrestricted generation.

### 4.12 Security and execution controls

**What:** current identity and policy constrain metadata, values, model context, source data, results, exports and administration.

**Why:** a read-only SQL connection alone does not prevent metadata disclosure, expensive workloads or result leakage.

**Contents:** verified identity, server-created access scope, source-side permissions/restrictions, field sensitivity, role grants, artifact expiry, workload limits, tenant isolation, audit and retention.

**Enforcement:** query authorization and catalog stewardship are separate privileges. A steward cannot access arbitrary business rows by editing metadata. Enforce at service and source boundaries, recheck after pauses and before execution/result delivery, and invalidate caches on revocation. UI visibility is convenience only. Neither a pinned release nor a persisted checkpoint freezes an access grant.

### 4.13 Evidence, freshness and explanation

**What:** evidence records why a rule is believed, its scope and expiry; provenance records source/owner/revision. Answers report the executed population, unit, filters and completeness.

**Why:** approved definitions can become incompatible with source changes; reproducibility needs more than SQL text.

**Contents:** constraint/profile/owner evidence, measured population and sampling method, fingerprints, validity, source observation time, request/manifest/model/compiler identity and result truncation status.

**Enforcement:** `assertion` declares required evidence and failure actions. Expired or violated critical evidence disables affected operations until revalidated. Version pinning recreates definitions, not necessarily historical source rows; record source consistency/snapshot guarantees separately. Do not claim a paged or truncated result is complete.

### 4.14 Publication, versions and canonical ownership

**What:** drafts become immutable semantic releases after review and evaluation. A manifest binds compatible catalog, retrieval, graph, application, prompt/model and compiler artifacts.

**Why:** an index updated before its matching definitions can return incompatible IDs; uncontrolled parallel publication can erase another domain's changes.

**Contents:** release/edit revision, canonical content digest, base manifest, review decisions, exact evaluation identity, projection checksums, selected retrieval profile, outbox and active-manifest pointer.

**Enforcement:** edits invalidate reviews tied to earlier content. Freeze and dispatch projection builds through an atomic authority/outbox transaction. Build artifacts outside the transaction, validate them, then activate with compare-and-swap against the expected prior manifest. Stale draft branches rebase and repeat affected review/gates. Hashes exclude their own fields, operational control rows and volatile authoring metadata. Snapshot files contain approved semantic records only; control rows and credentials remain outside. Publication lifecycle is application logic backed by transactions, not guaranteed by foreign keys alone.

### 4.15 Steward UI and alternative authoring channels

**What:** a restricted catalog area in the React + TypeScript frontend supports discovery triage, domain onboarding, metadata editing, mapping, relationship/predicate/metric authoring, evaluation, diff review and publication. Bulk import, APIs and metadata connectors remain supported.

**Why:** selected team members need accountable editing without database access, and all authoring channels must apply the same rules.

**Contents:** verified identity-provider subjects/groups; viewer, author, reviewer, publisher and administrator roles; catalog/domain scope; change sets, exact reviewed revisions, immutable review/audit history and job status. Advanced expression editing validates the same typed schemas as guided forms.

**Enforcement:** CatalogService authorizes every read/mutation, validates allowed domain changes, uses optimistic revisions and appends audit events in the same transaction. Authors do not approve their own changes by default; a smaller team's exception requires an explicit governed policy. Domain grants do not permit changing shared dependencies without their ownership permissions. Publishing executes approved changes only. Importing a file or accepting an AI suggestion never bypasses review. `catalog_role_binding`, `catalog_change_set`, `catalog_review`, `catalog_audit_event` and `evaluation_run` persist the workflow.

### 4.16 Discovery and incremental domain coverage

**What:** `discovery_run` and `discovered_asset` stage structural facts and suggestions; `domain_onboarding` tracks the work backlog. Published `business_domain.coverage_json` and `domain_capability` describe runtime coverage.

**Why:** companies can discover a large schema long before they have approved its meaning. A staged rollout makes useful coverage and remaining uncertainty measurable.

**Contents:** connector/source fingerprints, approved discovery scope, triage state, owners, prioritized question families, dependency closure, evidence gaps, pilot participants, domain acceptance criteria and release references.

**Enforcement:** promotion creates draft definitions. Runtime retrieval excludes staged assets and unapproved suggestions. Each domain passes semantic, retrieval, source-engine, security and operational gates; cross-domain paths require approval of their combined semantics. Backlog status alone cannot enable runtime queries. Track supported-question coverage separately from accuracy so widespread refusals cannot disguise poor usefulness.

### 4.17 Search/graph providers and durable storage

**What:** persistent SQLite is the initial metadata authority; published SQLite readers serve exact lookup. Configurable vector/lexical/reranker adapters and NetworkX provide immutable projections of approved metadata.

**Why:** metadata authority, search, graph traversal and workflow state have different operations and scaling limits. Their storage choices must be independently replaceable.

**Contents:** `retrieval_profile` pins backend selection, embedding model/configuration, dimensions, metric, normalization, fusion, reranker and filtering contract. Projection descriptors pin all component hashes and object-ID mappings. NumPy/FAISS files require durable artifacts and checksums; an in-memory matrix alone is not persistence.

**Enforcement:** the same semantic IDs and authorized-retrieval contract apply across NumPy, Chroma, FAISS and Azure AI Search. No implicit backend/model substitution. Test filter semantics, score conventions, release isolation and rebuild/recovery. Graph edges are stored canonically as relational records and projected into a typed multigraph; a graph database is optional. Migrate authority to PostgreSQL/Azure SQL or graph/search infrastructure when measured capacity, concurrency, availability or deployment requirements justify it.

### 4.18 Durable workflows, reliability and evaluation

**What:** the managed workflow uses LangGraph for durable request state, clarification and bounded repair; an external host may instead own the agent loop through the component tool interface. Deterministic services remain independently callable/testable. Execution workers enforce admission, cancellation and retry reconciliation.

**Why:** model interpretation may need several steps; failures and duplicate deliveries must not create uncontrolled source work or bypass policy.

**Contents:** versioned state, separate checkpoint store, request/attempt/artifact IDs, execution ledger, budgets, deadlines, recovery procedures, redacted traces, held-out evaluations and source-engine fixtures.

**Enforcement:** repeated transitions must be idempotent where required; external effects have durable IDs and reconciliation. Initial single-host SQLite checkpoints must pass their own workload/recovery gates; their scaling decision is independent of catalog storage. The first production domain requires observed security, semantic, retrieval, compiler, restart, backup/restore and rollback results. A successful local metadata DDL check is not evidence of production application readiness.

### 4.19 Composability, harness independence and MCP

**What:** contracts, semantic rules, application use cases, orchestration, transports and infrastructure adapters are separately testable modules. React is one user interface; HTTP, Python and MCP are entry adapters over the same authorized application facade. An MCP server exposes a selected composition of capabilities to an external host/client.

**Why:** reusing the enterprise platform in another host must not require rebuilding metadata retrieval, joining rules, value resolution, query compilation or source controls. Transport compatibility alone cannot enforce semantics or make two different agent loops identical.

**Contents:** typed component ports, dependency injection, optional provider/workflow/transport packages, versioned application/tool contracts, managed versus host-controlled modes, composition profiles, principal-bound contexts/artifacts, bounded job/clarification protocols and a tested host compatibility matrix.

**Enforcement:** core modules MUST NOT depend on React, MCP, HTTP or LangGraph types. Component-only deployments MUST function without the managed workflow package. Managed-flow MCP tools MUST call the same workflow as the web application when identical orchestration is required. Host-controlled tools MUST use the same resolvers/planner/compiler/policy/execution services; changing tool order cannot skip validation or authorize raw SQL. Every usable composition includes the dependency closure required for its guarantees.

Current authorization, egress policy, quotas and artifact validation apply across every adapter. An external host identity string or tool-supplied principal is not authentication. External hosts/models receive only information permitted for that approved channel. Context/job/handle state is durable operational data separate from MCP transport sessions and semantic definitions. Model/prompt provenance unavailable from an external host is recorded as unknown, not falsely pinned. Ordinary tool-based clarification and job polling provide the compatibility path; optional protocol features may improve it.

Test minimal package installations, import boundaries, HTTP/Python/MCP semantic parity, direct use without React/LangGraph, managed workflow reuse, role/handle/revocation negatives and each advertised host/version combination. Optional resources, prompts and Agent Skills may guide procedure; services remain authoritative. [MCP architecture](https://modelcontextprotocol.io/docs/learn/architecture)

## 5. Component-to-schema accountability

| Concern | Metadata tables | Additional required service responsibility |
|---|---|---|
| Release and object identity | `catalog_release`, `catalog_object` | Kind validation, lifecycle, stable ID rules and revision concurrency |
| Source/entity/field meaning | `data_source`, `entity`, `field` | Discovery verification, key/grain/type/source-policy validation |
| Canonical values | `value_domain`, `canonical_value`, `value_alias`, `value_binding` | Ambiguity, complete binding coverage, validity and resolved handles |
| Relationships | `relationship`, `relationship_operation` | Cardinality evidence, operation rules, graph projection and planner enforcement |
| Reusable semantics | `predicate`, `metric`, `query_template` | Typed DSL validation, dependency resolution and compiler support |
| Evidence and examples | `assertion`, `verified_example` | Evidence freshness, example access, fixtures and expected-result verification |
| Domains and graph context | `business_domain`, `domain_membership`, `semantic_concept`, `semantic_edge` | Coverage, typed edges, dependency closure and no inferred-join authority |
| Query capabilities | `capability`, `domain_capability` | Versioned executable operator registry and per-domain enablement |
| Retrieval selection | `retrieval_profile` | Valid adapter/configuration combinations, authorization-aware retrieval and compatibility tests |
| Publication control | `projection_artifact`, `release_manifest`, `active_manifest`, `publication_outbox` | Immutable artifacts, readiness, idempotency, hash checks and activation CAS |
| Stewardship control | `domain_onboarding`, `catalog_role_binding`, `catalog_change_set`, `catalog_review`, `catalog_audit_event`, `evaluation_run` | Live roles, workflow transitions, exact revision review, audit and release gates |
| Discovery staging | `discovery_run`, `discovered_asset` | Authorized connectors, isolated suggestions, triage and reviewed promotion |

Harness adapters and active query-context/job state require no host-specific semantic tables; deployment/operational stores own them. Existing `release_manifest.application_config_json` can bind compatible semantic API/tool contracts. The bootstrap has 35 tables. Foreign keys and checks enforce portions of structural integrity. JSON syntax checks do not validate the expression language or business meaning. Runtime requests, LangGraph checkpoints, execution ledgers, source business rows and full result sets are intentionally outside the catalog schema. Migrations, API code, workers and operational setup remain implementation work.

## 6. Production acceptance and phased maturity

The implementation plan MUST trace constitutional requirements to services, payload schemas, persistence records, tests and release gates. It MUST distinguish platform completion, domain coverage, optional provider deployment and tested harness/composition support.

1. **Foundation:** define typed contracts, security boundaries, synthetic invariants, steward workflow, reusable component/transport ports, MCP contracts, provider ports, source discovery and representative workload targets. No production business meaning is invented.
2. **First domain:** deliver the complete reviewed authoring/publication/query path with SQLite, the selected retrieval profile, graph planning, durable orchestration, deterministic compilation, source restrictions and evaluation. Deliver shared HTTP/Python/MCP entry points with managed and host-controlled composition profiles; each advertised host requires integration evidence. Implement the four selectable vector adapters with optional dependencies and per-provider readiness checks; provision only those selected for deployment. A provider is advertised as available only after its applicable conformance/integration checks pass.
3. **Broader coverage:** onboard more domains and reviewed cross-domain paths; expand capabilities through tested operators and templates. Retain existing-domain regression gates.
4. **Scale:** change storage/provider deployment when observed needs justify it; preserve IDs, payload semantics, published contracts and compiler boundaries. Reevaluate retrieval quality after any embedding/index change.

Acceptance includes complete-definition retrieval, correct identity/counts, null/temporal/fanout negatives, source-engine results, authorization/revocation, current-policy resumption, conflicting steward edits, review invalidation, stale publication bases, backend filtering, release isolation, recovery, workload limits, modular-package boundaries, cross-entry-point semantic parity and supported-question coverage. Record assumptions and operational limits rather than promising universal accuracy or unlimited scale.

The detailed design specifies these contracts and the planning handoff. Technology integrations must be pinned and rechecked against official documentation during implementation; the constitution governs their responsibilities rather than a particular library API version.
