"""Tool-independent orchestration with full accounting and atomic run directories."""

import json
import shutil
import tempfile
from pathlib import Path
from typing import Any

from data_mcp_core.results import json_safe, redact

from qa_mcp_server.engine.compare import STATUSES, common_dtype
from qa_mcp_server.engine.partition import execute_plan
from qa_mcp_server.engine.planner import load_and_plan
from qa_mcp_server.models import CompareOptions, DatasetSource, OutputOptions
from qa_mcp_server.report.excel import ExcelWriter, ParquetWriter
from qa_mcp_server.sources import iter_batches


def inspect(source: DatasetSource, sample_size: int = 5) -> dict[str, Any]:
    if not 0 <= sample_size <= 100:
        raise ValueError("sample_size must be between 0 and 100")
    types = {}
    rows = 0
    sample = []
    for frame in iter_batches(source):
        rows += frame.height
        for column, dtype in frame.schema.items():
            types.setdefault(column, []).append(dtype)
        if len(sample) < sample_size:
            sample.extend(frame.head(sample_size - len(sample)).to_dicts())
    return {
        "row_count": rows,
        "schema": {
            column: str(
                dtypes[0] if all(dtype == dtypes[0] for dtype in dtypes) else common_dtype(dtypes)
            )
            for column, dtypes in types.items()
        },
        "sample": json_safe(sample),
    }


def compare(
    expected: DatasetSource,
    actual: DatasetSource,
    options: CompareOptions | None = None,
    output: OutputOptions | None = None,
) -> dict[str, Any]:
    options, output = options or CompareOptions(), output or OutputOptions()
    root = output.output_dir.expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    directory = Path(tempfile.mkdtemp(prefix="comparison_", dir=root))
    excel = None
    try:
        with tempfile.TemporaryDirectory(prefix="qa_compare_") as scratch:
            temporary = Path(scratch)
            plan = load_and_plan(expected, actual, options, temporary / "raw")
            columns = list(plan.schema)
            excel = ExcelWriter(directory, columns, options.primary_keys or [], output)
            dump = ParquetWriter(directory, plan.schema)
            summary = {
                "mode": "keyed" if options.primary_keys else "multiset",
                "expected_source": redact(expected.model_dump(mode="json", exclude={"rows"})),
                "actual_source": redact(actual.model_dump(mode="json", exclude={"rows"})),
                "expected_row_count": plan.expected.row_count,
                "actual_row_count": plan.actual.row_count,
                "counts": dict.fromkeys(STATUSES, 0),
                "mismatches_per_column": {
                    c: 0 for c in columns if c not in (options.primary_keys or [])
                },
                "duplicate_key_rows": {"expected": 0, "actual": 0},
                "schema_differences": sorted(plan.schema_difference),
                "comparison_schema": {c: str(dtype) for c, dtype in plan.schema.items()},
                "partitioned": plan.partitioned,
                "num_partitions": plan.partitions,
                "disk_fallback_buckets": 0,
                "compare_options": options.model_dump(mode="json"),
                "output_options": output.model_dump(mode="json"),
                "sample_mismatches": [],
            }
            for record in execute_plan(plan, options, temporary / "partitions", summary):
                if record.status == "duplicate_key":
                    summary["duplicate_key_rows"][record.side] += 1
                else:
                    summary["counts"][record.status] += record.occurrences
                    for column in record.mismatch_columns:
                        summary["mismatches_per_column"][column] += record.occurrences
                    if record.status != "matched" and len(summary["sample_mismatches"]) < 10:
                        summary["sample_mismatches"].append(json_safe(record.as_dict()))
                dump.write(record)
                excel.write(record)
            counts = summary["counts"]
            paired = counts["matched"] + counts["mismatched"]
            if (
                paired + counts["missing_in_actual"] != plan.expected.row_count
                or paired + counts["extra_in_actual"] != plan.actual.row_count
            ):
                raise RuntimeError(
                    "Comparison completeness check failed: input rows were lost or duplicated"
                )
            summary["completeness_verified"] = True
            dump.finish()
            summary["report_files"] = [str(path) for path in excel.paths]
            summary["mismatch_parquet_path"] = str(dump.directory)
            summary["report_rows_written"] = excel.total_rows
            summary["report_rows_omitted"] = excel.omitted_rows
            summary["report_truncated"] = excel.omitted_rows > 0
            summary["summary_file"] = str(directory / "summary.json")
            excel.finish(summary)
            (directory / "summary.json").write_text(
                json.dumps(summary, indent=2, ensure_ascii=False, allow_nan=False),
                encoding="utf-8",
            )
            return summary
    except BaseException:
        if excel is not None:
            excel.close()
        shutil.rmtree(directory)
        raise
