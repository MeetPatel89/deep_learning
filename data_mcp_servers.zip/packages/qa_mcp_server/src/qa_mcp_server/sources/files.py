"""Backward-compatible file sources backed by the shared format registry."""

from collections.abc import Iterator

import polars as pl
from data_mcp_core.formats import iter_file_batches as core_batches
from data_mcp_core.stores import resolve_path

from qa_mcp_server.config import get_config
from qa_mcp_server.models import CSVSource, ExcelSource, FileSource, ParquetSource


def iter_file_batches(
    source: CSVSource | ParquetSource | ExcelSource | FileSource, batch_size: int
) -> Iterator[pl.DataFrame]:
    config = get_config()
    resolved = resolve_path(
        source.path,
        store=source.store,
        stores=config.stores,
        auth_profiles=config.auth_profiles,
        allowed_local_roots=config.allowed_local_roots,
    )
    if isinstance(source, FileSource):
        options = dict(source.options)
        if source.version is not None:
            options["version"] = source.version
        if source.timestamp is not None:
            options["timestamp"] = source.timestamp
        format = source.format
    else:
        options = source.model_dump(exclude={"type", "path", "store"})
        format = source.type
    yield from core_batches(resolved, batch_size, format, options)
