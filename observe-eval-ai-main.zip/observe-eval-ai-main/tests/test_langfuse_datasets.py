"""Verify local datasets and explicit SDK dataset operations without networking."""

from dataclasses import FrozenInstanceError
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, cast
from unittest.mock import Mock

from pytest import importorskip, mark, raises

importorskip("langfuse", reason="requires observe-eval-ai[langfuse]")

from langfuse import Langfuse  # noqa: E402
from langfuse.api import DatasetItem  # noqa: E402

from observability_ai.langfuse import (  # noqa: E402
    DatasetItemRecord,
    DatasetRepository,
    load_jsonl,
)


def test_dataset_operations_preserve_native_results_and_version() -> None:
    """Fetch timestamps and creation metadata reach the supplied SDK client."""
    client = Mock(spec=Langfuse)
    repository = DatasetRepository(client)
    version = datetime(2026, 9, 1, tzinfo=UTC)
    assert repository.get("qa", version) is client.get_dataset.return_value
    client.get_dataset.assert_called_once_with("qa", version=version)
    assert repository.create("qa", "questions", {"team": "search"}) is (
        client.create_dataset.return_value
    )
    client.create_dataset.assert_called_once_with(
        name="qa", description="questions", metadata={"team": "search"}
    )
    client.shutdown.assert_not_called()


def test_add_items_preserves_source_identity_and_upload_order() -> None:
    """Local items round-trip every field and explicit IDs support remote updates."""
    client = Mock(spec=Langfuse)
    first, second = Mock(spec=DatasetItem), Mock(spec=DatasetItem)
    client.create_dataset_item.side_effect = [first, second]
    items = [
        DatasetItemRecord("question", "answer", {"split": "test"}, "item", "t", "o"),
        DatasetItemRecord([1, 2]),
    ]
    assert DatasetRepository(client).add_items("qa", iter(items)) == (first, second)
    for call, item in zip(
        client.create_dataset_item.call_args_list, items, strict=True
    ):
        assert call.kwargs == {
            "dataset_name": "qa",
            "input": item.input,
            "expected_output": item.expected_output,
            "metadata": dict(item.metadata),
            "id": item.id,
            "source_trace_id": item.source_trace_id,
            "source_observation_id": item.source_observation_id,
        }


def test_item_metadata_is_shallow_frozen_snapshot() -> None:
    """Top-level changes cannot alter records while arbitrary input is preserved."""
    metadata: dict[str, object] = {"split": "test"}
    payload = object()
    item = DatasetItemRecord(payload, metadata=metadata)
    metadata["split"] = "train"
    assert item.input is payload
    assert item.metadata == {"split": "test"}
    with raises(TypeError):
        cast(dict[str, object], item.metadata)["split"] = "train"
    with raises(FrozenInstanceError):
        setattr(item, "input", "changed")


@mark.parametrize(
    "fields",
    [
        {"id": " "},
        {"source_trace_id": 1},
        {"source_observation_id": "o"},
        {"metadata": []},
        {"metadata": {"": 1}},
    ],
)
def test_invalid_records(fields: dict[str, Any]) -> None:
    """Reject malformed metadata and source identities at construction."""
    with raises((TypeError, ValueError)):
        DatasetItemRecord("input", **fields)


def test_add_items_prevalidates_and_propagates_partial_upload_failure() -> None:
    """Validation is atomic, but completed SDK writes cannot be rolled back."""
    client = Mock(spec=Langfuse)
    repository = DatasetRepository(client)
    with raises(TypeError):
        repository.add_items(
            "qa", [DatasetItemRecord("a"), cast(DatasetItemRecord, {})]
        )
    client.create_dataset_item.assert_not_called()
    failure = RuntimeError("upload failed")
    client.create_dataset_item.side_effect = [Mock(), failure]
    with raises(RuntimeError) as caught:
        repository.add_items("qa", [DatasetItemRecord("a"), DatasetItemRecord("b")])
    assert caught.value is failure
    assert client.create_dataset_item.call_count == 2


def test_dataset_validation_happens_before_sdk_calls() -> None:
    """Names, version types, descriptions, and metadata cannot bypass validation."""
    client = Mock(spec=Langfuse)
    repository = DatasetRepository(client)
    with raises(ValueError):
        repository.get(" ")
    with raises(TypeError):
        repository.get("qa", cast(datetime, 2))
    with raises(TypeError):
        repository.create("qa", cast(str, 42))
    with raises(ValueError):
        repository.create("qa", metadata={" ": 1})
    assert not client.mock_calls


def test_jsonl_loads_without_client_and_skips_blank_lines(tmp_path: Path) -> None:
    """Structured and falsy inputs survive loading with line-oriented metadata."""
    source = tmp_path / "qa.jsonl"
    source.write_text(
        '\n{"input":{"question":"café"},"expected_output":[1],"metadata":{"k":2}}\n'
        '{"input":false,"id":"i","source_trace_id":"t","source_observation_id":"o"}\n'
        '{"input":null}\n\n',
        encoding="utf-8",
    )
    assert load_jsonl(source) == (
        DatasetItemRecord({"question": "café"}, [1], {"k": 2}),
        DatasetItemRecord(
            False, id="i", source_trace_id="t", source_observation_id="o"
        ),
        DatasetItemRecord(None),
    )


@mark.parametrize(
    "line",
    [
        "[]",
        "{}",
        "not json",
        '{"input":1,"unknown":true}',
        '{"input":1,"input":2}',
        '{"input":NaN}',
        '{"input":1e400}',
        '{"input":1,"metadata":null}',
        '{"input":1,"id":""}',
    ],
)
def test_jsonl_errors_include_path_line_and_cause(tmp_path: Path, line: str) -> None:
    """Bad later lines fail the whole load with actionable file locations."""
    source = tmp_path / "bad.jsonl"
    source.write_text('{"input":"valid"}\n\n' + line, encoding="utf-8")
    with raises(ValueError, match="bad.jsonl:3:") as caught:
        load_jsonl(source)
    assert caught.value.__cause__ is not None


def test_jsonl_missing_file_error_is_preserved(tmp_path: Path) -> None:
    """File access errors retain their native type."""
    with raises(FileNotFoundError):
        load_jsonl(tmp_path / "missing.jsonl")
