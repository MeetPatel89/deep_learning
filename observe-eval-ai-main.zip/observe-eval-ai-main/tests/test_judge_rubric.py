"""Validate rubric configuration without requiring model-runtime."""

from typing import Any

from pytest import mark, raises

from observability_ai.evaluation import JudgeRubric


def test_categorical_labels_are_snapshotted() -> None:
    """Caller mutations cannot change the judge's accepted categories."""
    labels = ["pass", "fail"]
    rubric = JudgeRubric("quality", "Grade the answer", "CATEGORICAL", labels)
    labels.clear()
    assert rubric.labels == ("pass", "fail")


@mark.parametrize(
    "kwargs",
    [
        {"name": " "},
        {"instructions": ""},
        {"data_type": "BOOLEAN"},
        {"labels": ["pass"]},
        {"data_type": "CATEGORICAL"},
        {"data_type": "CATEGORICAL", "labels": "pass"},
        {"data_type": "CATEGORICAL", "labels": ["pass", "pass"]},
        {"data_type": "CATEGORICAL", "labels": [" "]},
        {"data_type": "CATEGORICAL", "labels": [1]},
    ],
)
def test_invalid_rubrics(kwargs: dict[str, Any]) -> None:
    """Require a single coherent scoring mode with a named, nonblank rubric."""
    arguments: dict[str, Any] = {
        "name": "quality",
        "instructions": "Grade the answer",
    } | kwargs
    with raises((ValueError, TypeError)):
        JudgeRubric(**arguments)
