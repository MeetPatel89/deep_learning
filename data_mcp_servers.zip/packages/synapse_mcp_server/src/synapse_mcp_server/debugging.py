"""Failure diagnosis, best-effort Spark history and gated data-flow debug sessions."""

import json
import re
from typing import Any, Literal
from urllib.parse import quote

from data_mcp_core.guards import planned_action, require
from data_mcp_core.results import MAX_CHARS, bounded_result, json_safe, paginate, redact

from synapse_mcp_server.base import field, wait_operation

CAUSES = [
    (
        "auth",
        r"unauthori[sz]ed|forbidden|authentication|authorization|invalid.?credential|AADSTS|403|401",
        "Check the execution identity's Entra and storage/SQL permissions.",
    ),
    (
        "firewall",
        r"firewall|not allowed to access|network.*denied|private.?endpoint|name.*resolution",
        "Check firewall rules, managed private endpoints and DNS from the integration runtime.",
    ),
    (
        "missing_path",
        r"path.*not.*found|file.*not.*found|does not exist|404|PathNotFound",
        "Verify the resolved path, container/table and parameter values.",
    ),
    (
        "schema_drift",
        r"schema|column.*not|type.*mismatch|conversion.*fail|cannot.*cast",
        "Compare source/sink schemas, mappings and recently changed columns.",
    ),
    (
        "timeout",
        r"timed?\s*out|timeout|deadline",
        "Check resource queues, activity timeout settings and slow upstream dependencies.",
    ),
    (
        "out_of_memory",
        r"out.?of.?memory|OutOfMemory|OOM|heap space|memory overhead",
        "Review Spark driver/executor memory, skew and partition sizes.",
    ),
]


def classify_failure(error: Any) -> list[dict[str, str]]:
    text = json.dumps(error, default=str)
    return [
        {"cause": cause, "hint": hint}
        for cause, pattern, hint in CAUSES
        if re.search(pattern, text, re.I)
    ]


class DebugTools:
    def list_spark_applications(
        self,
        workspace: str,
        pool: str | None = None,
        limit: int = 100,
        continuation: str | None = None,
    ) -> dict[str, Any]:
        """List Spark applications using the best-effort Synapse monitoring endpoint."""
        self.live_workspace(workspace, "debugging")
        response = self.clients.http_get(
            workspace, "/monitoring/workloadTypes/spark/Applications", {"api-version": "2020-12-01"}
        )
        items = response.json().get("sparkJobs", [])
        if pool:
            items = [item for item in items if field(item, "compute") == pool]
        return {
            **paginate(items, limit, continuation, f"spark:{workspace}:{pool}"),
            "best_effort": True,
        }

    def get_spark_application_logs(
        self,
        workspace: str,
        pool: str,
        application_id: str,
        livy_id: str | None = None,
        stream: Literal["stderr", "stdout"] = "stderr",
        tail_lines: int = 100,
        max_chars: int = MAX_CHARS,
    ) -> dict[str, Any]:
        """Get a bounded driver-log tail from the best-effort Spark history endpoint."""
        self.live_workspace(workspace, "debugging")
        if not 1 <= tail_lines <= 1000 or not 1 <= max_chars <= MAX_CHARS:
            raise ValueError("Invalid Spark log caps")
        if livy_id is None:
            response = self.clients.http_get(
                workspace,
                "/monitoring/workloadTypes/spark/Applications",
                {"api-version": "2020-12-01"},
            )
            job = next(
                (
                    job
                    for job in response.json().get("sparkJobs", [])
                    if field(job, "sparkApplicationId") == application_id
                    and field(job, "compute") == pool
                ),
                None,
            )
            if not job:
                raise ValueError("Spark application was not found; supply its livy_id explicitly")
            livy_id = str(field(job, "livyId"))
        segments = [quote(str(value), safe="") for value in (pool, livy_id, application_id)]
        path = (
            f"/sparkhistory/api/v1/sparkpools/{segments[0]}/livyid/{segments[1]}"
            f"/applications/{segments[2]}/driverlog/{stream}/"
        )
        response = self.clients.http_get(workspace, path, {"isDownload": "true"})
        lines = response.text.splitlines()
        text = "\n".join(lines[-tail_lines:])
        return {
            "application_id": application_id,
            "stream": stream,
            "text": redact(text[-max_chars:]),
            "truncated": len(lines) > tail_lines or len(text) > max_chars,
            "best_effort": True,
        }

    def diagnose_pipeline_run(
        self, workspace: str, run_id: str, max_depth: int = 10, include_spark_logs: bool = True
    ) -> dict[str, Any]:
        """Find failed leaf activities, resolved inputs/outputs and likely causes with remediation
        hints.
        """
        self.live_workspace(workspace, "debugging")
        if not 0 <= max_depth <= 20:
            raise ValueError("max_depth must be between 0 and 20")
        return self._diagnose_pipeline_run(workspace, run_id, max_depth, include_spark_logs)

    def _diagnose_pipeline_run(self, workspace, run_id, max_depth=10, include_spark_logs=True):
        tree = self._run_tree(workspace, run_id, max_depth)
        failures, warnings = [], []

        def walk(node):
            children = {child["run_id"]: child for child in node["children"]}
            for child in node["children"]:
                walk(child)
            for activity in node.get("activities", []):
                if str(field(activity, "status", "")).lower() != "failed":
                    continue
                kind = field(activity, "activityType", "")
                output, input_value = (
                    field(activity, "output", {}) or {},
                    field(activity, "input", {}) or {},
                )
                child_id = field(output, "pipelineRunId")
                if (
                    kind == "ExecutePipeline"
                    and child_id in children
                    and children[child_id].get("status") == "Failed"
                ):
                    continue
                error = field(activity, "error", {}) or {}
                failure = {
                    "run_id": node["run_id"],
                    "pipeline": node.get("pipeline"),
                    "activity": field(activity, "activityName"),
                    "activity_run_id": field(activity, "activityRunId"),
                    "type": kind,
                    "error": error,
                    "input": input_value,
                    "output": output,
                    "causes": classify_failure(error),
                }
                if kind == "Copy":
                    failure["copy"] = {
                        "rows_read": field(output, "rowsRead"),
                        "rows_written": field(output, "rowsCopied", field(output, "rowsWritten")),
                        "rows_skipped": field(output, "rowsSkipped"),
                        "errors": output.get("errors", []),
                        "source": input_value.get("source"),
                        "sink": input_value.get("sink"),
                    }
                elif "notebook" in kind.lower() or "spark" in kind.lower():
                    # Notebook activity responses may nest these fields under result.
                    details = field(output, "result", output) or {}
                    app = field(
                        details,
                        "sparkApplicationId",
                        field(details, "applicationId", field(details, "appId")),
                    )
                    pool = (
                        field(details, "sparkPool", field(details, "sparkPoolName"))
                        or field(output, "sparkPool")
                        or field(input_value, "sparkPool")
                    )
                    livy = field(
                        details, "livyId", field(details, "sessionId", field(output, "sessionId"))
                    )
                    if isinstance(pool, dict):
                        pool = field(pool, "referenceName")
                    if pool and not app and livy is not None:
                        try:
                            spark = self.clients.get(workspace, "spark", pool)
                            operation = (
                                spark.spark_batch.get_spark_batch_job
                                if "sparkjob" in kind.lower()
                                else spark.spark_session.get_spark_session
                            )
                            application = json_safe(operation(int(livy), detailed=True))
                            app = field(application, "appId")
                            failure["spark_errors"] = field(application, "errorInfo", [])
                        except Exception as lookup_error:
                            failure["log_warning"] = redact(str(lookup_error))
                    failure["spark_application_id"] = app
                    if app and pool and include_spark_logs:
                        try:
                            failure["driver_stderr"] = self.get_spark_application_logs(
                                workspace,
                                pool,
                                app,
                                livy_id=str(livy) if livy is not None else None,
                            )
                        except Exception as log_error:
                            failure["log_warning"] = redact(str(log_error))
                    failure["causes"] = classify_failure(
                        {
                            "error": error,
                            "logs": failure.get("driver_stderr"),
                            "spark": failure.get("spark_errors"),
                        }
                    )
                elif "sql" in kind.lower() or "storedprocedure" in kind.lower():
                    failure["sql_error"] = error
                elif "dataflow" in kind.lower():
                    failure["data_flow_metrics"] = field(
                        output, "runStatus", field(output, "metrics", {})
                    )
                failures.append(failure)
            if node.get("truncated"):
                warnings.append("Run tree was truncated by the configured depth/run cap")

        walk(tree)
        if not failures and tree.get("status") == "Failed":
            message = field(
                tree.get("run", {}), "message", "No failed activity details were available"
            )
            failures.append(
                {"run_id": run_id, "error": message, "causes": classify_failure(message)}
            )
        return bounded_result(
            {
                "run_id": run_id,
                "status": tree.get("status"),
                "failed_leaf_activities": failures,
                "warnings": warnings,
            }
        )

    def create_data_flow_debug_session(
        self,
        workspace: str,
        core_count: int = 8,
        time_to_live: int = 60,
        compute_type: str = "General",
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Create a billed data-flow debug session (requires allow_run)."""
        require(self.live_workspace(workspace, "debugging"), "allow_run")
        if core_count <= 0 or not 1 <= time_to_live <= 240:
            raise ValueError("Invalid debug session sizing or TTL")
        plan = planned_action(
            "create_data_flow_debug_session",
            dry_run,
            workspace=workspace,
            core_count=core_count,
            time_to_live=time_to_live,
        )
        if plan:
            return plan
        from azure.synapse.artifacts.models import CreateDataFlowDebugSessionRequest

        request = CreateDataFlowDebugSessionRequest(
            core_count=core_count, time_to_live=time_to_live, compute_type=compute_type
        )
        return bounded_result(
            wait_operation(
                self.artifact_client(
                    workspace, "debugging"
                ).data_flow_debug_session.begin_create_data_flow_debug_session(request)
            )
        )

    def add_data_flow_to_debug_session(
        self, workspace: str, session_id: str, package: dict[str, Any], dry_run: bool = False
    ) -> dict[str, Any]:
        """Add a data flow and dependencies to a debug session (requires allow_run)."""
        require(self.live_workspace(workspace, "debugging"), "allow_run")
        plan = planned_action(
            "add_data_flow_to_debug_session", dry_run, workspace=workspace, session_id=session_id
        )
        if plan:
            return plan
        from azure.synapse.artifacts.models import DataFlowDebugPackage

        request = DataFlowDebugPackage.deserialize({**package, "sessionId": session_id})
        return bounded_result(
            self.artifact_client(workspace, "debugging").data_flow_debug_session.add_data_flow(
                request
            )
        )

    def run_data_flow_debug_command(
        self,
        workspace: str,
        session_id: str,
        command: Literal[
            "executePreview",
            "executeStatistics",
            "executePreviewQuery",
            "executeStatisticsQuery",
            "executeExpressionQuery",
        ],
        payload: dict[str, Any],
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Run preview, statistics or expression commands (requires allow_run)."""
        require(self.live_workspace(workspace, "debugging"), "allow_run")
        command = {
            "executePreview": "executePreviewQuery",
            "executeStatistics": "executeStatisticsQuery",
        }.get(command, command)
        plan = planned_action(
            "run_data_flow_debug_command",
            dry_run,
            workspace=workspace,
            session_id=session_id,
            command=command,
        )
        if plan:
            return plan
        from azure.synapse.artifacts.models import DataFlowDebugCommandRequest

        request = DataFlowDebugCommandRequest.deserialize(
            {"sessionId": session_id, "command": command, "commandPayload": payload}
        )
        return bounded_result(
            wait_operation(
                self.artifact_client(
                    workspace, "debugging"
                ).data_flow_debug_session.begin_execute_command(request)
            )
        )

    def delete_data_flow_debug_session(
        self, workspace: str, session_id: str, dry_run: bool = False
    ) -> dict[str, Any]:
        """Close a data-flow debug session (requires allow_run)."""
        require(self.live_workspace(workspace, "debugging"), "allow_run")
        plan = planned_action(
            "delete_data_flow_debug_session", dry_run, workspace=workspace, session_id=session_id
        )
        if plan:
            return plan
        from azure.synapse.artifacts.models import DeleteDataFlowDebugSessionRequest

        self.artifact_client(
            workspace, "debugging"
        ).data_flow_debug_session.delete_data_flow_debug_session(
            DeleteDataFlowDebugSessionRequest(session_id=session_id)
        )
        return {"closed": True, "session_id": session_id}
