---
doc_id: COMM-INC-1104
title: Customer Communications for INC-1104 Employee Portal Sign-In Issue
doc_type: customer_communication
service_id: svc_identity_gateway
owner_group: Service Desk L1
visibility: customer_safe
status: closed
created_at: "2026-06-12T23:45:00"
updated_at: "2026-06-13T03:50:00"
related_records:
  - INC-1104
  - KI-104
  - POL-COMMS-001
source_facts:
  - KI-104
  - svc_identity_gateway
difficulty_tags:
  - customer-safe
  - permission-boundary
servicenow:
  table: u_customer_communication
  number: COMM0001001
  parent: INC001104
  parent_table: incident
  channel: Email and status page
  visibility: customer_safe
  contains_customer_safe_wording: true
---

# Customer Communications for INC-1104 Employee Portal Sign-In Issue

## Record details

| Field | Value |
| --- | --- |
| Table | u_customer_communication |
| Number | COMM0001001 |
| Parent | INC001104 |
| Parent table | incident |
| Channel | Email and status page |
| Visibility | customer_safe |
| Contains customer-safe wording | true |

## Purpose

This record contains the outbound updates sent to affected users during INC-1104. All updates use approved customer-safe wording only. Internal diagnostic detail is recorded separately in the incident work notes and is not included here.

## Outbound updates

### 2026-06-12T23:45:00 — Initial acknowledgment

Subject: Employee Portal sign-in issue — we are investigating

Some users are currently unable to sign in to Employee Portal. We are validating the enterprise sign-in configuration after scheduled identity maintenance. If you are affected, no action is needed from you at this time. We will send a further update as the review progresses.

### 2026-06-13T00:30:00 — In-progress update

Subject: Employee Portal sign-in issue — update

Our support teams are continuing to work on the Employee Portal sign-in issue. We are validating the enterprise sign-in configuration after scheduled identity maintenance. Some users may already be able to sign in normally. If your sign-in fails, please wait for our confirmation before retrying repeatedly.

### 2026-06-13T02:20:00 — Remediation progress update

Subject: Employee Portal sign-in issue — service recovering

Sign-in to Employee Portal is recovering. We are validating the enterprise sign-in configuration after scheduled identity maintenance and most affected users can now sign in successfully. If you are still unable to sign in, please close your browser, start a fresh session, and retry. Contact the service desk if the issue continues.

### 2026-06-13T03:50:00 — Resolution notice

Subject: Employee Portal sign-in issue — resolved

The Employee Portal sign-in issue has been resolved. The validation of the enterprise sign-in configuration after scheduled identity maintenance is complete. All users should now be able to sign in normally. If you experience any further sign-in problems, please contact the service desk and reference this notice.

## Wording approval

The wording used in these updates was approved per POL-COMMS-001 before the initial acknowledgment was sent. All updates use the approved customer-safe summary from KI-104 and generic next steps only. No internal diagnostic or implementation detail was included in any outbound message.

## Related records

- INC-1104: Parent incident for these communications.
- KI-104: Known issue whose approved customer-safe summary was used.
- POL-COMMS-001: Customer-Safe Communication Policy.

Internal record titles and diagnostic detail are intentionally omitted from this customer-safe record.
