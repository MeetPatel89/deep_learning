from collections import Counter

import polars as pl
import pytest
from qa_mcp_server import service
from qa_mcp_server.engine import partition, planner
from qa_mcp_server.models import CompareOptions, InlineSource, OutputOptions


def test_switch_to_spill_midstream_preserves_prior_batches(tmp_path, monkeypatch):
    expected = InlineSource(rows=[{"id": i % 5, "v": i} for i in range(30)])
    actual = InlineSource(rows=[{"id": float(i % 5), "v": str(i)} for i in range(28)])

    def batches(source):
        for offset in range(0, len(source.rows), 3):
            yield pl.from_dicts(source.rows[offset : offset + 3])

    monkeypatch.setattr(planner, "iter_batches", batches)
    plan = planner.load_and_plan(
        expected,
        actual,
        CompareOptions(primary_keys=["id"], memory_budget_mb=0.0002),
        tmp_path / "scratch",
    )
    assert plan.partitioned
    assert len(plan.expected.paths) == 10
    assert not plan.expected.frames
    assert sum(batch.height for batch in plan.expected.batches()) == 30
    assert plan.schema == {"id": pl.Float64, "v": pl.String}
    reference = service.compare(
        expected,
        actual,
        CompareOptions(primary_keys=["id"]),
        OutputOptions(output_dir=tmp_path / "reports"),
    )
    result = service.compare(
        expected,
        actual,
        CompareOptions(primary_keys=["id"], memory_budget_mb=0.0002),
        OutputOptions(output_dir=tmp_path / "reports"),
    )
    assert result["counts"] == reference["counts"]
    assert result["duplicate_key_rows"] == reference["duplicate_key_rows"]

    def differences(summary):
        rows = pl.read_parquet(summary["mismatch_parquet_path"] + "/*.parquet").to_dicts()
        return Counter(repr(sorted(row.items())) for row in rows)

    assert differences(result) == differences(reference)


def test_failed_completeness_check_removes_only_failed_run(tmp_path, monkeypatch):
    saved = tmp_path / "existing.txt"
    saved.write_text("keep me", encoding="utf-8")
    monkeypatch.setattr(service, "execute_plan", lambda *args: iter(()))
    with pytest.raises(RuntimeError, match="completeness"):
        service.compare(
            InlineSource(rows=[{"id": 1}]),
            InlineSource(rows=[{"id": 1}]),
            CompareOptions(primary_keys=["id"]),
            OutputOptions(output_dir=tmp_path),
        )
    assert list(tmp_path.iterdir()) == [saved]


def test_partition_accounting_fails_if_rows_are_dropped(tmp_path, monkeypatch):
    original = partition.canonical_batches

    def drop_one(side, plan, actual=False):
        for frame in original(side, plan, actual):
            yield frame.head(0) if actual else frame

    monkeypatch.setattr(partition, "canonical_batches", drop_one)
    with pytest.raises(RuntimeError, match="Partition completeness"):
        service.compare(
            InlineSource(rows=[{"id": 1}]),
            InlineSource(rows=[{"id": 1}]),
            CompareOptions(primary_keys=["id"], num_partitions=2),
            OutputOptions(output_dir=tmp_path),
        )
    assert not list(tmp_path.iterdir())
