"""Owned temporary SDK artifacts, durable LROs and conservative cleanup."""

import json
from io import BytesIO

from azure.core.exceptions import HttpResponseError, ResourceNotFoundError
from data_mcp_core.guards import require
from data_mcp_core.results import json_safe, redact

from synapse_mcp_server.base import field

MODEL_NAMES = {"dataset": "Dataset", "linked_service": "LinkedService", "data_flow": "DataFlow"}


def assert_preserved(expected, actual, path="properties"):
    if isinstance(expected, dict):
        for key, value in expected.items():
            if not isinstance(actual, dict) or key not in actual:
                if value == {}:
                    continue  # SDK serializers omit empty property containers.
                raise ValueError(f"SDK cannot preserve unsupported artifact property: {path}.{key}")
            assert_preserved(value, actual[key], path + "." + key)
    elif isinstance(expected, list):
        if not isinstance(actual, list) or len(actual) != len(expected):
            raise ValueError("SDK cannot preserve artifact list: " + path)
        for index, value in enumerate(expected):
            assert_preserved(value, actual[index], path + f"[{index}]")
    elif expected != actual:
        raise ValueError("SDK cannot preserve artifact value: " + path)


class SDKStagingAdapter:
    def __init__(self, service, workspace):
        self.service = service
        self.workspace = workspace

    def guard(self):
        settings = self.service.workspace(self.workspace, "execution")
        for permission in ("allow_live_env", "allow_run", "allow_manage"):
            require(settings, permission)

    def client(self):
        self.guard()
        return self.service.clients.get(self.workspace, "artifacts")

    @staticmethod
    def body(kind, definition):
        if kind in {"pipeline", "notebook"}:
            return BytesIO(json.dumps(definition, allow_nan=False).encode())
        from azure.synapse.artifacts import models

        if kind not in MODEL_NAMES:
            raise ValueError("Unsupported SDK staging artifact: " + kind)
        body = getattr(models, MODEL_NAMES[kind]).deserialize(definition["properties"])
        assert_preserved(definition["properties"], body.serialize())
        return body

    def plan(self, package, execution_id):
        self.guard()
        names, definitions, owner = package.stage(execution_id)
        staged = []
        for key in package.order:
            kind = key.split("/", 1)[0]
            self.body(kind, definitions[key])  # Validate the complete package before any SDK call.
            staged.append(
                {
                    "key": key,
                    "kind": kind,
                    "name": names[key],
                    "definition": definitions[key],
                    "state": "planned",
                }
            )
        return staged, names, owner

    def get(self, item):
        operations = getattr(self.client(), item["kind"])
        return json_safe(getattr(operations, "get_" + item["kind"])(item["name"]))

    def _save(self, record):
        self.service.execution_store.save(record)

    def _poll(self, poller, item, record, complete):
        if hasattr(poller, "continuation_token"):
            item["continuation"] = poller.continuation_token()
            self._save(record)
        poller.result(timeout=30)
        if hasattr(poller, "done") and not poller.done():
            raise TimeoutError(
                "Staging operation is pending; monitoring will resume its journaled LRO"
            )
        item["state"] = complete
        item.pop("continuation", None)
        self._save(record)

    def deploy(self, record):
        self.guard()
        # Check every unique name before creating the first artifact.
        for item in record["staged"]:
            try:
                self.get(item)
            except ResourceNotFoundError:
                continue
            raise ValueError("Staging name collision; existing published artifact was preserved")
        for item in record["staged"]:
            item["state"] = "creating"
            self._save(record)
            operations = getattr(self.client(), item["kind"])
            try:
                poller = getattr(operations, "begin_create_or_update_" + item["kind"])(
                    item["name"],
                    self.body(item["kind"], item["definition"]),
                    headers={"If-None-Match": "*"},
                )
            except HttpResponseError as error:
                if error.status_code in {400, 401, 403, 404, 409, 412, 422}:
                    item["state"] = "rejected"
                    self._save(record)
                raise
            self._poll(poller, item, record, "created")

    def submit(self, record):
        result = json_safe(
            self.client().pipeline.create_pipeline_run(
                record["names"]["pipeline/" + record["provenance"]["pipeline"]],
                parameters=record["provenance"]["parameters"],
            )
        )
        run_id = field(result, "runId")
        if not isinstance(run_id, str) or not run_id:
            raise ValueError("SDK submission did not return a native run ID")
        return run_id

    def status(self, record, run_id):
        return json_safe(self.client().pipeline_run.get_pipeline_run(run_id))

    def activities(self, record, run_id):
        self.guard()
        run = self.status(record, run_id)
        return self.service._activity_runs(self.workspace, run)

    def cancel(self, record, run_id):
        self.client().pipeline_run.cancel_pipeline_run(run_id, is_recursive=True)

    def cleanup(self, record):
        self.guard()
        errors = []
        for item in reversed(record["staged"]):
            if item["state"] in {"planned", "deleted", "absent", "rejected"}:
                continue
            try:
                operations = getattr(self.client(), item["kind"])
                if item.get("continuation"):
                    if item["state"] == "deleting":
                        poller = getattr(operations, "begin_delete_" + item["kind"])(
                            item["name"], continuation_token=item["continuation"]
                        )
                        self._poll(poller, item, record, "deleted")
                        continue
                    poller = getattr(operations, "begin_create_or_update_" + item["kind"])(
                        item["name"],
                        self.body(item["kind"], item["definition"]),
                        continuation_token=item["continuation"],
                    )
                    self._poll(poller, item, record, "created")
                elif item["state"] == "creating":
                    # A crash before recording the LRO has an uncertain deployment outcome.
                    raise ValueError(
                        "Creation outcome unknown; retain artifact for manual reconciliation"
                    )
                current = self.get(item)
                if record["owner"] not in current.get("properties", current).get("annotations", []):
                    raise PermissionError("Artifact ownership changed; cleanup refused")
                etag = field(current, "etag")
                if not etag:
                    raise ValueError("Missing artifact ETag; conditional cleanup is unavailable")
                item["state"] = "deleting"
                self._save(record)
                poller = getattr(operations, "begin_delete_" + item["kind"])(
                    item["name"], headers={"If-Match": etag}
                )
                self._poll(poller, item, record, "deleted")
            except ResourceNotFoundError:
                item["state"] = "absent"
                self._save(record)
            except Exception as error:
                errors.append({"artifact": item["name"], "error": redact(str(error))})
                # Dependencies must remain while any dependent could still exist.
                break
        record["cleanup"] = "pending" if errors else "complete"
        record["cleanup_errors"] = errors
        self._save(record)
        return {"cleanup": record["cleanup"], "errors": errors}

    def close(self):
        pass
