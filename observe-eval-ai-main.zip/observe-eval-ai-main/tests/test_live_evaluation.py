"""Verify sampled delivery, target selection, and async evaluator lifecycle."""

from asyncio import CancelledError, TaskGroup, sleep
from collections.abc import Mapping
from typing import Any, cast
from unittest.mock import Mock, call

from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from pytest import mark, raises

from observability_ai import Telemetry
from observability_ai.evaluation import EvaluationResult, ExactMatch, LiveEvaluation


async def test_mixed_evaluators_deliver_ordered_results() -> None:
    """Await async evaluators and flatten result sequences before delivery."""
    first = EvaluationResult("first", 0.1)
    second = EvaluationResult("second", "good", "CATEGORICAL")
    sink = Mock()
    sync = Mock(return_value=first)

    async def multiple(
        *,
        input: object,
        output: object,
        expected_output: object,
        metadata: Mapping[str, object] | None,
    ) -> list[EvaluationResult]:
        assert input == "question" and output == expected_output == "answer"
        assert metadata == {"tenant": "test"}
        sink.assert_not_called()
        await sleep(0)
        return [second]

    live = LiveEvaluation([sync, multiple], sink=sink)
    results = await live.evaluate(
        input="question",
        output="answer",
        expected_output="answer",
        metadata={"tenant": "test"},
        trace_id="trace",
        observation_id="observation",
    )
    assert results == (first, second)
    sync.assert_called_once_with(
        input="question",
        output="answer",
        expected_output="answer",
        metadata={"tenant": "test"},
    )
    assert sink.call_args_list == [
        call(first, "trace", "observation"),
        call(second, "trace", "observation"),
    ]


@mark.parametrize(
    ("ratio", "draw", "included", "draws"),
    [(0, 0, False, 0), (1, 0.999, True, 0), (0.5, 0.49, True, 1), (0.5, 0.5, False, 1)],
)
async def test_sampling_once_per_call(
    ratio: float, draw: float, included: bool, draws: int
) -> None:
    """Endpoints avoid randomness; a skipped call needs neither IDs nor evaluators."""
    random_source = Mock(return_value=draw)
    evaluator = Mock(return_value=EvaluationResult("metric", 1))
    sink = Mock()
    live = LiveEvaluation(
        [evaluator, evaluator],
        sink=sink,
        sample_ratio=ratio,
        random_source=random_source,
    )
    results = await live.evaluate(output="a", trace_id="trace" if included else None)
    assert len(results) == (2 if included else 0)
    assert evaluator.call_count == sink.call_count == (2 if included else 0)
    assert random_source.call_count == draws


async def test_targets_survive_nested_evaluator_spans_and_concurrent_tasks(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Capture the calling span before a judge changes the current context."""
    telemetry, _ = otel
    sink = Mock()

    async def evaluate(**kwargs: object) -> EvaluationResult:
        with telemetry.evaluator("nested"):
            await sleep(0)
            return EvaluationResult("quality", 1)

    live = LiveEvaluation([evaluate], sink=sink)
    targets: set[tuple[str | None, str | None]] = set()

    async def run() -> None:
        with telemetry.agent("agent") as parent:
            targets.add((parent.trace_id, parent.observation_id))
            await live.evaluate(output="answer")

    async with TaskGroup() as group:
        group.create_task(run())
        group.create_task(run())
    assert {(c.args[1], c.args[2]) for c in sink.call_args_list} == targets
    with telemetry.agent("active"):
        await live.evaluate(output="answer", trace_id="explicit")
    assert sink.call_args.args[1:] == ("explicit", None)


async def test_no_recording_span_requires_explicit_trace() -> None:
    """Reject absent IDs before any evaluation, but allow legacy explicit IDs."""
    evaluator = Mock(return_value=EvaluationResult("metric", 1))
    sink = Mock()
    live = LiveEvaluation([evaluator], sink=sink)
    with raises(ValueError, match="trace_id"):
        await live.evaluate(output="answer")
    evaluator.assert_not_called()
    sink.assert_not_called()
    await live.evaluate(output="answer", trace_id="legacy-id")
    assert sink.call_args.args[1:] == ("legacy-id", None)


@mark.parametrize("bad", [None, "", "text", b"", [EvaluationResult("a", 1), 3]])
async def test_invalid_evaluator_results_prevent_all_delivery(bad: object) -> None:
    """Do not emit earlier scores when a later evaluator violates the contract."""
    sink = Mock()
    live = LiveEvaluation([ExactMatch(), Mock(return_value=bad)], sink=sink)
    with raises(TypeError, match="EvaluationResult"):
        await live.evaluate(output=1, expected_output=1, trace_id="trace")
    sink.assert_not_called()


@mark.parametrize("failure", [RuntimeError("failed"), CancelledError()])
async def test_evaluator_failure_and_cancellation_propagate(
    failure: BaseException,
) -> None:
    """Preserve original errors without emitting partial results."""
    sink = Mock()

    async def fail(**kwargs: object) -> EvaluationResult:
        await sleep(0)
        raise failure

    with raises(type(failure)) as caught:
        await LiveEvaluation([ExactMatch(), fail], sink=sink).evaluate(
            output="a", trace_id="trace"
        )
    assert caught.value is failure
    sink.assert_not_called()


async def test_sink_errors_propagate_and_stop_delivery() -> None:
    """Delivery is sequential and does not retry failed sinks."""
    failure = RuntimeError("sink failure")
    sink = Mock(side_effect=failure)
    with raises(RuntimeError) as caught:
        await LiveEvaluation([ExactMatch(), ExactMatch()], sink=sink).evaluate(
            output="a", trace_id="trace"
        )
    assert caught.value is failure
    assert sink.call_count == 1


@mark.parametrize("ratio", [-0.1, 1.1, True, float("nan"), float("inf"), "1"])
def test_invalid_sample_ratio(ratio: object) -> None:
    """Require a finite nonboolean sampling fraction."""
    with raises((TypeError, ValueError)):
        kwargs: dict[str, Any] = {"sample_ratio": ratio}
        LiveEvaluation([], sink=Mock(), **kwargs)


async def test_evaluator_configuration_and_metadata_are_snapshots() -> None:
    """Caller edits cannot change the evaluator list or top-level shared metadata."""
    sink = Mock()
    evaluators = [ExactMatch()]
    live = LiveEvaluation(evaluators, sink=sink)
    evaluators.clear()
    results = await live.evaluate(output="a", expected_output="a", trace_id="trace")
    assert len(results) == 1
    sink.assert_called_once()

    def mutate(
        *,
        input: object = None,
        output: object,
        expected_output: object = None,
        metadata: Mapping[str, object] | None = None,
    ) -> EvaluationResult:
        assert metadata is not None
        cast(dict[str, object], metadata)["new"] = True
        return EvaluationResult("unused", 1)

    original = {"tenant": "test"}
    with raises(TypeError):
        await LiveEvaluation([mutate], sink=sink).evaluate(
            output="a", metadata=original, trace_id="trace"
        )
    assert original == {"tenant": "test"}
