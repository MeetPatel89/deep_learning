"""Delta table metadata and explicitly authorized maintenance."""

import json
from typing import Any, Literal

import polars as pl
from data_mcp_core import formats
from data_mcp_core.guards import planned_action, require
from data_mcp_core.results import bounded_result, paginate


class DeltaTools:
    def _delta(self, resolved, version=None):
        from deltalake import DeltaTable

        return DeltaTable(
            resolved.uri, version=version, storage_options=resolved.storage_options(token=True)
        )

    def delta_describe(self, store: str, path: str, version: int | None = None) -> dict[str, Any]:
        """Describe a Delta version, schema, protocol, partitions and active file count."""
        table = self._delta(self.resolve(store, path), version)
        metadata = table.metadata()
        protocol = table.protocol()
        return bounded_result(
            {
                "version": table.version(),
                "id": metadata.id,
                "name": metadata.name,
                "description": metadata.description,
                "partition_columns": metadata.partition_columns,
                "configuration": metadata.configuration,
                "schema": json.loads(table.schema().to_json()),
                "protocol": protocol._asdict(),
                "file_count": len(table.file_uris()),
            }
        )

    def delta_history(self, store: str, path: str, limit: int = 20) -> dict[str, Any]:
        """Read recent Delta commits."""
        if not 1 <= limit <= 1000:
            raise ValueError("Invalid history limit")
        return bounded_result({"history": self._delta(self.resolve(store, path)).history(limit)})

    def delta_list_files(
        self,
        store: str,
        path: str,
        version: int | None = None,
        limit: int = 100,
        continuation: str | None = None,
    ) -> dict[str, Any]:
        """List active files for a Delta version with pagination."""
        table = self._delta(self.resolve(store, path), version)
        return paginate(
            table.file_uris(), limit, continuation, f"delta:{store}:{path}:{table.version()}"
        )

    def delta_write(
        self,
        store: str,
        path: str,
        rows: list[dict[str, Any]],
        mode: Literal["append", "overwrite", "merge"] = "append",
        predicate: str | None = None,
        options: dict[str, Any] | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Append, overwrite or merge inline rows (requires allow_write)."""
        resolved = self.resolve(store, path)
        require(resolved.store, "allow_write")
        plan = planned_action(
            "delta_write",
            dry_run,
            store=store,
            path=path,
            mode=mode,
            row_count=len(rows),
            predicate=predicate,
        )
        if plan:
            return plan
        kwargs = {**(options or {}), "mode": mode}
        if predicate:
            kwargs["predicate"] = predicate
        return formats.write_dataset(
            pl.DataFrame(rows, infer_schema_length=None), resolved, "delta", kwargs
        )

    def delta_optimize(
        self, store: str, path: str, target_size: int | None = None, dry_run: bool = False
    ) -> dict[str, Any]:
        """Compact Delta files (requires allow_write)."""
        resolved = self.resolve(store, path)
        require(resolved.store, "allow_write")
        if target_size is not None and target_size <= 0:
            raise ValueError("target_size must be positive")
        plan = planned_action(
            "delta_optimize", dry_run, store=store, path=path, target_size=target_size
        )
        return plan or bounded_result(
            self._delta(resolved).optimize.compact(target_size=target_size)
        )

    def delta_vacuum(
        self, store: str, path: str, retention_hours: int = 168, dry_run: bool = True
    ) -> dict[str, Any]:
        """List/delete obsolete Delta files with a minimum seven-day retention (requires
        allow_delete).
        """
        resolved = self.resolve(store, path)
        require(resolved.store, "allow_delete")
        if retention_hours < 168:
            raise ValueError("Delta vacuum retention must be at least 168 hours")
        files = self._delta(resolved).vacuum(retention_hours=retention_hours, dry_run=dry_run)
        return bounded_result({"dry_run": dry_run, "files": files})

    def delta_restore(
        self,
        store: str,
        path: str,
        version: int | None = None,
        timestamp: str | None = None,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Restore a Delta table to a version or timestamp (requires allow_write)."""
        resolved = self.resolve(store, path)
        require(resolved.store, "allow_write")
        if (version is None) == (timestamp is None) or (version is not None and version < 0):
            raise ValueError("Specify exactly one nonnegative version or timestamp")
        target = version if version is not None else timestamp
        plan = planned_action("delta_restore", dry_run, store=store, path=path, target=target)
        return plan or bounded_result(self._delta(resolved).restore(target))
