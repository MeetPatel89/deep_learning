import sys

import anyio
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client


def test_synapse_stdio_roundtrip_without_cloud_credentials():
    async def exercise():
        parameters = StdioServerParameters(
            command=sys.executable, args=["-m", "synapse_mcp_server"]
        )
        async with stdio_client(parameters) as (reader, writer):
            async with ClientSession(reader, writer) as session:
                await session.initialize()
                tools = (await session.list_tools()).tools
                assert len(tools) == 64
                assert (
                    "ctx"
                    not in next(
                        tool for tool in tools if tool.name == "wait_for_pipeline_run"
                    ).inputSchema["properties"]
                )
                result = await session.call_tool("list_workspaces", {})
                assert not result.isError and result.structuredContent["workspaces"] == {}
                denied = await session.call_tool(
                    "run_pipeline", {"workspace": "unknown", "pipeline": "p"}
                )
                assert denied.isError

    anyio.run(exercise)
