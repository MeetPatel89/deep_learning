"""Exercise real SDK experiments locally, plus summary and CI gate boundaries."""

from collections.abc import Mapping, Sequence
from dataclasses import FrozenInstanceError
from datetime import UTC, datetime
from typing import Any, cast
from unittest.mock import Mock

from pytest import MonkeyPatch, importorskip, mark, raises

importorskip("langfuse", reason="requires observe-eval-ai[langfuse]")

from langfuse import Langfuse  # noqa: E402
from langfuse._client.datasets import DatasetClient  # noqa: E402
from langfuse.api import DatasetItem  # noqa: E402
from langfuse.experiment import (  # noqa: E402
    Evaluation,
    ExperimentItem,
    ExperimentItemResult,
    ExperimentResult,
    LocalExperimentItem,
)
from opentelemetry.sdk.trace.export.in_memory_span_exporter import (  # noqa: E402
    InMemorySpanExporter,
)

from observability_ai.evaluation import (  # noqa: E402
    EvaluationResult,
    Evaluator,
    ExactMatch,
)
from observability_ai.langfuse import (  # noqa: E402
    DatasetItemRecord,
    ExperimentReport,
    ExperimentRunner,
    RegressionDetected,
    RegressionGate,
)


def _echo(*, item: ExperimentItem, **kwargs: object) -> object:
    return item.input if isinstance(item, DatasetItem) else item.get("input")


def _result(evaluations: Sequence[Sequence[Evaluation]]) -> ExperimentResult:
    return Mock(
        spec=ExperimentResult,
        item_results=[
            ExperimentItemResult(
                item={"input": "x"},
                output="x",
                evaluations=list(scores),
                trace_id="trace",
                dataset_run_id=None,
            )
            for scores in evaluations
        ],
        run_evaluations=[],
    )


def test_real_sdk_experiment_adapts_async_multi_scores_and_run_evaluators(
    sdk: tuple[Langfuse, InMemorySpanExporter],
    monkeypatch: MonkeyPatch,
) -> None:
    """SDK execution receives local records and persists converted result metadata."""
    client, _ = sdk
    score = Mock()
    monkeypatch.setattr(client, "create_score", score)
    monkeypatch.setattr(client, "flush", Mock())
    seen: list[object] = []

    async def metrics(
        *,
        input: object,
        output: object,
        expected_output: object,
        metadata: Mapping[str, object] | None,
    ) -> tuple[EvaluationResult, ...]:
        seen.append(metadata)
        return (
            EvaluationResult(
                "quality", 0.75, comment="checked", metadata={"judge": "v1"}
            ),
            EvaluationResult("label", "pass", "CATEGORICAL"),
        )

    async def aggregate(
        *, item_results: Sequence[ExperimentItemResult]
    ) -> EvaluationResult:
        return EvaluationResult("items", len(item_results))

    report = ExperimentRunner(client).run(
        "qa",
        data=[
            DatasetItemRecord("a", "a", {"split": "test"}),
            DatasetItemRecord("b", "c"),
        ],
        task=_echo,
        evaluators=[ExactMatch(), metrics],
        run_evaluators=[aggregate],
        run_name="candidate",
        max_concurrency=2,
    )
    assert (report.total_count, report.completed_count, report.failed_count) == (
        2,
        2,
        0,
    )
    assert report.evaluation_count == 6
    assert report.metric_means == {"exact_match": 0.5, "quality": 0.75}
    assert report.metric_counts == {"exact_match": 2, "quality": 2}
    assert report.run_evaluations == (EvaluationResult("items", 2),)
    assert report.evaluator_failures == ()
    assert seen == [{"split": "test"}, {}]
    quality_calls = [
        call.kwargs for call in score.call_args_list if call.kwargs["name"] == "quality"
    ]
    assert len(quality_calls) == 2
    assert all(call["metadata"] == {"judge": "v1"} for call in quality_calls)
    assert all(call["comment"] == "checked" for call in quality_calls)
    RegressionGate({"quality": 0.75, "exact_match": 0.5}).check(report)


def test_sdk_partial_task_and_evaluator_failures_cannot_pass_gate(
    sdk: tuple[Langfuse, InMemorySpanExporter],
    monkeypatch: MonkeyPatch,
) -> None:
    """Task omissions and swallowed evaluator errors both survive in the report."""
    client, _ = sdk
    monkeypatch.setattr(client, "create_score", Mock())
    monkeypatch.setattr(client, "flush", Mock())

    async def task(*, item: ExperimentItem, **kwargs: object) -> object:
        value = _echo(item=item)
        if value == "bad":
            raise RuntimeError("task failed")
        return value

    def broken(**kwargs: object) -> EvaluationResult:
        raise RuntimeError("judge failed")

    def broken_run(*, item_results: Sequence[ExperimentItemResult]) -> EvaluationResult:
        raise ValueError("aggregate failed")

    report = ExperimentRunner(client).run(
        "qa",
        data=[DatasetItemRecord("ok", "ok"), DatasetItemRecord("bad", "bad")],
        task=task,
        evaluators=[ExactMatch(), broken],
        run_evaluators=[broken_run],
    )
    assert report.failed_count == 1
    assert report.metric_means == {"exact_match": 1.0}
    assert len(report.evaluator_failures) == 2
    assert "judge failed" in report.evaluator_failures[0]
    assert "aggregate failed" in report.evaluator_failures[1]
    with raises(RegressionDetected, match="1 item.*2 evaluator"):
        RegressionGate({"exact_match": 0.9}).check(report)


@mark.parametrize(
    "returned",
    [
        None,
        "wrong",
        [EvaluationResult("valid", 1), 2],
        EvaluationResult("text", "note", "TEXT"),
    ],
)
def test_invalid_evaluator_outputs_are_reported(
    sdk: tuple[Langfuse, InMemorySpanExporter],
    monkeypatch: MonkeyPatch,
    returned: object,
) -> None:
    """Malformed sequences and unsupported SDK TEXT scores are evaluator failures."""
    client, _ = sdk
    score = Mock()
    monkeypatch.setattr(client, "create_score", score)
    monkeypatch.setattr(client, "flush", Mock())
    evaluator = cast(Evaluator, lambda **kwargs: returned)
    report = ExperimentRunner(client).run(
        "qa", data=[DatasetItemRecord("a")], task=_echo, evaluators=[evaluator]
    )
    assert len(report.evaluator_failures) == 1
    assert report.evaluation_count == 0
    score.assert_not_called()
    with raises(RegressionDetected):
        RegressionGate({}).check(report)


def test_hosted_data_preserves_identity_version_and_run_options() -> None:
    """Native dataset objects remain native so the SDK links runs to their version."""
    client = Mock(spec=Langfuse)
    client.run_experiment.return_value = _result([])
    item = Mock(spec=DatasetItem)
    dataset = Mock(
        spec=DatasetClient, items=[item], version=datetime(2026, 9, 1, tzinfo=UTC)
    )
    ExperimentRunner(client).run(
        "qa",
        data=dataset,
        task=_echo,
        evaluators=[],
        run_name="v2",
        description="candidate",
        metadata={"model": "test"},
        max_concurrency=3,
    )
    call = client.run_experiment.call_args.kwargs
    assert call["data"] == [item]
    assert call["data"][0] is item
    assert call["_dataset_version"] == dataset.version
    assert call["run_name"] == "v2"
    assert call["description"] == "candidate"
    assert call["metadata"] == {"model": "test"}
    assert call["max_concurrency"] == 3
    client.shutdown.assert_not_called()


def test_local_dictionary_data_and_client_failure() -> None:
    """Plain local SDK dictionaries are copied and SDK invocation errors propagate."""
    client = Mock(spec=Langfuse)
    client.run_experiment.return_value = _result([])
    item: LocalExperimentItem = {"input": "a", "metadata": {"split": "test"}}
    runner = ExperimentRunner(client)
    runner.run("qa", data=[item], task=_echo, evaluators=[])
    prepared = client.run_experiment.call_args.kwargs["data"][0]
    assert prepared["input"] == "a"
    assert prepared is not item
    failure = RuntimeError("SDK failure")
    client.run_experiment.side_effect = failure
    with raises(RuntimeError) as caught:
        runner.run("qa", data=[], task=_echo, evaluators=[])
    assert caught.value is failure


@mark.parametrize(
    "kwargs",
    [
        {"name": " "},
        {"max_concurrency": 0},
        {"max_concurrency": True},
        {"run_name": ""},
        {"description": 1},
        {"metadata": {"key": 1}},
        {"metadata": {"": "value"}},
        {"task": None},
        {"evaluators": [None]},
        {"run_evaluators": [None]},
        {"data": [1]},
    ],
)
def test_invalid_experiment_configuration_never_runs(kwargs: dict[str, Any]) -> None:
    """Reject invalid settings before SDK side effects or deadlocked concurrency."""
    client = Mock(spec=Langfuse)
    arguments: dict[str, Any] = {
        "name": "qa",
        "data": [],
        "task": _echo,
        "evaluators": [],
    } | kwargs
    with raises((ValueError, TypeError)):
        ExperimentRunner(client).run(**arguments)
    client.run_experiment.assert_not_called()


def test_report_snapshot_separates_run_scores_and_handles_large_values() -> None:
    """Means stay finite, and SDK result mutations cannot alter the summary."""
    result = _result(
        [
            [Evaluation(name="metric", value=1e308)],
            [Evaluation(name="metric", value=1e308)],
        ]
    )
    result.run_evaluations = [Evaluation(name="metric", value=0)]
    report = ExperimentReport(result, 2)
    assert report.metric_means == {"metric": 1e308}
    result.item_results.clear()
    result.run_evaluations.clear()
    assert report.completed_count == 2
    assert report.metric_counts == {"metric": 2}
    assert report.run_evaluations == (EvaluationResult("metric", 0),)
    with raises(TypeError):
        cast(dict[str, float], report.metric_means)["metric"] = 0
    with raises(FrozenInstanceError):
        setattr(report, "failed_count", 0)


@mark.parametrize(
    "scores",
    [
        [[Evaluation(name="m", value=float("nan"))]],
        [
            [
                Evaluation(name="m", value=1),
                Evaluation(name="m", value="x", data_type="CATEGORICAL"),
            ]
        ],
    ],
)
def test_report_rejects_invalid_or_conflicting_sdk_metrics(
    scores: Sequence[Sequence[Evaluation]],
) -> None:
    """Invalid SDK values cannot silently pollute CI aggregates."""
    with raises(ValueError):
        ExperimentReport(_result(scores), 1)


@mark.parametrize(
    ("values", "total", "thresholds", "message"),
    [
        ([0.7, 0.9], 2, {"quality": 0.81}, "quality"),
        ([1.0], 1, {"absent": 0}, "missing metric absent"),
        ([1.0], 2, {}, "item.*failed"),
        ([], 0, {}, "no items"),
    ],
)
def test_regression_gate_rejects_incomplete_or_below_threshold_reports(
    values: list[float],
    total: int,
    thresholds: dict[str, float],
    message: str,
) -> None:
    """The gate fails missing data as well as metric regressions."""
    report = ExperimentReport(
        _result([[Evaluation(name="quality", value=value)] for value in values]), total
    )
    with raises(RegressionDetected, match=message):
        RegressionGate(thresholds).check(report)


@mark.parametrize("thresholds", [{"m": float("nan")}, {"m": True}, {"": 1}, {"m": "1"}])
def test_gate_validates_thresholds(thresholds: dict[str, Any]) -> None:
    """Invalid thresholds cannot silently turn off comparisons."""
    with raises((ValueError, TypeError)):
        RegressionGate(thresholds)


def test_gate_snapshots_thresholds_and_equality_passes() -> None:
    """Caller mutations cannot change a configured gate, and exact equality passes."""
    thresholds = {"m": 1.0}
    gate = RegressionGate(thresholds)
    thresholds["m"] = 2.0
    gate.check(ExperimentReport(_result([[Evaluation(name="m", value=1)]]), 1))
