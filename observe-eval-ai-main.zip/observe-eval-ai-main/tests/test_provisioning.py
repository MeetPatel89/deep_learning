"""Verify provisioning values and local persistence without external systems."""

from dataclasses import FrozenInstanceError, replace
from json import dumps, loads
from pathlib import Path
from stat import S_IMODE
from uuid import UUID

from pytest import mark, raises

from observability_ai.provisioning import (
    AppProvision,
    ProvisionedApp,
    ProvisioningError,
    init_environment,
    read_env_file,
    read_registry,
    resolve_stack_dir,
    upsert_env_file,
    write_registry,
)


@mark.parametrize("app", ["a", "fieldguide", "app-123", "a" * 40])
def test_app_defaults_generate_distinct_valid_credentials(app: str) -> None:
    """Each valid app receives default identity and independent UUID key pairs."""
    first = AppProvision(app)
    second = AppProvision(app)
    assert first.project_id == app
    assert first.project_name == app
    assert first.org_id == "observability-ai"
    assert first.org_name == "Observability AI"
    assert first.public_key.startswith("pk-lf-")
    assert first.secret_key.startswith("sk-lf-")
    assert UUID(first.public_key.removeprefix("pk-lf-")).version == 4
    assert UUID(first.secret_key.removeprefix("sk-lf-")).version == 4
    assert first.public_key != second.public_key
    assert first.secret_key != second.secret_key
    assert first.user_password is None
    assert first.secret_key not in repr(first)
    with raises(FrozenInstanceError):
        setattr(first, "app", "changed")


@mark.parametrize("app", ["", "Fieldguide", "a_b", "a b", "../app", "a" * 41])
def test_invalid_slug_is_rejected(app: str) -> None:
    """Unsupported slugs fail before they can identify a remote project."""
    with raises(ProvisioningError, match="app"):
        AppProvision(app)


@mark.parametrize("retention_days", [-1, 0, 1, 2, True])
def test_retention_requires_langfuse_minimum(retention_days: int) -> None:
    """Retention values below Langfuse's three-day minimum are invalid."""
    with raises(ProvisioningError, match="retention"):
        AppProvision("fieldguide", retention_days=retention_days)


def test_optional_owner_password_is_generated_and_hidden() -> None:
    """An owner gets a strong transient password that cannot leak through repr."""
    spec = AppProvision("fieldguide", user_email="owner@example.com")
    assert spec.user_password is not None
    assert len(spec.user_password) >= 32
    assert spec.user_password not in repr(spec)
    with raises(ProvisioningError, match="user_email"):
        AppProvision("fieldguide", user_name="Owner")
    with raises(ProvisioningError, match="user_email"):
        AppProvision("fieldguide", user_password="do-not-print")
    with raises(ProvisioningError, match="email"):
        AppProvision("fieldguide", user_email="not-an-email")


def test_init_mapping_includes_exact_names_and_resolved_values() -> None:
    """All supported Langfuse startup settings map to their upstream names."""
    spec = AppProvision(
        "fieldguide",
        project_id="project-123",
        project_name="Fieldguide",
        org_id="learning",
        org_name="Learning Apps",
        user_email="owner@example.com",
        user_name="Owner",
        user_password="generated-password",
        retention_days=30,
        public_key="pk-lf-public",
        secret_key="sk-lf-secret",
    )
    assert init_environment(spec) == {
        "LANGFUSE_INIT_ORG_ID": "learning",
        "LANGFUSE_INIT_ORG_NAME": "Learning Apps",
        "LANGFUSE_INIT_PROJECT_ID": "project-123",
        "LANGFUSE_INIT_PROJECT_NAME": "Fieldguide",
        "LANGFUSE_INIT_PROJECT_RETENTION": "30",
        "LANGFUSE_INIT_PROJECT_PUBLIC_KEY": "pk-lf-public",
        "LANGFUSE_INIT_PROJECT_SECRET_KEY": "sk-lf-secret",
        "LANGFUSE_INIT_USER_EMAIL": "owner@example.com",
        "LANGFUSE_INIT_USER_NAME": "Owner",
        "LANGFUSE_INIT_USER_PASSWORD": "generated-password",
    }


def test_init_mapping_masks_stale_optional_stack_values() -> None:
    """Absent optional fields explicitly override stale values in stack dotenv."""
    environment = init_environment(AppProvision("fieldguide"))
    for name in (
        "LANGFUSE_INIT_PROJECT_RETENTION",
        "LANGFUSE_INIT_USER_EMAIL",
        "LANGFUSE_INIT_USER_NAME",
        "LANGFUSE_INIT_USER_PASSWORD",
    ):
        assert environment[name] == ""


def test_env_upsert_preserves_comments_and_unrelated_lines(tmp_path: Path) -> None:
    """Replacing keys removes duplicates while retaining other app settings."""
    path = tmp_path / ".env"
    path.write_text(
        "# app settings\n"
        "OTHER='unchanged value' # keep\n"
        "export LANGFUSE_PUBLIC_KEY=pk-lf-old # public key\n"
        "LANGFUSE_PUBLIC_KEY=pk-lf-duplicate # duplicate comment\n"
        "\n"
        "LANGFUSE_SECRET_KEY=sk-lf-old\n"
        "LAST=value"
    )
    path.chmod(0o640)
    values = {
        "LANGFUSE_PUBLIC_KEY": "pk-lf-new",
        "LANGFUSE_SECRET_KEY": "sk-lf-new",
        "LANGFUSE_BASE_URL": "http://localhost:3333",
    }
    upsert_env_file(path, values)
    content = path.read_text()
    assert content.startswith("# app settings\nOTHER='unchanged value' # keep\n")
    assert "# public key" in content
    assert "# duplicate comment" in content
    assert "\n\n" in content
    assert "LAST=value\n" in content
    assert content.count("LANGFUSE_PUBLIC_KEY=") == 1
    assert read_env_file(path) == {
        "OTHER": "unchanged value",
        "LAST": "value",
        **values,
    }
    assert S_IMODE(path.stat().st_mode) == 0o640
    upsert_env_file(path, values)
    assert path.read_text() == content


def test_env_create_is_private_and_preserves_literal_values(tmp_path: Path) -> None:
    """New dotenv files use 0600 and quoting round-trips shell-like text."""
    path = tmp_path / ".env"
    values = {
        "SPACE": "value with spaces",
        "HASH": "value # still value",
        "QUOTES": 'owner\'s \\"value\\"',
        "SHELL": "$(touch should-not-exist) ${HOME} `id`",
        "EMPTY": "",
    }
    upsert_env_file(path, values)
    assert S_IMODE(path.stat().st_mode) == 0o600
    assert read_env_file(path) == values
    assert not (tmp_path / "should-not-exist").exists()


def test_env_read_supports_exports_comments_and_last_duplicate(tmp_path: Path) -> None:
    """Reading existing dotenv files respects quotes without shell expansion."""
    path = tmp_path / ".env"
    path.write_text(
        "# comment\n"
        "export STACK='../observe-eval-ai/observability' # stack\n"
        'MESSAGE="a # value" # comment\n'
        "VALUE=first\n"
        "VALUE=last # comment\n"
        "LITERAL=${VALUE}\n"
        "EMPTY= # comment\n"
    )
    assert read_env_file(path) == {
        "STACK": "../observe-eval-ai/observability",
        "MESSAGE": "a # value",
        "VALUE": "last",
        "LITERAL": "${VALUE}",
        "EMPTY": "",
    }
    assert read_env_file(tmp_path / "missing.env") == {}


@mark.parametrize(
    "values", [{"BAD-KEY": "value"}, {"KEY": "first\nSECOND=bad"}, {"KEY": "a\0b"}]
)
def test_invalid_env_update_leaves_file_untouched(
    tmp_path: Path, values: dict[str, str]
) -> None:
    """Invalid updates cannot inject assignments or partially replace a file."""
    path = tmp_path / ".env"
    path.write_text("ORIGINAL=keep\n")
    with raises(ProvisioningError):
        upsert_env_file(path, values)
    assert path.read_text() == "ORIGINAL=keep\n"


def test_registry_round_trip_contains_only_public_metadata(tmp_path: Path) -> None:
    """The registry retains app identity and timestamps without secret fields."""
    path = tmp_path / "provisioned.json"
    record = ProvisionedApp(
        app="fieldguide",
        org_id="observability-ai",
        project_id="fieldguide",
        public_key="pk-lf-public",
        user_email="owner@example.com",
        created_at="2026-09-25T10:00:00+00:00",
        rotated_at="2026-09-25T11:00:00+00:00",
    )
    assert read_registry(path) == []
    write_registry(path, [record])
    assert read_registry(path) == [record]
    payload = loads(path.read_text())
    assert set(payload[0]) == {
        "app",
        "org_id",
        "project_id",
        "public_key",
        "user_email",
        "created_at",
        "rotated_at",
    }
    assert "secret" not in path.read_text()
    assert "password" not in path.read_text()
    assert S_IMODE(path.stat().st_mode) == 0o600


def test_registry_rejects_ambiguous_projects_and_public_keys(tmp_path: Path) -> None:
    """Two app records cannot silently claim the same project or credential."""
    path = tmp_path / "provisioned.json"
    first = ProvisionedApp("fieldguide", "observability-ai", "fieldguide", "pk-lf-one")
    write_registry(path, [first])
    original = path.read_bytes()
    for second in (
        first,
        replace(first, app="scratch", public_key="pk-lf-two"),
        replace(first, app="scratch", project_id="scratch"),
    ):
        with raises(ProvisioningError, match="duplicate"):
            write_registry(path, [first, second])
        assert path.read_bytes() == original


@mark.parametrize("contents", ["{broken", "{}", "[1]", '[{"secret_key":"hidden"}]'])
def test_malformed_registry_is_rejected_without_echoing_values(
    tmp_path: Path, contents: str
) -> None:
    """Corrupt or unsupported registry records fail without echoing their data."""
    path = tmp_path / "provisioned.json"
    path.write_text(contents)
    with raises(ProvisioningError, match="registry") as caught:
        read_registry(path)
    assert "hidden" not in str(caught.value)


def test_registry_read_rejects_duplicate_app_records(tmp_path: Path) -> None:
    """A manually edited registry is subject to the same identity constraints."""
    path = tmp_path / "provisioned.json"
    write_registry(
        path,
        [ProvisionedApp("fieldguide", "observability-ai", "fieldguide", "pk-lf-one")],
    )
    records = loads(path.read_text())
    path.write_text(dumps(records + records))
    with raises(ProvisioningError, match="registry"):
        read_registry(path)


def test_stack_resolution_prefers_flag_and_requires_both_files(tmp_path: Path) -> None:
    """An explicit stack beats the environment and resolves to an existing stack."""
    stack = tmp_path / "observability"
    stack.mkdir()
    (stack / "compose.yaml").write_text("services: {}\n")
    (stack / ".env").write_text("LANGFUSE_BASE_URL=http://localhost:3000\n")
    assert (
        resolve_stack_dir(
            stack, {"OBSERVABILITY_AI_STACK_DIR": str(tmp_path / "wrong")}
        )
        == stack.resolve()
    )
    assert resolve_stack_dir(None, {"OBSERVABILITY_AI_STACK_DIR": str(stack)}) == stack
    with raises(ProvisioningError, match="--stack-dir.*OBSERVABILITY_AI_STACK_DIR"):
        resolve_stack_dir(None, {})
    (stack / ".env").unlink()
    with raises(ProvisioningError, match=".env"):
        resolve_stack_dir(stack, {})
