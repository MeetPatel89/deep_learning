---
doc_id: RUNBOOK-SSO-003
title: Identity Gateway SSO Login Failure Runbook
doc_type: runbook
service_id: svc_identity_gateway
owner_group: IAM Platform
visibility: internal
status: active
created_at: "2026-05-20T10:00:00"
updated_at: "2026-06-14T09:30:00"
related_records:
  - KI-104
  - CHG-2407
  - INC-1104
  - KB-118
  - POL-COMMS-001
source_facts:
  - KI-104
  - svc_identity_gateway
difficulty_tags:
  - procedural
  - action-sequencing
  - permission-boundary
---

# Identity Gateway SSO Login Failure Runbook

## Purpose

This runbook describes how to triage and recover Identity Gateway SSO login failures, especially failures reported after identity maintenance or certificate rotation. The primary matching known issue is KI-104, where some Identity Gateway nodes may continue using stale IdP metadata after certificate rotation.

The runbook is internal and includes diagnostic details that should not be copied directly into customer-facing messages.

## When to use this runbook

Use this runbook when Service Desk L1 or IAM Platform receives reports such as:

- Employee Portal login failure.
- Invalid SAML response.
- Users can reach the sign-in page but cannot complete authentication.
- Some users can log in while others cannot.
- A recent identity-related change appears in the last 24 hours.

First confirm whether the issue affects one user, a group, or many users. A single-user report may still require account or browser checks. A multi-user pattern after identity maintenance should be treated as a possible KI-104 event.

## Required inputs

Collect the following before escalation or remediation:

| Input | Why it matters |
| --- | --- |
| Affected application | Employee Portal is the most common report, but other internal applications can use Identity Gateway. |
| Exact error text | Invalid SAML response is a strong indicator for KI-104. |
| Scope | One user, group, branch, or broad multi-user impact. |
| First observed time | Needed to compare against CHG-2407 or another identity change. |
| Recent changes | Identity maintenance in the last 24 hours changes routing priority. |
| User retest result | Confirms whether recovery steps cleared the issue. |

## Initial triage

1. Confirm the affected service candidate is Identity Gateway and not an application-specific authorization issue.
2. Confirm whether the issue affects one user, a group, or many users.
3. Capture the exact error text from the user or ticket.
4. Check whether an identity-related change was implemented in the last 24 hours.
5. If the user reports invalid SAML response and impact is partial, review KI-104.

If a recent change is found, note the change record in the incident. For CHG-2407, the maintenance window ended at 2026-06-12T23:00:00 and INC-1104 was opened at 2026-06-12T23:18:00.

## Investigation steps

For IAM Platform:

1. Review the active identity maintenance or certificate rotation record.
2. Verify the active IdP certificate thumbprint.
3. Compare observed login behavior across affected and unaffected users.
4. Check whether the gateway path suggests partial node inconsistency.
5. Refresh the Identity Gateway metadata cache.
6. Ask Service Desk L1 to coordinate retesting with affected users.
7. Record whether invalid SAML response errors stop after cache refresh.

Do not keep the ticket with Service Desk L1 if many users are affected and the error matches KI-104. The owning group is IAM Platform.

## Decision points

Use these decision points during handling:

- If only one user is affected and no identity change occurred, continue normal access troubleshooting before platform escalation.
- If multiple users are affected and invalid SAML response is reported, escalate to IAM Platform.
- If identity maintenance occurred in the last 24 hours, link the incident to the change record and notify Release Management.
- If cache refresh clears most failures, keep the record linked to KI-104 and PRB-202.
- If cache refresh does not improve the issue, IAM Platform should continue deeper Identity Gateway investigation.

## Workaround or recovery steps

The approved KI-104 workaround is:

1. Refresh the Identity Gateway metadata cache.
2. Verify the active IdP certificate thumbprint.
3. Confirm Employee Portal login works for at least one previously affected user.
4. Ask Service Desk L1 to collect any remaining failed login examples.
5. Keep the incident open until multi-user failures have stopped or been transferred into user-specific tickets.

Refreshing the Identity Gateway metadata cache resolved most failures in INC-1104.

## Escalation criteria

Escalate to IAM Platform if failures continue after cache refresh.

Escalate or notify additionally as follows:

- Release Management: incident appears related to a recent completed identity change.
- Service Desk L1 lead: customer-facing communication needs approval.
- IAM Platform: certificate thumbprint verification, cache refresh, or continuing platform failures are required.

## Customer-safe communication

Do not copy internal root-cause detail into external updates. Use POL-COMMS-001 and the KI-104 safe summary:

"We are validating the enterprise sign-in configuration after scheduled identity maintenance."

Avoid mentioning stale IdP metadata, metadata cache internals, node inconsistency, or certificate thumbprint details in customer-facing communication unless IAM Platform explicitly approves different wording.

## Related records

- KI-104: SSO Metadata Cache Delay After Certificate Rotation.
- CHG-2407: Rotate Okta Signing Certificate for Identity Gateway.
- INC-1104: Employee Portal Login Failures After Okta Certificate Rotation.
- KB-118: Employee Portal SSO Login Troubleshooting.
- POL-COMMS-001: Customer-Safe Communication Policy.

