import polars as pl
import pytest

from qa_mcp_server.models import CompareOptions, InlineSource, OutputOptions
from qa_mcp_server.service import compare


@pytest.fixture
def run_compare(tmp_path):
    def run(expected, actual, *, output=None, **options):
        return compare(
            InlineSource(rows=expected),
            InlineSource(rows=actual),
            CompareOptions(**options),
            output or OutputOptions(output_dir=tmp_path),
        )

    return run


def read_dump(result):
    return pl.read_parquet(result["mismatch_parquet_path"] + "/*.parquet")
