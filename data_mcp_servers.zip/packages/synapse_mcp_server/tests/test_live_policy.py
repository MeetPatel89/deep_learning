import asyncio
from unittest.mock import Mock

import pytest
from synapse_mcp_server.clients import ClientRegistry
from synapse_mcp_server.config import SynapseConfig, WorkspaceConfig
from synapse_mcp_server.server import TOOLSETS, SynapseService, create_server

LIVE_CALLS = [
    ("get_workspace_info", {}),
    ("list_sql_pools", {}),
    ("list_spark_pools", {}),
    ("list_integration_runtimes", {}),
    ("list_role_assignments", {}),
    ("list_artifacts", {"source": "live"}),
    ("get_artifact", {"source": "live", "artifact_type": "pipeline", "name": "P"}),
    ("search_artifacts", {"source": "live", "text": "x"}),
    ("analyze_pipeline", {"source": "live", "pipeline": "P"}),
    (
        "upsert_artifact",
        {"source": "live", "artifact_type": "pipeline", "name": "P", "artifact": {}},
    ),
    ("delete_artifact", {"source": "live", "artifact_type": "pipeline", "name": "P"}),
    ("query_pipeline_runs", {}),
    ("get_pipeline_run", {"run_id": "r"}),
    ("query_activity_runs", {"run_id": "r"}),
    ("query_trigger_runs", {}),
    ("diagnose_pipeline_run", {"run_id": "r"}),
    ("run_pipeline", {"pipeline": "P"}),
    ("cancel_pipeline_run", {"run_id": "r"}),
    ("start_trigger", {"trigger": "t"}),
    ("pause_sql_pool", {"pool": "p"}),
    ("list_spark_applications", {}),
    ("get_spark_application_logs", {"pool": "p", "application_id": "a"}),
    ("create_spark_session", {"pool": "p", "name": "n"}),
    ("run_spark_statement", {"pool": "p", "session_id": 1, "code": "print(1)"}),
    ("submit_spark_batch", {"pool": "p", "name": "n", "file": "f"}),
    ("create_data_flow_debug_session", {}),
    ("test_sql_connection", {}),
    ("run_sql_query", {"query": "SELECT 1"}),
    ("run_sql_query", {"query": "DELETE FROM x"}),
    ("list_sql_objects", {}),
]


@pytest.mark.parametrize("method,kwargs", LIVE_CALLS)
def test_live_disabled_blocks_before_injected_clients_or_sql(method, kwargs, tmp_path):
    settings = WorkspaceConfig(
        name="example", allow_run=True, allow_manage=True, allow_sql_write=True
    )
    registry = Mock(spec=ClientRegistry)
    service = SynapseService(
        SynapseConfig(workspaces={"dev": settings}, execution_store=str(tmp_path / "db")), registry
    )
    with pytest.raises(PermissionError, match="allow_live_env"):
        getattr(service, method)("dev", **kwargs)
    registry.get.assert_not_called()
    registry.http_get.assert_not_called()


@pytest.mark.parametrize("kind", ["artifacts", "spark", "arm", "accesscontrol", "http"])
def test_registry_rechecks_permission_before_cache_or_authentication(kind, monkeypatch):
    config = SynapseConfig(workspaces={"dev": WorkspaceConfig(name="example")})
    registry = ClientRegistry(config)
    registry._clients[("dev", kind, None)] = Mock()
    auth = Mock(side_effect=AssertionError("authentication must not happen"))
    monkeypatch.setattr("synapse_mcp_server.clients.get_credential", auth)
    monkeypatch.setattr("synapse_mcp_server.clients.get_token", auth)
    with pytest.raises(PermissionError, match="allow_live_env"):
        registry.get("dev", kind)
    with pytest.raises(PermissionError, match="allow_live_env"):
        registry.http_get("dev", "/monitoring")
    auth.assert_not_called()


def test_default_config_and_mcp_schemas():
    settings = WorkspaceConfig(name="example")
    assert not settings.allow_live_env and not settings.allow_git_write
    assert settings.branch_execution_backend == "studio_http"
    server = create_server(SynapseConfig())
    tools = {tool.name: tool for tool in asyncio.run(server.list_tools())}
    assert set(tools) == {name for names in TOOLSETS.values() for name in names}
    for name in ("wait_for_pipeline_run", "wait_for_branch_pipeline_run"):
        assert "ctx" not in tools[name].inputSchema["properties"]
    assert tools["get_artifact"].inputSchema["properties"]["source"]["default"] == "git"
    assert "expected_revision" in tools["create_draft_pr"].inputSchema["required"]
    assert not any(name.startswith(("merge", "publish")) for name in tools)
