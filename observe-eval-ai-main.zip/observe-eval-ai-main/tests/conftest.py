"""Isolated settings and in-memory telemetry fixtures."""

from collections.abc import Iterator
from os import environ
from typing import TYPE_CHECKING
from uuid import uuid4

from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from pytest import MonkeyPatch, fixture

from observability_ai import LangfuseSettings, Telemetry

if TYPE_CHECKING:
    from langfuse import Langfuse


@fixture(autouse=True)
def isolated_environment(monkeypatch: MonkeyPatch) -> None:
    """Keep developer credentials and OTel configuration out of unit tests."""
    for name in tuple(environ):
        if name.startswith(("LANGFUSE_", "OTEL_")):
            monkeypatch.delenv(name)


@fixture
def settings() -> LangfuseSettings:
    """Return valid, deliberately fictitious project credentials."""
    return LangfuseSettings(public_key="pk-lf-test", secret_key="sk-lf-test")


@fixture
def otel(
    settings: LangfuseSettings,
) -> Iterator[tuple[Telemetry, InMemorySpanExporter]]:
    """Capture completed spans without constructing a network exporter."""
    exporter = InMemorySpanExporter()
    with Telemetry(
        settings,
        service_name="test-app",
        service_version="1.2.3",
        span_processor=SimpleSpanProcessor(exporter),
    ) as telemetry:
        yield telemetry, exporter


@fixture
def sdk() -> Iterator[tuple[Langfuse, InMemorySpanExporter]]:
    """Give each SDK test its own project resources and local span exporter."""
    from observability_ai.langfuse import build_langfuse_client

    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    client = build_langfuse_client(
        LangfuseSettings(
            public_key=f"pk-lf-{uuid4().hex}",
            secret_key="sk-lf-test",
            base_url="http://127.0.0.1:1",
            environment="test",
            release="sdk-test",
        ),
        tracer_provider=provider,
        span_exporter=exporter,
    )
    try:
        yield client, exporter
    finally:
        client.shutdown()
        provider.shutdown()
