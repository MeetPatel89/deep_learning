"""Connect model-runtime's existing observer to application-owned telemetry."""

from typing import TYPE_CHECKING

from ..attributes import TraceAttributes
from ..telemetry import Telemetry

if TYPE_CHECKING:
    from model_runtime.observability import OTelTraceObserver


def model_runtime_observer(
    telemetry: Telemetry,
    *,
    provider_name: str,
    trace: TraceAttributes | None = None,
    capture_message_content: bool | None = None,
) -> OTelTraceObserver:
    """Build the native observer without adding spans or owning a provider.

    Install ``observe-eval-ai[model-runtime]`` to use this factory. Each logical
    model call is a Langfuse generation, including when ``trace`` is omitted.
    Content capture follows model-runtime: ``None`` reads the standard GenAI
    environment flag, and an explicit bool overrides it. Reuse an observer only
    for requests that share its provider name and fixed trace dimensions.
    """
    try:
        from model_runtime.observability import (
            LangfuseTraceAttributes,
            OTelTraceObserver,
        )
    except ModuleNotFoundError as exc:
        if exc.name is None or exc.name.split(".")[0] != "model_runtime":
            raise
        raise ImportError(
            "model-runtime support is not installed; "
            "install observe-eval-ai[model-runtime]"
        ) from exc

    dimensions = trace if trace is not None else TraceAttributes()
    return OTelTraceObserver(
        telemetry.tracer("observability_ai.adapters.model_runtime"),
        provider_name=provider_name,
        capture_message_content=capture_message_content,
        # A non-None value also enables the upstream generation type attribute.
        langfuse_trace=LangfuseTraceAttributes(
            session_id=dimensions.session_id,
            user_id=dimensions.user_id,
            tags=dimensions.tags,
            metadata=dimensions.metadata,
        ),
    )


__all__ = ["model_runtime_observer"]
