"""Evaluate historical traces and observations using Langfuse's batch runner."""

from collections.abc import Mapping, Sequence
from typing import Literal

from langfuse import Langfuse
from langfuse.batch_evaluation import (
    BatchEvaluationResult,
    BatchEvaluationResumeToken,
    MapperFunction,
)

from ..evaluation.results import Evaluator, _metadata_snapshot
from ._evaluation import _adapt_evaluator, _validate_integer


class BatchEvaluation:
    """Adapt core evaluators while the SDK owns fetching, retries, and resume state."""

    def __init__(self, client: Langfuse) -> None:
        """Reuse the supplied client without owning its lifecycle."""
        self._client = client

    def run(
        self,
        *,
        mapper: MapperFunction,
        evaluators: Sequence[Evaluator],
        scope: Literal["traces", "observations"] = "traces",
        filter: str | None = None,
        fetch_batch_size: int = 50,
        fetch_trace_fields: str | None = None,
        max_items: int | None = None,
        max_retries: int = 3,
        max_concurrency: int = 5,
        metadata: Mapping[str, object] | None = None,
        resume_from: BatchEvaluationResumeToken | None = None,
        verbose: bool = False,
    ) -> BatchEvaluationResult:
        """Score fetched history and return native SDK statistics and resume state.

        The mapper follows the SDK's keyword-only ``item`` contract and returns
        ``EvaluatorInputs`` (sync or async). Filters use the SDK's JSON format.
        Individual errors are recorded by the SDK; inspect its result for them.
        """
        if scope not in ("traces", "observations"):
            raise ValueError("scope must be traces or observations")
        if not callable(mapper):
            raise TypeError("mapper must be callable")
        for name, value in (
            ("fetch_batch_size", fetch_batch_size),
            ("max_concurrency", max_concurrency),
        ):
            _validate_integer(name, value)
        _validate_integer("max_retries", max_retries, minimum=0)
        if max_items is not None:
            _validate_integer("max_items", max_items)
        for option, text in (
            ("filter", filter),
            ("fetch_trace_fields", fetch_trace_fields),
        ):
            if text is not None and not isinstance(text, str):
                raise TypeError(f"{option} must be a string")
        if not isinstance(verbose, bool):
            raise TypeError("verbose must be a boolean")
        dimensions = (
            dict(_metadata_snapshot(metadata)) if metadata is not None else None
        )
        return self._client.run_batched_evaluation(
            scope=scope,
            mapper=mapper,
            evaluators=[_adapt_evaluator(e) for e in evaluators],
            filter=filter,
            fetch_batch_size=fetch_batch_size,
            fetch_trace_fields=fetch_trace_fields,
            max_items=max_items,
            max_retries=max_retries,
            max_concurrency=max_concurrency,
            metadata=dimensions,
            resume_from=resume_from,
            verbose=verbose,
        )
