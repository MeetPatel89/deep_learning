"""Named Synapse workspaces, toolsets and explicit operation permissions."""

from pathlib import Path
from typing import Any, Literal

from data_mcp_core.auth import AuthProfile
from data_mcp_core.config import ConfigModel, DataConfig, load_config
from data_mcp_core.guards import relative_path
from data_mcp_core.results import register_secret
from pydantic import Field, SecretStr, field_validator, model_validator

Toolset = Literal["workspace", "artifacts", "monitoring", "debugging", "execution", "sql", "git"]
ALL_TOOLSETS = ["workspace", "artifacts", "monitoring", "debugging", "execution", "sql", "git"]
RepositoryBackend = Literal["local", "github"]
ArtifactSource = Literal["git", "live"]


class RepositoryConfig(ConfigModel):
    local_path: str | None = None
    github_repository: str | None = Field(default=None, pattern=r"^[\w.-]+/[\w.-]+$")
    github_token: SecretStr | None = None
    artifact_root: str = ""
    collaboration_branch: str = "main"
    publish_branch: str = "workspace_publish"
    default_backend: RepositoryBackend = "local"
    remote: str = Field(default="origin", pattern=r"^[A-Za-z0-9_][A-Za-z0-9_.-]*$")

    @field_validator("artifact_root")
    @classmethod
    def root_is_relative(cls, value):
        value = relative_path(value)
        if ".git" in value.split("/"):
            raise ValueError("artifact_root must not include .git")
        return "" if value == "." else value.rstrip("/")

    @model_validator(mode="after")
    def register_token(self):
        if self.github_token:
            register_secret(self.github_token.get_secret_value())
        return self


class BranchTestProfile(ConfigModel):
    parameters: dict[str, Any] = Field(default_factory=dict)
    # Keys are artifact_type/name; values merge into the artifact's JSON properties.
    artifact_overrides: dict[str, dict[str, Any]] = Field(default_factory=dict)
    spark_pools: list[str] = Field(default_factory=list)
    integration_runtimes: list[str] = Field(default_factory=list)


class StudioHTTPConfig(ConfigModel):
    # Internal Studio APIs have no public, stable contract. Pin a captured contract.
    contract_path: str | None = None
    contract_sha256: str | None = Field(default=None, pattern=r"^[a-f0-9]{64}$")


class WorkspaceConfig(ConfigModel):
    name: str = Field(pattern=r"^[A-Za-z0-9-]+$")
    subscription_id: str = ""
    resource_group: str = ""
    auth: str | AuthProfile = "default"
    default_dedicated_pool: str | None = None
    dedicated_pools: list[str] = Field(default_factory=list)
    serverless_database: str = "master"
    sql_driver: str = "ODBC Driver 18 for SQL Server"
    sql_timeout: int = Field(default=30, gt=0)
    allow_run: bool = False
    allow_live_env: bool = False
    allow_git_write: bool = False
    allow_manage: bool = False
    allow_sql_write: bool = False
    repository: RepositoryConfig | None = None
    branch_execution_backend: Literal["studio_http", "sdk_staging"] = "studio_http"
    default_test_profile: str | None = None
    test_profiles: dict[str, BranchTestProfile] = Field(default_factory=dict)
    studio_http: StudioHTTPConfig = Field(default_factory=StudioHTTPConfig)
    enabled_toolsets: list[Toolset] = Field(default_factory=lambda: list(ALL_TOOLSETS))

    @property
    def endpoint(self) -> str:
        return f"https://{self.name}.dev.azuresynapse.net"


class SynapseConfig(DataConfig):
    workspaces: dict[str, WorkspaceConfig] = Field(default_factory=dict)
    enabled_toolsets: list[Toolset] = Field(default_factory=lambda: list(ALL_TOOLSETS))
    execution_store: str = Field(
        default_factory=lambda: str(Path.home() / ".local/state/synapse-mcp/executions.sqlite3")
    )


def get_config() -> SynapseConfig:
    config = load_config("SYNAPSE_MCP_CONFIG", SynapseConfig)
    for workspace in config.workspaces.values():
        config.auth_profile(workspace.auth)
    return config
