-- Enterprise semantic catalog v3.1; catalog schema version 4.
-- Schema-independent bootstrap: no company tables, codes or business rules seeded.
-- Default authority: durable local SQLite behind CatalogService (one write owner).
-- On EVERY connection enable foreign_keys before transactions. Authority only:
-- journal_mode=WAL, synchronous=FULL, busy_timeout=5000 (initial tunable setting).
-- Do not apply authority WAL settings to immutable releases/in-memory readers.
-- Requires SQLite JSON functions; the separate lexical projection may use FTS5.
-- This creates metadata tables, never operational company tables.
-- Release-scoped semantic records through retrieval_profile are exportable.
-- projection_artifact and all subsequent tables are AUTHORITY-ONLY CONTROL STATE;
-- their tables can exist empty in snapshots, but their rows MUST NOT be exported.
-- Export only the selected release's approved dependency-complete semantic rows.
-- All JSON payloads also require versioned typed application validation.
-- CatalogService enforces roles, revisions, immutability, reviews and audit writes.
-- Publisher enforces kinds, evidence, source bindings, graph contracts, evaluation,
-- retrieval-profile compatibility and compare-and-swap manifest activation.
-- DDL is a bootstrap contract, NOT an upgrade migration or complete application.
-- Later PostgreSQL/Azure SQL adapters preserve these logical records and semantics.
-- Transport/harness neutral: HTTP, Python and MCP adapters share application services.
-- Managed workflow and host-controlled component modes use these SAME definitions.
-- release_manifest.application_config_json may bind semantic API/tool contract versions.
-- MCP endpoints/auth/host registration and query contexts/jobs/handles are deployment
-- or operational state, NOT semantic rows; no host-specific catalog tables required.
-- Component execution retains policy, typed preparation and sealed-artifact checks.
-- Documentation v3.1 adds these boundaries; SQL structure remains schema version 4.
PRAGMA foreign_keys = ON;

CREATE TABLE catalog_release (
    release_id TEXT NOT NULL PRIMARY KEY,
    schema_version INTEGER NOT NULL CHECK (schema_version > 0),
    status TEXT NOT NULL CHECK (status IN ('draft','reviewed','published','retired')),
    content_sha256 TEXT,
    created_at TEXT NOT NULL,
    published_at TEXT,
    edit_revision INTEGER NOT NULL DEFAULT 0 CHECK (edit_revision >= 0),
    CHECK (status <> 'published' OR
           (content_sha256 IS NOT NULL AND published_at IS NOT NULL))
);
CREATE TABLE catalog_object (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    object_id TEXT NOT NULL,
    object_kind TEXT NOT NULL CHECK (object_kind IN
      ('entity','field','value_domain','canonical_value','relationship',
       'predicate','metric','business_domain','concept','query_template')),
    label TEXT NOT NULL,
    description TEXT NOT NULL,
    owner TEXT NOT NULL,
    access_policy_ref TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('draft','reviewed','published','deprecated')),
    provenance_json TEXT NOT NULL CHECK (json_valid(provenance_json)),
    PRIMARY KEY (release_id, object_id)
);
CREATE TABLE data_source (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    source_id TEXT NOT NULL,
    provider_kind TEXT NOT NULL,
    dialect TEXT NOT NULL,
    connection_config_ref TEXT NOT NULL,
    schema_fingerprint TEXT NOT NULL,
    auth_policy_ref TEXT NOT NULL,
    freshness_json TEXT NOT NULL CHECK (json_valid(freshness_json)),
    PRIMARY KEY (release_id, source_id)
);
CREATE TABLE entity (
    release_id TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    binding_kind TEXT NOT NULL CHECK (binding_kind IN ('physical','derived')),
    connection_ref TEXT,
    physical_schema TEXT,
    physical_object TEXT,
    derived_plan_json TEXT CHECK (derived_plan_json IS NULL OR json_valid(derived_plan_json)),
    row_semantics_json TEXT NOT NULL CHECK (json_valid(row_semantics_json)),
    physical_row_key_json TEXT NOT NULL CHECK (json_valid(physical_row_key_json)),
    business_identity_json TEXT NOT NULL CHECK (json_valid(business_identity_json)),
    versioning_json TEXT NOT NULL CHECK (json_valid(versioning_json)),
    uniqueness_evidence_json TEXT NOT NULL CHECK (json_valid(uniqueness_evidence_json)),
    identity_namespace TEXT NOT NULL,
    temporal_json TEXT NOT NULL CHECK (json_valid(temporal_json)),
    access_policy_ref TEXT NOT NULL,
    PRIMARY KEY (release_id, entity_id),
    FOREIGN KEY (release_id, entity_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, connection_ref)
      REFERENCES data_source(release_id, source_id),
    CHECK ((binding_kind = 'physical' AND connection_ref IS NOT NULL
            AND physical_schema IS NOT NULL AND physical_object IS NOT NULL
            AND derived_plan_json IS NULL)
        OR (binding_kind = 'derived' AND derived_plan_json IS NOT NULL
            AND connection_ref IS NULL AND physical_schema IS NULL
            AND physical_object IS NULL))
);
CREATE TABLE value_domain (
    release_id TEXT NOT NULL,
    domain_id TEXT NOT NULL,
    normalization_json TEXT NOT NULL CHECK (json_valid(normalization_json)),
    resolution_policy_json TEXT NOT NULL CHECK (json_valid(resolution_policy_json)),
    PRIMARY KEY (release_id, domain_id),
    FOREIGN KEY (release_id, domain_id)
      REFERENCES catalog_object(release_id, object_id)
);
CREATE TABLE field (
    release_id TEXT NOT NULL,
    field_id TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    physical_column TEXT,
    expression_json TEXT CHECK (expression_json IS NULL OR json_valid(expression_json)),
    physical_type TEXT NOT NULL,
    semantic_type TEXT NOT NULL,
    nullable INTEGER NOT NULL CHECK (nullable IN (0,1)),
    null_meaning TEXT NOT NULL,
    roles_json TEXT NOT NULL CHECK (json_valid(roles_json)),
    operators_json TEXT NOT NULL CHECK (json_valid(operators_json)),
    aliases_json TEXT NOT NULL CHECK (json_valid(aliases_json)),
    sensitivity TEXT NOT NULL,
    domain_id TEXT,
    PRIMARY KEY (release_id, field_id),
    FOREIGN KEY (release_id, field_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, entity_id) REFERENCES entity(release_id, entity_id),
    FOREIGN KEY (release_id, domain_id) REFERENCES value_domain(release_id, domain_id),
    UNIQUE (release_id, entity_id, physical_column),
    CHECK ((physical_column IS NOT NULL AND expression_json IS NULL)
        OR (physical_column IS NULL AND expression_json IS NOT NULL))
);
CREATE TABLE canonical_value (
    release_id TEXT NOT NULL,
    value_id TEXT NOT NULL,
    domain_id TEXT NOT NULL,
    PRIMARY KEY (release_id, value_id),
    FOREIGN KEY (release_id, value_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, domain_id) REFERENCES value_domain(release_id, domain_id)
);
CREATE TABLE value_alias (
    release_id TEXT NOT NULL,
    value_id TEXT NOT NULL,
    locale TEXT NOT NULL,
    normalized_alias TEXT NOT NULL,
    PRIMARY KEY (release_id, value_id, locale, normalized_alias),
    FOREIGN KEY (release_id, value_id)
      REFERENCES canonical_value(release_id, value_id)
    -- Intentionally permits the same alias for different values.
    -- Resolver reports ambiguity; publisher prevents silent last-write wins.
);
CREATE INDEX value_alias_lookup
  ON value_alias(release_id, locale, normalized_alias);
CREATE TABLE value_binding (
    release_id TEXT NOT NULL,
    binding_id TEXT NOT NULL,
    value_id TEXT NOT NULL,
    field_id TEXT NOT NULL,
    literal_type TEXT NOT NULL CHECK (literal_type IN
      ('string','integer','decimal','boolean','date','timestamp')),
    literal_json TEXT NOT NULL CHECK (json_valid(literal_json)),
    valid_from TEXT NOT NULL,
    valid_to TEXT,
    PRIMARY KEY (release_id, binding_id),
    FOREIGN KEY (release_id, value_id)
      REFERENCES canonical_value(release_id, value_id),
    FOREIGN KEY (release_id, field_id) REFERENCES field(release_id, field_id),
    CHECK (valid_to IS NULL OR valid_from < valid_to)
);
CREATE INDEX value_binding_lookup
  ON value_binding(release_id, value_id, field_id, valid_from);
CREATE TABLE relationship (
    release_id TEXT NOT NULL,
    relationship_id TEXT NOT NULL,
    source_entity_id TEXT NOT NULL,
    target_entity_id TEXT NOT NULL,
    source_role TEXT NOT NULL,
    target_role TEXT NOT NULL,
    key_pairs_json TEXT NOT NULL CHECK (json_valid(key_pairs_json)),
    cardinality_json TEXT NOT NULL CHECK (json_valid(cardinality_json)),
    required_predicates_json TEXT NOT NULL CHECK (json_valid(required_predicates_json)),
    identity_json TEXT NOT NULL CHECK (json_valid(identity_json)),
    temporal_json TEXT NOT NULL CHECK (json_valid(temporal_json)),
    PRIMARY KEY (release_id, relationship_id),
    FOREIGN KEY (release_id, relationship_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, source_entity_id) REFERENCES entity(release_id, entity_id),
    FOREIGN KEY (release_id, target_entity_id) REFERENCES entity(release_id, entity_id)
);
CREATE INDEX relationship_outgoing
  ON relationship(release_id, source_entity_id);
CREATE TABLE relationship_operation (
    release_id TEXT NOT NULL,
    operation_id TEXT NOT NULL,
    relationship_id TEXT NOT NULL,
    operator TEXT NOT NULL CHECK (operator IN
      ('exists','not_exists','enrich_left','expand_left','enrich_inner',
       'expand_inner','temporal_lookup','bridge_membership','bridge_allocate')),
    contract_json TEXT NOT NULL CHECK (json_valid(contract_json)),
    PRIMARY KEY (release_id, operation_id),
    FOREIGN KEY (release_id, relationship_id)
      REFERENCES relationship(release_id, relationship_id)
);
CREATE TABLE predicate (
    release_id TEXT NOT NULL,
    predicate_id TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    expression_json TEXT NOT NULL CHECK (json_valid(expression_json)),
    purpose TEXT NOT NULL CHECK (purpose IN
      ('business','source_restriction','security_restriction')),
    PRIMARY KEY (release_id, predicate_id),
    FOREIGN KEY (release_id, predicate_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, entity_id) REFERENCES entity(release_id, entity_id)
);
CREATE TABLE metric (
    release_id TEXT NOT NULL,
    metric_id TEXT NOT NULL,
    base_entity_id TEXT NOT NULL,
    definition_json TEXT NOT NULL CHECK (json_valid(definition_json)),
    PRIMARY KEY (release_id, metric_id),
    FOREIGN KEY (release_id, metric_id)
      REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, base_entity_id) REFERENCES entity(release_id, entity_id)
);
CREATE TABLE verified_example (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    example_id TEXT NOT NULL,
    question TEXT NOT NULL,
    access_policy_ref TEXT NOT NULL,
    semantic_query_json TEXT NOT NULL CHECK (json_valid(semantic_query_json)),
    reference_sql TEXT,
    fixture_id TEXT NOT NULL,
    expected_json TEXT NOT NULL CHECK (json_valid(expected_json)),
    review_status TEXT NOT NULL CHECK (review_status IN ('draft','approved','rejected')),
    reviewer TEXT,
    PRIMARY KEY (release_id, example_id)
);
CREATE TABLE assertion (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    assertion_id TEXT NOT NULL,
    subject_id TEXT NOT NULL,
    requirement_json TEXT NOT NULL CHECK (json_valid(requirement_json)),
    evidence_json TEXT NOT NULL CHECK (json_valid(evidence_json)),
    valid_until TEXT,
    failure_action_json TEXT NOT NULL CHECK (json_valid(failure_action_json)),
    PRIMARY KEY (release_id, assertion_id)
    -- subject may be an object, an operation, or a source identity namespace;
    -- publisher resolves the typed subject in requirement_json.
);

-- Domain and context model. Dataset membership may span several domains.
CREATE TABLE business_domain (
    release_id TEXT NOT NULL,
    domain_id TEXT NOT NULL,
    routing_summary TEXT NOT NULL,
    vocabulary_json TEXT NOT NULL CHECK (json_valid(vocabulary_json)),
    coverage_json TEXT NOT NULL CHECK (json_valid(coverage_json)),
    steward TEXT NOT NULL,
    PRIMARY KEY (release_id, domain_id),
    FOREIGN KEY (release_id, domain_id)
      REFERENCES catalog_object(release_id, object_id)
);
CREATE TABLE domain_membership (
    release_id TEXT NOT NULL,
    domain_id TEXT NOT NULL,
    object_id TEXT NOT NULL,
    membership_role TEXT NOT NULL,
    PRIMARY KEY (release_id, domain_id, object_id),
    FOREIGN KEY (release_id, domain_id) REFERENCES business_domain(release_id, domain_id),
    FOREIGN KEY (release_id, object_id) REFERENCES catalog_object(release_id, object_id)
);
CREATE TABLE semantic_concept (
    release_id TEXT NOT NULL,
    concept_id TEXT NOT NULL,
    definition_json TEXT NOT NULL CHECK (json_valid(definition_json)),
    PRIMARY KEY (release_id, concept_id),
    FOREIGN KEY (release_id, concept_id) REFERENCES catalog_object(release_id, object_id)
);
CREATE TABLE semantic_edge (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    edge_id TEXT NOT NULL,
    from_object_id TEXT NOT NULL,
    to_object_id TEXT NOT NULL,
    edge_kind TEXT NOT NULL CHECK (edge_kind IN
      ('depends_on','lineage','concept_association','equivalence','taxonomy')),
    review_status TEXT NOT NULL CHECK (review_status IN ('proposed','approved')),
    properties_json TEXT NOT NULL CHECK (json_valid(properties_json)),
    PRIMARY KEY (release_id, edge_id),
    FOREIGN KEY (release_id, from_object_id) REFERENCES catalog_object(release_id, object_id),
    FOREIGN KEY (release_id, to_object_id) REFERENCES catalog_object(release_id, object_id)
    -- These edges never authorize an executable SQL relationship by themselves.
);
CREATE INDEX semantic_edge_outgoing ON semantic_edge(release_id, from_object_id, edge_kind);
CREATE INDEX semantic_edge_incoming ON semantic_edge(release_id, to_object_id, edge_kind);
CREATE TABLE query_template (
    release_id TEXT NOT NULL,
    template_id TEXT NOT NULL,
    parameter_schema_json TEXT NOT NULL CHECK (json_valid(parameter_schema_json)),
    plan_json TEXT NOT NULL CHECK (json_valid(plan_json)),
    capability_requirements_json TEXT NOT NULL CHECK (json_valid(capability_requirements_json)),
    PRIMARY KEY (release_id, template_id),
    FOREIGN KEY (release_id, template_id) REFERENCES catalog_object(release_id, object_id)
);
CREATE TABLE capability (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    capability_id TEXT NOT NULL,
    operator_name TEXT NOT NULL,
    operator_version INTEGER NOT NULL CHECK (operator_version > 0),
    dialect TEXT NOT NULL,
    schema_json TEXT NOT NULL CHECK (json_valid(schema_json)),
    requirements_json TEXT NOT NULL CHECK (json_valid(requirements_json)),
    PRIMARY KEY (release_id, capability_id)
);
CREATE TABLE domain_capability (
    release_id TEXT NOT NULL,
    domain_id TEXT NOT NULL,
    capability_id TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('disabled','evaluation','enabled')),
    evidence_json TEXT NOT NULL CHECK (json_valid(evidence_json)),
    PRIMARY KEY (release_id, domain_id, capability_id),
    FOREIGN KEY (release_id, domain_id) REFERENCES business_domain(release_id, domain_id),
    FOREIGN KEY (release_id, capability_id) REFERENCES capability(release_id, capability_id)
);

-- Selected retrieval configuration is semantic-release metadata, not vectors.
-- IDs resolve server-managed configuration; no secrets or arbitrary filesystem paths.
-- A search projection bundles vector, lexical, document-ID and reranker components.
CREATE TABLE retrieval_profile (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    profile_id TEXT NOT NULL,
    vector_backend TEXT NOT NULL CHECK (vector_backend IN
      ('numpy','chroma','faiss','azure_ai_search')),
    lexical_backend TEXT NOT NULL CHECK (lexical_backend IN
      ('sqlite_fts5','bm25','azure_ai_search')),
    embedding_config_ref TEXT NOT NULL,
    embedding_dimensions INTEGER NOT NULL CHECK (embedding_dimensions > 0),
    distance_metric TEXT NOT NULL CHECK (distance_metric IN ('cosine','dot','l2')),
    normalization_json TEXT NOT NULL CHECK (json_valid(normalization_json)),
    fusion_json TEXT NOT NULL CHECK (json_valid(fusion_json)),
    reranker_config_json TEXT NOT NULL CHECK (json_valid(reranker_config_json)),
    security_filter_contract_json TEXT NOT NULL CHECK (json_valid(security_filter_contract_json)),
    backend_config_json TEXT NOT NULL CHECK (json_valid(backend_config_json)),
    configuration_hash TEXT NOT NULL,
    PRIMARY KEY (release_id, profile_id)
    -- Publisher validates supported combinations, model/dimension/metric agreement,
    -- current-policy filtering capabilities, and configuration_hash canonicalization.
);

-- Authority control tables: populated in the durable SQLite authority by default.
-- Their rows are NOT copied into the immutable semantic snapshot/RAM reader.
-- Snapshot checksums/manifests live in the authority and external manifest.
-- This avoids embedding a file's own checksum inside the checksummed file.
CREATE TABLE projection_artifact (
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    projection_id TEXT NOT NULL,
    projection_kind TEXT NOT NULL CHECK (projection_kind IN
      ('sqlite','search','graph','examples','evaluation')),
    state TEXT NOT NULL CHECK (state IN ('building','ready','failed','retired')),
    locator TEXT NOT NULL,
    content_hash TEXT,
    retrieval_profile_id TEXT,
    configuration_json TEXT NOT NULL CHECK (json_valid(configuration_json)),
    PRIMARY KEY (release_id, projection_id),
    FOREIGN KEY (release_id, retrieval_profile_id)
      REFERENCES retrieval_profile(release_id, profile_id),
    CHECK ((projection_kind = 'search' AND retrieval_profile_id IS NOT NULL)
        OR (projection_kind <> 'search' AND retrieval_profile_id IS NULL)),
    CHECK (state <> 'ready' OR content_hash IS NOT NULL)
);
CREATE TABLE release_manifest (
    manifest_id TEXT NOT NULL PRIMARY KEY,
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    manifest_version INTEGER NOT NULL CHECK (manifest_version > 0),
    snapshot_projection_id TEXT NOT NULL,
    search_projection_id TEXT NOT NULL,
    graph_projection_id TEXT NOT NULL,
    retrieval_profile_id TEXT NOT NULL,
    application_config_json TEXT NOT NULL CHECK (json_valid(application_config_json)),
    manifest_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    UNIQUE (release_id, manifest_id),
    FOREIGN KEY (release_id, retrieval_profile_id)
      REFERENCES retrieval_profile(release_id, profile_id),
    FOREIGN KEY (release_id, snapshot_projection_id)
      REFERENCES projection_artifact(release_id, projection_id),
    FOREIGN KEY (release_id, search_projection_id)
      REFERENCES projection_artifact(release_id, projection_id),
    FOREIGN KEY (release_id, graph_projection_id)
      REFERENCES projection_artifact(release_id, projection_id)
    -- Publisher checks kinds/readiness, matching search profile, content,
    -- approved candidate revision and application compatibility before activation.
);
CREATE TABLE active_manifest (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    manifest_id TEXT NOT NULL REFERENCES release_manifest(manifest_id)
    -- Runtime uses the authority's active pointer, then pins a local snapshot.
);

-- Authority-only transactional outbox. Insert a publication event in the same
-- transaction as its release state transition. Consumers must be idempotent.
-- Rows stay in the authority; they are excluded from snapshots and RAM readers.
CREATE TABLE publication_outbox (
    event_id TEXT NOT NULL PRIMARY KEY,
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    topic TEXT NOT NULL,
    idempotency_key TEXT NOT NULL UNIQUE,
    payload_json TEXT NOT NULL CHECK (json_valid(payload_json)),
    created_at TEXT NOT NULL,
    delivered_at TEXT,
    attempt_count INTEGER NOT NULL DEFAULT 0 CHECK (attempt_count >= 0)
);
CREATE INDEX publication_outbox_pending ON publication_outbox(created_at)
  WHERE delivered_at IS NULL;

-- Domain rollout is an authoring backlog, not a runtime access grant. Runtime
-- coverage is supplied by published business_domain/domain_capability + live policy.
CREATE TABLE domain_onboarding (
    domain_id TEXT NOT NULL PRIMARY KEY,
    display_name TEXT NOT NULL,
    stage TEXT NOT NULL CHECK (stage IN
      ('inventoried','modeling','evaluation','pilot','enabled','paused','retired')),
    owner_subject TEXT NOT NULL,
    priority INTEGER NOT NULL DEFAULT 0,
    scope_json TEXT NOT NULL CHECK (json_valid(scope_json)),
    acceptance_json TEXT NOT NULL CHECK (json_valid(acceptance_json)),
    last_release_id TEXT REFERENCES catalog_release(release_id),
    updated_at TEXT NOT NULL
);

-- Principals are authenticated external identity-provider subjects/groups.
-- No passwords or automatic administrator grants are stored here.
CREATE TABLE catalog_role_binding (
    binding_id TEXT NOT NULL PRIMARY KEY,
    principal_kind TEXT NOT NULL CHECK (principal_kind IN ('user','group')),
    principal_id TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('viewer','author','reviewer','publisher','admin')),
    scope_kind TEXT NOT NULL CHECK (scope_kind IN ('catalog','domain')),
    domain_id TEXT REFERENCES domain_onboarding(domain_id),
    granted_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    expires_at TEXT,
    revoked_at TEXT,
    CHECK ((scope_kind = 'catalog' AND domain_id IS NULL)
        OR (scope_kind = 'domain' AND domain_id IS NOT NULL))
);
CREATE INDEX catalog_role_principal ON catalog_role_binding(principal_kind, principal_id);

-- Each change set owns a complete draft cloned from a pinned base manifest.
-- Only its authorized scoped changes may differ; publication cannot drop changes
-- from another domain that has since published. Stale bases require rebase/review.
CREATE TABLE catalog_change_set (
    change_set_id TEXT NOT NULL PRIMARY KEY,
    draft_release_id TEXT NOT NULL UNIQUE REFERENCES catalog_release(release_id),
    base_manifest_id TEXT REFERENCES release_manifest(manifest_id),
    scope_kind TEXT NOT NULL CHECK (scope_kind IN ('catalog','domain')),
    domain_id TEXT REFERENCES domain_onboarding(domain_id),
    title TEXT NOT NULL,
    summary TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN
      ('draft','submitted','changes_requested','approved','rejected','published','abandoned')),
    created_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    submitted_revision INTEGER CHECK (submitted_revision >= 0),
    submitted_content_hash TEXT,
    CHECK ((scope_kind = 'catalog' AND domain_id IS NULL)
        OR (scope_kind = 'domain' AND domain_id IS NOT NULL)),
    CHECK (status NOT IN ('submitted','approved','published') OR
           (submitted_revision IS NOT NULL AND submitted_content_hash IS NOT NULL))
);

-- Long-running validation/evaluation jobs execute outside metadata transactions.
-- Gates bind to exact release/revision/digest; scope_json identifies domains,
-- capabilities, dependency closure, fixtures and projection/profile versions.
CREATE TABLE evaluation_run (
    run_id TEXT NOT NULL PRIMARY KEY,
    release_id TEXT NOT NULL REFERENCES catalog_release(release_id),
    edit_revision INTEGER NOT NULL CHECK (edit_revision >= 0),
    content_hash TEXT NOT NULL,
    suite_version TEXT NOT NULL,
    scope_json TEXT NOT NULL CHECK (json_valid(scope_json)),
    status TEXT NOT NULL CHECK (status IN ('queued','running','passed','failed','cancelled')),
    requested_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    completed_at TEXT,
    report_locator TEXT,
    report_hash TEXT,
    metrics_json TEXT NOT NULL CHECK (json_valid(metrics_json)),
    CHECK (status <> 'passed' OR
           (completed_at IS NOT NULL AND report_locator IS NOT NULL AND report_hash IS NOT NULL))
);
CREATE INDEX evaluation_release_revision ON evaluation_run(release_id, edit_revision);

CREATE TABLE catalog_review (
    review_id TEXT NOT NULL PRIMARY KEY,
    change_set_id TEXT NOT NULL REFERENCES catalog_change_set(change_set_id),
    reviewer_subject TEXT NOT NULL,
    decision TEXT NOT NULL CHECK (decision IN ('approve','request_changes','reject')),
    reviewed_revision INTEGER NOT NULL CHECK (reviewed_revision >= 0),
    reviewed_content_hash TEXT NOT NULL,
    evaluation_run_id TEXT REFERENCES evaluation_run(run_id),
    rationale TEXT NOT NULL,
    created_at TEXT NOT NULL
    -- Service checks current reviewer scope, separation of duties and matching
    -- release/revision/digest. An FK alone does not prove evaluation validity.
);

CREATE TABLE catalog_audit_event (
    event_id TEXT NOT NULL PRIMARY KEY,
    actor_subject TEXT NOT NULL,
    event_kind TEXT NOT NULL,
    target_ref TEXT NOT NULL,
    release_id TEXT REFERENCES catalog_release(release_id),
    change_set_id TEXT REFERENCES catalog_change_set(change_set_id),
    correlation_id TEXT NOT NULL,
    created_at TEXT NOT NULL,
    before_hash TEXT,
    after_hash TEXT,
    details_json TEXT NOT NULL CHECK (json_valid(details_json))
    -- Append-only through CatalogService; commit with the associated mutation.
    -- Protect/ship audit records independently; do not place credentials here.
);
CREATE INDEX catalog_audit_target ON catalog_audit_event(target_ref, created_at);

-- Discovery is staged separately. Inventory can be broad; promotion is incremental.
-- No discovered asset automatically becomes a searchable/queriable runtime object.
CREATE TABLE discovery_run (
    discovery_run_id TEXT NOT NULL PRIMARY KEY,
    source_config_ref TEXT NOT NULL,
    connector_kind TEXT NOT NULL,
    scope_json TEXT NOT NULL CHECK (json_valid(scope_json)),
    source_fingerprint TEXT,
    status TEXT NOT NULL CHECK (status IN ('queued','running','completed','failed','cancelled')),
    requested_by TEXT NOT NULL,
    created_at TEXT NOT NULL,
    completed_at TEXT,
    report_locator TEXT
);
CREATE TABLE discovered_asset (
    discovery_run_id TEXT NOT NULL REFERENCES discovery_run(discovery_run_id),
    asset_id TEXT NOT NULL,
    asset_kind TEXT NOT NULL CHECK (asset_kind IN ('dataset','field','constraint','dependency')),
    physical_locator_json TEXT NOT NULL CHECK (json_valid(physical_locator_json)),
    observed_metadata_json TEXT NOT NULL CHECK (json_valid(observed_metadata_json)),
    suggestions_json TEXT CHECK (suggestions_json IS NULL OR json_valid(suggestions_json)),
    triage_status TEXT NOT NULL CHECK (triage_status IN ('unreviewed','selected','excluded','promoted')),
    proposed_domain_id TEXT REFERENCES domain_onboarding(domain_id),
    change_set_id TEXT REFERENCES catalog_change_set(change_set_id),
    promotion_refs_json TEXT CHECK (promotion_refs_json IS NULL OR json_valid(promotion_refs_json)),
    PRIMARY KEY (discovery_run_id, asset_id),
    CHECK (triage_status <> 'promoted' OR
           (change_set_id IS NOT NULL AND promotion_refs_json IS NOT NULL))
);
CREATE INDEX discovered_asset_triage ON discovered_asset(proposed_domain_id, triage_status);
