"""Exercise real runtime completions with deterministic, network-free models."""

from asyncio import CancelledError, sleep
from collections.abc import AsyncIterator
from json import loads

from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.trace import StatusCode
from pytest import importorskip, mark, raises

from observability_ai import ContentCapturePolicy, LangfuseSettings, Telemetry
from observability_ai.adapters import model_runtime_observer
from observability_ai.evaluation import (
    JudgeResponseError,
    JudgeRubric,
    ModelRuntimeJudge,
)

importorskip("model_runtime", reason="requires observe-eval-ai[model-runtime]")

from model_runtime import (  # noqa: E402
    Message,
    ModelCapabilities,
    ModelRequest,
    ModelResponse,
    ModelRouter,
    ModelRuntime,
    ProviderUnavailableError,
    RetryPolicy,
    StreamEvent,
)


class _JudgeModel:
    capabilities = ModelCapabilities()

    def __init__(self, response: str | BaseException) -> None:
        self.response = response
        self.requests: list[tuple[str, ModelRequest]] = []

    async def complete(self, model_id: str, request: ModelRequest) -> ModelResponse:
        self.requests.append((model_id, request))
        await sleep(0)
        if isinstance(self.response, BaseException):
            raise self.response
        return ModelResponse(Message.assistant(self.response))

    async def stream(
        self, model_id: str, request: ModelRequest
    ) -> AsyncIterator[StreamEvent]:
        raise NotImplementedError
        yield


async def test_judge_request_result_and_nested_runtime_span(
    otel: tuple[Telemetry, InMemorySpanExporter],
) -> None:
    """Use the configured route and parent runtime generations under evaluator spans."""
    telemetry, exporter = otel
    model = _JudgeModel('{"score": 0.8, "reasoning": "Matches most requirements"}')
    runtime = ModelRuntime(
        ModelRouter({"judge": (model, "test-model")}),
        observer=model_runtime_observer(telemetry, provider_name="test"),
    )
    judge = ModelRuntimeJudge(
        runtime,
        "judge",
        JudgeRubric("quality", "Check correctness"),
        telemetry=telemetry,
        prompt="Consider the supplied reference.",
    )
    with telemetry.agent("agent"):
        result = await judge(
            input="question",
            output="answer",
            expected_output="reference",
            metadata={"category": "test"},
        )
    assert (result.name, result.value, result.comment) == (
        "quality",
        0.8,
        "Matches most requirements",
    )
    model_id, request = model.requests[0]
    assert model_id == "test-model"
    text = request.messages[0].text
    assert "Check correctness" in text and "Consider the supplied reference." in text
    assert loads(text.rsplit("\n\n", 1)[-1]) == {
        "input": "question",
        "output": "answer",
        "expected_output": "reference",
        "metadata": {"category": "test"},
    }
    generation, evaluation, parent = exporter.get_finished_spans()
    assert generation.parent == evaluation.context
    assert evaluation.parent == parent.context
    assert evaluation.name == "quality"
    assert evaluation.attributes is not None
    assert evaluation.attributes["langfuse.observation.type"] == "evaluator"
    assert "langfuse.observation.input" not in evaluation.attributes
    assert "langfuse.observation.output" not in evaluation.attributes


async def test_categorical_judge_without_telemetry() -> None:
    """Return a configured category with no telemetry requirement."""
    model = _JudgeModel('{"score": "pass", "reasoning": "Correct"}')
    judge = ModelRuntimeJudge(
        ModelRuntime(ModelRouter({"judge": (model, "model")})),
        "judge",
        JudgeRubric("quality", "Check correctness", "CATEGORICAL", ["pass", "fail"]),
    )
    result = await judge(output="answer")
    assert (result.value, result.data_type) == ("pass", "CATEGORICAL")
    assert '"pass", "fail"' in model.requests[0][1].messages[0].text


@mark.parametrize(
    "response",
    [
        "",
        "not JSON",
        '```json\n{"score": 1, "reasoning": "ok"}\n```',
        "[]",
        '{"score": 1}',
        '{"score": 1, "reasoning": "ok", "extra": 1}',
        '{"score": true, "reasoning": "ok"}',
        '{"score": "1", "reasoning": "ok"}',
        '{"score": -0.1, "reasoning": "ok"}',
        '{"score": 1.1, "reasoning": "ok"}',
        '{"score": NaN, "reasoning": "ok"}',
        '{"score": 1e999, "reasoning": "ok"}',
        '{"score": 1, "reasoning": " "}',
        '{"score": 1, "reasoning": null}',
        '{"score": 0, "score": 1, "reasoning": "ok"}',
    ],
)
async def test_malformed_responses_raise_and_record_errors(
    otel: tuple[Telemetry, InMemorySpanExporter],
    response: str,
) -> None:
    """Reject prose, extra keys, invalid scores, and duplicate keys without retries."""
    telemetry, exporter = otel
    model = _JudgeModel(response)
    judge = ModelRuntimeJudge(
        ModelRuntime(ModelRouter({"judge": (model, "model")})),
        "judge",
        JudgeRubric("quality", "Check correctness"),
        telemetry=telemetry,
    )
    with raises(JudgeResponseError) as caught:
        await judge(output="answer")
    assert caught.value.__cause__ is not None
    assert len(model.requests) == 1
    (evaluation,) = exporter.get_finished_spans()
    assert evaluation.status.status_code == StatusCode.ERROR
    assert any(event.name == "exception" for event in evaluation.events)


async def test_unknown_category_is_rejected() -> None:
    """Category scores must match labels exactly, including case."""
    model = _JudgeModel('{"score": "PASS", "reasoning": "Correct"}')
    judge = ModelRuntimeJudge(
        ModelRuntime(ModelRouter({"judge": (model, "model")})),
        "judge",
        JudgeRubric("quality", "Check correctness", "CATEGORICAL", ["pass", "fail"]),
    )
    with raises(JudgeResponseError):
        await judge(output="answer")


async def test_capture_policy_redacts_judge_payloads(
    settings: LangfuseSettings,
) -> None:
    """The evaluator span uses the facade's policy for both request and result."""
    exporter = InMemorySpanExporter()
    with Telemetry(
        settings,
        service_name="test",
        service_version="1",
        span_processor=SimpleSpanProcessor(exporter),
        content_capture=ContentCapturePolicy(
            enabled=True, redactor=lambda _: "redacted"
        ),
    ) as telemetry:
        model = _JudgeModel('{"score": 1, "reasoning": "private reasoning"}')
        judge = ModelRuntimeJudge(
            ModelRuntime(ModelRouter({"judge": (model, "model")})),
            "judge",
            JudgeRubric("quality", "Check correctness"),
            telemetry=telemetry,
        )
        await judge(output="private answer")
    (evaluation,) = exporter.get_finished_spans()
    assert evaluation.attributes is not None
    assert evaluation.attributes["langfuse.observation.input"] == '"redacted"'
    assert evaluation.attributes["langfuse.observation.output"] == '"redacted"'
    assert "private answer" in model.requests[0][1].messages[0].text


@mark.parametrize(
    "failure", [ProviderUnavailableError("unavailable"), CancelledError()]
)
async def test_runtime_errors_and_cancellation_propagate(
    otel: tuple[Telemetry, InMemorySpanExporter],
    failure: BaseException,
) -> None:
    """Leave retry policy to the runtime and always close evaluator spans."""
    telemetry, exporter = otel
    model = _JudgeModel(failure)
    judge = ModelRuntimeJudge(
        ModelRuntime(
            ModelRouter({"judge": (model, "model")}),
            retry_policy=RetryPolicy(max_attempts=1),
        ),
        "judge",
        JudgeRubric("quality", "Check correctness"),
        telemetry=telemetry,
    )
    with raises(type(failure)) as caught:
        await judge(output="answer")
    assert caught.value is failure
    assert len(exporter.get_finished_spans()) == 1


async def test_non_json_application_data_never_calls_runtime() -> None:
    """Do not silently coerce unsupported evaluation values into model prompts."""
    model = _JudgeModel('{"score": 1, "reasoning": "ok"}')
    judge = ModelRuntimeJudge(
        ModelRuntime(ModelRouter({"judge": (model, "model")})),
        "judge",
        JudgeRubric("quality", "Check correctness"),
    )
    with raises(TypeError):
        await judge(output=object())
    with raises(ValueError):
        await judge(output=float("nan"))
    assert model.requests == []
