from unittest.mock import MagicMock

import pytest
from data_mcp_core.auth import AuthProfile
from data_mcp_core.stores import StoreConfig
from fs_mcp_server.config import FSConfig
from fs_mcp_server.server import FSService


@pytest.mark.parametrize(
    "name,arguments,flag",
    [
        ("set_acl", {"acl": "user::rwx"}, "allow_manage"),
        ("set_metadata", {"metadata": {"k": "v"}}, "allow_write"),
        ("undelete_path", {"deletion_id": "id"}, "allow_write"),
        ("list_deleted_paths", {}, "allow_manage"),
        ("generate_sas", {}, "allow_sas"),
    ],
)
def test_adls_mutations_and_sas_are_guarded(name, arguments, flag):
    service = FSService(
        FSConfig(
            stores={
                "lake": StoreConfig(
                    protocol="abfss", account_name="lake", container="raw", root="sales"
                )
            }
        )
    )
    with pytest.raises(PermissionError, match=flag):
        getattr(service, name)("lake", "file", **arguments)


def test_adls_acl_metadata_rename_and_sas(monkeypatch):
    from fs_mcp_server import adls

    store = StoreConfig(
        protocol="abfss",
        account_name="lake",
        container="raw",
        root="sales",
        auth=AuthProfile(mode="account_key", account_key="a2V5"),
        allow_write=True,
        allow_delete=True,
        allow_manage=True,
        allow_sas=True,
    )
    service = FSService(FSConfig(stores={"lake": store}))
    client = MagicMock()
    client.__enter__.return_value = client
    client.get_access_control.return_value = {"acl": "user::rwx"}
    client.get_file_properties.return_value = {"metadata": {"k": "v"}}
    client.set_metadata.return_value = {"etag": "etag"}
    client.set_access_control.return_value = {"etag": "etag"}
    monkeypatch.setattr(adls, "path_client", lambda resolved, directory=False: client)
    assert service.get_acl("lake", "file")["acl"] == "user::rwx"
    assert service.get_properties("lake", "file")["metadata"] == {"k": "v"}
    service.set_acl("lake", "file", "user::r--")
    client.set_access_control.assert_called_with(acl="user::r--")
    service.set_metadata("lake", "file", {"k": "new"})
    client.set_metadata.assert_called_with({"k": "new"})
    sas = service.generate_sas("lake", "file")
    assert "sp=r" in sas["sas"] and "sig=" in sas["sas"]
    service.config.stores["lake"].allow_write = False
    with pytest.raises(PermissionError):
        service.generate_sas("lake", "file", permissions="w")
